from .core.entity_resolver import EntityResolver
from .core.analyzer import AdverseMediaAnalyzer
from .core.scraper import WebScraper
from .core.processor import FileProcessor
from .config.config import Config

__version__ = "0.1.0"