import sys
import logging
import argparse
from rich.console import Console
from rich.table import Table
from rich import print as rprint
from .core.source_registry import SourceRegistry
from .media_screening_engine import orchestrate_screening_cycle

console = Console()

# Defined globally so we can update the version in one place
VERSION = "v0.1.0"

def print_banner():
    """Prints the system header."""
    table = Table(show_header=False, box=None)
    table.add_row(r"[bold cyan]    ___  __  ___  ___ [/bold cyan]")
    table.add_row(r"[bold cyan]   / _ |/  |/  / / _ \\[/bold cyan]")
    table.add_row(r"[bold cyan]  / __ / /|_/ / / ___/[/bold cyan]")
    table.add_row(r"[bold cyan] /_/ |_\/  /_/ /_/    [/bold cyan]")
    table.add_row(f"[bold white] Adverse Media Parser {VERSION}[/bold white]")
    console.print(table)
    # Only print separator if NOT running the version command (optional preference)
    # console.print(" [dim]------------------------------------------------[/dim]")

def list_sources():
    """Prints the table of all available sources."""
    print_banner()
    console.print(" [dim]------------------------------------------------[/dim]")
    
    table = Table(title="Registered Data Scrapers", box=None, show_lines=False)
    
    table.add_column("Key", style="cyan", no_wrap=True)
    table.add_column("Region", style="magenta")
    table.add_column("Provider / Source Name", style="white")
    table.add_column("Type", style="green")
    table.add_column("Status", style="bold green", justify="right")

    for key, data in SourceRegistry.get_all().items():
        table.add_row(
            key,
            data['region'],
            f"{data['provider']} - {data['name']}",
            data['type'],
            "● Online"
        )
    
    console.print(table)

def main():
    parser = argparse.ArgumentParser(description="Adverse Media Parser CLI")
    
    # --- NEW: Add the version flag here ---
    parser.add_argument(
        "--version", 
        action="store_true", 
        help="Show version banner and exit"
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Command: list
    subparsers.add_parser("list", help="Show all available data sources")

    # Command: run
    run_parser = subparsers.add_parser("run", help="Run the pipeline")
    run_parser.add_argument("source", nargs="?", default="all", help="Source Key (e.g., 'eu_consolidated') or 'all'")
    run_parser.add_argument("--dry-run", action="store_true", help="Run without saving")
    run_parser.add_argument("-v", "--verbose", action="store_true", help="Enable debug logs")

    args = parser.parse_args()

    # --- NEW: Handle Version Flag ---
    if args.version:
        print_banner()
        sys.exit(0)

    # Default to help if no command provided
    if not args.command:
        parser.print_help()
        return

    # 1. Handle LIST command
    if args.command == "list":
        list_sources()
        return

    # 2. Handle RUN command
    if args.command == "run":
        # Setup Logging
        log_level = logging.DEBUG if args.verbose else logging.INFO
        logging.basicConfig(level=log_level, format="%(asctime)s | %(levelname)s | %(message)s")
        
        target_keys = []
        if args.source.lower() == "all":
            target_keys = SourceRegistry.list_keys()
            console.print(f"[bold green]🚀 Launching ALL {len(target_keys)} scrapers...[/bold green]")
        else:
            try:
                # Validate key exists
                SourceRegistry.get_source(args.source)
                target_keys = [args.source]
                console.print(f"[bold green]🚀 Launching single scraper: {args.source}[/bold green]")
            except ValueError:
                console.print(f"[bold red]❌ Error: Source '{args.source}' not found.[/bold red]")
                console.print("Run [yellow]amp-pipeline list[/yellow] to see valid keys.")
                sys.exit(1)

        # Call the Engine with the specific list of keys
        orchestrate_screening_cycle(target_keys=target_keys, dry_run=args.dry_run)

if __name__ == "__main__":
    main()