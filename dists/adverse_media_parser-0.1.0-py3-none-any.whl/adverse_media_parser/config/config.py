import os
import yaml
from pathlib import Path
from dotenv import load_dotenv

class Config:
    def __init__(self):
        # 1. Determine Paths for New Package Structure
        # This file is located at: src/adverse_media_parser/config/config.py
        
        # Current directory (where config.yaml and prompts.yaml now live)
        self.config_dir = Path(__file__).resolve().parent
        
        # Project Root is 3 levels up from config_dir: 
        # config/ -> adverse_media_parser/ -> src/ -> [ROOT]
        self.base_dir = self.config_dir.parent.parent.parent
        
        # Load env from Project Root
        load_dotenv(self.base_dir / ".env")
        
        # 2. Data Paths (Kept at Project Root for persistence)
        self.data_dir = self.base_dir / "data"
        self.raw_dir = self.data_dir / "raw"
        self.processed_dir = self.data_dir / "processed"
        self.results_dir = self.data_dir / "results"
        self.final_dir = self.data_dir / "final"
        self.schema_dir = self.data_dir / "schema"
        
        # File specific paths
        self.failure_log_path = self.results_dir / "failures.json"
        
        # 3. Config Paths (Now located inside the package)
        self.config_yaml_path = self.config_dir / "config.yaml"
        self.prompts_path = self.config_dir / "prompts.yaml"
        
        # 4. Load YAML
        self.yaml_config = self._load_yaml_config()

        # 5. LLM Settings
        llm_conf = self.yaml_config.get("llm") or {}
        self.llm_provider = llm_conf.get("provider", "openai/gpt-oss-120b")
        self.analysis_concurrency = int(llm_conf.get("concurrency") or 1)
        self.vllm_base_url = os.getenv("VLLM_BASE_URL") or llm_conf.get("base_url") or "http://localhost:8000/v1"
        self.api_key = llm_conf.get("api_key", "EMPTY")
        
        # 6. Text Processing Defaults
        text_proc = self.yaml_config.get("text_processing") or {}
        self.chunk_size = int(text_proc.get("chunk_size") or 2000)
        self.chunk_overlap = int(text_proc.get("chunk_overlap") or 200)

        # 7. Scraping Config
        scrape_conf = self.yaml_config.get("scraping") or {}
        self.user_agent = scrape_conf.get("user_agent", "Mozilla/5.0...")
        
        # Tier 1 (Fast Lane)
        fast = self.yaml_config.get("fast_scrape") or {} # Changed 'fast_lane' to match your YAML
        self.request_timeout = int(fast.get("request_timeout") or 30)
        self.max_retries = int(fast.get("max_retries") or 3)
        self.retry_delay = int(fast.get("retry_delay") or 2)

        # Tier 2 (Advanced Lane)
        adv = self.yaml_config.get("advanced_scrape") or {}
        self.crawl_max_depth = int(adv.get("max_depth") or 20) # Added default to prevent error if missing
        self.crawl_max_pages = int(adv.get("max_pages") or 300)

        # Tier 3 (Pro Lane)
        pro = self.yaml_config.get("pro_scrape") or {} # Changed 'pro_lane' to match your YAML
        self.browser_wait_timeout = int(pro.get("browser_wait_timeout") or 60)
        
        # 8. Logic
        self.risk_keywords = self.yaml_config.get("risk_keywords") or []

        self._create_folders()

    def _load_yaml_config(self):
        if not self.config_yaml_path.exists(): 
            return {}
        try:
            with open(self.config_yaml_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f) or {}
        except: return {}

    def _create_folders(self):
        for folder in [self.raw_dir, self.processed_dir,
                       self.results_dir, self.final_dir,
                       self.schema_dir]:
            os.makedirs(folder, exist_ok=True)
