import tldextract
from typing import Dict, List, Any

# ==========================================
# CRAWLER KNOWLEDGE BASE
# ==========================================
# Key: Domain (e.g., 'eacc.go.ke')
# Value: Configuration Dictionary

CRAWLER_RULES = {
    "eacc.go.ke": {
        "allowed_domains": ["eacc.go.ke"],
        "blocked_domains": [
            "https://eacc.go.ke/en/default/careers",
            "https://eacc.go.ke/en/default/about-us",
            "https://eacc.go.ke/en/default/downloads-page/reports",
            "https://eacc.go.ke/en/default/Downloads"
        ],
        # Regex pattern to match specific news/article structures
        "url_patterns": [
            r"^https://eacc\.go\.ke/en/default/(?!document/|about-us|careers|downloads|contact-us|news-updates)[a-z0-9]+(?:-[a-z0-9]+)+/?$"
        ],
        "type_filter": ["text/html"],
        "headless": True,
        "delay":0
    },
    
    "fiscalia.gov.co": {
        "allowed_domains": ["fiscalia.gov.co"],
        "blocked_domains": [],
        # Pattern for 4-digit years (2024, 2025)
        "url_patterns": [
            r"*fiscalia.gov.co/colombia/en/[0-9][0-9][0-9][0-9]*"
        ],
        "type_filter": ["text/html"],
        "headless": True,
        "delay":0
    },
    
    "vtek.lt": {
        "allowed_domains": ["vtek.lt"],
        "blocked_domains": [],
        # Pattern for 4-digit years (2024, 2025)
        "url_patterns": [
            r"^https?://vtek\.lt/(?:[0-9]{4}|vtek_sprendimai)/.*"
        ],
        "type_filter": ["text/html"],
        "headless": False,
        "delay":15
    },
    
    "fi.se": {
        "allowed_domains": ["fi.se"],
        "blocked_domains": [],
        # Pattern for 4-digit years (2024, 2025)
        "url_patterns": [
            "*fi.se/en/our-registers/investor-alerts/*"
        ],
        "type_filter": ["text/html"],
        "headless": True,
        "delay":0
    },
    
    "fca.org.uk": {
        "allowed_domains": ["fca.org.uk"],
        "blocked_domains": [],
        # Pattern for 4-digit years (2024, 2025)
        "url_patterns": [
            "*fca.org.uk/news/warnings*"
        ],
        "type_filter": ["text/html"],
        "headless": True,
        "delay":0
    }
    
    
}

# ==========================================
# HELPER FUNCTION
# ==========================================

def get_crawler_config(url: str) -> Dict[str, Any]:
    """
    Extracts the domain from the URL and returns the specific config.
    Returns a default config if the domain is not found in the Knowledge Base.
    """
    # Extract domain (e.g., 'https://sub.eacc.go.ke/page' -> 'eacc.go.ke')
    ext = tldextract.extract(url)
    domain_key = f"{ext.domain}.{ext.suffix}"
    
    # Default Configuration (Fallback)
    default_config = {
        "allowed_domains": [],
        "blocked_domains": [],
        "url_patterns": [], # Empty means accept all (or define a safe default)
        "type_filter": ["text/html"]
    }
    return CRAWLER_RULES.get(domain_key, default_config)


