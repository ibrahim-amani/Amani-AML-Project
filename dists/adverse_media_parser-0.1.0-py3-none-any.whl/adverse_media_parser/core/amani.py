import gzip
import json
import os
import shutil
from datetime import datetime, timedelta

import requests

from .elasticsearch_client import ElasticsearchClient
from .utils import convert_turkish_characters, parse_date_of_birth, background_wait
from .base_provider import BaseProvider


class AmaniAI(BaseProvider):
    _all_data_url = None
    _update_data_url = None
    _auth_headers = None  
    _name = "AmaniAI"

    def __init__(self, config):
        super().__init__(config)

    def _parse_config(self, config: dict):
        self._all_data_url = config["all_data_url"]
        self._update_data_url = config["update_data_url"]
        self._auth_headers = config["auth_headers"]
        self._update_interval = config["update_interval"]

    def run(self, operation):
        """
        if providers data not exist in db, fetch all data and update data,
        if providers data exist in db and update interval is up, update data,
        """
        if operation == "update" and self._check_update_interval():
                self._update_data()
        elif operation == "insert":
                self._insert_data()
                self._update_data()
        else:
            print(f"Skipping {self._name} provider; no operation performed.")
            
    def _insert_data(self):
        """
        # check if file exist, if not download the whole file
            # check SHA, if same
                # resume download
            # else
                # remove existing file and start download from beginning
        # file not exist
            # download the file
        """
        print(f"Starting data insertion for provider: {self._name}")

        max_retries = 3
        attempt = 0
        wait_time = 300
        while attempt < max_retries:
            try:
                # This fetches the 'manifest' JSON
                response = requests.get(self._all_data_url, headers=self._auth_headers)
                response.raise_for_status()
                break
            except Exception as e:
                attempt += 1
                background_wait(wait_time)
                if max_retries <= attempt:
                    raise e

        body = response.json()

        # Ensure 'timestamp' exists if the API returned only ISO string
        if "timestamp" not in body:
            if "exported_at_iso" in body:
                try:
                    # Convert ISO string to unix timestamp (milliseconds)
                    dt = datetime.fromisoformat(body["exported_at_iso"].replace("Z", "+00:00"))
                    body["timestamp"] = int(dt.timestamp() * 1000)
                except ValueError:
                    body["timestamp"] = int(datetime.now().timestamp() * 1000)
            else:
                body["timestamp"] = int(datetime.now().timestamp() * 1000)
       
       
        sha256 = body.get("sha256")
        file_url = body.get("file")

        provider_data = ElasticsearchClient.get_by_id(
            self._name, index_name="providers"
        )
        provider_found = provider_data["found"]
        file_exists = os.path.isfile(f"data/{self._name}.jsonl.gz")

        if file_exists:
            if provider_found:
                stored_sha256 = provider_data["_source"].get("sha256")
                if sha256 != stored_sha256:
                    os.remove(f"data/{self._name}.jsonl.gz")
            else:
                os.remove(f"data/{self._name}.jsonl.gz")

        self._download_file(file_url)
        ElasticsearchClient.save_bulk(actions=self.generate_actions())
        ElasticsearchClient.save(self._name, data=body, index_name="providers")

    def _download_file(self, file_url):
        max_retries = 3
        attempt = 0
        wait_time = 300
        try:
            file_size = os.path.getsize(f"data/{self._name}.jsonl.gz")
        except FileNotFoundError:
            file_size = 0

        while attempt < max_retries:
            try:
                
                response = requests.get(
                    file_url,
                    headers={"Range": f"bytes={file_size}-"},
                    stream=True,
                )
                
                response.raise_for_status()

                if not os.path.exists("data"):
                    os.makedirs("data")

                with open(f"data/{self._name}.jsonl.gz", "ab") as f:
                    shutil.copyfileobj(response.raw, f)
                break

            except requests.exceptions.HTTPError as e:
                if e.response.status_code == 416:
                    break
                else:
                    attempt += 1
                    background_wait(wait_time)
                    if max_retries <= attempt:
                        raise e

    def generate_actions(self, data: list = None):
        if data:
            for item in data:
                self._parse(item)
                yield item
        else:
            with gzip.open(f"data/{self._name}.jsonl.gz", "rb") as file:
                for line in file:
                    item = json.loads(line)
                    self._parse(item)
                    yield item


    def _parse(self, data):
        """
        Adapts the Golden Record structure to the Elasticsearch Schema.
        """
        # 1. Unwrap if nested in "data"
        profile = data.get("data", data)
        datasets = data.get("datasets", [])
        
        # ID is critical
        profile["_id"] = profile.get("resourceId") or profile.get("_id")

        # Ensure datasets are flattened
        profile["datasets"] = datasets

        # Search tokens (copy nameAliases if present)
        if "nameAliases" in profile:
            profile["nameTokens"] = profile["nameAliases"]
    

        # Update the dict reference (since we unwrapped it)
        data.clear()
        data.update(profile)

    def _update_data(self):
        """
        Get latest timestamp Acuris data updated, get delta data starting from that timestamp,
        group new profiles and save to elasticsearch, update latest timestamp to elasticsearch.
        """
        last_update_information = ElasticsearchClient.get_by_id(
            self._name, index_name="providers"
        )
        if not last_update_information["found"]:
            if os.path.isfile(f"data/{self._name}.jsonl.gz"):
                os.remove(f"data/{self._name}.jsonl.gz")
            self._insert_data()
            last_update_information = ElasticsearchClient.get_by_id(
                self._name, index_name="providers"
            )

        last_update_timestamp = last_update_information["_source"]["timestamp"]
        last_update_date = datetime.fromtimestamp(last_update_timestamp / 1000)

        if last_update_date < (datetime.now() - timedelta(days=31)):
            # If the last update date is older than 31 days, Acuris raises an error.
            if os.path.isfile(f"data/{self._name}.jsonl.gz"):
                os.remove(f"data/{self._name}.jsonl.gz")
            self._insert_data()
            last_update_information = ElasticsearchClient.get_by_id(
                self._name, index_name="providers"
            )
            last_update_timestamp = last_update_information["_source"]["timestamp"]

        profiles = []
        max_retries = 3
        attempt = 0
        wait_time = 300
        while attempt < max_retries:
            try:
                new_profiles, last_update_timestamp = self._get_update_batch(
                    last_update_timestamp
                )
                if not new_profiles:
                    break
                profiles.extend(new_profiles)
            except Exception as e:
                attempt += 1
                background_wait(wait_time)
                if max_retries <= attempt:
                    break

        if profiles:
            ElasticsearchClient.save_bulk(actions=self.generate_actions(profiles))

            ElasticsearchClient.update(
                self._name, {"timestamp": last_update_timestamp}, index_name="providers"
            )


    def _get_update_batch(self, timestamp):
        response = requests.get(
            f"{self._update_data_url}{timestamp}",
            headers=self._auth_headers,
        )
        response.raise_for_status()
        data = response.json()
        return data["profiles"], data["timestamp"]



if __name__ == "__main__":
    # 1. DEFINE CONFIG
    # This points to your local Python HTTP server
    config = {
        "all_data_url": "http://localhost:8000/amani_meta.json",
        "update_data_url": "http://localhost:8000/", 
        "auth_headers": {},
        "update_interval": 0  # Set to 0 to force run immediately for testing
    }

    print("Initializing AmaniAI Provider...")
    
    # 2. INSTANTIATE
    provider = AmaniAI(config)
    
    # 3. RUN (Use "insert" for the first run)
    print("Starting ingestion...")
    try:
        provider.run("insert")
        print("Success! Data ingestion complete.")
    except Exception as e:
        print(f"Error during execution: {e}")