import os
import json
import logging
import yaml
import time
import json_repair  # Essential for fixing broken JSON from LLMs
from functools import lru_cache
from typing import List, Dict, Any, Optional
import concurrent.futures # For handling concurrency
# --- LangChain Imports ---
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI 
from langchain_core.output_parsers import StrOutputParser
from langchain_text_splitters import RecursiveCharacterTextSplitter

class AdverseMediaAnalyzer:

    def __init__(self, config, reporter):
        self.config = config
        self.reporter = reporter
        self.logger = logging.getLogger("Analyzer")
        self._chain = None 

    @property
    def chain(self):
        """
        Lazy initialization of the LLM Chain.
        Returns:
            LangChain Runnable: The configured LLM pipeline.
        """
        if not self._chain:
            self.logger.info(f"Loading LLM: {self.config.llm_provider} at {self.config.vllm_base_url}")
            try:
                # Initialize Ollama connection
                # vLLM is OpenAI-Compatible
                model = ChatOpenAI(
                    model=self.config.llm_provider,
                    openai_api_base=self.config.vllm_base_url, # Maps to 'base_url' in config
                    openai_api_key="EMPTY",
                    temperature=0.0,
                    timeout=600 
                )
                # Create a chain that returns raw strings (we parse JSON manually later)
                self._chain = model | StrOutputParser()
            except Exception as e:
                self.logger.critical(f"Failed to initialize LLM: {e}")
                raise e
        return self._chain

    def analyze_file(self, processed_json_path: str) -> bool:
        """
        Main orchestrator for analyzing a single file.
        Uses ThreadPoolExecutor for parallel chunk processing.
        """
        try:
            # 1. Load Processed Data
            with open(processed_json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            filename_id = data.get('filename_id')
            content = data.get('content', '')
            source_url = data.get('source_url')
            metadata = data.get('metadata', {})
            self.logger.info(f"Starting Analysis: {filename_id}")
            # 2. Idempotency Check
            result_filename = os.path.splitext(filename_id)[0] + "_analysis.json"
            save_path = os.path.join(self.config.results_dir, result_filename)
            
            if os.path.exists(save_path):
                self.logger.info(f"Skipping {filename_id} - Analysis exists.")
                return True

            if not content:
                self.logger.warning(f"Skipping {filename_id} - Empty content.")
                return False

            # 3. Split Content 
            chunks = self._split_text(content)
            
            # Get concurrency from config
            max_workers = getattr(self.config, 'analysis_concurrency', 1)
            max_workers = min(max_workers, len(chunks))  # Avoid more workers than chunks
            self.logger.info(f"[{filename_id}] Analyzing {len(chunks)} chunks (Threads: {max_workers}).")
            
            self.reporter.track_analysis_chunk(len(chunks))

            # 4. Run Analysis Loop (PARALLEL)
            start_time = time.time()
            all_analyses = []
            
            # Force init chain before threading to avoid race conditions
            _ = self.chain 
            
            with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                # Submit all chunks to the pool
                future_to_index = {
                    executor.submit(self._invoke_chunk, chunk, metadata): i 
                    for i, chunk in enumerate(chunks)
                }
                
                # Collect results as they finish
                for future in concurrent.futures.as_completed(future_to_index):
                    i = future_to_index[future]
                    try:
                        chunk_result = future.result()
                        if chunk_result:
                            chunk_result['chunk_index'] = i
                            all_analyses.append(chunk_result)
                    except Exception as exc:
                        self.logger.error(f"Chunk {i} generated an exception: {exc}")

            # Sort by index to maintain document order logic
            all_analyses.sort(key=lambda x: x.get('chunk_index', 0))

            duration = time.time() - start_time
            
            # 5. Construct Final Output Object
            final_output = {
                "source_file": filename_id,
                "original_url": source_url,
                "metadata": metadata,
                "timings": {
                    "llm_analysis": self.reporter.format_duration(duration)
                },
                "total_chunks": len(chunks),
                "successful_chunks": len(all_analyses),
                "analyses": all_analyses
            }
            
            # 6. Save to Disk
            with open(save_path, 'w', encoding='utf-8') as f:
                json.dump(final_output, f, indent=4, ensure_ascii=False)
                
            self.logger.info(f"Saved Analysis: {save_path}")
            return True

        except Exception as e:
            self.logger.error(f"Analysis failed for {processed_json_path}: {e}")
            self.reporter.log_failure(processed_json_path, str(e), "analysis_crash")
            return False

    # --- Internal Methods ---
    def _invoke_chunk(self, text_chunk: str, metadata: Dict) -> Optional[Dict]:
        """
        Sends a single text chunk to the LLM and repairs the JSON output.
        """
        try:
            # Generate the full prompt with system instructions + text
            prompt = self._generate_prompt(text_chunk, metadata)
            
            # Send to Ollama
            response = self.chain.invoke(prompt)
            
            # Robust JSON parsing:
            # LLMs often forget closing brackets "}" or add trailing commas.
            # json_repair fixes these syntax errors automatically.
            return json_repair.loads(response)
            
        except Exception as e:
            self.logger.error(f"LLM Chunk Invoke Error: {e}")
            return None

    def _split_text(self, text: str) -> List[str]:
        """
        Splits text using configuration values loaded from config.yaml (via settings.py).
        """
        splitter = RecursiveCharacterTextSplitter(
            chunk_size=self.config.chunk_size,       # Loaded from YAML
            chunk_overlap=self.config.chunk_overlap, # Loaded from YAML
            length_function=len,
            # Priority separators: Paragraphs -> Sentences -> Words
            separators=["\n\n", "\n", " ", ""]
        )
        return splitter.split_text(text)

    def _generate_prompt(self, article_text: str, metadata: Dict) -> str:
        """
        Loads the prompt template from YAML and injects the article text.
        """
        current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        template_str = self._load_yaml_template()
        prompt_template = ChatPromptTemplate.from_template(template_str)
        return prompt_template.invoke({'article_text': article_text,
                                       'metadata': metadata,
                                       'current_time': current_time})

    @lru_cache(maxsize=1)
    def _load_yaml_template(self) -> str:
        """
        Loads the prompt template from disk.
        """
        path = os.path.join(self.config.prompts_path)
        
        if not os.path.exists(path):
            raise FileNotFoundError(f"Prompts file not found: {path}")
            
        with open(path, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
            
        # Return the specific key for the classifier
        return data.get("adverse_media_classifier", "")