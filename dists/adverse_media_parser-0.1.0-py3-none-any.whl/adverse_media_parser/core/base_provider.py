from abc import ABC, abstractmethod
from datetime import datetime, timedelta

from elasticsearch_client import ElasticsearchClient


class BaseProvider(ABC):
    _name = None
    _update_interval = None

    def __init__(self, config: dict, **kwargs):
        self._parse_config(config)

    @abstractmethod
    def _parse_config(self, config: dict):
        pass

    @abstractmethod
    def run(self, operation):
        pass

    @abstractmethod
    def generate_actions(self):
        pass

    def _check_update_interval(self):
        provider_data = ElasticsearchClient.get_by_id(
            self._name, index_name="providers"
        )

        if provider_data["found"]:
            last_updated = datetime.fromtimestamp(
                provider_data["_source"]["timestamp"] / 1000
            )

            return (
                timedelta(hours=self._update_interval) + last_updated < datetime.now()
            )
        return True