

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
import re


class BaseScraper(ABC):
    """
    Abstract base class for all scrapers in the project.

    Every scraper MUST:
      - define a human-readable `name`
      - implement `async def run(self) -> None`

    Output convention:
      outputs/
        <scraper_slug>/
          ... scraper outputs ...
    """

    #: Human readable name for logs (e.g. "Argentina – Most Wanted")
    name: str = "Unnamed scraper"

    #: Root output directory for the whole project
    output_root: Path = Path("data/outputs")

    @property
    def slug(self) -> str:
        """
        Stable folder name derived from `self.name`.
        """
        text = (self.name or "unnamed").strip().lower()
        text = re.sub(r"[^a-z0-9]+", "_", text)
        return text.strip("_") or "unnamed"

    @property
    def out_dir(self) -> Path:
        """
        Output folder dedicated to this scraper: outputs/<slug>/
        """
        return self.output_root / self.slug

    def ensure_out_dir(self) -> Path:
        """
        Create the scraper output directory if it doesn't exist.
        """
        self.out_dir.mkdir(parents=True, exist_ok=True)
        return self.out_dir

    @abstractmethod
    async def run(self) -> None:
        """
        Execute the scraper end-to-end.

        Even if the underlying implementation is synchronous,
        this method must be async to provide a unified interface.
        """
        raise NotImplementedError
