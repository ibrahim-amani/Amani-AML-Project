import os
import time
import logging
from copy import deepcopy
from typing import Generator, Optional, Dict, Any

from elasticsearch import Elasticsearch
from elasticsearch import BadRequestError, NotFoundError, ConnectionError
from elasticsearch.helpers import streaming_bulk

from .utils import DEFAULT_INDEX

# Logging configuration 
logger = logging.getLogger("ElasticsearchClient")

if not logger.handlers:
    logging.basicConfig(
        level=os.getenv("LOG_LEVEL", "INFO"),
        format="[%(asctime)s] %(levelname)s %(name)s: %(message)s",
    )


def trace_log(event: str, payload: Any) -> None:
    """
    Lightweight tracing helper.
    Replaces span_trace.trace.add_log for local execution.
    """
    logger.info("%s | %s", event, payload)


# Local configuration 

class LocalConfig:
    """
    Local-friendly Elasticsearch configuration.
    All values can be overridden via environment variables.
    """

    # Example: http://127.0.0.1:9200 (prefer 127.0.0.1 over localhost on Windows)
    ELASTICSEARCH_URL = os.getenv("ELASTICSEARCH_URL", "http://127.0.0.1:9200")

    # Optional basic authentication (usually empty in local Docker)
    ELASTICSEARCH_USERNAME = os.getenv("ELASTICSEARCH_USERNAME", "")
    ELASTICSEARCH_PASSWORD = os.getenv("ELASTICSEARCH_PASSWORD", "")

    # Index configuration
    INDEX_NAME = os.getenv("ELASTICSEARCH_INDEX_NAME", "aml")
    INDEX_VERSION = int(os.getenv("INDEX_VERSION", "1"))

    # Client behavior
    REQUEST_TIMEOUT = int(os.getenv("ELASTICSEARCH_TIMEOUT", "60"))
    MAX_RETRIES = int(os.getenv("ELASTICSEARCH_MAX_RETRIES", "3"))
    RETRY_ON_TIMEOUT = os.getenv("ELASTICSEARCH_RETRY_ON_TIMEOUT", "1") == "1"


# Elasticsearch client factory

def build_es_client() -> Elasticsearch:
    """
    Build a local Elasticsearch client.

    - Uses a single URL instead of scheme/host/port
    - Supports optional Basic Auth
    - Safe defaults for retries and timeouts
    """
    kwargs: Dict[str, Any] = {
        "hosts": [LocalConfig.ELASTICSEARCH_URL],
        "request_timeout": LocalConfig.REQUEST_TIMEOUT,
        "retry_on_timeout": LocalConfig.RETRY_ON_TIMEOUT,
        "max_retries": LocalConfig.MAX_RETRIES,
    }

    if LocalConfig.ELASTICSEARCH_USERNAME and LocalConfig.ELASTICSEARCH_PASSWORD:
        kwargs["basic_auth"] = (
            LocalConfig.ELASTICSEARCH_USERNAME,
            LocalConfig.ELASTICSEARCH_PASSWORD,
        )

    return Elasticsearch(**kwargs)


# Shared Elasticsearch client
es = build_es_client()

# System documents stored inside the index
initial_stats = {"total_search_count": 0}
index_version_doc = {"index_version": LocalConfig.INDEX_VERSION}


# Elasticsearch client wrapper

class ElasticsearchClient:
    """
    Thin wrapper around elasticsearch-py providing:
    - Safe index initialization
    - Bulk ingestion
    - Stats & index version tracking
    - Local-friendly error handling
    """

    # Health check
    @staticmethod
    def ping() -> bool:
        """
        Check if Elasticsearch is reachable.

        IMPORTANT:
        - elasticsearch-py `es.ping()` uses HEAD / which can return 400 in some setups.
        - We use `es.info()` (GET /) instead, which is a reliable reachability check.
        """
        try:
            info = es.info()  # GET /
            body = getattr(info, "body", None) or {}
            ok = bool(body.get("version", {}).get("number"))
            if not ok:
                trace_log("elasticsearch_ping_unexpected_info", body)
            return ok
        except Exception as e:
            trace_log("elasticsearch_ping_failed", {"error": str(e)})
            return False

    # --------------------------------------------------------
    # Search
    # --------------------------------------------------------
    @staticmethod
    def search(query: dict, index_name: str = LocalConfig.INDEX_NAME) -> dict:
        """Execute a search query and return the response body."""
        response = es.search(index=index_name, body=query)
        return response.body

    # Index creation & bootstrap
    @staticmethod
    def create_index(
        mapping: Optional[dict] = None,
        index_name: str = LocalConfig.INDEX_NAME,
    ) -> None:
        """
        Create the index if it does not exist and ensure
        required system documents are present.
        """
        if not mapping:
            mapping = deepcopy(DEFAULT_INDEX)

        try:
            result = es.indices.create(index=index_name, body=mapping)
            trace_log("index_created", result.body)

        except BadRequestError:
            # Index already exists
            trace_log(
                "index_create_skipped",
                {"index": index_name, "reason": "already_exists"},
            )

        except ConnectionError as e:
            trace_log("index_create_failed_connection", str(e))
            raise

        # Ensure stats document exists
        stats_doc = ElasticsearchClient.get_by_id("stats", index_name)
        trace_log("index_stats", stats_doc)

        if not stats_doc.get("found"):
            result = ElasticsearchClient.save("stats", initial_stats, index_name)
            trace_log("index_stats_created", result)

        # Ensure index version document exists
        version_doc = ElasticsearchClient.get_by_id("index_version", index_name)
        if not version_doc.get("found"):
            result = ElasticsearchClient.save(
                "index_version",
                index_version_doc,
                index_name,
            )
            trace_log("index_version_created", result)

    # Bulk ingestion
    @staticmethod
    def save_bulk(
        actions: Generator,
        index_name: str = LocalConfig.INDEX_NAME,
    ) -> None:
        """
        Insert documents using Elasticsearch streaming bulk API.
        """
        item_count = 0
        failed_items: Dict[str, Any] = {}

        for ok, result in streaming_bulk(
            es,
            actions,
            index=index_name,
            raise_on_error=False,
            chunk_size=1000,
        ):
            item_count += 1
            if not ok:
                index_info = result.get("index", {})
                doc_id = index_info.get("_id", f"unknown_{item_count}")
                failed_items[str(doc_id)] = result

        trace_log(
            "elasticsearch_bulk_save",
            {
                "total_items_count": item_count,
                "failed_items_count": len(failed_items),
                "failed_items_sample": dict(list(failed_items.items())[:10]),
            },
        )

        if failed_items:
            logger.warning("Bulk insert completed with failures: %d", len(failed_items))

    # Data existence check
    @staticmethod
    def check_if_data_exists(
        provider_name: str = "",
        index_name: str = LocalConfig.INDEX_NAME,
    ) -> bool:
        """
        Check whether the index contains data.

        - Automatically creates the index if missing
        - Retries on connection failures
        - Provider filter is flexible: provider.keyword OR provider
        """
        if not provider_name:
            query = {"query": {"match_all": {}}}
        else:
            query = {
                "query": {
                    "bool": {
                        "should": [
                            {"term": {"provider.keyword": provider_name}},
                            {"term": {"provider": provider_name}},
                        ],
                        "minimum_should_match": 1,
                    }
                }
            }

        for attempt in range(1, 4):
            try:
                response = es.search(index=index_name, body=query)
                total = response.body.get("hits", {}).get("total", {}).get("value", 0)
                return total > 0

            except NotFoundError:
                trace_log(
                    "index_not_found_create",
                    {"index": index_name, "attempt": attempt},
                )
                ElasticsearchClient.create_index(index_name=index_name)
                time.sleep(1)

            except ConnectionError as e:
                trace_log(
                    "elasticsearch_connection_error",
                    {"attempt": attempt, "error": str(e)},
                )
                time.sleep(2 * attempt)

        return False

    # CRUD helpers
    @staticmethod
    def save(item_id: str, data: dict, index_name: str) -> dict:
        """Insert or overwrite a document by ID."""
        return es.index(index=index_name, id=item_id, body=data).body

    @staticmethod
    def update(item_id: str, data: dict, index_name: str) -> dict:
        """Partial document update with conflict retry."""
        return es.update(
            index=index_name,
            id=item_id,
            body={"doc": data},
            retry_on_conflict=3,
        ).body

    @staticmethod
    def get_by_id(item_id: str, index_name: str) -> dict:
        """Retrieve a document by ID."""
        try:
            return es.get(index=index_name, id=item_id).body
        except NotFoundError:
            return {"found": False}

    # Stats & versioning
    @staticmethod
    def increase_search_counter(index_name: str = LocalConfig.INDEX_NAME) -> None:
        """Increment the global search counter."""
        stats_doc = ElasticsearchClient.get_by_id("stats", index_name)
        trace_log("stats_document", stats_doc)

        if stats_doc.get("found"):
            counter = stats_doc["_source"].get("total_search_count", 0)
            ElasticsearchClient.update(
                "stats",
                {"total_search_count": counter + 1},
                index_name,
            )
        else:
            ElasticsearchClient.create_index(index_name=index_name)

    @staticmethod
    def get_index_version(index_name: str = LocalConfig.INDEX_NAME) -> int:
        """Return the current index schema version."""
        version_doc = ElasticsearchClient.get_by_id("index_version", index_name)
        if not version_doc.get("found"):
            return 0
        return int(version_doc["_source"].get("index_version", 0))

    @staticmethod
    def update_index(index_name: str = LocalConfig.INDEX_NAME) -> None:
        """Update index mappings (fields only)."""
        response = es.indices.put_mapping(
            index=index_name,
            body=DEFAULT_INDEX["mappings"],
        )
        trace_log(
            "index_mapping_updated",
            {"mappings": DEFAULT_INDEX["mappings"], "result": response.body},
        )

    @staticmethod
    def update_index_version(index_name: str = LocalConfig.INDEX_NAME) -> None:
        """Update the stored index version document."""
        result = ElasticsearchClient.save(
            "index_version",
            index_version_doc,
            index_name,
        )
        trace_log(
            "index_version_updated",
            {"document": index_version_doc, "result": result},
        )


# Local smoke test

if __name__ == "__main__":
    if not ElasticsearchClient.ping():
        raise SystemExit(
            "Elasticsearch is not reachable. "
            "Start it locally first (e.g., via Docker)."
        )

    ElasticsearchClient.create_index()
    print("Index version:", ElasticsearchClient.get_index_version())
    print("Has any data:", ElasticsearchClient.check_if_data_exists())
