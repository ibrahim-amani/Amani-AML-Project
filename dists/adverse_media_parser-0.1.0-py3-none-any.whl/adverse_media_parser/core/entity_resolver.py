from __future__ import annotations

import glob
import hashlib
import json
import os
import re
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Set, Tuple

import networkx as nx
from metaphone import doublemetaphone
from rapidfuzz import fuzz
import gzip
# Nationality normalization (ISO-2)
from .nat_to_iso import normalize_country_fields_in_profile, normalize_nationalities


class EntityResolver:
    def __init__(
        self,
        folder_name: str = "data/schema",
        output_dir: str = "data/provider",
        output_file: str = "Acuris_Full_Export.jsonl",
        max_block_size: int = 500,
        debug_top_n_clusters: int = 20,
    ):
        self.folder_name = folder_name
        self.output_dir = output_dir
        self.output_file = output_file
        self.max_block_size = max_block_size
        self.debug_top_n_clusters = debug_top_n_clusters

    # Public entrypoint
    def run(self) -> None:
        print("=== ROBUST ENTITY RESOLUTION ===")

        all_profiles = self._load_all_profiles()
        print(f"Loaded {len(all_profiles)} raw profiles.")

        if not all_profiles:
            print("No profiles loaded. Exiting.")
            return

        graph = self._build_similarity_graph(all_profiles)

        clusters = list(nx.connected_components(graph))
        print(f"Resolved into {len(clusters)} connected components (candidate entities).")

        merged_results: List[Dict[str, Any]] = []
        split_total = 0

        for component in clusters:
            cluster_profiles = [all_profiles[i] for i in component]
            subclusters = self._split_cluster_by_dob(cluster_profiles)
            split_total += len(subclusters)

            for sub in subclusters:
                merged_results.append(self._merge_cluster(sub))

        print(f"After DOB-aware split: {split_total} final entity clusters.")
        self._save_final_output(merged_results)
        self._debug_largest_clusters_with_split(all_profiles, clusters)

    # ---------------------------------------------------------------------
    # Debug helpers
    # ---------------------------------------------------------------------
    def _debug_largest_clusters_with_split(self, all_profiles: List[Dict[str, Any]], clusters: List[Set[int]]) -> None:
        clusters_sorted = sorted(clusters, key=len, reverse=True)
        top_n = min(self.debug_top_n_clusters, len(clusters_sorted))

        print("\n--- TOP N LARGEST CONNECTED COMPONENTS (Before DOB split) ---")
        for i in range(top_n):
            c_indices = list(clusters_sorted[i])

            names: List[str] = []
            for idx in c_indices:
                d = (all_profiles[idx].get("data") or {}) if isinstance(all_profiles[idx], dict) else {}
                names.append(d.get("fullName") or "")

            print("---------------------------------------------")
            print(f"Component {i + 1} ({len(c_indices)} profiles): {names}")

            cluster_profiles = [all_profiles[idx] for idx in c_indices]
            subclusters = self._split_cluster_by_dob(cluster_profiles)

            print(f"  -> DOB-aware split into {len(subclusters)} subclusters:")
            for j, sub in enumerate(subclusters, 1):
                sub_names = []
                sub_years: Set[str] = set()
                for p in sub:
                    d = p.get("data", {}) if isinstance(p, dict) else {}
                    sub_names.append(d.get("fullName") or "")
                    sub_years.update(self._extract_years(d.get("datesOfBirthIso") or []))
                print(f"     - Subcluster {j}: size={len(sub)} years={sorted(sub_years)} names={sub_names}")

            print("---------------------------------------------\n")

    # ---------------------------------------------------------------------
    # Load JSONL
    # ---------------------------------------------------------------------
    def _load_all_profiles(self) -> List[Dict[str, Any]]:
        profiles: List[Dict[str, Any]] = []
        files = sorted(glob.glob(os.path.join(self.folder_name, "*.jsonl")))
        print(f"Found {len(files)} JSONL files in '{self.folder_name}' directory.")

        for fpath in files:
            try:
                with open(fpath, "r", encoding="utf-8") as f:
                    for line_number, line in enumerate(f, 1):
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            obj = json.loads(line)
                            if isinstance(obj, dict):
                                d = obj.get("data")
                                if isinstance(d, dict):
                                    normalize_country_fields_in_profile(d)
                                profiles.append(obj)
                            else:
                                print(f"Skipping non-object JSON at {fpath}:{line_number}")
                        except json.JSONDecodeError as e:
                            print(f"Skipping invalid JSON at {fpath}:{line_number} -> {e}")
            except Exception as e:
                print(f"Error reading file {fpath}: {e}")

        return profiles

    # ---------------------------------------------------------------------
    # Text normalization helpers
    # ---------------------------------------------------------------------
    _UNICODE_APOS_RE = re.compile(r"[’‘`´]")
    _DASH_RE = re.compile(r"[\u2010\u2011\u2012\u2013\u2014\u2212\-]+")
    _NONALNUM_RE = re.compile(r"[^\w\s]", re.UNICODE)
    _WS_RE = re.compile(r"\s+", re.UNICODE)

    _NAME_STOPWORDS = {
        "al", "el", "as", "ash", "ad", "at", "ar", "az",
        "abu", "umm", "um",
        "bin", "ibn", "bint",
        "ben", "b", "st", "saint",
        "de", "del", "da", "di", "la", "le",
        "the", "of",
        "abd", "abdel", "abdul",
    }

    def _norm_text(self, s: str) -> str:
        # "  Mohammad–Al’Ali  "  →  "mohammad al ali"
        if not isinstance(s, str):
            return ""
        s = s.strip()
        if not s:
            return ""
        s = self._UNICODE_APOS_RE.sub("'", s)
        s = self._DASH_RE.sub(" ", s)
        s = s.lower()
        s = self._NONALNUM_RE.sub(" ", s)
        s = self._WS_RE.sub(" ", s).strip()
        return s

    def _name_tokens(self, name: str) -> List[str]:
        # "Mohammad Al Ali" → ["mohammad", "al", "ali"]
        tokens = self._norm_text(name).split()
        return [t for t in tokens if t]

    def _pick_first_meaningful_token(self, tokens: List[str]) -> str:
        for t in tokens:
            if t not in self._NAME_STOPWORDS and len(t) >= 2:
                return t
        return tokens[0] if tokens else ""

    def _pick_last_meaningful_token(self, tokens: List[str]) -> str:
        # Muhammad vs Mohamed vs Mohammad
        for t in reversed(tokens):
            if t not in self._NAME_STOPWORDS and len(t) >= 2:
                return t
        return tokens[-1] if tokens else ""

    def _metaphone(self, token: str) -> str:
        if not token:
            return ""
        try:
            return doublemetaphone(token)[0] or ""
        except Exception:
            return ""

    # ---------------------------------------------------------------------
    # Blocking utilities
    # ---------------------------------------------------------------------
    def _fingerprint_name(self, name: str) -> str:
        if not name:
            return ""
        tokens = sorted(set(self._name_tokens(name)))
        return " ".join(tokens)

    def _extract_years(self, dobs: Any) -> Set[str]:
        years: Set[str] = set()
        if not dobs or not isinstance(dobs, list):
            return years

        for dob in dobs:
            if not isinstance(dob, str):
                continue
            s = dob.strip()
            if not s:
                continue
            for y in re.findall(r"\b(18\d{2}|19\d{2}|20\d{2})\b", s):
                years.add(y)

        return years

    def _get_blocking_keys(self, profile: Dict[str, Any]) -> Set[str]:
        keys: Set[str] = set()
        data = profile.get("data", {}) if isinstance(profile, dict) else {}

        full_name = data.get("fullName") or ""
        if not isinstance(full_name, str) or not full_name.strip():
            return keys

        fp = self._fingerprint_name(full_name)
        if fp:
            keys.add(f"fp:{fp}")

        years = self._extract_years(data.get("datesOfBirthIso") or [])
        tokens = self._name_tokens(full_name)

        first_tok = self._pick_first_meaningful_token(tokens)
        last_tok = self._pick_last_meaningful_token(tokens)

        if years and first_tok:
            ph = self._metaphone(first_tok)
            if ph:
                for y in years:
                    keys.add(f"ph:{ph}:{y}")

        if years and last_tok:
            phl = self._metaphone(last_tok)
            if phl:
                for y in years:
                    keys.add(f"phl:{phl}:{y}")

        if years and len(tokens) >= 2:
            t2 = tokens[-2:]
            t2 = [t for t in t2 if t not in self._NAME_STOPWORDS]
            if len(t2) >= 2:
                a, b = sorted(t2[-2:])
                if len(a) >= 2 and len(b) >= 2:
                    for y in years:
                        keys.add(f"tail2:{a}_{b}:{y}")

        fp_tokens = fp.split()
        long_tokens = [t for t in fp_tokens if len(t) > 5]

        if years:
            for token in long_tokens:
                keys.add(f"tok:{token}")
        else:
            if len(long_tokens) >= 2:
                for token in long_tokens:
                    keys.add(f"tok:{token}")

        alias_candidates: List[str] = []
        for obj in (data.get("nameAliases") or []):
            if isinstance(obj, dict):
                s = obj.get("fullName") or ""
                if isinstance(s, str) and s.strip():
                    alias_candidates.append(s)
            elif isinstance(obj, str) and obj.strip():
                alias_candidates.append(obj)


        norm_aliases = []
        seen = set()
        for s in alias_candidates:
            ns = self._norm_text(s)
            if not ns:
                continue
            if len(ns.split()) < 2 and len(ns) < 10:
                continue
            if ns in seen:
                continue
            seen.add(ns)
            norm_aliases.append(ns)

        norm_aliases = sorted(norm_aliases, key=len, reverse=True)[:6]

        for ns in norm_aliases:
            afp = " ".join(sorted(set(ns.split())))
            if afp:
                keys.add(f"afp:{afp}")

            a_tokens = ns.split()
            a_first = self._pick_first_meaningful_token(a_tokens)
            a_last = self._pick_last_meaningful_token(a_tokens)

            if years:
                if a_first:
                    aph = self._metaphone(a_first)
                    if aph:
                        for y in years:
                            keys.add(f"aph:{aph}:{y}")

                if a_last:
                    aphl = self._metaphone(a_last)
                    if aphl:
                        for y in years:
                            keys.add(f"aphl:{aphl}:{y}")

                if len(a_tokens) >= 2:
                    at2 = a_tokens[-2:]
                    at2 = [t for t in at2 if t not in self._NAME_STOPWORDS]
                    if len(at2) >= 2:
                        aa, bb = sorted(at2[-2:])
                        if len(aa) >= 2 and len(bb) >= 2:
                            for y in years:
                                keys.add(f"atail2:{aa}_{bb}:{y}")

        return keys

    # Graph build  (multi-year DOB in down-blocking supported)
    def _build_similarity_graph(self, profiles: List[Dict[str, Any]]) -> nx.Graph:
        G = nx.Graph()
        for i in range(len(profiles)):
            G.add_node(i)

        start_time = time.time()

        blocks: Dict[str, List[int]] = {}
        print("Generating blocking keys...")
        for i, p in enumerate(profiles):
            for k in self._get_blocking_keys(p):
                blocks.setdefault(k, []).append(i)

        print(f"Generated {len(blocks)} blocks. Starting comparisons...")

        checked_pairs: Set[Tuple[int, int]] = set()
        actual_comparisons = 0
        downblocked_blocks = 0

        def _years_or_nodob(idx: int) -> List[str]:
            d = profiles[idx].get("data", {}) if isinstance(profiles[idx], dict) else {}
            years = sorted(self._extract_years(d.get("datesOfBirthIso") or []))
            return years if years else ["NODOB"]

        def _last_token_metaphone(idx: int) -> str:
            d = profiles[idx].get("data", {}) if isinstance(profiles[idx], dict) else {}
            name = d.get("fullName") or ""
            tokens = self._name_tokens(name)
            last_tok = self._pick_last_meaningful_token(tokens)
            return self._metaphone(last_tok) or ""

        for key, indices in blocks.items():
            if len(indices) < 2:
                continue

            if len(indices) > self.max_block_size:
                if key.startswith(("fp:", "afp:", "tok:")):
                    downblocked_blocks += 1
                    subblocks: Dict[str, List[int]] = {}

                    for idx in indices:
                        years_list = _years_or_nodob(idx)
                        ph_last = _last_token_metaphone(idx) or "NOPH"

                        for y in years_list:
                            subk = f"{key}|y:{y}|phl:{ph_last}"
                            subblocks.setdefault(subk, []).append(idx)

                    for _, subidxs in subblocks.items():
                        if len(subidxs) < 2:
                            continue
                        if len(subidxs) > self.max_block_size:
                            continue

                        for a in range(len(subidxs)):
                            for b in range(a + 1, len(subidxs)):
                                idx_a, idx_b = subidxs[a], subidxs[b]
                                if idx_a > idx_b:
                                    idx_a, idx_b = idx_b, idx_a

                                pair = (idx_a, idx_b)
                                if pair in checked_pairs:
                                    continue
                                checked_pairs.add(pair)

                                actual_comparisons += 1
                                if self._is_match(profiles[idx_a], profiles[idx_b]):
                                    G.add_edge(idx_a, idx_b)

                continue

            for a in range(len(indices)):
                for b in range(a + 1, len(indices)):
                    idx_a, idx_b = indices[a], indices[b]
                    if idx_a > idx_b:
                        idx_a, idx_b = idx_b, idx_a

                    pair = (idx_a, idx_b)
                    if pair in checked_pairs:
                        continue
                    checked_pairs.add(pair)

                    actual_comparisons += 1
                    if self._is_match(profiles[idx_a], profiles[idx_b]):
                        G.add_edge(idx_a, idx_b)

        end_time = time.time()
        duration = end_time - start_time

        n = len(profiles)
        naive_comparisons = (n * (n - 1)) // 2
        reduction = (1 - (actual_comparisons / naive_comparisons)) * 100 if naive_comparisons else 0.0

        print("\n" + "=" * 40)
        print(f" BENCHMARK REPORT ({n} Profiles)")
        print("=" * 40)
        print(f"Time Taken:           {duration:.4f} seconds")
        print(f"Naive Comparisons:    {naive_comparisons:,}")
        print(f"Blocking Comparisons: {actual_comparisons:,}")
        print(f"Work Saved:           {reduction:.2f}%")
        print(f"Down-blocked blocks:  {downblocked_blocks:,}")
        print("=" * 40 + "\n")

        return G

    # Evidence helpers
    def _collect_nationalities(self, d: Dict[str, Any]) -> Set[str]:
        raw = []
        raw.extend(d.get("nationalitiesIsoCodes") or [])
        raw.extend(d.get("nationality") or [])
        iso = normalize_nationalities(raw)
        return set([x.upper() for x in iso if isinstance(x, str) and x.strip()])

    def _collect_aliases(self, d: Dict[str, Any]) -> Set[str]:
        out: Set[str] = set()

        fn = d.get("fullName")
        nfn = self._norm_text(fn) if fn else ""
        if nfn:
            out.add(nfn)

        for obj in (d.get("nameAliases") or []):
            if isinstance(obj, dict):
                n = self._norm_text(obj.get("fullName") or "")
                if n:
                    out.add(n)
            elif isinstance(obj, str):
                n = self._norm_text(obj)
                if n:
                    out.add(n)


        return out

    # Match logic  (UPDATED: normalize names before scoring)

    def _is_match(self, p1: Dict[str, Any], p2: Dict[str, Any]) -> bool:
        d1 = p1.get("data", {}) if isinstance(p1, dict) else {}
        d2 = p2.get("data", {}) if isinstance(p2, dict) else {}

        # Normalize full names before scoring
        name1 = self._norm_text(d1.get("fullName") or "")
        name2 = self._norm_text(d2.get("fullName") or "")
        name_score = fuzz.token_sort_ratio(name1, name2)

        dob1 = self._extract_years(d1.get("datesOfBirthIso") or [])
        dob2 = self._extract_years(d2.get("datesOfBirthIso") or [])

        has_dob1 = bool(dob1)
        has_dob2 = bool(dob2)


        nats1 = self._collect_nationalities(d1)
        nats2 = self._collect_nationalities(d2)
        nat_overlap = bool(nats1 and nats2 and (not nats1.isdisjoint(nats2)))

        # We only "boost" when there is an overlap
        dob_name_threshold = 92 if not nat_overlap else 90
        strong_name_threshold = 97 if not nat_overlap else 96
        alias_name_threshold = 93 if not nat_overlap else 92

        # If both have DOB years, require overlapping year, then check name score
        if has_dob1 and has_dob2:
            if dob1.isdisjoint(dob2):
                return False
            return name_score > dob_name_threshold

        # No DOB for one or both: use aliases as supporting evidence
        a1 = self._collect_aliases(d1)
        a2 = self._collect_aliases(d2)
        alias_overlap = bool(a1 and a2 and (not a1.isdisjoint(a2)))

        if name_score >= strong_name_threshold:
            return True
        if alias_overlap and name_score >= alias_name_threshold:
            return True

        return False

    # DOB-aware splitting
    def _split_cluster_by_dob(self, profiles: List[Dict[str, Any]]) -> List[List[Dict[str, Any]]]:
        with_dob: List[Tuple[Dict[str, Any], Set[str]]] = []
        no_dob: List[Dict[str, Any]] = []

        for p in profiles:
            d = p.get("data", {}) if isinstance(p, dict) else {}
            years = self._extract_years(d.get("datesOfBirthIso") or [])
            if years:
                with_dob.append((p, years))
            else:
                no_dob.append(p)

        if not with_dob:
            return [profiles]

        buckets: List[Tuple[Set[str], List[Dict[str, Any]]]] = []
        for p, years in with_dob:
            placed = False
            for b_years, b_items in buckets:
                if not b_years.isdisjoint(years):
                    b_years.update(years)
                    b_items.append(p)
                    placed = True
                    break
            if not placed:
                buckets.append((set(years), [p]))

        def bucket_rep_name(items: List[Dict[str, Any]]) -> str:
            votes: Dict[str, int] = {}
            for it in items:
                d = it.get("data", {}) if isinstance(it, dict) else {}
                fn = d.get("fullName")
                if isinstance(fn, str) and fn.strip():
                    clean = " ".join(fn.split()).strip()
                    votes[clean] = votes.get(clean, 0) + 1
            if not votes:
                return ""
            return sorted(votes.keys(), key=lambda x: (votes[x], len(x)), reverse=True)[0]

        def strong_attach(no_dob_profile: Dict[str, Any], bucket_items: List[Dict[str, Any]]) -> Tuple[bool, int]:
            d = no_dob_profile.get("data", {}) if isinstance(no_dob_profile, dict) else {}
            p_name = (d.get("fullName") or "")
            if not isinstance(p_name, str) or not p_name.strip():
                return (False, 0)

            rep = bucket_rep_name(bucket_items)
            if not rep:
                return (False, 0)

            score = fuzz.token_sort_ratio(p_name.lower(), rep.lower())

            a_p = self._collect_aliases(d)
            a_b: Set[str] = set()
            for it in bucket_items:
                it_d = it.get("data", {}) if isinstance(it, dict) else {}
                a_b |= self._collect_aliases(it_d)
            alias_overlap = bool(a_p and a_b and (not a_p.isdisjoint(a_b)))

            if score >= 98:
                return (True, score)
            if alias_overlap and score >= 95:
                return (True, score)

            return (False, score)

        groups: List[List[Dict[str, Any]]] = [items for _, items in buckets]

        remaining_no_dob: List[Dict[str, Any]] = []
        for p in no_dob:
            best_idx = -1
            best_score = -1

            for i, bucket_items in enumerate(groups):
                ok, score = strong_attach(p, bucket_items)
                if ok and score > best_score:
                    best_score = score
                    best_idx = i

            if best_idx >= 0:
                groups[best_idx].append(p)
            else:
                remaining_no_dob.append(p)

        if remaining_no_dob:
            groups.append(remaining_no_dob)

        return groups

    # ---------------------------------------------------------------------
    # Merge cluster into Golden Record
    # ---------------------------------------------------------------------
    def _merge_cluster(self, profiles: List[Dict[str, Any]]) -> Dict[str, Any]:
        now_ms = int(time.time() * 1000)

        merged: Dict[str, Any] = {
            "qrCode": "",
            "resourceUri": "",
            "resourceId": "",
            "firstName": "",
            "fullName": "",
            "middleName": "",
            "lastName": "",
            "gender": None,
            "provider": "AmaniAI",
            "provider_version": now_ms,
            "isDeleted": False,
            "isDeceased": False,
            "nationality": [],
            "datesOfBirthParsed": [],
            "nameAliases": set(),
            "aliases": [],
            "datesOfBirthIso": set(),
            "datesOfDeathIso": set(),
            "nationalitiesIsoCodes": set(),
            "addresses": [],
            "profileImages": set(),
            "notes": [],
            "contactEntries": [],
            "identifiers": [],
            "evidences": [],
            "sanEntries": {"current": [], "former": []},
            "pepEntries": {"current": [], "former": []},
            "pepByAssociationEntries": [],
            "relEntries": [],
            "rreEntries": [],
            "poiEntries": [],
            "insEntries": [],
            "ddEntries": [],
            "individualLinks": [],
            "businessLinks": [],
            "griEntries": [],
        }

        final_datasets_list: Set[str] = set()

        full_name_votes: Dict[str, int] = {}
        first_votes: Dict[str, int] = {}
        middle_votes: Dict[str, int] = {}
        last_votes: Dict[str, int] = {}
        gender_votes: Dict[Any, int] = {}

        all_struct_aliases: List[Any] = []
        all_addresses: List[Any] = []
        all_dob_parsed: List[Any] = []

        gender_values: Set[Any] = set()
        dob_year_values: Set[str] = set()

        def _vote(votes: Dict[str, int], value: Optional[str]) -> None:
            if not value:
                return
            clean = " ".join(str(value).split()).strip()
            if clean:
                votes[clean] = votes.get(clean, 0) + 1

        def _extend_list(dst: List[Any], src: Any) -> None:
            if not src:
                return
            if isinstance(src, list):
                dst.extend(src)
            else:
                dst.append(src)

        for p in profiles:
            d = p.get("data", {}) if isinstance(p, dict) else {}
            final_datasets_list.update(p.get("datasets") or [])

            _vote(full_name_votes, d.get("fullName"))
            _vote(first_votes, d.get("firstName"))
            _vote(middle_votes, d.get("middleName"))
            _vote(last_votes, d.get("lastName"))

            if d.get("fullName"):
                clean_full = " ".join(str(d.get("fullName")).split()).strip()
                if clean_full:
                    merged["nameAliases"].add(clean_full)

            for alias_obj in (d.get("nameAliases") or []):
                if isinstance(alias_obj, dict):
                    a_name = alias_obj.get("fullName")
                    if a_name:
                        clean_a = " ".join(str(a_name).split()).strip()
                        if clean_a:
                            merged["nameAliases"].add(clean_a)
                elif isinstance(alias_obj, str):
                    clean_a = " ".join(alias_obj.split()).strip()
                    if clean_a:
                        merged["nameAliases"].add(clean_a)

            if d.get("gender") is not None:
                g = d.get("gender")
                gender_votes[g] = gender_votes.get(g, 0) + 1
                gender_values.add(g)

            dob_year_values.update(self._extract_years(d.get("datesOfBirthIso") or []))

            _extend_list(all_struct_aliases, d.get("aliases"))

            if d.get("isDeceased"):
                merged["isDeceased"] = True
            if d.get("isDeleted"):
                merged["isDeleted"] = True

            merged["datesOfBirthIso"].update(d.get("datesOfBirthIso") or [])
            merged["datesOfDeathIso"].update(d.get("datesOfDeathIso") or [])

            merged["nationalitiesIsoCodes"].update(normalize_nationalities(d.get("nationalitiesIsoCodes")))
            merged["nationalitiesIsoCodes"].update(normalize_nationalities(d.get("nationality")))

            merged["profileImages"].update(d.get("profileImages") or [])

            _extend_list(all_addresses, d.get("addresses"))
            _extend_list(all_dob_parsed, d.get("datesOfBirthParsed"))

            _extend_list(merged["notes"], d.get("notes"))
            _extend_list(merged["contactEntries"], d.get("contactEntries"))
            _extend_list(merged["identifiers"], d.get("identifiers"))
            _extend_list(merged["evidences"], d.get("evidences"))

            if d.get("sanEntries"):
                se = d.get("sanEntries") or {}
                merged["sanEntries"]["current"].extend(se.get("current") or [])
                merged["sanEntries"]["former"].extend(se.get("former") or [])

            if d.get("pepEntries"):
                pe = d.get("pepEntries") or {}
                merged["pepEntries"]["current"].extend(pe.get("current") or [])
                merged["pepEntries"]["former"].extend(pe.get("former") or [])

            for key in [
                "relEntries",
                "rreEntries",
                "poiEntries",
                "insEntries",
                "ddEntries",
                "pepByAssociationEntries",
                "individualLinks",
                "businessLinks",
                "griEntries",
            ]:
                _extend_list(merged[key], d.get(key))

        def _pick_best(votes: Dict[str, int]) -> str:
            if not votes:
                return ""
            sorted_vals = sorted(votes.keys(), key=lambda x: (votes[x], len(x)), reverse=True)
            return sorted_vals[0]

        merged["fullName"] = _pick_best(full_name_votes)
        merged["firstName"] = _pick_best(first_votes)
        merged["middleName"] = _pick_best(middle_votes)
        merged["lastName"] = _pick_best(last_votes)

        if gender_votes:
            merged["gender"] = sorted(gender_votes.keys(), key=lambda x: gender_votes[x], reverse=True)[0]

        if merged["fullName"] and merged["fullName"] in merged["nameAliases"]:
            merged["nameAliases"].remove(merged["fullName"])

        merged["nameAliases"] = [{"fullName": n} for n in sorted(merged["nameAliases"]) if n]
        merged["aliases"] = all_struct_aliases
        merged["addresses"] = all_addresses
        merged["datesOfBirthParsed"] = all_dob_parsed

        merged["datesOfBirthIso"] = sorted([x for x in merged["datesOfBirthIso"] if x])
        merged["datesOfDeathIso"] = sorted([x for x in merged["datesOfDeathIso"] if x])

        merged["nationalitiesIsoCodes"] = sorted([x for x in merged["nationalitiesIsoCodes"] if isinstance(x, str) and x])
        merged["profileImages"] = sorted([x for x in merged["profileImages"] if x])

        merged["nationality"] = list(merged["nationalitiesIsoCodes"])

        dob_seed = merged["datesOfBirthIso"][0] if merged["datesOfBirthIso"] else "NODOB"
        id_seed = f"{merged['fullName']}:{dob_seed}".strip()
        res_id = hashlib.sha256(id_seed.encode("utf-8")).hexdigest()

        merged["resourceId"] = res_id
        merged["resourceUri"] = f"/individuals/{res_id}"
        merged["qrCode"] = res_id[:10]

        merged["provider"] = "AmaniAI"
        merged["provider_version"] = int(time.time() * 1000)

        conflicts: Dict[str, Any] = {}
        if len(gender_values) > 1:
            conflicts["gender_values"] = sorted([str(x) for x in gender_values])
        if len(dob_year_values) > 1:
            conflicts["dob_years"] = sorted(dob_year_values)

        out_obj = {
            "data": merged,
            "datasets": sorted([x for x in final_datasets_list if isinstance(x, str) and x]),
        }
        if conflicts:
            out_obj["debug_trace"] = {"conflicts": conflicts}

        return out_obj

    def _save_final_output(self, merged_results: List[Dict[str, Any]]) -> None:
        os.makedirs(self.output_dir, exist_ok=True)

        out_file = self.output_file
        if not out_file.lower().endswith(".jsonl"):
            out_file = os.path.splitext(out_file)[0] + ".jsonl"

        output_path = os.path.join(self.output_dir, out_file)
        gz_output_path = output_path + ".gz"

        total = 0
        all_datasets: Set[str] = set()

        # We'll write JSONL and JSONL.GZ in one pass.
        with open(output_path, "w", encoding="utf-8") as f_jsonl, gzip.open(gz_output_path, "wt", encoding="utf-8") as f_gz:
            for item in merged_results:
                if not isinstance(item, dict):
                    continue

                ds = item.get("datasets")
                if isinstance(ds, list):
                    all_datasets.update([x for x in ds if isinstance(x, str)])

                line = json.dumps(
                    item,
                    ensure_ascii=False,
                    default=lambda o: list(o) if isinstance(o, set) else str(o),
                )

                f_jsonl.write(line + "\n")
                f_gz.write(line + "\n")
                total += 1

        print(f"Saved {total} Golden Records as JSONL to: {output_path}")
        print(f"Saved {total} Golden Records as JSONL.GZ to: {gz_output_path}")

        # Compute sha256 of the .jsonl.gz file (this matches future download/compare use-case)
        sha256 = hashlib.sha256()
        with open(gz_output_path, "rb") as rf:
            for chunk in iter(lambda: rf.read(1024 * 1024), b""):
                sha256.update(chunk)
        gz_sha256 = sha256.hexdigest()

        manifest_path = os.path.join(self.output_dir, os.path.splitext(out_file)[0] + ".manifest.json")
        manifest = {
            "exported_at_iso": datetime.now(timezone.utc).isoformat(),
            "records": total,
            "datasets": sorted(all_datasets),
            "format": "jsonl",
            "file": out_file,
            "file_gz": os.path.basename(gz_output_path),
            "sha256_gz": gz_sha256,
            "source_dir": self.folder_name,
            "max_block_size": self.max_block_size,
        }

        with open(manifest_path, "w", encoding="utf-8") as mf:
            json.dump(manifest, mf, indent=2, ensure_ascii=False)

        print(f"Saved manifest to: {manifest_path}")

        provider_body_path = os.path.join(self.output_dir, "amani_meta.json")
        provider_body = {
            "sha256": gz_sha256,
            "file": gz_output_path,
            "format": "jsonl.gz",
            "records": total,
            "exported_at_iso": manifest["exported_at_iso"],
            "datasets": sorted(all_datasets),
        }

        with open(provider_body_path, "w", encoding="utf-8") as pf:
            json.dump(provider_body, pf, indent=2, ensure_ascii=False)

        print(f"Saved provider body metadata to: {provider_body_path} (sha256 + file)")

if __name__ == "__main__":
    resolver = EntityResolver(folder_name="data/schema", output_dir="data/provider")
    resolver.run()
