import logging
import sys
import os
from typing import Optional

# Try to import colorama for Windows support
try:
    import colorama
    colorama.init()
except ImportError:
    pass

class ColorFormatter(logging.Formatter):
    """
    Custom formatter to add colors to log levels and specific unit names.
    """

    # ANSI Color Codes
    GREY = "\x1b[38;20m"
    GREEN = "\x1b[32;20m"
    YELLOW = "\x1b[33;20m"
    RED = "\x1b[31;20m"
    BOLD_RED = "\x1b[31;1m"
    BLUE = "\x1b[34;20m"
    CYAN = "\x1b[36;20m"
    MAGENTA = "\x1b[35;20m"
    RESET = "\x1b[0m"

    # Map log levels to colors
    LEVEL_COLORS = {
        logging.DEBUG: GREY,
        logging.INFO: GREEN,
        logging.WARNING: YELLOW,
        logging.ERROR: RED,
        logging.CRITICAL: BOLD_RED
    }

    # Map specific units/loggers to colors
    UNIT_COLORS = {
        "Scraper": CYAN,
        "Processor": MAGENTA,
        "Analyzer": BLUE,
        "ScreeningEngine": GREEN
    }

    def __init__(self, fmt: str, datefmt: Optional[str] = None, use_color: bool = True):
        super().__init__(fmt, datefmt)
        self.use_color = use_color

    def format(self, record: logging.LogRecord) -> str:
        # Save original values to restore them later (prevents color bleed in file logs if reused)
        original_levelname = record.levelname
        original_name = record.name

        if self.use_color:
            # 1. Colorize the Log Level
            color = self.LEVEL_COLORS.get(record.levelno, self.RESET)
            record.levelname = f"{color}{record.levelname}{self.RESET}"

            # 2. Colorize the Unit Name (Logger Name) if recognized
            if record.name in self.UNIT_COLORS:
                unit_color = self.UNIT_COLORS[record.name]
                record.name = f"{unit_color}{record.name}{self.RESET}"

        # Format the message using the parent class
        result = super().format(record)

        # Restore original values so we don't mess up other handlers (like file handlers)
        record.levelname = original_levelname
        record.name = original_name

        return result

def setup_colored_logging(level: int = logging.INFO):
    """
    Configures the root logger with a colored StreamHandler.
    Detects if the output is a TTY (terminal) to enable/disable colors automatically.
    """
    # Check if we are printing to a terminal (TTY)
    # If piping to a file (python main.py > log.txt), isatty will be False
    is_tty = sys.stderr.isatty() or os.environ.get("FORCE_COLOR_LOGS")

    # Define the log format
    # %(asctime)s - Time
    # %(name)s    - The Logger Name (e.g., Scraper, Processor)
    # %(levelname)s - INFO, ERROR, etc.
    # %(message)s - The actual log message
    log_fmt = "%(asctime)s | %(name)-18s | %(levelname)-8s | %(message)s"
    date_fmt = "%Y-%m-%d %H:%M:%S"

    # Create the formatter
    formatter = ColorFormatter(log_fmt, date_fmt, use_color=is_tty)

    # Create Console Handler
    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setFormatter(formatter)

    # Setup Root Logger
    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    
    # Clear existing handlers to avoid duplicates if function is called twice
    if root_logger.hasHandlers():
        root_logger.handlers.clear()
    
    root_logger.addHandler(console_handler)

