import os
import json
import logging
import pdfplumber
import pandas as pd
from datetime import datetime
from typing import Optional, List, Dict
from .utils import load_json
import uuid
import hashlib
from nameparser import HumanName
import easyocr 
import numpy as np
from PIL import Image
import io
from adverse_media_parser.core.profile_mapper import ProfileMapper

UUID_NAMESPACE = uuid.uuid5(uuid.NAMESPACE_DNS, "AmaniAI.ai")


class FileProcessor:
    """
    Unified Data Processor.
    - Phase 1 (Pre-process): Raw File -> Clean Text (JSON)
    - Phase 3 (Post-process): LLM Output -> Golden Record (_final.json)
    - Phase 4 (Target Map): Golden Record -> Target Schema (_target.json)
    """
    
    def __init__(self, config, reporter):
        self.config = config
        self.reporter = reporter
        self.logger = logging.getLogger("Processor")
        self.ocr_reader = easyocr.Reader(['en'], gpu=False)
        self.mapper = ProfileMapper() 
        
    # ==========================================
    # PHASE 1: PRE-PROCESSING (Raw -> Text)
    # ==========================================
    def pre_process(self,
                file_path: str,
                filename: str,
                source_url: str,
                file_type: str,
                metadata: Dict = None) -> Optional[str]:
        """
        Main entry point: Orchestrates extraction and saving.
        
        Args:
            file_path: Local path to the raw downloaded file.
            filename: The unique filename generated during ingestion.
            source_url: Original URL (for metadata/logging).
            file_type: 'pdf' or 'xlsx'.

        Returns:
            str: Path to the saved JSON file, or None on failure.
        """
        self.logger.info(f"Processing: {filename}")
        
        extracted_text = ""
        
        try:
            # Route to appropriate extractor
            if file_type == 'pdf':
                extracted_text = self._extract_from_pdf(file_path, source_url)
            elif file_type == 'xlsx':
                extracted_text = self._extract_from_excel(file_path, source_url)
            elif file_type == 'html':
                extracted_text = self._extract_from_html(file_path, source_url)
            elif file_type == 'image':
                extracted_text = self._extract_from_image(file_path, source_url)
            # Validation check
            if not extracted_text:
                self.logger.warning(f"No text extracted from {filename}")
                self.reporter.log_failure(source_url, "Empty text extraction", "extraction")
                return None

            # Save the result
            json_path = self._save_processed_data(
                filename=filename,
                url=source_url,
                ftype=file_type,
                content=extracted_text,
                metadata=metadata
            )
            
            return json_path

        except Exception as e:
            self.logger.error(f"Processing failed for {filename}: {e}")
            self.reporter.log_failure(source_url, str(e), "processing_crash")
            return None
        
    # ==========================================
    # PHASE 3: POST-PROCESSING (LLM -> Golden Record)
    # ==========================================  
      
    def post_process_analysis(self, analysis_json_path: str) -> bool:
        """
        Post-processes the analyzed JSON to add UUID, source list, scrape timing, and Url.
        Args:
            analysis_json_path: Path to the analyzed JSON file from LLM.
        Returns:
            bool: True if successful, False otherwise.
        """
        base_path = analysis_json_path.rsplit("_analysis", 1)[0]
        final_result_path = f"{base_path}_final.json"
        
        try:
            # Load the analyzed JSON
            with open(analysis_json_path, "r",encoding="utf-8") as f:
                data = json.load(f)

            metadata = data.get("metadata", {})
            region = metadata.get("Region", "")
            source_name = metadata.get("Source Name", "")
            provider = metadata.get("Provider", "")
            risk_keywords = metadata.get("risk_keywords", [])
            
            source_list = " - ".join(filter(None, [region, source_name, provider]))
            scraped_at = metadata.get("scraped_at", "")
            source_url = data.get("original_url", "")
            
            
            all_profiles = []
            raw_analyses = data.get("analyses", [])
            
            for chunk in raw_analyses:
                # Handle keys safely
                chunk_profiles = chunk.get("extracted_profiles")
                all_profiles.extend(chunk_profiles)

            # 4. Enrich Each Profile (Looping through the list)
            for item in all_profiles:
                # A. Handle Profile Key Nesting 
                profile = item.get('profile', item)
                
                # B. Generate UUID
                full_name = profile.get('full_name')
                #  OMIT IF NAME IS NULL
                if not full_name or not isinstance(full_name, str) or len(full_name.strip()) < 2 or len(full_name.split()) < 2:
                    continue 
                p_id = self._generate_uuid(full_name)
                
                # Update the profile ID in the dict
                # If 'profile' key exists, update inside it, else update root
                profile['id'] = p_id

                # C. Add Metadata Fields
                # for source list, scraped_at, url
                
                for risk_event in item.get("risk_events", []):
                    risk_event["source_list"] = source_list
                    
                item["evidence"]["scraped_at"] = scraped_at
                item["evidence"]["url"] = source_url
                item["evidence"]["risk_keywords"] = risk_keywords

            
            base_path = analysis_json_path.rsplit("_analysis", 1)[0]
            final_result_path = f"{base_path}_final.json"
            final_output = {
                "file_id": data.get("source_file"),
                "total_profiles": len(all_profiles),
                "profiles": all_profiles
            }

            # Save to final directory
            final_save_path = os.path.join(self.config.final_dir, os.path.basename(final_result_path))
            with open(final_save_path, "w", encoding="utf-8") as f:
                json.dump(final_output, f, indent=2, ensure_ascii=False)

                
            self.logger.info(f"Post-processing records saved: {final_save_path}")
            return True

        except Exception as e:
            self.logger.error(f"Post-processing failed for {final_result_path}: {e}")
            return False
    
    # ==========================================
    # PHASE 4: TARGET SCHEMA MAPPING (Golden -> Target)
    # ==========================================
    
    def create_target_schema(self, golden_json_path: str) -> bool:
        """
        Transforms the Golden Record (_final.json) into the Complex Target Schema.
        Saves as _target.json.
        """
        self.logger.info(f"Mapping to Target Schema: {golden_json_path}")
        try:
            with open(golden_json_path, 'r', encoding='utf-8') as f:
                golden_data = json.load(f)
            
            output_results = []
            global_datasets = set()
            input_profiles = golden_data.get("profiles") or []

            for profile_entry in input_profiles:
                entry_with_dataset = self.mapper.map_single_profile(profile_entry)
                mapped_entry = entry_with_dataset.get("data")
                dataset = entry_with_dataset.get("datasets", set())
                output_results.append(mapped_entry)
                global_datasets.update(dataset)

            final_output = {
                "result": output_results,
                "datasets": sorted(list(global_datasets))
            }
            if len(output_results) == 0:
                self.logger.warning("No profiles mapped to target schema.")
                return False
            else:
                # Save _target.jsonl
                target_path = golden_json_path.replace("_final.json", "_target.jsonl")
                final_save_path = os.path.join(self.config.schema_dir, os.path.basename(target_path))

                with open(final_save_path, 'w', encoding='utf-8') as f:
                    json.dump(final_output, f, indent=2, ensure_ascii=False)

                self.logger.info(f"Target Schema saved: {target_path}")
                return True

        except Exception as e:
            self.logger.error(f"Target mapping failed for {golden_json_path}: {e}")
            return False

    # --- Internal Methods ---

    def _extract_from_pdf(self, path: str, url_for_log: str) -> str:
        """
        Extracts text from PDF using a Table-First strategy.
        This preserves data structure in sanctions lists better than raw text extraction.
        """
        text_parts = []
        try:
            # Open file from disk (memory efficient for large docs)
            with pdfplumber.open(path) as pdf:
                total_pages = len(pdf.pages)
                self.logger.info(f"PDF has {total_pages} pages.")
                
                for i, page in enumerate(pdf.pages):
                    page_content_found = False
                    # 1. Try Table Extraction (Best for structured lists)
                    tables = page.extract_tables({
                        "vertical_strategy": "lines", 
                        "horizontal_strategy": "lines",
                        "snap_tolerance": 3,
                    })
                    if tables:
                        for table in tables:
                            for row in table:
                                # Flatten multi-line cells (e.g. addresses) into single line
                                clean_row = [
                                    str(cell).replace('\n', ' ').strip()  
                                    for cell in row
                                    if cell and str(cell).strip()
                                ]
                                text_parts.append(" ".join(clean_row))
                        page_content_found = True
                    
                    # 2. Fallback: Standard Text Extraction
                    # Only run if no tables found to avoid duplicating data
                    if not page_content_found:
                        txt = page.extract_text()
                        if txt and len(txt.strip()) > 50: # Threshold to filter out noise
                            text_parts.append(txt)
                            page_content_found = True
                            
                    if not page_content_found:
                        # Log only occasionally to avoid spamming
                        if i == 0 or i % 5 == 0:
                            self.logger.info(f"Page {i+1} appears to be scanned. Running OCR...")

                        try:
                            # 1. Render page to high-res image (300 DPI)
                            # pdfplumber.to_image() returns a PageImage object
                            # .original gives us the Pillow (PIL) Image
                            pil_image = page.to_image(resolution=300).original
                            
                            # 2. Convert to Numpy Array for EasyOCR
                            # (EasyOCR expects a numpy array or file path)
                            image_np = np.array(pil_image)
                            
                            # 3. Run Inference
                            ocr_result = self.ocr_reader.readtext(image_np, detail=0, paragraph=True)
                            
                            # 4. Append Text
                            if ocr_result:
                                text_parts.append("\n".join(ocr_result))
                                page_content_found = True
                                
                        except Exception as e:
                            self.logger.warning(f"OCR failed on page {i+1}: {e}")

                    if i % 50 == 0 and i > 0: 
                        self.logger.debug(f"Processed page {i}/{total_pages}")
                        
            final_text = "\n\n".join(text_parts)
            # Final Safety Check: If after all that we still have nothing...
            if not final_text.strip():
                self.logger.warning(f"Failed to extract ANY meaningful text from {path} (Digital or OCR).")
                return ""

            return final_text

        except Exception as e:
            self.logger.error(f"PDF Error: {e}")
            self.reporter.log_failure(url_for_log, f"PDF parsing failed: {e}", "pdf_extraction")
            return ""
        
        
    def _extract_from_html(self, path: str, url_for_log: str) -> str:
        """
        Extracts text from Excel or CSV files.
        Converts content to CSV-string format which LLMs handle well.
        """
        try:
            # get markdown content from json
            file_data = load_json(path)
            markdown_cotent = file_data["clean_text"]
            return markdown_cotent

        except Exception as e:
            self.logger.error(f"Excel/CSV Error: {e}")
            self.reporter.log_failure(url_for_log, f"Excel parsing failed: {e}", "excel_extraction")
            return ""
        
        
    def _extract_from_image(self, path: str, url_for_log: str) -> str:
        """
        Extracts text from an image file using EasyOCR.
        """
        try:
            # Load image
            # easyocr supports file paths directly
            with Image.open(path) as img:
                # 2. Convert to RGB to ensure 3 channels (removes Alpha channel issues)
                img = img.convert("RGB")
                # 3. Convert to Numpy Array (EasyOCR native format)
                image_np = np.array(img)
            
            # 4. Run Inference on the Array (Not the file path)
            result = self.ocr_reader.readtext(image_np, detail=0, paragraph=True)
            
            # Join text blocks
            full_text = "\n".join(result)

            self.logger.info(f"OCR extracted {len(full_text)} characters from {path}.")
            return full_text

        except Exception as e:
            self.logger.error(f"OCR Error: {e}")
            self.reporter.log_failure(url_for_log, f"OCR failed: {e}", "ocr_extraction")
            return ""
            
    def _extract_from_excel(self, path: str, url_for_log: str) -> str:
        """
        Extracts text from Excel or CSV files.
        Converts content to CSV-string format which LLMs handle well.
        """
        try:
            # Try Excel Engine first
            df = pd.read_excel(path)
            return df.to_csv(index=False)
        except Exception:
            # Fallback to CSV engine if extension was misleading
            try:
                df = pd.read_csv(path)
                return df.to_csv(index=False)
            except Exception as e:
                self.logger.error(f"Excel/CSV Error: {e}")
                self.reporter.log_failure(url_for_log, f"Excel parsing failed: {e}", "excel_extraction")
                return ""

    def _save_processed_data(self,
                             filename: str,
                             url: str,
                             ftype: str,
                             content: str,
                             metadata: Dict) -> str:
        """
        Saves the extraction metadata and content to a JSON file.
        """
        metadata.update({"risk_keywords": self._check_risk_keywords(content)})
        json_data = {
            "source_url": url,
            "file_type": ftype,
            "filename_id": filename,
            "downloaded_at": datetime.now().isoformat(),
            "content": content,
            "metadata": metadata
        }
        
        # Swap extension for .json
        base_name = os.path.splitext(filename)[0]
        json_filename = f"{base_name}.json"
        save_path = os.path.join(self.config.processed_dir, json_filename)
        
        try:
            with open(save_path, 'w', encoding='utf-8') as f:
                json.dump(json_data, f, indent=4, ensure_ascii=False)
            self.logger.info(f"Saved JSON: {save_path}")
            return save_path
        except Exception as e:
            self.logger.error(f"Failed to save JSON: {e}")
            raise e

    def _check_risk_keywords(self, text: str) -> List[str]:
        """
        Scans text for high-priority AML keywords.
        Returns a list of found keywords.
        """
        if not text: return []
        
        keywords = self.config.risk_keywords
        found = list(set([k for k in keywords if k.lower() in text.lower()]))
        return found

    def _generate_uuid(self, val: str) -> str:
        """Generate consistent UUID based on the source ID."""
        return str(uuid.uuid5(UUID_NAMESPACE, val))