import hashlib
import time
import re
from typing import Dict, List, Set, Tuple, Any, Optional
from nameparser import HumanName

# --- CONSTANTS & HELPERS ---

NOISE_SUFFIXES = {
    "DMD", "D.M.D", "DDS", "D.D.S", "MD", "M.D", "PHD", "PH.D",
    "DCFH", "LLC", "LTD", "INC", "CORP", "S.A.", "GMBH", "D.O."
}

QRCODE_LEN = 10

def parse_date_of_birth(date_of_birth: str) -> Dict[str, str]:
    result = {"year": "", "month": "", "day": ""}
    if not date_of_birth:
        return result
    try:
        components = date_of_birth.split("-")
        for i, component in enumerate(components):
            if not component.isdigit():
                continue
            if i == 0: result["year"] = component
            elif i == 1: result["month"] = component
            elif i == 2: result["day"] = component
        return result
    except ValueError:
        return result

class ProfileMapper:
    """
    Handles the transformation of raw 'golden profile' data into the 
    target schema structure. Merges logic from old Processor and new Mapper.
    """

    _ISO2_AT_END_RE = re.compile(r"(?:,|\s)\b([A-Z]{2})\b\s*$")
    _TRAIL_PUNCT_RE = re.compile(r"^[\W_]+|[\W_]+$", re.UNICODE)
    _PATRONYMIC_RE = re.compile(r".*(ovich|evich|yevich|ovna|evna|ich)$", re.IGNORECASE)

    @staticmethod
    def _sha256_hex(val: str) -> str:
        return hashlib.sha256(val.encode("utf-8")).hexdigest()

    def _stable_qrcode(self, val: str, length: int = QRCODE_LEN) -> str:
        return self._sha256_hex(val)[:length]

    @staticmethod
    def _norm_ws(s: Optional[str]) -> str:
        if not s: return ""
        return " ".join(str(s).strip().split())

    def _clean_name_token(self, tok: str) -> str:
        tok = self._norm_ws(tok)
        return self._TRAIL_PUNCT_RE.sub("", tok)

    def _clean_name_noise(self, full_name: str) -> str:
        parts = full_name.split()
        cleaned = []
        for p in parts:
            clean_p = p.replace(".", "").upper()
            if clean_p in NOISE_SUFFIXES:
                continue
            cleaned.append(p)
        return " ".join(cleaned)

    def _parse_name_details(self, full_name: str) -> Dict[str, str]:
        """Robust name parsing with heuristics for Slavic/Western names."""
        if not full_name:
            return {"first": "", "middle": "", "last": ""}

        s = self._clean_name_noise(self._norm_ws(full_name))
        if not s:
            return {"first": "", "middle": "", "last": ""}

        # Heuristic 1: "LAST, First Middle"
        if "," in s:
            left, right = [x.strip() for x in s.split(",", 1)]
            right_parts = right.split()
            first = self._clean_name_token(right_parts[0]) if right_parts else ""
            middle = self._clean_name_token(" ".join(right_parts[1:])) if len(right_parts) > 1 else ""
            last = self._clean_name_token(left)
            return {"first": first, "middle": middle, "last": last}

        # Heuristic 2: Slavic "Last First Patronymic"
        parts = s.split()
        if len(parts) == 3 and self._PATRONYMIC_RE.match(parts[2]):
            return {
                "first": self._clean_name_token(parts[1]), 
                "middle": self._clean_name_token(parts[2]), 
                "last": self._clean_name_token(parts[0])
            }

        # Fallback: Library
        try:
            hn = HumanName(s)
            first = self._clean_name_token(hn.first)
            middle = self._clean_name_token(f"{hn.middle} {hn.nickname}")
            last = self._clean_name_token(f"{hn.last} {hn.suffix}")
            
            if not (first or last):
                raise ValueError("Empty parse")
            return {"first": first, "middle": middle, "last": last}
        except Exception:
            # Fallback: Simple Split
            p = s.split()
            if len(p) == 1: return {"first": p[0], "middle": "", "last": ""}
            return {"first": p[0], "middle": " ".join(p[1:-1]), "last": p[-1]}

    # ---------------------------------------------------------
    # MAIN MAPPING FUNCTION
    # ---------------------------------------------------------
    def map_single_profile(self, entry: Dict[str, Any]) -> Tuple[Dict[str, Any], Set[str]]:
        """
        Maps a single golden profile entry to the target schema.
        Handles the 'Global Evidence' structure where one snippet applies to the whole profile.
        """
        profile = entry.get("profile", {})
        risk_events = entry.get("risk_events", [])
        
        # --- 1. Evidence Parsing (Global) ---
        # We combine Scraper Metadata (URL) with LLM Content (Snippet, Title)
        
        # Scraper metadata (passed in 'evidence' list usually, or top level if you restructured input)
        # Assuming 'entry' still has the scraper's 'evidence' list with URLs:
        scraper_evidence_list = entry.get("evidence_metadata", []) # You might need to adjust key based on how you pass scraper data
        if not scraper_evidence_list and isinstance(entry.get("evidence"), list):
             scraper_evidence_list = entry.get("evidence")

        # LLM extracted content
        llm_evidence = entry.get("evidence", {})
        
        target_evidences = []
        evidence_ids = []

        # Logic: Create ONE main evidence record merging LLM text + Scraper URL
        # Use the first available URL from scraper metadata if available
        base_url = scraper_evidence_list[0].get("url") if scraper_evidence_list else ""
        capture_date = scraper_evidence_list[0].get("scraped_at", "").split("T")[0] if scraper_evidence_list else ""
        
        snippet = llm_evidence.get("raw_text_snippet", "")
        title = llm_evidence.get("title", "")
        pub_date = llm_evidence.get("publication_date", "")
        risk_keywords = llm_evidence.get("risk_keywords", [])

        # Generate ID
        ev_str = f"{base_url}{snippet}"
        ev_id = str(int(hashlib.md5(ev_str.encode()).hexdigest(), 16))[:8]
        evidence_ids.append(ev_id)

        target_evidences.append({
            "datasets": [], # Populated later
            "evidenceId": ev_id,
            "originalUrl": base_url,
            "isCopyrighted": True,
            "title": title,
            "credibility": "Medium",
            "language": "eng",
            "summary": snippet,
            "keywords": risk_keywords,
            "captureDateIso": capture_date,
            "publicationDateIso": pub_date, 
            "assetUrl": base_url,
        })

        # --- 2. Basic Profile Info ---
        full_name = profile.get("full_name", "Unknown")
        parsed_name = self._parse_name_details(full_name) 
        resource_id = str(profile.get("id") or self._sha256_hex(full_name))

        # --- 3. Risk Buckets Initialization ---
        san_entries = {"current": [], "former": []}
        pep_entries = {"current": [], "former": []}
        rel_entries = []
        rre_entries = []
        ins_entries = []
        dd_entries = []
        poi_entries = []
        gri_entries = []
        
        active_datasets = set()
        datasets = set()
        # --- 4. Process Risk Events ---
        for event in risk_events:
            evt_type = event.get("type", "").lower()
            is_current = event.get("is_current", True)
            dataset = event.get("source_list","")
            ds_tag = "GRI"
            if "sanction" in evt_type: ds_tag = "SAN-CURRENT" if is_current else "SAN-FORMER"
            elif "pep" in evt_type: ds_tag = "PEP-CURRENT" if is_current else "PEP-FORMER"
            elif any(x in evt_type for x in ["regulatory", "enforcement", "wanted", "law"]): ds_tag = "REL"
            elif any(x in evt_type for x in ["adverse", "media"]): ds_tag = "RRE"
            elif any(x in evt_type for x in ["insolvency", "bankruptcy"]): ds_tag = "INS"
            elif any(x in evt_type for x in ["disqualified", "director"]): ds_tag = "DD"
            elif "person" in evt_type and "interest" in evt_type: ds_tag = "POI"

            active_datasets.add(ds_tag)
            datasets.add(dataset)
            # Link the GLOBAL evidence ID to this event
            target_event = {
                "type": "Added", 
                "dateIso": event.get("date_listed", ""),
                "evidenceIds": evidence_ids # <--- Uses the single global ID
            }

            details = event.get("specific_details", {})
            
            # --- MAPPING LOGIC (Same as before) ---
            if "sanction" in evt_type:
                entry_obj = {
                    "sanctionId": hashlib.md5(event.get("reason", "").encode()).hexdigest()[:12],
                    "measures": [event.get("reason")],
                    "regime": {
                        "body": event.get("authority"),
                        "name": event.get("authority"), 
                        "origin": event.get("authority")
                    },
                    "events": [target_event]
                }
                san_entries["current" if is_current else "former"].append(entry_obj)

            elif "pep" in evt_type:
                # Handle PEP Tier from details if present
                entry_obj = {
                    "position": details.get("position") or event.get("reason"),
                    "countryIsoCode": profile.get("nationality"),
                    "evidenceIds": evidence_ids
                }
                pep_entries["current" if is_current else "former"].append(entry_obj)
                
                # Check for Tier in details to update root (Simple Max Logic)
                if details.get("pep_tier"):
                    # You can add logic here to update a variable for the root 'pepTier'
                    pass

            elif any(x in evt_type for x in ["regulatory", "enforcement", "law", "wanted"]):
                entry_obj = {
                    "category": details.get("category") or "Law Enforcement",
                    "subcategory": details.get("subcategory") or "Regulatory Action",
                    "events": [{
                        "type": details.get("enforcement_type", "Regulatory Action"),
                        "dateIso": event.get("date_listed"),
                        "evidenceIds": evidence_ids
                    }]
                }
                rel_entries.append(entry_obj)

            elif "adverse" in evt_type or "media" in evt_type:
                entry_obj = {
                    "category": details.get("category") or "Financial Crime", 
                    "subcategory": details.get("subcategory") or "Adverse Media Report",
                    "events": [{
                        "type": details.get("adverse_media_type", "Allegation"),
                        "dateIso": event.get("date_listed"),
                        "evidenceIds": evidence_ids
                    }]
                }
                rre_entries.append(entry_obj)

            elif "insolvency" in evt_type or "bankruptcy" in evt_type:
                entry_obj = {
                    "type": event.get("reason", "Insolvency Proceeding"),
                    "insolvencyIdNumber": details.get("case_reference"),
                    "solicitor": details.get("solicitor"),
                    "court": event.get("authority"), 
                    "petitioner": details.get("petitioner"),
                    "debt": details.get("debt_amount"),
                    "insolvencyStartDateIso": event.get("date_listed"),
                    "evidenceIds": evidence_ids
                }
                ins_entries.append(entry_obj)

            elif "disqualified" in evt_type or "director" in evt_type:
                entry_obj = {
                    "caseReference": details.get("case_reference", "Unknown"),
                    "reason": event.get("reason"),
                    "conduct": details.get("company_name") or event.get("authority"),
                    "dateFromIso": event.get("date_listed"),
                    "evidenceIds": evidence_ids
                }
                dd_entries.append(entry_obj)

            elif "person" in evt_type and "interest" in evt_type:
                entry_obj = {
                    "category": details.get("category") or "Public Interest",
                    "evidenceIds": evidence_ids,
                    "positions": [{
                        "position": details.get("position") or event.get("reason"),
                        "segment": "General",
                        "countryIsoCode": profile.get("nationality"),
                        "dateFromIso": event.get("date_listed"),
                        "dateToIso": event.get("date_listed")
                    }]
                }
                poi_entries.append(entry_obj)

            else:
                entry_obj = {
                    "evidenceId": evidence_ids,
                    "title": f"Risk Report - {event.get('type', 'General Risk')}",
                    "summary": event.get("reason"),
                    "keywords": [event.get("type", "General")]
                }
                gri_entries.append(entry_obj)

        # --- 5. Back-fill datasets into evidence ---
        for ev in target_evidences:
            ev["datasets"] = list(active_datasets)

        # --- 6. Address Mapping (New) ---
        raw_addresses = profile.get("addresses", [])
        mapped_addresses = []
        for addr in raw_addresses:
            mapped_addresses.append({
                "addressType": addr.get("type", "Unknown"),
                "line1": addr.get("street", ""),
                "line2": "", 
                "postcode": addr.get("postal_code", ""),
                "city": addr.get("city", ""),
                "county": addr.get("region", ""),
                "countryIsoCode": addr.get("country_code", "")
            })

        # --- 7. Alias Mapping ---
        name_aliases = [] 
        aliases_struct = [] 
        raw_aliases = profile.get("aliases", [])
        seen_aliases = {full_name.lower().strip()}

        for alias in raw_aliases:
            alias_str = alias if isinstance(alias, str) else alias.get("fullName", str(alias))
            if alias_str and alias_str.strip():
                clean_alias = alias_str.strip()
                if clean_alias.lower() not in seen_aliases:
                    name_aliases.append({"fullName": clean_alias})
                    seen_aliases.add(clean_alias.lower())
                
                ap = self._parse_name_details(clean_alias)
                if ap["first"] or ap["last"]:
                    aliases_struct.append({
                        "firstName": ap["first"],
                        "middleName": ap["middle"],
                        "lastName": ap["last"],
                        "type": "Original Script Name", 
                    })

        # --- 8. Date Parsing ---
        dates_of_birth_iso = [profile.get("date_of_birth")] if profile.get("date_of_birth") else []
        dates_of_birth_parsed = []
        for date in dates_of_birth_iso:
            parsed = parse_date_of_birth(date)
            if parsed.get("year"):
                dates_of_birth_parsed.append(parsed)

        # --- 9. Identifiers/Contacts/Associations (Pass through) ---
        # Direct mapping from your new profile structure
        identifiers = profile.get("identifiers", [])
        contacts = profile.get("contacts", [])
        
        # Link processing (Associations)
        associations = profile.get("associations", [])
        individual_links = []
        business_links = []
        
        for assoc in associations:
            link_obj = {
                "qrCode": self._stable_qrcode(assoc.get("name", "")),
                "name": assoc.get("name"), # For business links
                "firstName": assoc.get("name"), # For individual links (simplified)
                "relationship": assoc.get("relationship"),
                "resourceId": self._sha256_hex(assoc.get("name", "")),
                "datasets": list(active_datasets)
            }
            if assoc.get("is_person", False):
                individual_links.append(link_obj)
            else:
                business_links.append(link_obj)


        # --- 10. Construct Final Data Block ---
        data_block = {
            "qrCode": self._stable_qrcode(resource_id),
            "resourceUri": f"/individuals/{resource_id}",
            "resourceId": resource_id,
            "firstName": parsed_name["first"],
            "fullName": full_name,
            "middleName": parsed_name["middle"],
            "lastName": parsed_name["last"],
            "gender": profile.get("gender"),
            "provider": "AmaniAI",
            "nationality": [profile.get("nationality")] if profile.get("nationality") else [],
            "datesOfBirthParsed": dates_of_birth_parsed,
            "provider_version": int(time.time() * 1000),
            "isDeleted": False,
            "nameAliases": name_aliases,
            "isDeceased": not profile.get("is_active", True),
            "aliases": aliases_struct,
            "datesOfBirthIso": dates_of_birth_iso,
            "datesOfDeathIso": [profile.get("date_of_death")] if profile.get("date_of_death") else [],
            "nationalitiesIsoCodes": [profile.get("nationality")] if profile.get("nationality") else [],
            "addresses": mapped_addresses,
            "profileImages": profile.get("images", []),
            "notes": [{"value": n} for n in profile.get("notes", [])],
            "contactEntries": contacts,
            "identifiers": identifiers,
            "evidences": target_evidences,
            "sanEntries": san_entries,
            "relEntries": rel_entries,
            "rreEntries": rre_entries,
            "poiEntries": poi_entries,
            "insEntries": ins_entries,
            "ddEntries": dd_entries,
            "pepEntries": pep_entries,
            "pepByAssociationEntries": [],
            "individualLinks": individual_links,
            "businessLinks": business_links,
            "griEntries": gri_entries,
            "datasets": list(active_datasets),
        }

        return {"data": data_block,
                "datasets": datasets}