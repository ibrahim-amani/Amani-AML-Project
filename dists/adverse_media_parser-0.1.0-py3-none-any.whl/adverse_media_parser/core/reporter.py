import os
import json
import logging
from datetime import datetime
from typing import List, Dict, Any

class PipelineReporter:
    """
    Handles statistics tracking, failure logging, and summary generation.
    """
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger("Reporter")
        
        self.stats = {
            "urls_processed": 0,
            "urls_with_errors": [],
            "total_files_found": 0,
            "total_chunks_analyzed": 0
        }
        self.processed_json_files: List[str] = []
        self.analyzed_json_files: List[str] = []

    # --- Utility Method ---
    @staticmethod
    def format_duration(seconds: float) -> str:
        """Converts seconds into HH:MM:SS format."""
        seconds = int(seconds)
        hours = seconds // 3600
        remainder = seconds % 3600
        minutes = remainder // 60
        seconds = remainder % 60
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

    # --- Tracking Methods ---
    def track_url(self):
        self.stats["urls_processed"] += 1

    def track_ingestion_success(self, json_paths: List[str]):
        if not json_paths: return
        count = len(json_paths)
        self.stats["total_files_found"] += count
        self.processed_json_files.extend(json_paths)

    def track_analysis_chunk(self, count: int = 1):
        self.stats["total_chunks_analyzed"] += count

    def log_failure(self, url: str, error_message: str, context: str = "general"):
        """Writes failure to JSON immediately."""
        if url not in self.stats["urls_with_errors"]:
            self.stats["urls_with_errors"].append(url)

        entry = {
            "timestamp": datetime.now().isoformat(),
            "url": url,
            "context": context,
            "error": str(error_message)
        }
        
        try:
            log_path = self.config.failure_log_path
            current_data = []
            
            if os.path.exists(log_path):
                try:
                    with open(log_path, 'r', encoding='utf-8') as f:
                        current_data = json.load(f)
                        if not isinstance(current_data, list): current_data = []
                except: current_data = []
            
            current_data.append(entry)
            
            with open(log_path, 'w', encoding='utf-8') as f:
                json.dump(current_data, f, indent=4)
                
        except Exception as e:
            self.logger.error(f"CRITICAL: Failed to write to failure log: {e}")

    def save_summary(self, total_duration_str: str, total_targets: int):
        """Generates final report."""
        summary = {
            "execution_date": datetime.now().isoformat(),
            "pipeline_duration": total_duration_str,
            "statistics": {
                "total_target_urls": total_targets,
                "urls_processed": self.stats["urls_processed"],
                "urls_failed": len(self.stats["urls_with_errors"]),
                "total_files_extracted": self.stats["total_files_found"],
                "total_chunks_analyzed": self.stats["total_chunks_analyzed"]
            },
            "failed_urls_details": self.stats["urls_with_errors"]
        }

        filename = f"pipeline_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        report_path = os.path.join(self.config.results_dir, filename)
        
        try:
            with open(report_path, 'w', encoding='utf-8') as f:
                json.dump(summary, f, indent=4)
            
            self.logger.info("==========================================")
            self.logger.info(f"SUMMARY REPORT: {report_path}")
            self.logger.info(f"Duration: {summary['pipeline_duration']}")
            self.logger.info(f"Files Found: {summary['statistics']['total_files_extracted']}")
            self.logger.info("==========================================")
        except Exception as e:
            self.logger.error(f"Failed to save summary report: {e}")