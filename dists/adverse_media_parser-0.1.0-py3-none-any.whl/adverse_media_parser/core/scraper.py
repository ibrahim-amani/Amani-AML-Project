import json
import os
from pathlib import Path
import re
import time
import requests 
import tldextract
import trafilatura
import urllib3
import logging
import hashlib
from urllib.parse import unquote, urlparse, urljoin, quote
from datetime import datetime
from typing import List, Dict, Optional
from lxml import html
from botasaurus.browser import browser, Driver
import asyncio
from .utils import save_json
from .state_manager import StateManager
from crawl4ai import AsyncWebCrawler, CrawlerRunConfig, BrowserConfig, CacheMode
from crawl4ai.deep_crawling import(
    BestFirstCrawlingStrategy,
    KeywordRelevanceScorer,
    FreshnessScorer,
    CompositeScorer)

from crawl4ai.deep_crawling.filters import (
    FilterChain,
    URLPatternFilter,
    DomainFilter,
    ContentTypeFilter,
    ContentRelevanceFilter
    )

from adverse_media_parser.config.crawler_config import get_crawler_config

# SPECIALIZED SCRAPER IMPORTS
from ..scrapers.cftc_scraper import CftcDispositionsPdfDownloaderScraper
from ..scrapers.efcc_scraper import EfccWantedPersonsScraper
from ..scrapers.pcaob_scraper import PcaobEnforcementScraper
from ..scrapers.uaeiec_scraper import UaeiecSanctionsScraper
from ..scrapers.sanctionsmap_scraper import SanctionsMapScraper
from ..scrapers.jcf_scraper import JcfWantedPersonsScraper
from ..scrapers.belize_scraper import BelizePoliceWantedPersonsScraper

# Suppress SSL Warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ==========================================
# BOTASAURUS TASK (Tier 3: PRO)
# ==========================================

@browser()
def _run_botasaurus_scrape(driver: Driver, data: Dict):
    """
    Standalone Botasaurus task.
    'data' is a dict: {'url': str, 'timeout': int}
    """
    target_url = data.get('url')
    wait_time = data.get('timeout', 10)
    
    print(f"Botasaurus visiting: {target_url} (Timeout: {wait_time}s)")
    
    try:
        driver.get(target_url)
    except Exception as e:
        print(f"Botasaurus Navigation Error: {e}")
        return None
    
    # 1. Solve Captcha
    try:
        driver.short_random_sleep()
        candidates = ["من ربات نیستم", "Verify you are human", "I am not a robot"]
        for text in candidates:
            checkbox = driver.get_element_containing_text(text)
            if checkbox:
                driver.enable_human_mode()
                checkbox.click()
                print("Clicked CAPTCHA. Waiting...")
                driver.disable_human_mode()
                driver.sleep(5)
                break
    except Exception as e:
        print(f"Botasaurus Captcha Error: {e}")

    # 2. Wait for Content (Using Configured Timeout)
    print(f"Waiting up to {wait_time}s for content...")
    try:
        # Wait for any file link
        driver.wait_for_element("a[href*='pdf'], a[href*='files']", wait=wait_time)
        print("Content Loaded!")
    except:
        print("Content wait timed out.")

    driver.scroll_to_bottom()
    driver.sleep(3)
    
    # 3. Extract Session Data
    cookies = driver.get_cookies()
    cookies_dict = {c['name']: c['value'] for c in cookies}
    user_agent = driver.user_agent
    
    return driver.page_html, driver.current_url, cookies_dict, user_agent


# ==========================================
# 2. CRAWL4AI TASK (Tier 2: Advanced)
# ==========================================
async def _crawl4ai_deep_crawl(base_url: str,
                               site_config: Dict = None,
                               cookies: Dict = None,
                               user_agent: str = None,
                               context: Dict = None) -> List[Dict]:
    """
    Uses crawl4ai to find all relevant internal URLs starting from a base URL.
    """
    
    if cookies:
        cookies = [{'name': k, 'value': v, 'url': base_url }for k, v in cookies.items()]#change from dict to list(dict)
    aml_keywords = site_config.get("aml_keywords")

    filter_chain = FilterChain([
        # Only follow URLs with specific patterns
        URLPatternFilter(patterns=site_config.get("url_patterns",[]),),
        
        
        # Only HTML (ignore images/pdfs during crawling)
        ContentTypeFilter(allowed_types=site_config.get("type_filter",[]))
    ])
    # Configure Browser
    if user_agent:
        browser_config = BrowserConfig(
            headless=site_config.get("headless", True), 
            verbose=False,
            user_agent= user_agent,
            cookies=cookies
            )
    else:
        # Configure Browser
        browser_config = BrowserConfig(
            headless=site_config.get("headless", True), 
            verbose=False,
            user_agent_mode="random", 
            )


    kw_scorer = KeywordRelevanceScorer(keywords= aml_keywords, weight=0.7)
    fresh_scorer = FreshnessScorer(weight=0.3, current_year=2025 )

    scorer = CompositeScorer(scorers=[kw_scorer, fresh_scorer])


    deep_crawl_config = BestFirstCrawlingStrategy(
        max_depth=site_config.get('max_depth', 20),
        max_pages=200,
        include_external=False,
        url_scorer=scorer,
        filter_chain=filter_chain
    )

    config = CrawlerRunConfig(
        deep_crawl_strategy=deep_crawl_config,
        exclude_all_images=True,
        remove_overlay_elements=False,
        page_timeout=45000,
        stream=True,
        cache_mode= CacheMode.BYPASS,
        delay_before_return_html=site_config.get("delay",0.0)
    )

    found_urls = set()
    results_list = []
    max_visit = site_config.get('max_pages', 50)
    print(f" Starting crawl on {base_url}...")

    async with AsyncWebCrawler(config=browser_config) as crawler:
        async for result in await crawler.arun(base_url, config=config):
            if result and result.url:
                if result.url not in found_urls:
                    if len(found_urls)< max_visit:
                        # print(f"  -> Found: {str(result._markdown)}")
                        found_urls.add(result.url)
                                                    
                        # --- RICH DATA EXTRACTION ---
                        # Pack all technical details into 'metadata'
                        scraped_metadata = result.metadata or {}
                        scraped_metadata.update({
                            "response_headers": result.response_headers or {},
                            "status_code": result.status_code,
                            "redirected_url": result.redirected_url,
                            "scraped_at": datetime.now().isoformat()
                        })
                        # --- Trafilatura Cleaning ---
                        # Extract clean article text instead of raw HTML/Markdown
                        clean_text = trafilatura.extract(result.html)
                
                        # Standardized Result Object
                        results_list.append({
                            "url": result.url,
                            "type": "html",
                            "html_content": result.html,
                            "clean_text": clean_text, 
                            "context": context or {},
                            "metadata": scraped_metadata or {}
                        })
                    else:
                        break


    return results_list



# ==========================================
# MAIN CLASS
# ==========================================

class WebScraper:
    def __init__(self, config, reporter):
        self.config = config
        self.reporter = reporter
        self.logger = logging.getLogger("Scraper")
        
        # Initialize Session
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': config.user_agent
        })
        self.state_manager = StateManager()

    def find_files(self, target_url: str, initial_context: Dict = None) -> List[Dict]:
        """
        Router: Tier 1 (Requests) -> Tier 2 (Crawl4AI) -> Tier 3 (Botasaurus).
        """
        
        context = initial_context or {}
        # --- SPECIAL  ROUTING ---
        if "www.cftc.gov/LawRegulation/EnforcementActions" in target_url:
            self.logger.info("Detected CFTC Enforcement Actions URL. Routing to Specialized Scraper...")
            return self._run_cftc_scraper(context)
        
        if "efcc.gov.ng" in target_url:
            self.logger.info("Detected EFCC Wanted Persons URL. Routing to Specialized Scraper...")         
            return self._run_efcc_scraper(context)
        
        if "pcaobus.org/oversight/enforcement" in target_url:
            self.logger.info("Detected PCAOB Enforcement page. Routing to Specialized Scraper...")
            return self._run_pcaob_scraper(context)
        
        if "sanctionsmap.eu" in target_url:
            self.logger.info("Detected Sanctions Map EU page. Routing to Specialized Scraper...")
            return self._run_sanctionsmap_scraper(context)
        
        if "jcf.gov.jm" in target_url:
            self.logger.info("Detected JCF Wanted Persons page. Routing to Specialized Scraper...")
            return self._run_jcf_scraper(context)
         
        if "belizepolice.bz" in target_url:
            self.logger.info("Detected Belize Police Wanted Persons page. Routing to Specialized Scraper...")
            return self._run_belize_scraper(context)
        # ----------------------------
        
        self.logger.info("Attempting Tier 1 (Light)...")
        # ---------------------------------------------------------
        # A. TIER 1: FAST LANE
        # ---------------------------------------------------------
        files = self._fast_scrape(target_url, context)
        
        # Case 1: Success (Found Files)
        if files and len(files) > 0:
            self.logger.info(f"Tier 1 success. Found {len(files)} files.")
            return files
            
        # Case 2: Success (No Files) -> Try Advanced Lane
        elif files == []:
            self.logger.info("Tier 1 returned 0 files. Switching to Tier 2 (Advanced/Crawl4AI)...")
            files = self._advanced_scrape(url=target_url, context = context)
            
            if files:
                self.logger.info(f"Tier 2 success. Found {len(files)} relevant pages.")
                return files


        # Case 3: Failed/Blocked (files is None) -> Try Pro Lane
        # (This falls through to below)
        self.logger.warning("Tier 1 Blocked/Failed. Switching to Tier 3 (Pro/Botasaurus)...")

        # ---------------------------------------------------------
        # B. TIER 3: PRO LANE (Botasaurus)
        # ---------------------------------------------------------
        # Note: We return here or fall through to Advanced+Cookies logic
        files = self._pro_scrape(target_url, context)
        
        if files:
            self.logger.info(f"Tier 3 success. Found {len(files)} files.")
            return files
            
        # ---------------------------------------------------------
        # C. TIER 2 REDUX: ADVANCED LANE + COOKIES
        # ---------------------------------------------------------
        # If Botasaurus loaded the page but found no direct files,
        # we assume it's a dynamic app that needs Deep Crawling using the authenticated session.
        
        self.logger.info("Tier 3 found no direct files. Attempting Tier 2 with captured Cookies...")
        
        # Retrieve cookies captured by Botasaurus in _pro_scrape
        cookies = self.session.cookies.get_dict()
        user_agent = self.session.headers.get('User-Agent')
        
        files = self._advanced_scrape(target_url, cookies=cookies, user_agent=user_agent)
        
        if files:
            self.logger.info(f"Tier 2 success. Found {len(files)} pages using auth session.")
            return files
            
        self.reporter.log_failure(target_url, "All Scrapers exhausted (0 files)", "discovery")
        return []
            

    def download_file(self, file_info: Dict) -> Optional[str]:
        """
        Downloads file stream to disk with RETRY LOGIC.
        """
        
        #if file is html download directly from memory.
        url = file_info['url']
        ftype = file_info.get('type', None)
        
        # Combine Excel Context (Business Data) with Scraped Metadata (Technical Data)
        context_data = file_info.get("context") or {}
        scraped_data = file_info.get("metadata") or {}
        
        # Create one rich metadata object for the Processor
        rich_metadata = {**context_data, **scraped_data}
        
        # PATH A: HTML CONTENT (Already in memory)
        if ftype =="html":
            clean_text = file_info["clean_text"]
            # 1. Check Hash: Has this text changed since last time?
            if not self.state_manager.should_process(url, current_content=clean_text):
                self.logger.info(f"Skipping HTML save (Content unchanged): {url}")
                # Update timestamp in state to show we checked it today
                self.state_manager.update_state(url, status="skipped_no_change", content=clean_text)
                return None
            
            ext = f".json"
            html_content = file_info["html_content"]
            filename = self._generate_unique_filename(url, ext)
            save_path = os.path.join(self.config.raw_dir, filename)

    
            file_data = {"url":url,
                         "html_content": html_content,
                         "clean_text": clean_text,
                         "metadata": rich_metadata,
                         "downloaded_at": datetime.now().isoformat()
                         } 
            
            
            try:
                save_json(file_data, save_path)
                    
                self.logger.info(f"Saved: {save_path}")
                return {
                    "path": save_path, 
                    "filename": filename, 
                    "source_url": url, 
                    "type": ftype,
                    "metadata": rich_metadata
                }
            except Exception as e:
                self.logger.error(f"Failed to save HTML file {url}: {e}")
                self.reporter.log_failure(url, str(e), "save_failed")
                return None
        # PATH B: BINARY FILES (PDF, Excel, Images)
        
        # 1. Pre-Flight Check (HEAD Request) to save bandwidth
        remote_etag = None
        remote_last_mod = None
        
        try:
            # Short timeout for HEAD check
            head_resp = self.session.head(url, timeout=5, allow_redirects=True, verify=False)
            remote_etag = head_resp.headers.get('ETag')
            remote_last_mod = head_resp.headers.get('Last-Modified')
            
            # ASK STATE MANAGER: Do we need to download?
            if not self.state_manager.should_download_based_on_headers(url, remote_etag, remote_last_mod):
                
                # RETRIEVE PREVIOUS PATH from State if available
                prev_record = self.state_manager.state.get(url, {})
                prev_path = prev_record.get('meta', {}).get('local_path')
                
                self.state_manager.update_state(url,
                                                status="skipped_no_change",
                                                etag=remote_etag,
                                                last_modified=remote_last_mod,
                                                meta={"local_path": prev_path} )
                
                if prev_path and os.path.exists(prev_path):
                    self.logger.info(f"Skipping download (Content unchanged): {url}")
                    return None
        except Exception as e:
            self.logger.warning(f"Head check failed ({e}). Proceeding to full download.")
            
            
        # Full Download Logic (Retry Loop)
        retries = self.config.max_retries
        delay = self.config.retry_delay
        timeout = self.config.request_timeout

        for attempt in range(retries + 1):
            try:
                self.logger.info(f"Downloading ({ftype}) [Attempt {attempt+1}]: {url}")
                
                # Use persistent session (carries Botasaurus cookies if set)
                response = self.session.get(
                    url, 
                    stream=True, 
                    verify=False, 
                    timeout=timeout
                )
                response.raise_for_status()

                # Add headers to metadata (Last-Modified, Content-Length, etc.)
                rich_metadata["http_headers"] = dict(response.headers)
                                    
                # Generate Filename
                ext = ".pdf"
                if ftype == 'xlsx': ext = ".xlsx"
                elif ftype == 'image':
                    if url.lower().endswith(".png"): ext = ".png"
                    elif url.lower().endswith(".gif"): ext = ".gif"
                    else: ext = ".jpg"

                filename = self._generate_unique_filename(url, ext)
                save_path = os.path.join(self.config.raw_dir, filename)

                # Stream Save
                with open(save_path, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        f.write(chunk)
                
                self.logger.info(f"Saved: {save_path}")

                # 3. UPDATE STATE (Success)
                # We store 'local_path' in meta so we can skip next time and still return the path
                self.state_manager.update_state(
                    url, 
                    status="success", 
                    etag=remote_etag,
                    last_modified=remote_last_mod,
                    meta={"local_path": save_path} 
                )
                
                return {
                    "path": save_path, 
                    "filename": filename, 
                    "source_url": url, 
                    "type": ftype,
                    "metadata": rich_metadata 
                }

            except Exception as e:
                self.logger.warning(f"Download failed on attempt {attempt+1}: {e}")
                if attempt < retries:
                    time.sleep(delay)
                else:
                    self.logger.error(f"All {retries} retries failed for {url}")
                    self.reporter.log_failure(url, str(e), "download_exhausted")
                    return None

    # --- Internal Methods ---
    
    # --- SPECIALIZED HANDLER ---
    def _run_cftc_scraper(self, context: Dict) -> List[Dict]:
        """
        Executes the specialized CFTC scraper (user's code) and ingests the results.
        Uses manifest to map local files back to original URLs.
        """
        try:
            # 1. Run the external logic
            cftc = CftcDispositionsPdfDownloaderScraper()
            asyncio.run(cftc.run())
            
            # 2. Harvest the downloaded files using the Manifest
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            output_dir = os.path.join(base_dir, "data", "outputs", "cftc_dispositions_pdfs")
            files_dir = Path(output_dir) / "files"
            manifest_path = Path(output_dir) / cftc.MANIFEST_FILENAME
            
            found_files = []
            
            if manifest_path.exists():
                urls = manifest_path.read_text(encoding="utf-8").splitlines()
                
                for original_url in urls:
                    if not original_url.strip(): continue
                    
                    # Reconstruct expected local path using scraper logic
                    # logic: files_dir / subdir / filename
                    filename = cftc.sanitize_filename(Path(urlparse(original_url).path).name)
                    subdir = cftc.infer_subdir_from_url(original_url)
                    full_path = files_dir / subdir / filename
                    
                    if full_path.exists():
                        found_files.append({
                            "url": original_url, 
                            "type": "pdf",
                            "context": context,
                            "metadata": {
                                "source_logic": "cftc_special_script",
                                "scraped_at": datetime.now().isoformat(),
                                "local_path": str(full_path) # Pass local path for download_file
                            }
                        })
            
            self.logger.info(f"Ingested {len(found_files)} files from CFTC scraper manifest.")
            return found_files
            
        except Exception as e:
            self.logger.error(f"CFTC Scraper Failed: {e}")
            return []
        
        
        
    def _run_efcc_scraper(self, context: Dict) -> List[Dict]:
        """
        Executes the specialized EFCC scraper and ingests the results.
        Reads the output JSON and creates synthetic file entries.
        """
        try:
            efcc = EfccWantedPersonsScraper()
            asyncio.run(efcc.run())

            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            # Matches the output path logic in BaseScraper/EfccWantedPersonsScraper
            output_dir = os.path.join(base_dir, "data", "outputs", "nigeria_efcc_wanted_persons")
            json_path = Path(output_dir) / "efcc_wanted_persons_full.json"
            
            found_files = []
            
            if json_path.exists():
                data = json.loads(json_path.read_text(encoding="utf-8"))
                entries = data.get("entries", [])

                for i, entry in enumerate(entries):
                    # Construct text for LLM Analysis
                    url = entry.get("image_url", "N/A")
                    name = entry.get("name", "N/A")
                    # Global Page Info
                    scraped_metadata = {
                    "page_title": "EFCC Wanted Persons",
                    "found_on_page": "https://efcc.gov.ng/WantedPersons",
                    "scraped_at": datetime.now().isoformat(),
                    "source_logic": "efcc_special_script",
                    "person_name": name
                    }

                    file_data = {
                        "url": url,
                        "type": "image",
                        "context": context,
                        "metadata": scraped_metadata
                    }
                        
                    found_files.append(file_data)
            
            self.logger.info(f"Ingested {len(found_files)} profiles from EFCC scraper output.")
            return found_files
            
        except Exception as e:
            self.logger.error(f"EFCC Scraper Failed: {e}")
            return []
        
        
    def _run_pcaob_scraper(self, context: Dict) -> List[Dict]:
        """
        Executes the specialized PCAOB scraper and ingests the results.
        Uses manifest.jsonl to map local PDFs.
        """
        try:
            # 1. Run the external logic
            pcaob = PcaobEnforcementScraper()
            pcaob.run() # Sync run

            # 2. Harvest
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            output_dir = os.path.join(base_dir, "data", "outputs", "pcaob_enforcement_actions")
            manifest_path = Path(output_dir) / "manifest.json"
            
            found_files = []
            
            if manifest_path.exists():
                with open(manifest_path, "r", encoding="utf-8") as f:
                    for line in f:
                        if not line.strip(): continue
                        try:
                            doc = json.loads(line)
                            original_url = doc.get("pdf_url")
                            local_pdf = doc.get("local_pdf")
                            
                            # Ensure local path is absolute
                            if local_pdf:
                                full_path = Path(local_pdf).resolve()
                            else:
                                continue # Skip if no local path recorded

                            if full_path.exists():
                                # Add context metadata from scraper + Excel
                                meta = doc.get("meta", {})
                                meta.update({
                                    "source_logic": "pcaob_special_script",
                                    "scraped_at": doc.get("scraped_at_utc"),
                                    "local_path": str(full_path),
                                    "title": doc.get("title")
                                })

                                found_files.append({
                                    "url": original_url, 
                                    "type": "pdf",
                                    "context": context,
                                    "metadata": meta
                                })
                        except Exception as e:
                             self.logger.warning(f"Error parsing PCAOB manifest line: {e}")

            self.logger.info(f"Ingested {len(found_files)} files from PCAOB scraper manifest.")
            return found_files
            
        except Exception as e:
            self.logger.error(f"PCAOB Scraper Failed: {e}")
            return []
        
        
    def _run_uaeiec_scraper(self, context: Dict) -> List[Dict]:
        try:
            uae = UaeiecSanctionsScraper()
            asyncio.run(uae.run())
            
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            output_dir = os.path.join(base_dir, "data", "outputs", "uaeiec_sanctions_lists")
            manifest_path = Path(output_dir) / uae.MANIFEST_FILENAME
            
            found_files = []
            
            if manifest_path.exists():
                with open(manifest_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                
                items = data.get("items", [])
                for item in items:
                    meteada = {k:v for k,v in item.items() if k !='url' and k !='saved_path'}
                    original_url = item.get("url")
                    local_path_str = item.get("saved_path")
                    
                    if local_path_str and os.path.exists(local_path_str):
                         # Dynamically check for excel vs pdf
                         ftype = "pdf"
                         if local_path_str.lower().endswith(".xlsx") or local_path_str.lower().endswith(".xls"):
                             ftype = "xlsx"
                         elif local_path_str.lower().endswith(".csv"):
                             ftype = "csv"
                             
                         found_files.append({
                            "url": original_url,
                            "type": ftype,
                            "context": context,
                            "metadata": {
                                "source_logic": "uaeiec_special_script",
                                "scraped_at": item.get("downloaded_at"),
                                "local_path": str(local_path_str),
                                "original_text": item.get("text")
                            }
                         })
            
            self.logger.info(f"Ingested {len(found_files)} files from UAEIEC scraper manifest.")
            return found_files

        except Exception as e:
            self.logger.error(f"UAEIEC Scraper Failed: {e}")
            return []
        
        
    def _run_sanctionsmap_scraper(self, context: Dict) -> List[Dict]:
        try:
            sm = SanctionsMapScraper()
            sm.run()

            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            # Slug matches SanctionsMapScraper.name logic: "Sanctions Map EU" -> "sanctions_map_eu"
            output_dir = os.path.join(base_dir, "data", "outputs", "sanctions_map_eu")
            manifest_path = Path(output_dir) / sm.MANIFEST_FILENAME
            
            found_files = []
            if manifest_path.exists():
                with open(manifest_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                items = data.get("items", [])
                for item in items:
                    # Check if download succeeded
                    local_path_str = item.get("saved_to")
                    if local_path_str and os.path.exists(local_path_str):
                        found_files.append({
                            "url": item.get("pdf_url"),
                            "type": "pdf",
                            "context": context,
                            "metadata": {
                                "source_logic": "sanctionsmap_special_script",
                                "scraped_at": data.get("downloaded_at"),
                                "local_path": str(local_path_str),
                                "country_category": item.get("country_or_category")
                            }
                        })
            
            self.logger.info(f"Ingested {len(found_files)} files from Sanctions Map scraper manifest.")
            return found_files

        except Exception as e:
            self.logger.error(f"Sanctions Map Scraper Failed: {e}")
            return []


    def _run_jcf_scraper(self, context: Dict) -> List[Dict]:
        """
        Runs JcfWantedPersonsScraper (Text + Image).
        """
        try:
            jcf = JcfWantedPersonsScraper()
            asyncio.run(jcf.run())

            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            # Matches JcfWantedPersonsScraper.name logic: "jamaica_jcf_wanted_persons"
            output_dir = os.path.join(base_dir, "data", "outputs", "jamaica_jcf_wanted_persons")
            json_path = Path(output_dir) / "listing.json"
            
            found_files = []
            with open(json_path, "r", encoding="utf-8") as f:
                for line in f:
                    if not line.strip(): continue
                    try:
                        row = json.loads(line)
                        name = row.get("title", "N/A")
                                                    
                        # Image Entry (Triggers Download)
                        img_url = row.get("image_url")
                        if img_url:
                            found_files.append({
                                "url": img_url,
                                "type": "image",
                                "context": context,
                                "metadata": {
                                    "source_logic": "jcf_special_script",
                                    "scraped_at": row.get("scraped_at_utc"),
                                    "person_name": name,
                                    "detail_url": row.get("detail_url")
                                }
                            })

                    except Exception as e:
                            self.logger.warning(f"JCF JSONL Parse Error: {e}")

            self.logger.info(f"Ingested {len(found_files)} items from JCF scraper output.")
            return found_files
        
        except Exception as e:
            self.logger.error(f"JCF Scraper Failed: {e}")
            return []        


    def _run_belize_scraper(self, context: Dict) -> List[Dict]:
        try:
            belize = BelizePoliceWantedPersonsScraper()
            asyncio.run(belize.run())
            base_dir = os.path.dirname(os.path.abspath(__file__))
            # Matches BelizePoliceWantedPersonsScraper.name logic: "Belize Police – Wanted Persons" -> "belize_police_wanted_persons"
            output_dir = os.path.join(base_dir, "outputs", "belize_police_wanted_persons")
            json_path = Path(output_dir) / "listing.json"
            found_files = []
            with open(json_path, "r", encoding="utf-8") as f:
                for line in f:
                    if not line.strip(): continue
                    try:
                        row = json.loads(line)
                        name = row.get("title", "N/A")
                        # Image Entry (Triggers Download)
                        img_url = row.get("image_url")
                        if img_url:
                            found_files.append({
                                "url": img_url,
                                "type": "image",
                                "context": context,
                                "metadata": {
                                    "source_logic": "jcf_special_script",
                                    "scraped_at": row.get("scraped_at_utc"),
                                    "person_name": name,
                                    "detail_url": row.get("detail_url")
                                }
                            })
                    except Exception as e:
                        self.logger.warning(f"Belize JSONL Parse Error: {e}")
            self.logger.info(f"Ingested {len(found_files)} items from Belize scraper output.")
            return found_files
        except Exception as e:
            self.logger.error(f"Belize Scraper Failed: {e}")
            return []
    
                
    def _fast_scrape(self, url: str, context: Dict =None) -> List[Dict]:
        """Requests + LXML with Retry Logic."""
        retries = self.config.max_retries
        timeout = self.config.request_timeout
        blocked = False
        for attempt in range(retries + 1):
            try:
                # Head Check
                try:
                    h = self.session.head(url, allow_redirects=True, timeout=10, verify=False)
                    ct = h.headers.get('Content-Type', '').lower()
                    if 'pdf' in ct or url.endswith('.pdf'): return [{"url": url, "type": "pdf", "context":context}]
                    if 'excel' in ct or 'spreadsheet' in ct: return [{"url": url, "type": "xlsx", "context":context}]
                    if 'jpg' in ct or 'image' in ct or 'png' in ct: return [{"url": url, "type": "image", "context":context}]
                except: pass

                # Scrape
                self.logger.info(f"Fast Scraping [Attempt {attempt+1}]...")
                resp = self.session.get(url, verify=False, timeout=timeout)
                # Check if we got a CAPTCHA page (Soft Block)
                if self._is_blocked(resp.text):
                    self.logger.warning("Soft Block (Captcha) Detected in Tier 1.")
                    blocked = True
                    raise Exception("Soft Block - Captcha Page")
                    
                return self._parse_html(resp.content, url, context)
            
            except Exception as e:
                self.logger.warning(f"Fast scrape error: {e}")
                if attempt < retries and not blocked:
                    time.sleep(self.config.retry_delay)
                else:
                    break
        return None

        
    def _advanced_scrape(self, url: str,
                         cookies: Dict = None ,
                         user_agent :str = None,
                         context: Dict = None) -> List[Dict]:
        """
        Tier 2: Crawl4AI Deep Scrape -> Parse Results.
        """
        
        self.logger.info("Loading Crawler Config...")
        site_config = get_crawler_config(url)
        

        site_config['max_depth'] = getattr(self.config, 'crawl_max_depth')
        site_config['max_pages'] = getattr(self.config, 'crawl_max_pages')
        site_config['aml_keywords'] = self.config.risk_keywords
        self.logger.info(f"Running Crawl4AI Deep Crawl on {url} (Depth: {site_config['max_depth']})...")
            
        # Run Crawler (Async)
        found_results = asyncio.run(_crawl4ai_deep_crawl(url, site_config,cookies,user_agent,context))
            
            

        return found_results

        
        
        
        
    def _pro_scrape(self, url: str, context: Dict = None) -> List[Dict]:
        """Botasaurus Wrapper."""
        try:
            # Prepare data payload
            task_data = {
                "url": url, 
                "timeout": self.config.browser_wait_timeout
            }
            
            # Run Task
            result = _run_botasaurus_scrape(task_data)
            
            if not result: return []
            
            html_content, current_url, cookies, user_agent = result
            
            # UPDATE SESSION with new credentials
            self.session.cookies.update(cookies)
            self.session.headers.update({'User-Agent': user_agent})
            
            return self._parse_html(html_content, current_url, context)
        except Exception as e:
            self.logger.error(f"Pro scrape error: {e}")
            self.reporter.log_failure(url, str(e), "browser_crash")
            return []
        
                
        
    def _parse_html(self, content, base_url, context) -> List[Dict]:
        """Shared Parsing Logic."""
        try:
            doc = html.fromstring(content)
        except: return []
        
        # 1. Extract Global Page Info
        page_title = ""
        try: page_title = doc.findtext(".//title").strip()
        except: pass
        
        page_h1 = ""
        try: 
            h1s = doc.xpath("//h1")
            if h1s: page_h1 = h1s[0].text_content().strip()
        except: pass
        
        meta_desc = ""
        try: 
            descs = doc.xpath("//meta[@name='description']/@content")
            if descs: meta_desc = descs[0].strip()
        except: pass
        
        found = []
        seen = set()

        # Special Case: Bahamas Wanted Suspects
        # Hardcoded logic to find images
        if "royalbahamaspolice.org/wantedsuspects" in base_url:
            self.logger.info("Detected Bahamas Wanted Suspects page. Scanning for images...")
            img_nodes = doc.xpath('//div[@id="missing"]//img[contains(@class, "missingimage")]')
            for img in img_nodes:
                src = img.get("src")
                if not src: continue
                
                full_url = urljoin(base_url, src)
                if full_url in seen: continue
                
                # Bundle Metadata for Image
                scraped_metadata = {
                    "page_title": page_title,
                    "page_header": page_h1,
                    "found_on_page": base_url,
                    "scraped_at": datetime.now().isoformat(),
                    "source_logic": "bahamas_hardcoded"
                }
                
                found.append({
                    "url": full_url,
                    "type": "image", 
                    "context": context,
                    "metadata": scraped_metadata
                })
                seen.add(full_url)
                
        # 2. General File Link Extraction
        else:        
            for el in doc.xpath('//a[@href]'):
                href = el.get('href')
                if not href:
                    continue

                href = href.strip()
                full_url = urljoin(base_url, href)

                try:
                    parsed = urlparse(full_url)
                    clean = quote(unquote(parsed.path))
                    full_url = parsed.scheme + "://" + parsed.netloc + clean
                    if parsed.query:
                        full_url += "?" + parsed.query
                except:
                    pass

                if full_url in seen:
                    continue

                # Heuristics
                path = urlparse(full_url).path.lower()
                text = el.text_content().strip().lower()
                is_pdf_icon = bool(el.xpath('.//i[contains(@class, "pdf") or contains(@class, "download")]'))
                is_wp = ("wpdmdl" in (parsed.query or "")) or ("download" in path)

                ftype = None
                if path.endswith('.pdf'):
                    ftype = 'pdf'
                elif path.endswith(('.xlsx', '.xls', '.csv')):
                    ftype = 'xlsx'
                elif is_wp or "getfile" in path:
                    if is_pdf_icon or "pdf" in text or "download" in text:
                        ftype = 'pdf'
                    elif "excel" in text or "xls" in text:
                        ftype = 'xlsx'
                elif "files/sanction" in path and ("pdf" in text or "designation" in text):
                    ftype = 'pdf'
                elif is_pdf_icon:
                    ftype = 'pdf'

                if ftype:
                    # Extract Nearby Text (Context)
                    parent = el.getparent()
                    nearby_text = parent.text_content().strip() if parent is not None else ""
                    if len(nearby_text) > 300:
                        nearby_text = nearby_text[:300] + "..."

                    file_metadata = ({
                        "page_title": page_title,
                        "page_header": page_h1,
                        "page_summary": meta_desc,
                        "link_text": text,
                        "nearby_context": nearby_text,
                        "found_on_page": base_url,
                        "scraped_at": datetime.now().isoformat()
                    })

                    found.append({
                        "url": full_url, 
                        "type": ftype,
                        "context": context,
                        "metadata": file_metadata 
                    })
                    seen.add(full_url)
        
        self.logger.info(f"Found {len(found)} files.")
        return found

    def _generate_unique_filename(self, url: str, extension: str = ".pdf") -> str:
        """
        Generates a unique filename.
        - Handles standard files: site.com/report.pdf -> 20251124_site_report.pdf
        - Handles dynamic files: site.com/get?id=123 -> 20251124_site_get_123.pdf
        """
        domain_name = tldextract.extract(url).domain

        # 1. Parse URL components
        parsed = urlparse(url)
        path_name = unquote(parsed.path.split('/')[-1])

        # 2. Handle Query Parameters (The Fix for CySEC)
        # If the path is generic (like 'GetFile.aspx' or 'download'), append the query params
        clean_path_name = os.path.splitext(path_name)[0].lower()
        
        # If query params exist, use them to make it unique
        if parsed.query:
            # sanitize query string (remove = & chars)
            query_slug = re.sub(r'[^a-zA-Z0-9_-]', '_', parsed.query)
            # Shorten if too long
            if len(query_slug) > 50:
                query_slug = query_slug[:50]
            
            final_name = f"{clean_path_name}_{query_slug}"
        else:
            # Fallback: If no query, hash the full URL to ensure uniqueness
            url_hash = hashlib.md5(url.encode()).hexdigest()[:8]
            final_name = f"{clean_path_name}_{url_hash}"
            

        # 3. Ensure Extension
        if not final_name.lower().endswith(extension):
            final_name += extension
    
        timestamp_prefix = datetime.now().strftime("%Y%m%d") 
    
        # 4. Final Sanitize
        clean_final_name = re.sub(r'[^a-zA-Z0-9_.-]', '_', final_name)
    
        return f"{timestamp_prefix}_{domain_name}_{clean_final_name}"
    
    def _is_blocked(self, html_content: str) -> bool:
        """Checks text for common soft-block signatures."""
        if not html_content: return False
        content_lower = html_content.lower()
        triggers = [
            "verify you are human",
            "checking your browser",
            "challenges.cloudflare.com",
            "security check",
            "please turn javascript on",
            "access denied",
            "attention required",
            "ddos protection"
        ]
        return any(t in content_lower for t in triggers)