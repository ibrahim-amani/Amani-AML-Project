from typing import List, Dict, Optional

class SourceRegistry:
    """
    Central database of all Adverse Media sources.
    Replaces 'AML - Data Sources.xlsx'.
    """
    
    # The clean, hardcoded data from your Excel file
    SOURCES = {
        "eu_consolidated": {
            "name": "EU Consolidated List",
            "provider": "European Commission",
            "url": "https://www.sanctionsmap.eu/#/main",
            "region": "European Union",
            "type": "sanEntries"
        },
        "uae_national_sanctions": {
            "name": "UAE National Sanctions List",
            "provider": "International Economic Council",
            "url": "https://www.uaeiec.gov.ae/en-us/un-page",
            "region": "UAE",
            "type": "sanEntries"
        },
        "uk_iran_financial": {
            "name": "Iran financial sanctions",
            "provider": "HM Treasury (OFSI)",
            "url": "https://assets.publishing.service.gov.uk/media/6908b7e014e0c1d978417560/Iran.pdf",
            "region": "United Kingdom",
            "type": "sanEntries"
        },
        "algeria_bank_press": {
            "name": "Press Releases",
            "provider": "Bank of Algeria",
            "url": "https://www.bank-of-algeria.dz/#https://www.bank-of-algeria.dz/stoodroa",
            "region": "Algeria",
            "type": "rreEntries"
        },
        "kenya_eacc_corruption": {
            "name": "Corruption Investigations",
            "provider": "Ethics and Anti-Corruption Commission",
            "url": "https://eacc.go.ke/en/default/news-updates/",
            "region": "Kenya",
            "type": "rreEntries"
        },
        "bahamas_wanted": {
            "name": "Bahamas Wanted Suspects",
            "provider": "Royal Bahamas Police Force",
            "url": "https://www.royalbahamaspolice.org/wantedsuspects/",
            "region": "Bahamas",
            "type": "relEntries"
        },
        "belize_wanted": {
            "name": "Wanted Persons",
            "provider": "Belize Police Department",
            "url": "https://www.belizepolice.bz/wanted-persons/",
            "region": "Belize",
            "type": "relEntries"
        },
        "colombia_fiscalia": {
            "name": "Noticias - Wanted Criminals",
            "provider": "Fiscalía General",
            "url": "https://www.fiscalia.gov.co/colombia/en/todas-las-noticias/",
            "region": "Colombia",
            "type": "relEntries"
        },
        "cyprus_cysec_sanctions": {
            "name": "Administrative Sanctions",
            "provider": "CySEC",
            "url": "https://www.cysec.gov.cy/el-GR/public-info/administrative-sanctions/",
            "region": "Cyprus",
            "type": "relEntries"
        },
        "india_nse_defaulters": {
            "name": "Expelled/Defaulter Members",
            "provider": "National Stock Exchange (NSE)",
            "url": "https://www.nseindia.com/static/complaints/defaulter-expelled-members",
            "region": "India",
            "type": "relEntries"
        },
        "jamaica_wanted": {
            "name": "Wanted Persons",
            "provider": "Jamaica Constabulary Force",
            "url": "https://jcf.gov.jm/missing-person-3/missing-person-2/",
            "region": "Jamaica",
            "type": "relEntries"
        },
        "lithuania_vtek": {
            "name": "Decisions & Investigations",
            "provider": "Chief Official Ethics Commission",
            "url": "https://vtek.lt/paieskos-rezultatai/",
            "region": "Lithuania",
            "type": "relEntries"
        },
        "malaysia_macc": {
            "name": "Corruption Offenders Database",
            "provider": "Anti-Corruption Commission",
            "url": "https://www.sprm.gov.my/offenders",
            "region": "Malaysia",
            "type": "relEntries"
        },
        "malaysia_bnm_alert": {
            "name": "Financial Consumer Alert List",
            "provider": "Bank Negara Malaysia",
            "url": "https://www.bnm.gov.my/financial-consumer-alert-list",
            "region": "Malaysia",
            "type": "relEntries"
        },
        "nigeria_efcc_wanted": {
            "name": "Nigeria EFCC Most Wanted",
            "provider": "Economic and Financial Crimes Commission",
            "url": "https://efcc.gov.ng/efcc_site/Wanted",
            "region": "Nigeria",
            "type": "relEntries"
        },
        "pakistan_secp_warnings": {
            "name": "Public Warnings/Alerts",
            "provider": "Securities & Exchange Commission",
            "url": "https://www.secp.gov.pk/investigation-and-reports/stock-market-crisis-2008/",
            "region": "Pakistan",
            "type": "relEntries"
        },
        "sweden_fi_alerts": {
            "name": "Unauthorized Firms List",
            "provider": "Swedish Financial Supervisory Authority",
            "url": "https://www.fi.se/en/our-registers/investor-alerts/",
            "region": "Sweden",
            "type": "relEntries"
        },
        "trinidad_fiu_dereg": {
            "name": "List of de-registrants",
            "provider": "Financial Intelligence Unit (FIU)",
            "url": "https://fiu.gov.tt/wp-content/uploads/2025/10/LIST-OF-DE-REGISTRANTS-AS-AT-September-30-2025.pdf",
            "region": "Trinidad & Tobago",
            "type": "relEntries"
        },
        "uk_fca_warnings": {
            "name": "Warnings (Unauthorized Firms)",
            "provider": "Financial Conduct Authority (FCA)",
            "url": "https://www.fca.org.uk/consumers/warning-list-unauthorised-firms",
            "region": "United Kingdom",
            "type": "relEntries"
        },
        "uk_ofsi_penalties": {
            "name": "Monetary Penalties",
            "provider": "HM Treasury (OFSI)",
            "url": "https://www.gov.uk/government/collections/enforcement-of-financial-sanctions#Svarog",
            "region": "United Kingdom",
            "type": "relEntries"
        },
        "us_cftc_enforcement": {
            "name": "CFTC Enforcement Actions",
            "provider": "Commodity Futures Trading Commission",
            "url": "https://www.cftc.gov/LawRegulation/EnforcementActions/index.htm",
            "region": "United States",
            "type": "relEntries"
        },
        "us_pcaob_orders": {
            "name": "PCAOB Enforcement Orders",
            "provider": "Public Company Accounting Oversight Board",
            "url": "https://pcaobus.org/oversight/enforcement/enforcement-actions",
            "region": "United States",
            "type": "relEntries"
        },
        "us_finra_disciplinary": {
            "name": "Disciplinary Actions",
            "provider": "FINRA",
            "url": "https://www.finra.org/rules-guidance/oversight-enforcement/disciplinary-actions",
            "region": "United States",
            "type": "relEntries"
        },
        "kyrgyzstan_sfis_highrisk": {
            "name": "List of High Risk Countries",
            "provider": "State Financial Intelligence Service",
            "url": "https://fiu.gov.kg/sked/3",
            "region": "Kyrgyzstan",
            "type": "poiEntries"
        }
    }

    @classmethod
    def list_keys(cls) -> List[str]:
        return list(cls.SOURCES.keys())

    @classmethod
    def get_source(cls, key: str) -> Dict:
        if key not in cls.SOURCES:
            raise ValueError(f"Source key '{key}' not found.")
        return cls.SOURCES[key]

    @classmethod
    def get_all(cls) -> Dict[str, Dict]:
        return cls.SOURCES