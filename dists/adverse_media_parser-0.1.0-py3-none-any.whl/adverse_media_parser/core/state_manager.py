import json
import hashlib
import os
from datetime import datetime, timedelta
from typing import Optional, Dict, Any

class StateManager:
    """
    Manages the state of the scraping pipeline to prevent redundant processing.
    Tracks URLs, timestamps, and content hashes in a JSON file.
    """

    def __init__(self, state_file: str = "data/pipeline_state.json"):
        self.state_file = state_file
        self.state = self._load_state()

    def _load_state(self) -> Dict[str, Any]:
        """Loads the state file or returns an empty dict if it doesn't exist."""
        if os.path.exists(self.state_file):
            try:
                with open(self.state_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                print(f"[Warning] State file {self.state_file} corrupted. Starting fresh.")
                return {}
        return {}

    def _save_state(self):
        """Persists the current state to disk."""
        os.makedirs(os.path.dirname(self.state_file), exist_ok=True)
        with open(self.state_file, 'w', encoding='utf-8') as f:
            json.dump(self.state, f, indent=4)

    def compute_hash(self, content: str) -> str:
        """Generates a SHA-256 hash of the content string."""
        if not content:
            return ""
        return hashlib.sha256(content.encode('utf-8')).hexdigest()

    def should_process(self, url: str, current_content: str = None, expiration_hours: int = 24) -> bool:
        """
        Determines if a URL needs processing.
        Returns True if:
        1. URL is new.
        2. Content has changed (if current_content is provided).
        3. Last scrape was older than expiration_hours.
        """
        if url not in self.state:
            return True

        record = self.state[url]
        last_scraped_str = record.get('last_scraped')
        stored_hash = record.get('content_hash')

        # Check Expiration (Time-based re-scrape)
        if last_scraped_str:
            last_scraped = datetime.fromisoformat(last_scraped_str)
            if datetime.now() - last_scraped > timedelta(hours=expiration_hours):
                # Even if expired, we might skip if content matches (see below)
                pass 
            else:
                # Not expired yet
                return False

        # Check Content (if we have the new content ready to compare)
        if current_content:
            current_hash = self.compute_hash(current_content)
            if current_hash == stored_hash:
                print(f"[Info] Content unchanged for {url}. Skipping.")
                return False
        
        return True

    def should_download_based_on_headers(self, url: str, remote_etag: str, remote_last_mod: str) -> bool:
        """
        Compares remote headers (ETag / Last-Modified) against stored state.
        Returns False (skip download) ONLY if headers match exactly.
        """
        if url not in self.state:
            return True  # New URL, always download

        record = self.state[url]
        stored_etag = record.get('etag')
        stored_last_mod = record.get('last_modified')

        # 1. Check ETag (Strong Validator)
        if remote_etag and stored_etag:
            if remote_etag == stored_etag:
                return False  # Match! Skip download.
        
        # 2. Check Last-Modified (Weak Validator)
        if remote_last_mod and stored_last_mod:
            if remote_last_mod == stored_last_mod:
                return False  # Match! Skip download.

        # If headers are missing or don't match, we must download to be safe.
        return True

    def update_state(self, url: str, status: str, content: str = None, 
                     etag: str = None, last_modified: str = None, meta: dict = None):
        """
        Updated to store HTTP headers.
        """
        current_hash = self.compute_hash(content) if content else None
        
        # Preserve existing data if not provided
        if not current_hash and url in self.state:
            current_hash = self.state[url].get('content_hash')
        
        # Merge new headers with old ones (if new ones are None, keep old? No, usually overwrite)
        # But for safety, if the server stops sending headers, we might want to be careful.
        # For now, let's just save what we get.
        
        self.state[url] = {
            "last_scraped": datetime.now().isoformat(),
            "status": status,
            "content_hash": current_hash,
            "etag": etag,               # <--- New Field
            "last_modified": last_modified, # <--- New Field
            "meta": meta or {}
        }
        self._save_state()

    def get_last_status(self, url: str) -> Optional[str]:
        return self.state.get(url, {}).get("status")