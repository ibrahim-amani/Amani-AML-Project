import os
import json
from typing import Optional, Any


def load_json(filepath: str, encoding: str = 'utf-8') -> Optional[Any]:
    if not os.path.exists(filepath):
        print(f"Error: File not found at {filepath}")
        return None
    with open(filepath, 'r', encoding=encoding) as f:
        return json.load(f)

def save_json(data: Any, filepath: str, indent: int = 4, encoding: str = 'utf-8') -> bool:
    try:
        directory = os.path.dirname(filepath)
        if directory:
            os.makedirs(directory, exist_ok=True)
        with open(filepath, 'w', encoding=encoding) as f:
            json.dump(data, f, indent=indent, ensure_ascii=False)
        print(f"JSON saved to: {filepath}")
        return True
    except Exception as e:
        print(f"Error saving JSON: {e}")
        return False
