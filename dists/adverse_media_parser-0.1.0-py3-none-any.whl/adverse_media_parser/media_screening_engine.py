import os
import logging
import time
from typing import List, Optional

# --- Relative Imports (Package Internal) ---
from .config.config import Config
from .core.scraper import WebScraper
from .core.processor import FileProcessor
from .core.analyzer import AdverseMediaAnalyzer
from .core.reporter import PipelineReporter
from .core.logging_setup import setup_colored_logging
from .core.source_registry import SourceRegistry  # <--- NEW IMPORT

def orchestrate_screening_cycle(target_keys: Optional[List[str]] = None, dry_run: bool = False):
    """
    Main Orchestrator: Coordinates the Adverse Media Screening lifecycle.
    Flow: Discovery -> Ingestion -> LLM Analysis -> Profiles Building.
    
    Args:
        target_keys: List of specific keys to run (e.g. ['us_cftc']). 
                     If None, defaults to ALL sources in registry.
        dry_run: If True, skips actual scraping and heavy processing.
    """
    # 1. Initialize Colored Logging
    setup_colored_logging(level=logging.INFO)
    logger = logging.getLogger("ScreeningEngine")
    logging.getLogger("pdfminer").setLevel(logging.ERROR)

    # 2. Setup Configuration & Reporter
    config = Config()
    reporter = PipelineReporter(config)
    
    # 3. Initialize Domain Workers
    scraper = WebScraper(config, reporter)
    processor = FileProcessor(config, reporter)
    
    # 4. Determine Targets (Replaces Excel Logic)
    if not target_keys:
        logger.info("No specific targets provided. Loading ALL from Registry.")
        target_keys = SourceRegistry.list_keys()
    
    logger.info(f"Loaded {len(target_keys)} screening targets from Source Registry.")

    # --- GLOBAL TIMER START ---
    global_start = time.time()

    # ==========================================
    # PHASE 1: INGESTION (Scrape -> Download -> Extract)
    # ==========================================
    logger.info("=== INITIALIZING PHASE 1: MEDIA INGESTION ===")
    ingestion_start = time.time()
    
    # NEW LOOP: Iterate over Keys instead of Excel Rows
    for key in target_keys:
        try:
            source_config = SourceRegistry.get_source(key)
            url = source_config['url']
            
            logger.info(f"--- Engaging Target: {key} ({url}) ---")
            reporter.track_url()
            
            # --- DRY RUN CHECK ---
            if dry_run:
                logger.info(f"   [DRY RUN] Would scrape: {url}")
                logger.info(f"   [DRY RUN] Metadata: {source_config}")
                continue  # Skip to next target
            
            # A. Discovery
            # We pass the whole source_config as metadata context
            found_files = scraper.find_files(url, initial_context=source_config)
            
            if not found_files:
                continue 

            # B. Processing
            for file_info in found_files:
                # 1. Download
                download_result = scraper.download_file(file_info)
                
                if download_result:
                    # 2. Pre-process (Extract Text)
                    json_path = processor.pre_process(
                        file_path=download_result['path'],
                        filename=download_result['filename'],
                        source_url=download_result['source_url'],
                        file_type=download_result['type'],
                        metadata=download_result['metadata']
                    )
                    
                    if json_path:
                        reporter.track_ingestion_success([json_path])
        
        except Exception as e:
            logger.error(f"Critical failure on target {key}: {e}")
            continue

    ingestion_duration = time.time() - ingestion_start
    ingestion_duration_str = reporter.format_duration(ingestion_duration)
    reporter.stats["ingestion_duration"] = ingestion_duration_str
    
    logger.info(f"=== PHASE 1 COMPLETE. Duration: {ingestion_duration_str}. Files Staged: {len(reporter.processed_json_files)} ===")

    # ==========================================
    # PHASE 2: INTELLIGENCE ANALYSIS (LLM Classification)
    # ==========================================
    # Only run Phase 2 if we actually have files AND it's not a dry run
    if reporter.processed_json_files and not dry_run:
        logger.info("=== INITIALIZING PHASE 2: INTELLIGENCE ANALYSIS ===")
        analysis_phase_start = time.time()
        
        analyzer = AdverseMediaAnalyzer(config, reporter)
        
        # A. LLM Inference Loop
        for json_path in reporter.processed_json_files:
            analysis_filename = os.path.splitext(os.path.basename(json_path))[0] + "_analysis.json"
            analysis_path = config.results_dir / analysis_filename
            
            if analysis_path.exists():
                logger.info(f"Analysis artifact exists for {os.path.basename(json_path)}. Skipping inference.")
                continue
                
            success = analyzer.analyze_file(str(json_path))
            if not success:
                logger.warning(f"Analysis failed for {os.path.basename(json_path)}")
        
        # B. Post-Processing & Schema Mapping Loop
        logger.info("--- executing schema mapping & standardization ---")
        for json_path in reporter.processed_json_files:
            base_name = os.path.splitext(os.path.basename(json_path))[0]
            analysis_path = config.results_dir / f"{base_name}_analysis.json"
            golden_path = config.final_dir / f"{base_name}_final.json"
            
            if analysis_path.exists():
                # Post-process the LLM output (clean up logic)
                processor.post_process_analysis(str(analysis_path))
                
                # Map to Golden Record Schema (if not already done)
                if not golden_path.exists():
                    processor.create_target_schema(str(golden_path))

        analysis_duration = time.time() - analysis_phase_start
        analysis_duration_str = reporter.format_duration(analysis_duration)
        reporter.stats["analysis_duration"] = analysis_duration_str
        
        logger.info(f"=== PHASE 2 COMPLETE. Duration: {analysis_duration_str} ===")
                
    elif dry_run:
        logger.info("=== PHASE 2 SKIPPED (DRY RUN MODE) ===")
    else:
        logger.info("No staged files found. Skipping Phase 2.")
        
    # ==========================================
    # REPORTING
    # ==========================================
    total_duration = reporter.format_duration(time.time() - global_start)
    reporter.save_summary(total_duration, len(target_keys))
    logger.info("=== SCREENING CYCLE COMPLETED SUCCESSFULLY ===")

if __name__ == "__main__":
    # Default behavior if run directly: Run everything
    orchestrate_screening_cycle()