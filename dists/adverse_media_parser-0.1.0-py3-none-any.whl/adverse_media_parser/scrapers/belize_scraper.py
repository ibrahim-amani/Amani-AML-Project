from __future__ import annotations

import asyncio
import json
import re
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from urllib.parse import urljoin

from bs4 import BeautifulSoup
from crawl4ai import AsyncWebCrawler, BrowserConfig, CrawlerRunConfig

from ..core.base_scraper import BaseScraper

@dataclass
class GalleryItem:
    title: str
    full_image_url: str
    thumb_url: Optional[str]
    detail_url: str


class BelizePoliceWantedPersonsScraper(BaseScraper):
    """
    Scrapes Belize Police Wanted Persons.
    """
    name = "Belize Police – Wanted Persons"
    BASE_URL = "https://www.belizepolice.bz/wanted-persons/"
    OUTPUT_FILENAME = "listing.json"

    # ------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------
    def utc_now_iso(self) -> str:
        return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")

    def stable_id(self, value: str) -> str:
        return uuid.uuid5(uuid.NAMESPACE_URL, value).hex

    def safe_get_attr(self, tag, attr: str) -> str:
        if not tag:
            return ""
        return (tag.get(attr) or "").strip()

    def pick_best_from_srcset(self, srcset: str) -> Optional[str]:
        if not srcset:
            return None

        candidates: List[Tuple[int, str]] = []
        for part in srcset.split(","):
            part = part.strip()
            if not part:
                continue

            chunks = part.split()
            url = chunks[0].strip()

            w = 0
            if len(chunks) > 1:
                m = re.match(r"(\d+)w", chunks[1].strip())
                if m:
                    w = int(m.group(1))

            candidates.append((w, url))

        if not candidates:
            return None

        candidates.sort(key=lambda x: x[0], reverse=True)
        return candidates[0][1]

    def parse_total_pages(self, html_content: str) -> int:
        soup = BeautifulSoup(html_content, "html.parser")
        meta = soup.select_one("nav.pagination span.pagination-meta")
        if not meta:
            return 1

        txt = meta.get_text(" ", strip=True)
        m = re.search(r"Page\s+\d+\s+of\s+(\d+)", txt, flags=re.IGNORECASE)
        if not m:
            return 1

        return max(1, int(m.group(1)))

    def extract_gallery_items(self, html_content: str, base_url: str) -> List[GalleryItem]:
        soup = BeautifulSoup(html_content, "html.parser")
        items: List[GalleryItem] = []

        for a in soup.select("div.ngg-galleryoverview div.ngg-gallery-thumbnail a"):
            href = self.safe_get_attr(a, "href")
            data_src = self.safe_get_attr(a, "data-src")
            data_thumb = self.safe_get_attr(a, "data-thumbnail")
            data_title = self.safe_get_attr(a, "data-title")

            img = a.select_one("img")
            img_src = self.safe_get_attr(img, "src")
            img_title = self.safe_get_attr(img, "title")
            img_alt = self.safe_get_attr(img, "alt")

            # The full image is usually in href or data-src
            full = href or data_src
            if not full:
                continue
            full = urljoin(base_url, full)

            # Thumb
            thumb = data_thumb or img_src
            thumb = urljoin(base_url, thumb) if thumb else None

            # Title / Name
            title = data_title or img_title or img_alt
            title = title.strip()

            # Fallback title from filename if empty
            if not title:
                title = full.split("/")[-1].rsplit(".", 1)[0]

            # Detail URL - In this gallery structure, the "detail" is often just the image itself 
            # or the gallery page. We'll use the full image URL as the unique detail pointer 
            # unless a specific profile link exists.
            detail_url = full

            items.append(GalleryItem(title=title, full_image_url=full, thumb_url=thumb, detail_url=detail_url))

        return items

    def build_page_url(self, page_num: int) -> str:
        if page_num <= 1:
            return self.BASE_URL
        return f"{self.BASE_URL}?avia-element-paging={page_num}"

    # ------------------------------------------------------------
    # Crawl4AI fetch
    # ------------------------------------------------------------
    async def fetch_html(self, crawler: AsyncWebCrawler, url: str) -> str:
        run_cfg = CrawlerRunConfig(
            wait_until="domcontentloaded",
            wait_for="css:div.ngg-galleryoverview",
            wait_for_timeout=90000,
            page_timeout=90000,
            delay_before_return_html=1.0,
        )
        res = await crawler.arun(url, config=run_cfg)
        if not res.success:
            print(f"[WARN] Failed to fetch {url}: {res.error_message}")
            return ""
        return res.html or ""

    # ------------------------------------------------------------
    # Main
    # ------------------------------------------------------------
    async def scrape_all(self):
        out_dir = self.ensure_out_dir()
        out_file = out_dir / self.OUTPUT_FILENAME

        browser_cfg = BrowserConfig(
            headless=True,
            browser_type="chromium",
        )

        async with AsyncWebCrawler(config=browser_cfg) as crawler:
            first_url = self.build_page_url(1)
            first_html = await self.fetch_html(crawler, first_url)
            
            if not first_html:
                print("[ERR] Could not fetch first page.")
                return

            total_pages = self.parse_total_pages(first_html)
            print(f"[OK] total_pages={total_pages}")

            all_rows: List[Dict] = []
            seen: set[str] = set()

            for page_num in range(1, total_pages + 1):
                page_url = self.build_page_url(page_num)
                print(f"[*] Fetch page {page_num}/{total_pages}: {page_url}")

                html_content = first_html if page_num == 1 else await self.fetch_html(crawler, page_url)
                if not html_content:
                    continue

                items = self.extract_gallery_items(html_content, page_url)
                print(f"    - items found: {len(items)}")

                for it in items:
                    rid = self.stable_id(it.full_image_url)
                    if rid in seen:
                        continue
                    seen.add(rid)

                    row = {
                        "id": rid,
                        "title": it.title,
                        "detail_url": it.detail_url, # Points to image usually
                        "image_url": it.full_image_url,
                        "thumb_url": it.thumb_url,
                        "page_number": page_num,
                        "page_url": page_url,
                        "scraped_at_utc": self.utc_now_iso(),
                        "source": "belizepolice_wanted_persons",
                    }
                    all_rows.append(row)

            # Save JSONL
            with out_file.open("w", encoding="utf-8") as f:
                for row in all_rows:
                    f.write(json.dumps(row, ensure_ascii=False) + "\n")

            print(f"[OK] items={len(all_rows)}")
            print(f"[OK] saved: {out_file}")

    async def run(self):
        await self.scrape_all()


if __name__ == "__main__":
    asyncio.run(BelizePoliceWantedPersonsScraper().run())