from __future__ import annotations

import asyncio
from datetime import timezone
import re
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Set, Tuple
from urllib.parse import parse_qs, urljoin, urlparse

import aiohttp
from bs4 import BeautifulSoup
from crawl4ai import AsyncWebCrawler, BrowserConfig, CrawlerRunConfig
from playwright.async_api import async_playwright
import json
from ..core.base_scraper import BaseScraper


class CftcDispositionsPdfDownloaderScraper(BaseScraper):
    """
    Scrapes the CFTC Dispositions pages to collect PDF links and downloads them.

    Flow:
      1) Fetch first page HTML using Crawl4AI
      2) Parse PDFs + last page index (rel=last)
      3) If last page can't be detected, use Playwright as a fallback
      4) Iterate all pages and aggregate unique PDF URLs
      5) Save a URL manifest
      6) Download PDFs concurrently into organized subfolders (year/month when possible)
    """

    name = "CFTC – Dispositions PDFs"

    BASE_URL = "https://www.cftc.gov/LawRegulation/Dispositions/index.htm"

    # Runtime knobs
    DEFAULT_TIMEOUT_MS = 90_000
    CONCURRENCY = 8
    DOWNLOAD_TIMEOUT_SEC = 180

    # Output filenames
    MANIFEST_FILENAME = "manifest_urls.txt"

    # ---------------------------
    # Utilities
    # ---------------------------

    def build_page_url(self, base: str, page_index: int) -> str:
        """
        CFTC uses query param `?page=N`. Page 0 is the base URL itself.
        """
        if page_index == 0:
            return base
        return f"{base}?page={page_index}"

    def sanitize_filename(self, name: str, max_len: int = 180) -> str:
        """
        Convert arbitrary names into a safe filesystem filename.
        """
        name = (name or "").strip()
        name = re.sub(r"[^\w\.\-]+", "_", name, flags=re.UNICODE)
        name = re.sub(r"_+", "_", name).strip("_")
        if not name:
            name = "file"
        return name[:max_len]

    def infer_subdir_from_url(self, pdf_url: str) -> Path:
        """
        Many CFTC PDFs look like:
          /sites/default/files/2024/05/BAKER051324.pdf

        We'll store as:
          outputs/<slug>/files/2024/05/BAKER051324.pdf

        If pattern not found, store under "misc".
        """
        path = urlparse(pdf_url).path
        parts = [p for p in path.split("/") if p]

        year: Optional[str] = None
        month: Optional[str] = None

        for i, p in enumerate(parts):
            if re.fullmatch(r"20\d{2}", p):
                year = p
                if i + 1 < len(parts) and re.fullmatch(r"\d{2}", parts[i + 1]):
                    month = parts[i + 1]
                break

        if year and month:
            return Path(year) / month
        if year:
            return Path(year)
        return Path("misc")

    def is_pdf_url(self, href: str) -> bool:
        """
        Minimal PDF check.
        """
        return href.lower().endswith(".pdf")

    # ---------------------------
    # Fetch + parse (Crawl4AI)
    # ---------------------------

    @dataclass
    class PageParseResult:
        pdf_urls: List[str]
        last_page: Optional[int]  # extracted from rel="last" if present

    async def fetch_html_with_crawl4ai(self, crawler: AsyncWebCrawler, url: str) -> str:
        """
        Fetch raw HTML using Crawl4AI (no extraction strategy needed here).
        """
        cfg = CrawlerRunConfig()
        res = await crawler.arun(url, config=cfg)
        if not res.success or not res.html:
            raise RuntimeError(f"Failed to fetch page HTML: {url}")
        return res.html

    def parse_pdf_links_and_last_page(self, html: str, page_url: str) -> "CftcDispositionsPdfDownloaderScraper.PageParseResult":
        """
        Parse:
          - PDF links from the table
          - last page index from rel="last" pager link if present
        """
        soup = BeautifulSoup(html, "lxml")

        pdf_urls: Set[str] = set()
        for a in soup.select("table a[href]"):
            href = (a.get("href") or "").strip()
            if not href:
                continue

            full = urljoin(page_url, href)
            if self.is_pdf_url(urlparse(full).path):
                pdf_urls.add(full)

        last_page = None
        last_a = soup.select_one('li.pager__item--last a[rel="last"][href]')
        if last_a:
            href = (last_a.get("href") or "").strip()
            full = urljoin(page_url, href)
            qs = parse_qs(urlparse(full).query)
            if "page" in qs and qs["page"]:
                try:
                    last_page = int(qs["page"][0])
                except Exception:
                    last_page = None

        return self.PageParseResult(pdf_urls=sorted(pdf_urls), last_page=last_page)

    # ---------------------------
    # Playwright fallback for last page
    # ---------------------------

    async def get_last_page_via_playwright(self, base_url: str) -> int:
        """
        Fallback if HTML parsing can't find the last page.
        Opens base_url in a real browser and reads the rel=last link.
        """
        async with async_playwright() as pw:
            browser = await pw.chromium.launch(headless=True)
            page = await browser.new_page()
            page.set_default_timeout(self.DEFAULT_TIMEOUT_MS)

            await page.goto(base_url, wait_until="domcontentloaded", timeout=self.DEFAULT_TIMEOUT_MS)

            loc = page.locator('li.pager__item--last a[rel="last"]')
            await loc.wait_for(state="visible", timeout=self.DEFAULT_TIMEOUT_MS)
            href = await loc.get_attribute("href")

            await browser.close()

        if not href:
            return 0

        full = urljoin(base_url, href)
        qs = parse_qs(urlparse(full).query)
        try:
            return int(qs.get("page", ["0"])[0])
        except Exception:
            return 0

    # ---------------------------
    # Downloading
    # ---------------------------

    async def download_one(
        self,
        session: aiohttp.ClientSession,
        url: str,
        dest_path: Path,
    ) -> Tuple[str, bool, Optional[str]]:
        """
        Download one PDF. Returns: (url, ok, error).
        """
        dest_path.parent.mkdir(parents=True, exist_ok=True)

        if dest_path.exists() and dest_path.stat().st_size > 0:
            return url, True, None

        try:
            async with session.get(url, allow_redirects=True) as resp:
                if resp.status != 200:
                    return url, False, f"HTTP {resp.status}"
                data = await resp.read()

            # Quick PDF validation to avoid saving HTML error pages.
            if not data.startswith(b"%PDF"):
                return url, False, "Not a PDF (response did not start with %PDF)"

            dest_path.write_bytes(data)
            return url, True, None

        except Exception as e:
            return url, False, str(e)

    async def download_all(self, urls: List[str], files_dir: Path, concurrency: int) -> Tuple[int, int]:
        """
        Download all PDFs concurrently.
        Returns (downloaded_count, failed_count).
        """
        timeout = aiohttp.ClientTimeout(total=self.DOWNLOAD_TIMEOUT_SEC)
        connector = aiohttp.TCPConnector(limit=concurrency)
        sem = asyncio.Semaphore(concurrency)

        downloaded = 0
        failed = 0

        async with aiohttp.ClientSession(timeout=timeout, connector=connector) as session:

            async def _task(u: str) -> Tuple[str, bool, Optional[str]]:
                async with sem:
                    filename = self.sanitize_filename(Path(urlparse(u).path).name)
                    subdir = self.infer_subdir_from_url(u)
                    dest = files_dir / subdir / filename
                    return await self.download_one(session, u, dest)

            tasks = [_task(u) for u in urls]

            for fut in asyncio.as_completed(tasks):
                url, ok, err = await fut
                if ok:
                    downloaded += 1
                else:
                    failed += 1
                    print(f"[ERR] {url} -> {err}")

                done = downloaded + failed
                if done % 25 == 0 or done == len(urls):
                    print(f"[INFO] Downloaded {done}/{len(urls)} (failed={failed})")

        return downloaded, failed

    # ---------------------------
    # Main pipeline
    # ---------------------------

    async def run(self) -> None:
        """
        Unified async entrypoint (BaseScraper contract).
        """
        # outputs/<slug>/
        out_dir = self.ensure_out_dir()

        # Keep PDFs under a dedicated subfolder
        files_dir = out_dir / "files"
        files_dir.mkdir(parents=True, exist_ok=True)

        browser_cfg = BrowserConfig(headless=True, verbose=False)

        all_pdf_urls: Set[str] = set()

        async with AsyncWebCrawler(config=browser_cfg) as crawler:
            print(f"[INFO] Fetching first page: {self.BASE_URL}")

            html0 = await self.fetch_html_with_crawl4ai(crawler, self.BASE_URL)
            parsed0 = self.parse_pdf_links_and_last_page(html0, self.BASE_URL)
            all_pdf_urls.update(parsed0.pdf_urls)

            last_page = parsed0.last_page
            if last_page is None:
                print("[WARN] Could not detect last page via HTML parse. Using Playwright fallback...")
                last_page = await self.get_last_page_via_playwright(self.BASE_URL)

            print(f"[INFO] Last page index: {last_page}  (pages = {last_page + 1})")

            # Iterate pagination pages (?page=N)
            for i in range(1, last_page + 1):
                page_url = self.build_page_url(self.BASE_URL, i)
                print(f"[INFO] Fetching page {i}/{last_page}: {page_url}")

                html = await self.fetch_html_with_crawl4ai(crawler, page_url)
                parsed = self.parse_pdf_links_and_last_page(html, page_url)
                all_pdf_urls.update(parsed.pdf_urls)

        pdf_list = sorted(all_pdf_urls)
        print(f"[INFO] Total unique PDFs found: {len(pdf_list)}")

        # Save manifest for traceability
        manifest_path = out_dir / self.MANIFEST_FILENAME
        manifest_path.write_text("\n".join(pdf_list), encoding="utf-8")
        print(f"[INFO] URL manifest saved: {manifest_path.resolve()}")

        print("[INFO] Starting downloads...")
        downloaded, failed = await self.download_all(
            pdf_list, files_dir=files_dir, concurrency=self.CONCURRENCY
        )

        # Save a small run metadata file
        meta = {
            "source": {"name": "CFTC Dispositions", "url": self.BASE_URL},
            "run_stats": {
                "total_urls": len(pdf_list),
                "downloaded": downloaded,
                "failed": failed,
                "concurrency": self.CONCURRENCY,
            },
            "outputs": {
                "manifest_urls": str(manifest_path),
                "files_dir": str(files_dir),
            },
            "run_at": __import__("datetime").datetime.now(timezone.utc).isoformat(),
        }
        (out_dir / "meta.json").write_text(
            json.dumps(meta, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        print("[DONE] Finished.")

