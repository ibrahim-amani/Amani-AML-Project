
from __future__ import annotations

import asyncio
import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

from playwright.sync_api import Page, sync_playwright

from ..core.base_scraper import BaseScraper

class EfccWantedPersonsScraper(BaseScraper):
    """
    Scrapes Nigeria EFCC "Wanted Persons" pages using Playwright (sync) with a
    persistent Chrome profile.

    Notes:
      - Uses launch_persistent_context so cookies/sessions are preserved.
      - Keeps browser non-headless by default to allow manual solving if needed.

    Output:
      outputs/<scraper_slug>/efcc_wanted_persons_full.json
    """

    name = "Nigeria – EFCC Wanted Persons"

    BASE_URL = "https://efcc.gov.ng/WantedPersons?page="
    TOTAL_PAGES = 20

    USER_DATA_DIR = Path("./chrome_profile").resolve()
    VIEWPORT = {"width": 1500, "height": 1000}

    # Timing
    WAIT_AFTER_NAV_SEC = 5

    def load_page(self, page: Page, page_num: int) -> None:
        """
        Navigate to a specific EFCC wanted persons page and wait for it to render.
        """
        url = f"{self.BASE_URL}{page_num}"
        print(f"[INFO] Loading page {page_num}/{self.TOTAL_PAGES}: {url}")

        page.goto(url, wait_until="domcontentloaded")
        time.sleep(self.WAIT_AFTER_NAV_SEC)

    def parse_person_card(self, card) -> Dict[str, Any]:
        """
        Extract a single person's data from a card element.
        Prefers image alt text for name, otherwise falls back to title.
        """
        img = card.query_selector("img")
        title = card.query_selector(".MuiTypography-h5")
        desc = card.query_selector(".MuiTypography-body2")
        date_tag = card.query_selector("button")

        alt_name = ""
        if img:
            alt = img.get_attribute("alt")
            alt_name = (alt or "").strip()

        title_name = (title.inner_text() if title else "").strip()

        person_name = alt_name or title_name
        person_name = person_name.replace("Wanted ", "").strip()

        return {
            "name": person_name,
            "image_url": (img.get_attribute("src") if img else "") or "",
            "crime": (desc.inner_text().strip() if desc else "") or "",
            "date": (date_tag.inner_text().strip() if date_tag else "") or "",
        }

    def scrape_page_cards(self, page: Page, page_num: int) -> List[Dict[str, Any]]:
        """
        Scrape all cards on the current page.
        """
        cards = page.query_selector_all(".MuiCard-root")
        print(f"[INFO] Found {len(cards)} cards on page {page_num}")

        persons: List[Dict[str, Any]] = []
        for card in cards:
            person = self.parse_person_card(card)
            person["page"] = page_num
            persons.append(person)

        return persons

    def scrape_sync(self, total_pages: int | None = None) -> Dict[str, Any]:
        """
        Full synchronous pipeline:
          1) Launch persistent Chrome context
          2) Iterate pages and collect cards
          3) Return JSON-ready dict
        """
        total_pages = total_pages or self.TOTAL_PAGES

        print("[INFO] Launching Chrome persistent session...")
        with sync_playwright() as p:
            context = p.chromium.launch_persistent_context(
                user_data_dir=str(self.USER_DATA_DIR),
                channel="chrome",
                headless=False,
                viewport=self.VIEWPORT,
            )

            page = context.new_page()
            all_persons: List[Dict[str, Any]] = []

            for page_num in range(1, total_pages + 1):
                self.load_page(page, page_num)
                all_persons.extend(self.scrape_page_cards(page, page_num))

            context.close()

        return {
            "source": {
                "name": "EFCC – Wanted Persons",
                "url": "https://efcc.gov.ng/WantedPersons",
                "total_entries": len(all_persons),
                "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "total_pages_scraped": total_pages,
            },
            "entries": all_persons,
        }

    def write_outputs(self, data: Dict[str, Any]) -> Path:
        """
        Write output JSON under outputs/<scraper_slug>/.
        """
        out_dir = self.ensure_out_dir()
        out_path = out_dir / "efcc_wanted_persons_full.json"

        out_path.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        print(f"[DONE] Saved {data['source']['total_entries']} entries to: {out_path.resolve()}")
        return out_path

    async def run(self) -> None:
        """
        Unified async entrypoint (runs sync pipeline in a worker thread).
        """
        data = await asyncio.to_thread(self.scrape_sync)
        self.write_outputs(data)


if __name__ == "__main__":
    asyncio.run(EfccWantedPersonsScraper().run())
