from __future__ import annotations

import hashlib
import json
import re
import time
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional
from urllib.parse import urlparse

import requests
from bs4 import BeautifulSoup
from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
from playwright.sync_api import sync_playwright

from ..core.base_scraper import BaseScraper

@dataclass
class EnforcementDoc:
    id: str
    title: str
    pdf_url: str
    meta: Dict[str, str]
    page_number: int
    scraped_at_utc: str
    local_pdf: Optional[str] = None


class PcaobEnforcementScraper(BaseScraper):
    """
    Scrapes PCAOB Enforcement Actions pages using Playwright (sync).
    Downloads PDFs and saves a manifest.
    """

    name = "PCAOB Enforcement Actions"
    START_URL = "https://pcaobus.org/oversight/enforcement/enforcement-actions"
    
    # Runtime Configuration
    HEADLESS = True
    MAX_PAGES = None # Set int to limit
    NAV_TIMEOUT_MS = 180000
    DOWNLOAD_TIMEOUT = 90
    RETRIES = 3
    ITEMS_PER_PAGE = 96

    # ---------------------------
    # Utils
    # ---------------------------
    def utc_now_iso(self) -> str:
        return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")

    def normalize_ws(self, s: str) -> str:
        return re.sub(r"\s+", " ", (s or "")).strip()

    def sha1_short(self, s: str, n: int = 12) -> str:
        return hashlib.sha1(s.encode("utf-8", errors="ignore")).hexdigest()[:n]

    def slugify(self, s: str, max_len: int = 120) -> str:
        s = (s or "").strip()
        s = re.sub(r"\s+", " ", s)
        s = re.sub(r"[^\w\s\-\.]", "", s, flags=re.UNICODE)
        s = s.strip().replace(" ", "_")
        s = re.sub(r"_+", "_", s)
        if not s:
            s = "file"
        return s[:max_len].rstrip("_")

    def append_jsonl(self, path: Path, obj: dict) -> None:
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(obj, ensure_ascii=False) + "\n")

    def read_jsonl_pdf_urls(self, path: Path) -> set[str]:
        if not path.exists():
            return set()
        out: set[str] = set()
        with path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                    u = obj.get("pdf_url")
                    if u:
                        out.add(u)
                except Exception:
                    continue
        return out

    def safe_filename_from_url(self, url: str) -> str:
        parsed = urlparse(url)
        base = Path(parsed.path).name or "document.pdf"
        base = base.split("?")[0]
        if not base.lower().endswith(".pdf"):
            base += ".pdf"
        base_slug = self.slugify(base.replace(".pdf", ""), max_len=110)
        return f"{base_slug}__{self.sha1_short(url)}.pdf"

    def download_pdf(self, url: str, out_path: Path, timeout_s: int = 90, retries: int = 3) -> None:
        headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123 Safari/537.36"
            ),
            "Accept": "application/pdf,application/octet-stream;q=0.9,*/*;q=0.8",
            "Referer": self.START_URL,
        }

        last_err: Optional[Exception] = None
        for attempt in range(1, retries + 1):
            try:
                with requests.get(url, headers=headers, stream=True, timeout=timeout_s) as r:
                    r.raise_for_status()
                    out_path.parent.mkdir(parents=True, exist_ok=True)
                    tmp = out_path.with_suffix(out_path.suffix + ".part")
                    with tmp.open("wb") as f:
                        for chunk in r.iter_content(chunk_size=1024 * 256):
                            if chunk:
                                f.write(chunk)
                    tmp.replace(out_path)
                    return
            except Exception as e:
                last_err = e
                time.sleep(min(2 * attempt, 8))

        raise RuntimeError(f"Failed to download after {retries} retries: {url}") from last_err

    # ---------------------------
    # Playwright Logic
    # ---------------------------
    def goto_with_retries(self, page, url: str, timeout_ms: int, retries: int = 3) -> None:
        last_err: Optional[Exception] = None
        for attempt in range(1, retries + 1):
            try:
                print(f"[NAV] {url} (attempt {attempt}/{retries})")
                page.goto(url, wait_until="commit", timeout=timeout_ms)
                page.wait_for_load_state("domcontentloaded", timeout=timeout_ms)
                return
            except PlaywrightTimeoutError as e:
                last_err = e
                try:
                    page.wait_for_timeout(750)
                    page.reload(wait_until="commit", timeout=timeout_ms)
                    page.wait_for_load_state("domcontentloaded", timeout=timeout_ms)
                    return
                except Exception as e2:
                    last_err = e2
                time.sleep(min(2 * attempt, 8))
        raise RuntimeError(f"Navigation failed after retries: {url}") from last_err

    def wait_results_ready(self, page, timeout_ms: int) -> None:
        page.wait_for_selector("div.hawk-results__listing div.sf-search-results", timeout=timeout_ms)

    def get_first_result_href(self, page) -> Optional[str]:
        try:
            return page.locator("div.hawk-results__listing h3 a[href]").first.get_attribute("href")
        except Exception:
            return None

    def get_current_page_number(self, page) -> int:
        try:
            v = page.locator("input.hawk-pagination__input").input_value()
            return int(v)
        except Exception:
            return 1

    def detect_total_pages(self, page, timeout_ms: int) -> int:
        page.wait_for_selector("div.hawk-pagination__controls input.hawk-pagination__input", timeout=timeout_ms)
        deadline = time.time() + (timeout_ms / 1000.0)

        while time.time() < deadline:
            try:
                max_attr = page.locator("input.hawk-pagination__input").get_attribute("max")
                if max_attr and max_attr.isdigit():
                    total = int(max_attr)
                    if total >= 1:
                        return total
            except Exception:
                pass

            try:
                txt = page.locator("span.hawk-pagination__total-text").inner_text()
                m = re.search(r"of\s+(\d+)", txt, flags=re.I)
                if m:
                    return int(m.group(1))
            except Exception:
                pass
            page.wait_for_timeout(250)
        return 1

    def set_items_per_page(self, page, items: Optional[int], timeout_ms: int) -> None:
        if not items or items not in (24, 48, 96):
            return

        sel = "div.hawk-items-per-page select"
        try:
            if not page.locator(sel).count():
                return
            old_first = self.get_first_result_href(page)
            page.select_option(sel, value=str(items))
            page.wait_for_timeout(300)
            self.wait_results_ready(page, timeout_ms=timeout_ms)

            if old_first:
                try:
                    page.wait_for_function(
                        """({oldHref}) => {
                            const a = document.querySelector('div.hawk-results__listing h3 a[href]');
                            const href = a ? a.getAttribute('href') : null;
                            return href && href !== oldHref;
                        }""",
                        arg={"oldHref": old_first},
                        timeout=min(timeout_ms, 15_000),
                    )
                except PlaywrightTimeoutError:
                    pass
        except Exception:
            return

    def go_to_page_number(self, page, target: int, timeout_ms: int) -> None:
        if target < 1:
            return
        old_first = self.get_first_result_href(page)

        page.evaluate(
            """(n) => {
                const i = document.querySelector('input.hawk-pagination__input');
                if (!i) return false;
                i.focus();
                i.value = String(n);
                i.dispatchEvent(new Event('input', { bubbles: true }));
                i.dispatchEvent(new Event('change', { bubbles: true }));
                i.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', bubbles: true }));
                i.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', bubbles: true }));
                return true;
            }""",
            target,
        )

        try:
            page.wait_for_function(
                """({oldHref, n}) => {
                    const i = document.querySelector('input.hawk-pagination__input');
                    const val = i ? parseInt(i.value || '0', 10) : 0;
                    const a = document.querySelector('div.hawk-results__listing h3 a[href]');
                    const href = a ? a.getAttribute('href') : null;
                    if (val !== n) return false;
                    if (!href) return false;
                    if (!oldHref) return true;
                    return href !== oldHref;
                }""",
                arg={"oldHref": old_first or "", "n": target},
                timeout=min(timeout_ms, 25_000),
            )
        except PlaywrightTimeoutError:
            current = self.get_current_page_number(page)
            steps = target - current
            if steps <= 0:
                return
            next_btn = page.locator("div.hawk-pagination__controls button").nth(2)
            for _ in range(steps):
                old_first2 = self.get_first_result_href(page)
                next_btn.click()
                self.wait_results_ready(page, timeout_ms=timeout_ms)
                try:
                    if old_first2:
                        page.wait_for_function(
                            """(oldHref) => {
                                const a = document.querySelector('div.hawk-results__listing h3 a[href]');
                                const href = a ? a.getAttribute('href') : null;
                                return href && href !== oldHref;
                            }""",
                            arg=old_first2,
                            timeout=min(timeout_ms, 20_000),
                        )
                except PlaywrightTimeoutError:
                    pass

    def parse_results_from_html(self, html_content: str, page_number: int) -> List[EnforcementDoc]:
        soup = BeautifulSoup(html_content, "lxml")
        docs: List[EnforcementDoc] = []

        for card in soup.select("div.sf-search-results.media-list"):
            title_a = card.select_one("h3 a[href]")
            if not title_a:
                continue
            title = self.normalize_ws(title_a.get_text(" ", strip=True))

            pdf_a = card.select_one("a.hawk-download-pdf[href]")
            pdf_url = (pdf_a.get("href") if pdf_a else title_a.get("href")) or ""
            pdf_url = pdf_url.strip()

            if not pdf_url or ".pdf" not in pdf_url.lower():
                continue

            meta: Dict[str, str] = {}
            for col in card.select("div.hawk-row.inline div.hawk-column"):
                k_el = col.select_one("div.lead-text-lt")
                v_el = col.select_one("div.lead-text-st")
                k = self.normalize_ws(k_el.get_text(" ", strip=True)) if k_el else ""
                v = self.normalize_ws(v_el.get_text(" ", strip=True)) if v_el else ""
                if k and v:
                    meta[k] = v

            doc_id = self.sha1_short(pdf_url, n=16)
            docs.append(
                EnforcementDoc(
                    id=doc_id,
                    title=title,
                    pdf_url=pdf_url,
                    meta=meta,
                    page_number=page_number,
                    scraped_at_utc=self.utc_now_iso(),
                )
            )
        return docs

    def scrape_all_pages_with_playwright(self) -> List[EnforcementDoc]:
        all_docs: List[EnforcementDoc] = []
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=self.HEADLESS)
            context = browser.new_context(
                locale="en-US",
                ignore_https_errors=True,
                user_agent=(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123 Safari/537.36"
                ),
            )
            page = context.new_page()
            page.set_default_navigation_timeout(self.NAV_TIMEOUT_MS)
            page.set_default_timeout(self.NAV_TIMEOUT_MS)

            def _route(route):
                rt = route.request.resource_type
                if rt in ("image", "media", "font"):
                    return route.abort()
                return route.continue_()

            page.route("**/*", _route)

            self.goto_with_retries(page, self.START_URL, timeout_ms=self.NAV_TIMEOUT_MS, retries=3)
            self.wait_results_ready(page, timeout_ms=self.NAV_TIMEOUT_MS)
            page.wait_for_selector("div.hawk-pagination__controls input.hawk-pagination__input", timeout=self.NAV_TIMEOUT_MS)

            self.set_items_per_page(page, items=self.ITEMS_PER_PAGE, timeout_ms=self.NAV_TIMEOUT_MS)

            total_pages = self.detect_total_pages(page, timeout_ms=self.NAV_TIMEOUT_MS)
            if self.MAX_PAGES:
                total_pages = min(total_pages, self.MAX_PAGES)

            for page_num in range(1, total_pages + 1):
                if page_num != 1:
                    self.go_to_page_number(page, target=page_num, timeout_ms=self.NAV_TIMEOUT_MS)

                html_content = page.content()
                docs = self.parse_results_from_html(html_content, page_number=page_num)
                all_docs.extend(docs)
                print(f"[OK] Page {page_num}/{total_pages}: extracted {len(docs)} PDF links")

            context.close()
            browser.close()

        uniq: Dict[str, EnforcementDoc] = {}
        for d in all_docs:
            uniq[d.pdf_url] = d
        return list(uniq.values())

    # ---------------------------
    # Main pipeline method
    # ---------------------------
    def run(self) -> None:
        out_dir = self.ensure_out_dir()
        pdf_dir = out_dir / "pdfs"
        pdf_dir.mkdir(parents=True, exist_ok=True)
        manifest_path = out_dir / "manifest.json"
        
        # Resume capability
        already = self.read_jsonl_pdf_urls(manifest_path)

        print("[INIT] Scraping listing pages (Playwright pagination)...")
        docs = self.scrape_all_pages_with_playwright()
        print(f"[OK] Total unique PDFs found: {len(docs)}")

        downloaded = 0
        skipped = 0
        failed = 0

        for i, doc in enumerate(docs, start=1):
            if doc.pdf_url in already:
                skipped += 1
                continue

            filename = self.safe_filename_from_url(doc.pdf_url)
            out_pdf = pdf_dir / filename

            try:
                self.download_pdf(doc.pdf_url, out_pdf, timeout_s=self.DOWNLOAD_TIMEOUT, retries=self.RETRIES)
                doc.local_pdf = str(out_pdf.resolve())
                self.append_jsonl(manifest_path, asdict(doc))
                downloaded += 1
                print(f"[DL] {i}/{len(docs)} -> {out_pdf.name}")
            except Exception as e:
                failed += 1
                print(f"[ERR] {i}/{len(docs)} failed: {doc.pdf_url}\n      {e}")

        print(f"[DONE] downloaded={downloaded} skipped={skipped} failed={failed}")


if __name__ == "__main__":
    scraper = PcaobEnforcementScraper()
    scraper.run()