from __future__ import annotations

import os
import re
import json
import time
from datetime import datetime, timezone
from urllib.parse import urljoin

import requests
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeoutError

from ..core.base_scraper import BaseScraper

class SanctionsMapScraper(BaseScraper):
    """
    Scrapes https://www.sanctionsmap.eu/#/main for PDF lists.
    Uses Playwright (Sync) to handle the SPA overlay logic.
    """

    name = "Sanctions Map EU"
    BASE_URL = "https://www.sanctionsmap.eu/#/main"
    ORIGIN = "https://www.sanctionsmap.eu"
    
    # Runtime knobs
    LIMIT = 0 # 0 = All
    HEADED = False
    
    # Output filenames
    MANIFEST_FILENAME = "sanctionsmap_pdfs.json"

    # ----------------------------
    # Helpers
    # ----------------------------

    def now_utc_iso(self) -> str:
        return datetime.now(timezone.utc).isoformat()

    def slugify(self, text: str, max_len: int = 120) -> str:
        text = (text or "").strip()
        text = re.sub(r"[^\w\s\-\.&]+", "", text, flags=re.UNICODE)
        text = re.sub(r"\s+", "_", text).strip("_")
        return text[:max_len] or "unknown"

    def safe_click(self, locator, timeout_ms: int = 15000) -> bool:
        try:
            locator.first.wait_for(state="visible", timeout=timeout_ms)
            locator.first.click()
            return True
        except Exception:
            return False

    def try_accept_cookies(self, page):
        for label in ["Accept", "I agree", "Agree", "OK", "Got it", "Allow all", "Accept all"]:
            btn = page.get_by_role("button", name=label)
            if btn.count() > 0:
                self.safe_click(btn, 3000)
                break

    def scroll_to_load_all_rows(self, page, rows_selector: str, max_rounds: int = 80):
        stable = 0
        prev = -1
        for _ in range(max_rounds):
            count = page.locator(rows_selector).count()
            if count == prev:
                stable += 1
            else:
                stable = 0
                prev = count

            if stable >= 4:
                break

            page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            page.wait_for_timeout(900)

    def build_requests_session_from_playwright(self, context) -> requests.Session:
        s = requests.Session()
        s.headers.update({
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            ),
            "Accept": "application/pdf,application/octet-stream;q=0.9,*/*;q=0.8",
            "Referer": self.ORIGIN + "/",
        })
        try:
            for c in context.cookies():
                s.cookies.set(c["name"], c["value"])
        except Exception:
            pass
        return s

    def download_file(self, session: requests.Session, url: str, out_path: str, timeout: int = 90) -> dict:
        tmp_path = out_path + ".part"
        r = session.get(url, stream=True, timeout=timeout)
        r.raise_for_status()

        total = 0
        with open(tmp_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=1024 * 64):
                if chunk:
                    f.write(chunk)
                    total += len(chunk)

        if os.path.exists(out_path):
            os.remove(out_path)
        os.rename(tmp_path, out_path)
        return {"status_code": r.status_code, "bytes": total}

    def extract_country_text(self, row_locator) -> str:
        try:
            a = row_locator.locator('li[data-heading="Country or Category"] .hidden-print a')
            if a.count() > 0:
                t = a.first.inner_text().strip()
                if t: return t
        except Exception: pass

        try:
            s = row_locator.locator('li[data-heading="Country or Category"] .visible-print-inline')
            if s.count() > 0:
                t = s.first.inner_text().strip()
                if t: return t
        except Exception: pass

        return "unknown"

    # ----------------------------
    # Details overlay logic
    # ----------------------------

    def wait_for_details_overlay(self, page, timeout_ms: int = 30000):
        page.wait_for_selector("input#dt0", timeout=timeout_ms)

    def ensure_dt0_checked(self, page):
        dt0 = page.locator("input#dt0").first
        dt0.wait_for(state="attached", timeout=30000)
        try:
            if not dt0.is_checked():
                try:
                    dt0.check(timeout=15000, force=True)
                except Exception:
                    lbl = page.locator('label[for="dt0"]', has_text="Lists of persons, entities and items").first
                    lbl.click(force=True)
        except Exception:
            lbl = page.locator('label[for="dt0"]', has_text="Lists of persons, entities and items").first
            lbl.click(force=True)

        page.wait_for_timeout(1200)
        try: page.wait_for_load_state("networkidle", timeout=15000)
        except Exception: pass

    def get_pdf_url_from_overlay(self, page, lang: str = "en") -> str:
        pdf_a = page.locator('div.pull-right.hidden-print a[target="_blank"]:has-text("PDF")').first
        pdf_a.wait_for(state="visible", timeout=30000)

        href = pdf_a.get_attribute("href") or ""
        if not href: return ""

        pdf_url = urljoin(self.ORIGIN, href)
        if lang and "lang=" not in pdf_url:
            sep = "&" if "?" in pdf_url else "?"
            pdf_url = f"{pdf_url}{sep}lang={lang}"
        return pdf_url

    def close_overlay(self, page):
        close_btn = page.locator("a.close.hidden-print").first
        if close_btn.count() > 0:
            try:
                close_btn.click(timeout=8000)
                page.wait_for_selector("input#dt0", state="detached", timeout=15000)
                return
            except Exception: pass

        try:
            page.keyboard.press("Escape")
            page.wait_for_selector("input#dt0", state="detached", timeout=15000)
        except Exception: pass

    # ----------------------------
    # Main runner
    # ----------------------------

    def run(self):
        out_dir = self.ensure_out_dir()
        files_dir = out_dir / "files"
        files_dir.mkdir(parents=True, exist_ok=True)
        
        meta_json = out_dir / self.MANIFEST_FILENAME

        results = {
            "source": self.BASE_URL,
            "download_root": str(files_dir),
            "downloaded_at": self.now_utc_iso(),
            "items": []
        }

        print(f"[INFO] Starting SanctionsMap Scraper...")

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=not self.HEADED)
            context = browser.new_context(
                viewport={"width": 1400, "height": 900},
                user_agent=(
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                ),
            )
            page = context.new_page()

            page.goto(self.BASE_URL, wait_until="domcontentloaded", timeout=60000)
            page.wait_for_selector("div.regimes-table", timeout=60000)
            self.try_accept_cookies(page)

            rows_sel = "div.regimes-table ul.filter-list"
            self.scroll_to_load_all_rows(page, rows_sel)

            session = self.build_requests_session_from_playwright(context)

            total_detected = page.locator(rows_sel).count()
            total_to_process = total_detected if self.LIMIT <= 0 else min(self.LIMIT, total_detected)
            print(f"[INFO] Rows detected: {total_detected} | Processing: {total_to_process}")

            for i in range(total_to_process):
                rows = page.locator(rows_sel)
                row = rows.nth(i)
                country = self.extract_country_text(row)

                item = {
                    "index": i + 1,
                    "country_or_category": country,
                    "pdf_url": None,
                    "saved_to": None,
                    "error": None,
                }

                list_icon = row.locator('li[data-heading="List"] a.icon-card').first
                if list_icon.count() == 0:
                    item["error"] = "No List icon found"
                    results["items"].append(item)
                    continue

                if not self.safe_click(list_icon, timeout_ms=20000):
                    item["error"] = "Failed to click List icon"
                    results["items"].append(item)
                    continue

                try:
                    self.wait_for_details_overlay(page, timeout_ms=30000)
                    self.ensure_dt0_checked(page)

                    pdf_url = self.get_pdf_url_from_overlay(page, lang="en")
                    if not pdf_url:
                        raise RuntimeError("PDF href not found")

                    item["pdf_url"] = pdf_url
                    filename = f"{i+1:03d}_{self.slugify(country)}_lists.pdf"
                    out_path = files_dir / filename

                    last_err = None
                    for attempt in range(1, 4):
                        try:
                            info = self.download_file(session, pdf_url, str(out_path), timeout=90)
                            item["saved_to"] = str(out_path)
                            item["download_info"] = info
                            last_err = None
                            break
                        except Exception as e:
                            last_err = str(e)
                            time.sleep(1.2 * attempt)

                    if last_err:
                        item["error"] = f"Download failed: {last_err}"

                except Exception as e:
                    item["error"] = str(e)
                finally:
                    self.close_overlay(page)

                results["items"].append(item)
                print(f"[{i+1:03d}/{total_to_process}] {country} => {'OK' if item.get('saved_to') else 'FAIL'}")

            browser.close()

        with open(meta_json, "w", encoding="utf-8") as f:
            json.dump(results, f, ensure_ascii=False, indent=2)

        print(f"[DONE] Saved manifest: {meta_json}")

if __name__ == "__main__":
    SanctionsMapScraper().run()