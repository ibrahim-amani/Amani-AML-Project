from __future__ import annotations

import asyncio
import os
import re
import json
import hashlib
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urljoin, urlparse, parse_qs
from typing import List, Dict, Any, Optional

from playwright.sync_api import sync_playwright, TimeoutError as PWTimeoutError
from ..core.base_scraper import BaseScraper
class UaeiecSanctionsScraper(BaseScraper):
    """
    Scrapes the UAEIEC Sanctions page using Playwright (sync).
    Handles cookie consent, expands lists, and downloads files.
    """

    name = "UAEIEC Sanctions Lists"
    START_URL = "https://www.uaeiec.gov.ae/en-us/un-page"
    
    # Output configuration
    MANIFEST_FILENAME = "uaeiec_sanctions_links.json"
    DOWNLOAD_FILES = True

    # ---------------------------
    # Utils (From your script)
    # ---------------------------
    def utc_now_iso(self) -> str:
        return datetime.now(timezone.utc).isoformat()

    def safe_filename(self, name: str, max_len: int = 160) -> str:
        name = (name or "").strip()
        name = re.sub(r"[^\w\s\.\-]+", "_", name, flags=re.UNICODE)
        name = re.sub(r"\s+", " ", name).strip()
        if not name:
            name = "file"
        if len(name) > max_len:
            name = name[:max_len].rstrip()
        return name

    def guess_ext_from_headers(self, headers: dict) -> str:
        ct = (headers.get("content-type") or "").lower()
        if "pdf" in ct: return ".pdf"
        if "excel" in ct or "spreadsheet" in ct: return ".xlsx"
        if "zip" in ct: return ".zip"
        if "csv" in ct: return ".csv"
        if "json" in ct: return ".json"
        return ""

    def extract_filename_from_cd(self, headers: dict) -> str | None:
        cd = headers.get("content-disposition") or headers.get("Content-Disposition")
        if not cd:
            return None
        m = re.search(r'filename\*?=(?:UTF-8\'\')?"?([^\";]+)"?', cd, flags=re.IGNORECASE)
        if m:
            return m.group(1).strip()
        return None

    def sha256_file(self, path: Path) -> str:
        h = hashlib.sha256()
        with path.open("rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()

    def is_downloadfile_url(self, u: str) -> bool:
        return "API/Upload/DownloadFile" in u or "DownloadFile?FileID=" in u

    def parse_file_id(self, u: str) -> str | None:
        try:
            qs = parse_qs(urlparse(u).query)
            fid = qs.get("FileID", [None])[0]
            return fid
        except Exception:
            return None

    # ---------------------------
    # Playwright Logic
    # ---------------------------

    def collect_sanctions_links(self, page) -> list[dict]:
        # 1. Accept Cookies
        for sel in [
            "button:has-text('Accept')", "button:has-text('I agree')",
            "button#onetrust-accept-btn-handler", ".cookie button:has-text('Accept')",
            "button:has-text('Got it')", "button:has-text('OK')",
        ]:
            try:
                if page.locator(sel).first.is_visible():
                    page.locator(sel).first.click(timeout=1500)
                    break
            except Exception: pass

        # 2. Trigger List Expansion
        trigger_selectors = [
            "div.square:has-text('Sanctions List and Subscription')",
            "div.square span:has-text('Sanctions List and Subscription')",
            "div.square img[src*='todo-list']",
            "div.square",
        ]

        for sel in trigger_selectors:
            try:
                loc = page.locator(sel).first
                loc.wait_for(state="attached", timeout=20000)
                try: loc.hover(timeout=2000)
                except: pass
                loc.click(timeout=8000)
                break
            except Exception: continue

        # 3. Force Visibility (JS Injection)
        page.wait_for_selector("div.square-list", state="attached", timeout=30000)
        try:
            page.evaluate("""
            () => {
              const el = document.querySelectorAll('div.square-list')[0];
              if (el) { el.style.display = 'block'; el.style.visibility = 'visible'; el.style.opacity = '1'; }
            }
            """)
        except Exception: pass

        # 4. Scrape Links
        page.wait_for_selector("#sancationslist-container a", state="attached", timeout=30000)
        anchors = page.locator("#sancationslist-container a")
        n = anchors.count()

        items = []
        for i in range(n):
            a = anchors.nth(i)
            try: text = (a.inner_text() or "").strip()
            except: text = ""
            
            href = (a.get_attribute("href") or "").strip()
            if not href: continue

            full_url = urljoin(page.url, href)
            items.append({
                "text": text,
                "href_raw": href,
                "url": full_url,
                "kind": "file" if self.is_downloadfile_url(full_url) else "page",
                "file_id": self.parse_file_id(full_url),
                "extracted_at": self.utc_now_iso(),
            })

        return items

    def also_collect_any_download_links_on_page(self, page) -> list[dict]:
        anchors = page.locator("a[href*='DownloadFile']")
        n = anchors.count()
        out = []
        for i in range(n):
            a = anchors.nth(i)
            text = (a.inner_text() or "").strip()
            href = (a.get_attribute("href") or "").strip()
            if not href: continue
            full_url = urljoin(page.url, href)
            out.append({
                "text": text,
                "href_raw": href,
                "url": full_url,
                "kind": "file",
                "file_id": self.parse_file_id(full_url),
                "extracted_at": self.utc_now_iso(),
            })
        return out

    def download_one_via_playwright_request(self, request_ctx, item: dict, download_dir: Path) -> dict:
        url = item["url"]
        try:
            resp = request_ctx.get(url, timeout=120_000)
            ok = resp.ok
            headers = resp.headers
        except Exception as e:
            return {**item, "download_ok": False, "error": str(e), "downloaded_at": self.utc_now_iso()}

        meta = {
            "download_ok": bool(ok),
            "status": resp.status,
            "content_type": headers.get("content-type"),
            "content_length": headers.get("content-length"),
            "saved_path": None,
            "sha256": None,
            "downloaded_at": self.utc_now_iso(),
        }

        if not ok:
            return {**item, **meta}

        cd_name = self.extract_filename_from_cd(headers)
        ext = self.guess_ext_from_headers(headers)

        base_name = self.safe_filename(cd_name or (item.get("text") or "download"))
        if ext and not base_name.lower().endswith(ext):
            base_name += ext

        file_id = item.get("file_id")
        if file_id:
            name_part, dot, ex = base_name.partition(".")
            if dot:
                base_name = f"{self.safe_filename(name_part)}_{file_id}.{ex}"
            else:
                base_name = f"{base_name}_{file_id}"

        out_path = download_dir / base_name
        
        try:
            body = resp.body()
            with open(out_path, "wb") as f:
                f.write(body)

            meta["saved_path"] = str(out_path.resolve())
            meta["sha256"] = self.sha256_file(out_path)
        except Exception as e:
            meta["error"] = str(e)
            meta["download_ok"] = False

        return {**item, **meta}

    def dedupe_by_url(self, items: list[dict]) -> list[dict]:
        seen = set()
        out = []
        for it in items:
            u = it.get("url")
            if not u or u in seen: continue
            seen.add(u)
            out.append(it)
        return out

    def run_sync(self):
        out_dir = self.ensure_out_dir()
        download_dir = out_dir / "files"
        download_dir.mkdir(parents=True, exist_ok=True)
        
        manifest_path = out_dir / self.MANIFEST_FILENAME

        result = {
            "source": self.START_URL,
            "scraped_at": self.utc_now_iso(),
            "download_files": self.DOWNLOAD_FILES,
            "items": [],
        }

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            context = browser.new_context()
            page = context.new_page()

            print(f"[OPEN] {self.START_URL}")
            try:
                page.goto(self.START_URL, wait_until="domcontentloaded", timeout=120_000)
                items = self.collect_sanctions_links(page)
                more = self.also_collect_any_download_links_on_page(page)
                all_items = self.dedupe_by_url(items + more)

                final_items = []
                if self.DOWNLOAD_FILES:
                    print("[DL] Downloading files one by one...")
                    for it in all_items:
                        if it.get("kind") != "file":
                            final_items.append(it)
                            continue
                        
                        # Download
                        res = self.download_one_via_playwright_request(context.request, it, download_dir)
                        final_items.append(res)
                        
                        if res.get("download_ok"):
                            print(f"  ✓ {res.get('text','(no text)')} -> {res.get('saved_path')}")
                        else:
                            print(f"  ✗ {res.get('url')} | {res.get('error')}")
                else:
                    final_items = all_items

                result["items"] = final_items
            
            except Exception as e:
                print(f"[ERR] UAEIEC Scrape Loop Failed: {e}")
            
            finally:
                browser.close()

        with open(manifest_path, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)

        print(f"[SAVE] {manifest_path}")
        print(f"[DONE] items={len(result['items'])}")

    async def run(self) -> None:
        await asyncio.to_thread(self.run_sync)

if __name__ == "__main__":
    asyncio.run(UaeiecSanctionsScraper().run())