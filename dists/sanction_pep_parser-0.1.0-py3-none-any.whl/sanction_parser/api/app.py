from __future__ import annotations

import gzip
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse

from sanction_parser.core.config import settings

app = FastAPI(
    title="Sanction PEP Parser Export API",
    version="1.0.0",
)


# -------------------------------------------------------------------
# Helpers
# -------------------------------------------------------------------

NEW_DATA_DIR = settings.DATA_LAKE_DIR / "new_data"
GOLDEN_FILE = NEW_DATA_DIR / "Golden_Export.jsonl.gz"
META_FILE = NEW_DATA_DIR / "AmaniAI_meta.json"


def _require_file(path: Path) -> None:
    if not path.exists():
        raise HTTPException(status_code=404, detail=f"File not found: {path.name}")


def _file_sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _stream_file(path: Path) -> Iterator[bytes]:
    with path.open("rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            yield chunk


# -------------------------------------------------------------------
# 1️⃣ ALL DATA MANIFEST (used by _insert_data)
# -------------------------------------------------------------------

@app.get("/amani/meta")
def get_all_data_manifest():
    """
    Returns the manifest required by AmaniAI._insert_data()

    Fields:
      - file      → URL to download Golden_Export.jsonl.gz
      - sha256    → SHA256 hash of the file
      - timestamp → export time in milliseconds
    """
    _require_file(GOLDEN_FILE)

    sha256 = _file_sha256(GOLDEN_FILE)
    timestamp_ms = int(
        GOLDEN_FILE.stat().st_mtime * 1000
    )

    return JSONResponse(
        {
            "file": "http://localhost:8000/amani/file",
            "sha256": sha256,
            "timestamp": timestamp_ms,
            "exported_at_iso": datetime.fromtimestamp(
                timestamp_ms / 1000, tz=timezone.utc
            ).isoformat(),
        }
    )


# -------------------------------------------------------------------
# 2️⃣ FILE DOWNLOAD (used by _download_file)
# -------------------------------------------------------------------

@app.get("/amani/file")
def download_golden_export():
    """
    Streams Golden_Export.jsonl.gz
    """
    _require_file(GOLDEN_FILE)

    return StreamingResponse(
        _stream_file(GOLDEN_FILE),
        media_type="application/gzip",
        headers={
            "Content-Disposition": 'attachment; filename="Golden_Export.jsonl.gz"'
        },
    )


# -------------------------------------------------------------------
# 3️⃣ UPDATE DATA ENDPOINT (used by _update_data)
# -------------------------------------------------------------------

@app.get("/amani/update/{timestamp}")
def get_updates_since(timestamp:str):
    """
    Delta update endpoint.

    Currently returns empty updates but keeps the contract
    expected by AmaniAI._get_update_batch().
    """
    timestamp = int(timestamp)
    return JSONResponse(
        {
            "profiles": [],
            "timestamp": int(datetime.now(tz=timezone.utc).timestamp() * 1000),
        }
    )


# -------------------------------------------------------------------
# Health
# -------------------------------------------------------------------

@app.get("/health")
def health():
    return {"ok": True}
