
import asyncio
import logging
from datetime import datetime
from typing import Optional
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.status import Status
from rich.logging import RichHandler
from rich.text import Text
from rich import box

# Internal Package Imports
from sanction_parser.scrapers.registry import ScraperRegistry
from sanction_parser.pipelines.resolver import EntityResolver
from sanction_parser.core.config import settings, set_data_lake_path

# Console and Logging Configuration
console = Console()
logging.basicConfig(
    level=logging.INFO,
    format="%(message)s",
    datefmt="[%X]",
    handlers=[RichHandler(rich_tracebacks=True, console=console)]
)
logger = logging.getLogger("sanction-pep")

app = typer.Typer(
    help="🛡️ [bold]SANCTION PEP CLI[/bold] - Intelligence Data Management System",
    rich_markup_mode="rich"
)

# -------------------------------------------------------------------
# Shared Options
# -------------------------------------------------------------------
output_dir_opt = typer.Option(
    None, 
    "--output-dir", "-o", 
    help="Target directory for the Data Lake (where 'raw' and 'processed' live)"
)

# -------------------------------------------------------------------
# UI Helpers
def print_banner():
    """Prints the high-impact SANCTION PEP ASCII system header with extra spacing."""
    table = Table(show_header=False, box=None, padding=(0, 1))
    
    # Professional Block ASCII for "SANCTION PEP"
    ascii_art = [
        r"[bold cyan]  ____    _    _   _  ____ _____ ___ ___  _   _ [/bold cyan]",
        r"[bold cyan] / ___|  / \  | \ | |/ ___|_   _|_ _/ _ \| \ | |[/bold cyan]",
        r"[bold cyan] \___ \ / _ \ |  \| | |     | |  | | | | |  \| |[/bold cyan]",
        r"[bold cyan]  ___) / ___ \| |\  | |___  | |  | | |_| | |\  |[/bold cyan]",
        r"[bold cyan] |____/_/   \_\_| \_|\____| |_| |___\___/|_| \_|[/bold cyan]",
        r"[bold white]  ____  _____ ____                              [/bold white]",
        r"[bold white] |  _ \| ____|  _ \                             [/bold white]",
        r"[bold white] | |_) |  _| | |_) |                            [/bold white]",
        r"[bold white] |  __/| |___|  __/                             [/bold white]",
        r"[bold white] |_|   |_____|_|                                [/bold white]"
    ]
    
    for line in ascii_art:
        table.add_row(line)

    # Adding two empty rows for spacing
    table.add_row("")
    table.add_row("")
    
    # Subtitle with version
    table.add_row("[bold yellow]    Sanction & PEP Intelligence v0.1.0[/bold yellow]")
    
    console.print("") 
    console.print(table)
    console.print("[dim] ---------------------------------------------------------------[/dim]")

# -------------------------------------------------------------------
# Async & Pipeline Helpers
# -------------------------------------------------------------------
async def run_scraper_async(source: str, force: bool) -> None:
    """Run a single scraper with a visual status spinner."""
    scraper = ScraperRegistry.get_scraper(source)
    mode_label = "[bold red]FORCE[/]" if force else "[bold green]INCREMENTAL[/]"
    
    with console.status(f"[bold blue]Scraping {source}...[/] (Mode: {mode_label})", spinner="dots"):
        try:
            await scraper.run(force=force)
            console.print(f"  [bold green]✔[/] [white]{source.upper()}[/] [dim]process completed.[/]")
        except Exception as e:
            console.print(f"  [bold red]✘[/] [white]{source.upper()}[/] [bold red]failed:[/] {e}")
            raise

async def run_all_scrapers_async(force: bool, parallel: int = 3) -> None:
    """Run all registered scrapers with concurrency control."""
    keys = ScraperRegistry.list_keys()
    
    summary = Panel(
        f"🚀 [bold]SANCTION PEP GLOBAL UPDATE[/]\n"
        f"• Total Sources: [bold cyan]{len(keys)}[/]\n"
        f"• Max Concurrency: [bold yellow]{parallel}[/]\n"
        f"• Target Root: [dim]{settings.DATA_LAKE_DIR}[/dim]",
        border_style="magenta",
        title="Pipeline Overview"
    )
    console.print(summary)

    sem = asyncio.Semaphore(parallel)

    async def run_one(key: str) -> None:
        async with sem:
            try:
                await run_scraper_async(key, force=force)
            except Exception:
                logger.error(f"Scraper failure: {key}")

    tasks = [asyncio.create_task(run_one(key)) for key in keys]
    await asyncio.gather(*tasks)

def run_entity_resolution(custom_export_path: Optional[str] = None) -> None:
    """Executes the Entity Resolution pipeline with a UI status bar."""
    status_msg = "[bold yellow]🔗 RESOLVER: Merging records & generating Golden Profiles...[/]"
    
    with console.status(status_msg, spinner="bouncingBar"):
        resolver = EntityResolver(output_dir=custom_export_path)
        resolver.run()
        
    final_path = resolver.output_dir
    console.print(Panel(f"✨ IDENTITY RESOLUTION COMPLETED!\nResults saved to: [bold green]{final_path}[/]", border_style="green"))

# -------------------------------------------------------------------
# CLI Commands
# -------------------------------------------------------------------
@app.callback()
def main(output_dir: Optional[str] = output_dir_opt):
    """Global configuration for SANCTION PEP CLI."""
    if output_dir:
        set_data_lake_path(output_dir)

@app.command()
def list():
    """List all registered scrapers in the registry."""
    print_banner()
    table = Table(title="SANCTION PEP REGISTRY", header_style="bold magenta", box=box.SIMPLE_HEAVY)
    table.add_column("Key", style="cyan", no_wrap=True)
    table.add_column("Provider Description", style="white")
    table.add_column("Status", justify="center")

    for key in ScraperRegistry.list_keys():
        try:
            scraper = ScraperRegistry.get_scraper(key)
            name = getattr(scraper, "name", "Unknown Provider")
            status = "[green]● ACTIVE[/]"
        except Exception:
            name, status = "N/A", "[red]● ERROR[/]"
        table.add_row(key.upper(), name, status)

    console.print(table)

@app.command()
def run(
    source: str = typer.Argument(..., help="The specific scraper key to run"),
    force: bool = typer.Option(False, "--force", "-f", help="Force cache bypass")
):
    """Run a specific scraper pipeline."""
    print_banner()
    try:
        asyncio.run(run_scraper_async(source, force=force))
    except Exception as e:
        console.print(f"\n[bold red]CRITICAL ERROR:[/] {e}")
        raise typer.Exit(code=1)

@app.command()
def update(
    force: bool = typer.Option(False, "--force", "-f", help="Force update for all sources"),
    parallel: int = typer.Option(3, "--parallel", "-p", help="Maximum concurrent scrapers"),
    export_dir: Optional[str] = typer.Option(None, "--export-dir", "-e", help="Custom folder for final export")
):
    """Full Pipeline: Scrape all sources + Run Entity Resolution."""
    print_banner()
    start_time = datetime.now()
    
    try:
        # Phase 1
        asyncio.run(run_all_scrapers_async(force=force, parallel=parallel))
        
        # Phase 2
        console.rule("[bold yellow]PHASE 2: ENTITY RESOLUTION[/]")
        run_entity_resolution(custom_export_path=export_dir)
        
        duration = datetime.now() - start_time
        console.print(f"\n[bold green]🎉 FULL UPDATE COMPLETED IN {duration.total_seconds():.2f}s[/]")
    except Exception as e:
        console.print(f"\n[bold red]PIPELINE FAILED:[/] {e}")
        raise typer.Exit(code=1)

@app.command()
def resolve(
    export_dir: Optional[str] = typer.Option(None, "--export-dir", "-e", help="Target folder for final export")
):
    """Run Entity Resolution on previously processed data."""
    print_banner()
    try:
        run_entity_resolution(custom_export_path=export_dir)
    except Exception as e:
        console.print(f"\n[bold red]RESOLUTION FAILED:[/] {e}")
        raise typer.Exit(code=1)

if __name__ == "__main__":
    app()