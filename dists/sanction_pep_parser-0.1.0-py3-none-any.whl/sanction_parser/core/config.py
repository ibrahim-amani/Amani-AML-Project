
# """Configuration settings for the Sanction PEP Parser project.
# src.sanction_parser.core.config
# """

# from pathlib import Path
# from pydantic_settings import BaseSettings
# from typing import Optional

# class Settings(BaseSettings):
#     PROJECT_NAME: str = "Sanction PEP Parser"
    
#     # 1. Internal Code Directory
#     # Resolves to the root of your source code
#     BASE_DIR: Path = Path(__file__).resolve().parent.parent.parent.parent
    
#     # 2. Dynamic Data Lake Directory
#     # Defaults to 'data' in the user's Current Working Directory (CWD).
#     # This makes the tool portable when installed as a package.
#     DATA_LAKE_DIR: Path = Path.cwd() / "data"
    
#     # 3. Derived Paths
#     # We use @property to ensure these update automatically if DATA_LAKE_DIR changes.
#     @property
#     def RAW_DIR(self) -> Path:
#         return self.DATA_LAKE_DIR / "raw"
        
#     @property
#     def PROCESSED_DIR(self) -> Path:
#         return self.DATA_LAKE_DIR / "schema"
    
#     # General Settings
#     DEFAULT_TIMEOUT: int = 60
#     DEFAULT_RETRIES: int = 3
#     DEFAULT_UPDATE_INTERVAL_HOURS: int = 24  
#     USER_AGENT: str = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    
#     # Elasticsearch Settings
#     ELASTICSEARCH_URL: str = "http://localhost:9200"
#     ELASTICSEARCH_USERNAME: str = ""
#     ELASTICSEARCH_PASSWORD: str = ""
#     REQUEST_TIMEOUT: int = 60
#     RETRY_ON_TIMEOUT: bool = True
#     MAX_RETRIES: int = 3

#     INDEX_NAME: str = "sanction_profiles"
#     PROVIDERS_INDEX: str = "providers"
#     INDEX_VERSION: int = 1
    
  
    
    
    
    

#     class Config:
#         env_file = ".env"
#         env_prefix = "SANCTION_"
#         # Allows updating DATA_LAKE_DIR after the object is initialized
#         validate_assignment = True 

# # Initialize the settings object
# settings = Settings()

# def set_data_lake_path(new_path: str):
#     """
#     Updates the Data Lake path at runtime based on user CLI input.
#     """
#     path = Path(new_path).resolve()
#     settings.DATA_LAKE_DIR = path
    
#     # Ensure directories exist immediately to prevent FileNotFoundError
#     settings.RAW_DIR.mkdir(parents=True, exist_ok=True)
#     settings.PROCESSED_DIR.mkdir(parents=True, exist_ok=True)


"""
Configuration settings for the Sanction PEP Parser project.
src.sanction_parser.core.config
"""

from pathlib import Path
from typing import Optional

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # ------------------------------------------------------------------
    # Project
    # ------------------------------------------------------------------
    PROJECT_NAME: str = "Sanction PEP Parser"

    # ------------------------------------------------------------------
    # Internal Code Directory
    # ------------------------------------------------------------------
    BASE_DIR: Path = Path(__file__).resolve().parent.parent.parent.parent

    # ------------------------------------------------------------------
    # Data Lake
    # ------------------------------------------------------------------
    DATA_LAKE_DIR: Path = Path.cwd() / "data"

    @property
    def RAW_DIR(self) -> Path:
        return self.DATA_LAKE_DIR / "raw"

    @property
    def PROCESSED_DIR(self) -> Path:
        return self.DATA_LAKE_DIR / "schema"

    # ------------------------------------------------------------------
    # General Runtime Settings
    # ------------------------------------------------------------------
    DEBUG_MODE: bool = False

    DEFAULT_TIMEOUT: int = 60
    DEFAULT_RETRIES: int = 3
    DEFAULT_UPDATE_INTERVAL_HOURS: int = 24

    USER_AGENT: str = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    )

    # ------------------------------------------------------------------
    # Batch & Flush Control
    # ------------------------------------------------------------------
    BATCH_SIZE: int = 2000
    FLUSH_SIZE: int = 50000

    # ------------------------------------------------------------------
    # Relationship Caps (OOM & graph safety)
    # ------------------------------------------------------------------
    MAX_RELS_PER_ENTITY: int = 300
    MAX_REL_ENDPOINTS_PER_SIDE: int = 50

    # ------------------------------------------------------------------
    # ID / Token Lengths
    # ------------------------------------------------------------------
    QRCODE_LEN: int = 10
    EVIDENCE_ID_LEN: int = 12

    # ------------------------------------------------------------------
    # Elasticsearch
    # ------------------------------------------------------------------
    ELASTICSEARCH_URL: str = "http://localhost:9200"
    ELASTICSEARCH_USERNAME: str = ""
    ELASTICSEARCH_PASSWORD: str = ""

    REQUEST_TIMEOUT: int = 60
    RETRY_ON_TIMEOUT: bool = True
    MAX_RETRIES: int = 3

    INDEX_NAME: str = "sanction_profiles"
    PROVIDERS_INDEX: str = "providers"
    INDEX_VERSION: int = 1

    # ------------------------------------------------------------------
    # Pydantic Settings Config
    # ------------------------------------------------------------------
    class Config:
        env_file = ".env"
        env_prefix = "SANCTION_"
        validate_assignment = True


# ----------------------------------------------------------------------
# Singleton Settings Instance
# ----------------------------------------------------------------------
settings = Settings()


def set_data_lake_path(new_path: str):
    """
    Updates the Data Lake path at runtime (CLI / API usage).
    """
    path = Path(new_path).resolve()
    settings.DATA_LAKE_DIR = path

    # Ensure directories exist immediately
    settings.RAW_DIR.mkdir(parents=True, exist_ok=True)
    settings.PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
