"""
src/sanction_parser/domain/normalizers.py

This module handles the normalization of entity data into the internal
'Golden Profile' schema used by the ETL pipeline.
"""

import hashlib
import time
import re
import logging
from typing import Dict, List, Set, Tuple, Any, Optional

# Initialize module logger
logger = logging.getLogger(__name__)

# Attempt to import nameparser, provide fallback if missing
try:
    from nameparser import HumanName
except ImportError:
    logger.warning("'nameparser' library not found. Using basic fallback logic.")
    
    class HumanName:
        """Fallback class if 'nameparser' library is not installed."""
        def __init__(self, full_name: str):
            parts = str(full_name or "").split()
            self.first = parts[0] if parts else ""
            self.last = parts[-1] if len(parts) > 1 else ""
            self.middle = " ".join(parts[1:-1]) if len(parts) > 2 else ""
            self.title = ""
            self.suffix = ""
            self.nickname = ""

# Constants
NOISE_SUFFIXES = {
    "DMD", "D.M.D", "DDS", "D.D.S", "MD", "M.D", "PHD", "PH.D",
    "DCFH", "LLC", "LTD", "INC", "CORP", "S.A.", "GMBH", "D.O."
}

QRCODE_LEN = 10

class ProfileMapper:
    """
    Handles the transformation of raw data into the target schema structure.
    Uses regex patterns and heuristics to clean names and categorize risk.
    """

    _POSTCODE_RE = re.compile(
        r"\b(\d{5}-\d{4}|\d{5,9}|[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}|[A-Z]\d[A-Z]\s*\d[A-Z]\d)\b",
        re.IGNORECASE,
    )
    _TRAIL_PUNCT_RE = re.compile(r"^[\W_]+|[\W_]+$", re.UNICODE)
    _PATRONYMIC_RE = re.compile(r".*(ovich|evich|yevich|ovna|evna|ich)$", re.IGNORECASE)

    def __init__(self):
        pass

    @staticmethod
    def _sha256_hex(val: str) -> str:
        """Generates SHA256 hash string."""
        return hashlib.sha256(val.encode("utf-8")).hexdigest()

    def _stable_qrcode(self, val: str, length: int = QRCODE_LEN) -> str:
        """Generates a stable short hash for QR codes."""
        return self._sha256_hex(val)[:length]

    @staticmethod
    def _norm_ws(s: Optional[str]) -> str:
        """Normalizes whitespace."""
        if not s:
            return ""
        return " ".join(str(s).strip().split())

    def _clean_name_token(self, tok: str) -> str:
        """Removes trailing punctuation from name tokens."""
        tok = self._norm_ws(tok)
        return self._TRAIL_PUNCT_RE.sub("", tok)

    def _clean_name_noise(self, full_name: str) -> str:
        """Removes professional suffixes from names."""
        parts = str(full_name or "").split()
        cleaned = []
        for p in parts:
            clean_p = p.replace(".", "").upper()
            if clean_p in NOISE_SUFFIXES:
                continue
            cleaned.append(p)
        return " ".join(cleaned)

    # ---------------------------------------------------------
    # Name Parsing Logic
    # ---------------------------------------------------------
    def _parse_name(self, full_name: str) -> Dict[str, str]:
        """
        Parses a full name string into first, middle, and last components.
        """
        if not full_name:
            return {"first": "", "middle": "", "last": ""}

        s = self._clean_name_noise(self._norm_ws(full_name))
        if not s:
            return {"first": "", "middle": "", "last": ""}

        # Heuristic 1: "LAST, First Middle"
        if "," in s:
            left, right = [x.strip() for x in s.split(",", 1)]
            right_parts = right.split()
            first = self._clean_name_token(right_parts[0]) if right_parts else ""
            middle = self._clean_name_token(" ".join(right_parts[1:])) if len(right_parts) > 1 else ""
            last = self._clean_name_token(left)
            return {"first": first, "middle": middle, "last": last}

        parts = s.split()
        
        # Heuristic 2: Slavic "Last First Patronymic"
        if len(parts) == 3 and self._PATRONYMIC_RE.match(parts[2]):
            last = self._clean_name_token(parts[0])
            first = self._clean_name_token(parts[1])
            middle = self._clean_name_token(parts[2])
            return {"first": first, "middle": middle, "last": last}

        try:
            # Use library
            hn = HumanName(s)
            first = self._clean_name_token(getattr(hn, "first", ""))
            middle = self._clean_name_token(f"{getattr(hn, 'middle', '')} {getattr(hn, 'nickname', '')}")
            last = self._clean_name_token(f"{getattr(hn, 'last', '')} {getattr(hn, 'suffix', '')}")

            if not (first or last):
                raise ValueError("Name parser returned empty")

            return {"first": first, "middle": middle, "last": last}
        except Exception:
            # Fallback
            if len(parts) == 1:
                return {"first": parts[0], "middle": "", "last": ""}
            return {
                "first": parts[0],
                "middle": " ".join(parts[1:-1]) if len(parts) > 2 else "",
                "last": parts[-1],
            }

    # ---------------------------------------------------------
    # Helper: Ensure list of strings (Flattening)
    # ---------------------------------------------------------
    @staticmethod
    def _ensure_str_list(value: Any) -> List[str]:
        """
        Flattens nested lists and ensures the output is a list of strings.
        Removes duplicates while preserving order.
        """
        if value is None:
            return []

        if isinstance(value, str):
            s = value.strip()
            return [s] if s else []

        if isinstance(value, list):
            flat: List[str] = []
            for item in value:
                # Handle list of chars acting as string
                if isinstance(item, list) and item and all(isinstance(ch, str) and len(ch) == 1 for ch in item):
                    s = "".join(item).strip()
                    if s: flat.append(s)
                    continue
                
                # Recursive flatten (simplified)
                if isinstance(item, list):
                    flat.extend(ProfileMapper._ensure_str_list(item))
                    continue

                if isinstance(item, str):
                    s = item.strip()
                    if s: flat.append(s)

            # Deduplicate
            return list(dict.fromkeys(flat))

        s = str(value).strip()
        return [s] if s else []

    # ---------------------------------------------------------
    # Main Mapping Function
    # ---------------------------------------------------------
    def map_single_profile(self, entry: Dict[str, Any]) -> Dict[str, Any]:
        """
        Maps a single golden profile entry to the target schema.
        
        Args:
            entry: Input dictionary containing 'profile', 'risk_events', and 'evidence'.
            
        Returns:
            A dictionary containing 'data' (the profile) and 'datasets' (tags).
        """
        profile = entry.get("profile", {}) or {}
        risk_events = entry.get("risk_events", []) or []
        evidence_list = entry.get("evidence", []) or []

        if isinstance(evidence_list, dict):
            evidence_list = [evidence_list]

        # --- Name Parsing ---
        full_name = profile.get("full_name", "Unknown")
        parsed_name = self._parse_name(full_name)
        addresses = profile.get("addresses", []) or []

        # --- Alias Mapping ---
        name_aliases: List[Dict[str, str]] = []
        raw_aliases = profile.get("aliases", []) or []
        seen_aliases = {str(full_name).lower().strip()}

        for alias in raw_aliases:
            if isinstance(alias, str) and alias.strip():
                clean_alias = alias.strip()
                if clean_alias.lower() not in seen_aliases:
                    name_aliases.append({"fullName": clean_alias})
                    seen_aliases.add(clean_alias.lower())

        # --- Evidence Mapping ---
        target_evidences: List[Dict[str, Any]] = []
        evidence_ids: List[str] = []

        for ev in evidence_list:
            url = (ev.get("url") or "") if isinstance(ev, dict) else ""
            snippet = (ev.get("raw_text_snippet") or "") if isinstance(ev, dict) else ""
            ev_str = f"{url}{snippet}"
            
            # Generate 8-char ID
            ev_id = str(int(hashlib.md5(ev_str.encode()).hexdigest(), 16))[:8]
            evidence_ids.append(ev_id)
            
            scraped_at = ev.get("scraped_at", "") if isinstance(ev, dict) else ""
            capture_date = scraped_at.split("T")[0] if scraped_at else ""

            target_evidences.append({
                "evidenceId": ev_id,
                "originalUrl": url,
                "summary": "",
                "captureDateIso": capture_date,
                "datasets": [], # Populated later
            })

        # --- Risk Buckets ---
        san_entries = {"current": [], "former": []}
        pep_entries = {"current": [], "former": []}
        rel_entries: List[Any] = []
        rre_entries: List[Any] = []
        ins_entries: List[Any] = []
        dd_entries: List[Any] = []
        poi_entries: List[Any] = []
        gri_entries: List[Any] = []

        active_datasets: Set[str] = set()
        dataset_sources: List[str] = []

        # --- Processing Risk Events ---
        for event in risk_events:
            evt_type = str(event.get("type", "")).lower()
            is_current = bool(event.get("is_current", True))
            source_list = str(event.get("source_list", " "))
            dataset_sources.append(source_list)

            # Determine Dataset Tag
            ds_tag = "GRI"
            if "sanction" in evt_type:
                ds_tag = "SAN-CURRENT" if is_current else "SAN-FORMER"
            elif "pep" in evt_type:
                ds_tag = "PEP-CURRENT" if is_current else "PEP-FORMER"
            elif any(x in evt_type for x in ["regulatory", "enforcement", "wanted"]):
                ds_tag = "REL"
            elif any(x in evt_type for x in ["adverse", "media"]):
                ds_tag = "RRE"
            elif any(x in evt_type for x in ["insolvency", "bankruptcy"]):
                ds_tag = "INS"
            elif any(x in evt_type for x in ["disqualified", "director"]):
                ds_tag = "DD"
            elif "person" in evt_type and "interest" in evt_type:
                ds_tag = "POI"

            active_datasets.add(ds_tag)

            # Common Event Structure
            target_event = {"type": "Added", "evidenceIds": evidence_ids}
            if event.get("date_listed"):
                target_event["dateIso"] = event.get("date_listed")

            details = event.get("specific_details", {}) or {}

            # 1. Sanctions
            if "sanction" in evt_type:
                entry_obj = {
                    "sanctionId": hashlib.md5(str(event.get("reason", "")).encode()).hexdigest()[:12],
                    "measures": [event.get("reason")],
                    "regime": {
                        "name": event.get("source_list"),
                        "body": event.get("authority"),
                        "origin": event.get("authority"),
                    },
                    "events": [target_event],
                }
                san_entries["current" if is_current else "former"].append(entry_obj)

            # 2. PEPs
            elif "pep" in evt_type:
                pos = details.get("position") or event.get("reason")
                entry_obj = {
                    "position": pos,
                    "countryIsoCode": profile.get("nationality"),
                    "evidenceIds": evidence_ids,
                }
                pep_entries["current" if is_current else "former"].append(entry_obj)

            # 3. Regulatory / Law Enforcement
            elif any(x in evt_type for x in ["regulatory", "enforcement", "law"]):
                entry_obj = {
                    "category": details.get("category") or "Law Enforcement",
                    "subcategory": details.get("subcategory") or "Regulatory Action",
                    "events": [{
                        "type": details.get("enforcement_type") or "Regulatory Action",
                        "description": event.get("reason"),
                        "dateIso": event.get("date_listed"),
                        "evidenceIds": evidence_ids,
                    }],
                }
                rel_entries.append(entry_obj)

            # 4. Adverse Media
            elif "adverse" in evt_type or "media" in evt_type:
                entry_obj = {
                    "category": details.get("category") or "Financial Crime",
                    "subcategory": details.get("subcategory") or "Adverse Media Report",
                    "events": [{
                        "type": details.get("adverse_media_type") or "Allegation",
                        "description": event.get("reason"),
                        "dateIso": event.get("date_listed"),
                        "evidenceIds": evidence_ids,
                    }],
                }
                rre_entries.append(entry_obj)

            # 5. Insolvency
            elif "insolvency" in evt_type or "bankruptcy" in evt_type:
                entry_obj = {
                    "type": event.get("reason", "Insolvency Proceeding"),
                    "court": event.get("authority"),
                    "debt": details.get("debt_amount"),
                    "insolvencyIdNumber": details.get("case_reference"),
                    "solicitor": details.get("solicitor"),
                    "petitioner": details.get("petitioner"),
                    "insolvencyStartDateIso": event.get("date_listed"),
                    "evidenceIds": evidence_ids,
                }
                ins_entries.append(entry_obj)

            # 6. Disqualified Directors
            elif "disqualified" in evt_type or "director" in evt_type:
                entry_obj = {
                    "caseReference": details.get("case_reference", "Unknown"),
                    "reason": event.get("reason"),
                    "conduct": details.get("company_name") or event.get("authority"),
                    "dateFromIso": event.get("date_listed"),
                    "evidenceIds": evidence_ids,
                }
                dd_entries.append(entry_obj)

            # 7. Person of Interest
            elif "person" in evt_type and "interest" in evt_type:
                entry_obj = {
                    "category": details.get("category") or "Public Interest",
                    "evidenceIds": evidence_ids,
                    "positions": [{
                        "position": details.get("position") or event.get("reason"),
                        "segment": "General",
                        "countryIsoCode": profile.get("nationality"),
                        "dateFromIso": event.get("date_listed"),
                        "dateToIso": event.get("date_listed"),
                    }],
                }
                poi_entries.append(entry_obj)

            # 8. Global Risk (Default)
            else:
                entry_obj = {
                    "evidenceId": evidence_ids,
                    "title": f"Risk Report - {event.get('type', 'General Risk')}",
                    "summary": event.get("reason"),
                    "keywords": [event.get("type", "General")],
                }
                gri_entries.append(entry_obj)

        # Backfill datasets
        for ev in target_evidences:
            ev["datasets"] = list(active_datasets)

        # Structured Aliases
        aliases_struct = []
        for a in raw_aliases:
            ap = self._parse_name(str(a))
            if ap["first"] or ap["last"]:
                aliases_struct.append({
                    "firstName": ap["first"],
                    "middleName": ap["middle"],
                    "lastName": ap["last"],
                    "type": "Original Script Name",
                })

        # Dates of Birth
        dates_of_birth = []
        raw_dob = profile.get("date_of_birth")
        if raw_dob:
            dob_parsed = parse_date_of_birth(raw_dob)
            if dob_parsed.get("year"):
                dates_of_birth.append(dob_parsed)

        # Nationality (Flattened)
        nat_list = self._ensure_str_list(profile.get("nationality"))

        # Final Data Block Assembly
        data_block = {
            "qrCode": self._stable_qrcode(str(profile.get("id"))),
            "resourceUri": f"/individuals/{profile.get('id')}",
            "resourceId": profile.get("id"),
            "firstName": parsed_name.get("first", ""),
            "fullName": full_name,
            "middleName": parsed_name.get("middle", ""),
            "lastName": parsed_name.get("last", ""),
            "gender": profile.get("gender"),
            "provider": "AmaniAI",
            "nationality": nat_list,
            "datesOfBirthParsed": dates_of_birth,
            "provider_version": int(time.time() * 1000),
            "isDeleted": False,
            "nameAliases": name_aliases,
            "isDeceased": not profile.get("is_active", True),
            "aliases": aliases_struct,
            "datesOfBirthIso": [raw_dob] if raw_dob else [],
            "datesOfDeathIso": [],
            "nationalitiesIsoCodes": nat_list,
            "addresses": addresses,
            "profileImages": profile.get("images", []),
            "notes": [],
            "contactEntries": [],
            "identifiers": [],
            "evidences": target_evidences,
            "sanEntries": san_entries,
            "relEntries": rel_entries,
            "rreEntries": rre_entries,
            "poiEntries": poi_entries,
            "insEntries": ins_entries,
            "ddEntries": dd_entries,
            "pepEntries": pep_entries,
            "pepByAssociationEntries": [],
            "individualLinks": [],
            "businessLinks": [],
            "griEntries": gri_entries,
        }

        # Return format tailored for the Generator in BaseScraper
        return {
            "data": data_block,
            "datasets": dataset_sources,
        }

def parse_date_of_birth(date_of_birth: str) -> Dict[str, str]:
    """
    Parses ISO date 'YYYY-MM-DD' into {year, month, day}.
    """
    result = {"year": "", "month": "", "day": ""}
    if not date_of_birth:
        return result
    try:
        components = str(date_of_birth).split("-")
        if len(components) > 0: result["year"] = components[0]
        if len(components) > 1: result["month"] = components[1]
        if len(components) > 2: result["day"] = components[2]
    except Exception:
        pass
    return result




import threading


def convert_turkish_characters(text: str) -> str:
    turkish_to_english = {
        'ı': 'i', 'İ': 'I',
        'ğ': 'g', 'Ğ': 'G',
        'ü': 'u', 'Ü': 'U',
        'ş': 's', 'Ş': 'S',
        'ö': 'o', 'Ö': 'O',
        'ç': 'c', 'Ç': 'C'
    }
    for turkish_char, english_char in turkish_to_english.items():
        text = text.replace(turkish_char, english_char)

    return text


def parse_date_of_birth(date_of_birth):
    result = {
        "year":"",
        "month":"",
        "day": ""
    }
    try:
        components = date_of_birth.split("-")
        for i, component in enumerate(components):
            if not component.isdigit():
                return result

            if i == 0:  # Year
                result["year"] = component
            elif i == 1:  # Month
                result["month"] = component
            elif i == 2:  # Day
                result["day"] = component
        return result
    except ValueError:
        return result


def background_wait(seconds):
    event = threading.Event()
    event.wait(seconds)
    
  