from __future__ import annotations

import uuid
import json
import hashlib
import logging
import re
import typer
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, Iterator, Optional, Union
from datetime import datetime, timedelta
from sanction_parser.core.config import set_data_lake_path
from sanction_parser.core.config import settings

logger = logging.getLogger("sanction_parser")


class BaseSanctionScraper(ABC):
    """
    The unified abstract base class for all sanction and PEP scrapers.
    
    Capabilities:
    1. Orchestration: Manages the Extract -> Transform -> Load pipeline.
    2. State Management: Handles idempotency via content hashing and metadata.
    3. Path Management: Automatically resolves raw/processed paths based on config.
    """

    #: Human readable name (Override this in child class)
    name: str = "Unnamed Scraper"
    
    #: Country context (e.g., "USA", "Global")
    country: str = "Global"

    #: Namespace for UUID generation (Preserved from legacy code)
    UUID_NAMESPACE = uuid.uuid5(uuid.NAMESPACE_DNS, "AmaniAI.ai")

    def __init__(self, execution_date: Optional[str] = None):
        self.execution_date = execution_date or datetime.now().strftime("%Y-%m-%d")
        self.update_interval = timedelta(hours=settings.DEFAULT_UPDATE_INTERVAL_HOURS)
        self.logger = logging.getLogger(f"scraper.{self.slug}")

    # ---------------------------------------------------------
    # Properties & Identifiers
    # ---------------------------------------------------------
    @property
    def slug(self) -> str:
        """Normalized identifier for the scraper source."""
        text = (self.name or "unnamed").strip().lower()
        text = re.sub(r"[^a-z0-9]+", "_", text)
        return text.strip("_")

    @property
    def country_slug(self) -> str:
        """Normalized identifier for the country."""
        text = (self.country or "global").strip().lower()
        text = re.sub(r"[^a-z0-9]+", "_", text)
        return text.strip("_")

    # ---------------------------------------------------------
    # Path Management (Injects paths from Settings)
    # ---------------------------------------------------------
    @property
    def raw_dir(self) -> Path:
        """Path: data_lake/raw/<scraper_slug>/<date>/"""
        path = settings.RAW_DIR / self.slug / self.execution_date
        path.mkdir(parents=True, exist_ok=True)
        return path

    @property
    def metadata_path(self) -> Path:
        """Path: data_lake/raw/<scraper_slug>/metadata.json"""
        path = settings.RAW_DIR / self.slug / "metadata.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        return path

    @property
    def processed_dir(self) -> Path:
        """Path: data_lake/processed/<country_slug>/"""
        path = settings.PROCESSED_DIR / self.country_slug
        path.mkdir(parents=True, exist_ok=True)
        return path

    # ---------------------------------------------------------
    # Core Logic (Hashing & Metadata)
    # ---------------------------------------------------------
    def _calculate_file_hash(self, file_path: Path) -> str:
        """Efficient SHA256 hash for large files."""
        if not file_path.exists():
            return ""
        sha256 = hashlib.sha256()
        with open(file_path, "rb") as f:
            for block in iter(lambda: f.read(65536), b""):
                sha256.update(block)
        return sha256.hexdigest()

    def _load_metadata(self) -> Dict[str, Any]:
        if self.metadata_path.exists():
            try:
                with open(self.metadata_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                self.logger.warning(f"Corrupt metadata: {e}")
        return {}

    def _save_metadata(self, data: Dict[str, Any]) -> None:
        with open(self.metadata_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4)

    def should_run_update(self) -> bool:
        """Checks if enough time has passed since last update."""
        metadata = self._load_metadata()
        last_updated = metadata.get("last_updated")
        
        if not last_updated:
            return True

        try:
            delta = datetime.now() - datetime.fromisoformat(last_updated)
            if delta < self.update_interval:
                self.logger.info(f"Skipping: Last run was {delta} ago (Interval: {self.update_interval})")
                return False
        except ValueError:
            return True
            
        return True

    def verify_content_changed(self, file_path: Path) -> bool:
        """Updates metadata and returns True if content is new."""
        new_hash = self._calculate_file_hash(file_path)
        metadata = self._load_metadata()
        
        if metadata.get("content_hash") == new_hash:
            self.logger.info("Hash match: Content unchanged.")
            return False
            
        metadata.update({
            "content_hash": new_hash,
            "last_updated": datetime.now().isoformat(),
            "last_file_processed": file_path.name
        })
        self._save_metadata(metadata)
        return True

    # ---------------------------------------------------------
    # Utilities
    # ---------------------------------------------------------
    def generate_uuid(self, *args: str) -> Optional[str]:
        """Deterministic UUID generator based on project namespace."""
        val = "".join(str(a) for a in args if a)
        if not val:
            return None
        return str(uuid.uuid5(self.UUID_NAMESPACE, val))

    def _save_processed_data(self, data: Iterator[Dict] | list[Dict]) -> Path:
        """Helper to save transformed data to JSONL."""
        filename = f"{self.slug}_unified.jsonl"
        out_path = self.processed_dir / filename
        
        self.logger.info(f"Saving processed data to {out_path}...")
        
        with open(out_path, 'w', encoding='utf-8') as f:
            count = 0
            # Handle both list and iterator
            iterator = data if isinstance(data, Iterator) else iter(data)
            for entry in iterator:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
                count += 1
                
        self.logger.info(f"Saved {count} records.")
        return out_path

    # ---------------------------------------------------------
    # Abstract Interface (To be implemented by Scrapers)
    # ---------------------------------------------------------
    @abstractmethod
    async def extract(self) -> Optional[Path]:
        """
        Step 1: Download raw data.
        Returns: Path to the downloaded file, or None if failed/skipped.
        """
        pass

    @abstractmethod
    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Parse raw file and yield normalized dictionaries.
        """
        pass

    # ---------------------------------------------------------
    # Orchestration
    # ---------------------------------------------------------
    async def run(self, force: bool = False) -> None:
        """Main Pipeline Entrypoint."""
        self.logger.info(f"Starting pipeline for: {self.name}")

        # 1. Check Interval
        if not force and not self.should_run_update():
            return

        # 2. Extract
        try:
            raw_path = await self.extract()
        except Exception as e:
            self.logger.error(f"Extraction failed: {e}", exc_info=True)
            return

        if not raw_path: 
            self.logger.warning("Extraction returned no file.")
            return

        # 3. Check Hash (Idempotency)
        if not force and not self.verify_content_changed(raw_path):
            return

        # 4. Transform & Load
        try:
            # We use a generator here to handle large datasets efficiently
            transformed_data = self.transform(raw_path)
            output_path = self._save_processed_data(transformed_data)
            self.logger.info(f"Pipeline completed. Output: {output_path}")
        except Exception as e:
            self.logger.error(f"Transformation failed: {e}", exc_info=True)
            raise e