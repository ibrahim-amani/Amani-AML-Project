# src/sanction_parser/pipelines/runner.py
"""
Main orchestrator to run scrapers then entity resolution.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Iterable, List, Optional

from sanction_parser.scrapers.registry import ScraperRegistry
from sanction_parser.pipelines.resolver import EntityResolver

logger = logging.getLogger("sanction_parser.pipeline_runner")


class PipelineRunner:
    """
    Runs a list of scrapers (async) then runs the EntityResolver (sync).
    """

    def __init__(self, force: bool = True, continue_on_error: bool = True):
        self.force = force
        self.continue_on_error = continue_on_error

    async def execute_all(self, scraper_keys: Optional[List[str]] = None) -> None:
        # 1) Run scrapers
        keys = scraper_keys or ScraperRegistry.list_keys()
        logger.info("Starting pipeline for %d sources. force=%s", len(keys), self.force)

        for key in keys:
            try:
                logger.info("Running scraper: %s", key)
                scraper = ScraperRegistry.get_scraper(key)
                await scraper.run(force=self.force)
                logger.info("Finished scraper: %s", key)
            except Exception as e:
                logger.exception("Scraper failed: %s -> %s", key, e)
                if not self.continue_on_error:
                    raise

        # 2) Run resolver
        logger.info("Initiating Entity Resolution...")
        resolver = EntityResolver()
        resolver.run()
        logger.info("Entity Resolution finished.")


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    runner = PipelineRunner(force=True, continue_on_error=True)
    # Example: Run specifically for AFDB and NZ Police
    asyncio.run(runner.execute_all(["afdb", "nz_police"]))
