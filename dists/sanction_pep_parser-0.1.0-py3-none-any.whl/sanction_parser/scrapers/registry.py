from typing import Dict, Type
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper

from sanction_parser.scrapers.sources.afdb import AfdbSanctionsScraper
from sanction_parser.scrapers.sources.adb_published import AdbSanctionsPublishedScraper
from sanction_parser.scrapers.sources.argentina_repet import ArgentinaRePETScraper
from sanction_parser.scrapers.sources.australia_dfat import AustralianSanctionsScraper
from sanction_parser.scrapers.sources.belgium_finance import BelgiumSanctionsScraper
from sanction_parser.scrapers.sources.canada_mps import CanadaMPsScraper
from sanction_parser.scrapers.sources.canada_sema import CanadaSEMASanctionsScraper
from sanction_parser.scrapers.sources.chile_infoprobidad import ChileInfoProbidadScraper
from sanction_parser.scrapers.sources.directorio_legislativo import DirectorioLegislativoPEPsScraper
from sanction_parser.scrapers.sources.eu_meps import EUMembersScraper
from sanction_parser.scrapers.sources.ebrd_ineligible import EBRDSanctionsScraper
from sanction_parser.scrapers.sources.us_fhfa_suspended import FhfaSuspendedScraper
from sanction_parser.scrapers.sources.us_bis_denied import BISDeniedPersonsScraper
from sanction_parser.scrapers.sources.iadb_sanctions import IADBSanctionsScraper
from sanction_parser.scrapers.sources.israel_nbctf import IsraelNBCTFScraper
from sanction_parser.scrapers.sources.kyrgyzstan_fiu import KyrgyzstanFiuScraper
from sanction_parser.scrapers.sources.lebanon_isf import LebanonISFTerrorismListScraper
from sanction_parser.scrapers.sources.netherlands_terrorism import NetherlandsTerrorismListScraper
from sanction_parser.scrapers.sources.nigeria_peps import NigeriaPEPsScraper
from sanction_parser.scrapers.sources.nz_police import NZPoliceSanctionsScraper
from sanction_parser.scrapers.sources.us_occ_enforcement import OCCEnforcementScraper
from sanction_parser.scrapers.sources.ofac_sdn import OFACSanctionsScraper
from sanction_parser.scrapers.sources.south_africa_fic import SouthAfricaFICScraper
from sanction_parser.scrapers.sources.taiwan_cib import TaiwanCibScraper
from sanction_parser.scrapers.sources.ukraine_nsdc import UkraineNSDCScraper
from sanction_parser.scrapers.sources.un_aq_sanctions import UNAlQaidaSanctionsScraper
from sanction_parser.scrapers.sources.un_consolidated import UNSanctionsScraper
from sanction_parser.scrapers.sources.un_yemen_sanctions import UNYemenSanctionsScraper
from sanction_parser.scrapers.sources.un_sc_consolidated import UNSCSanctionsScraper
from sanction_parser.scrapers.sources.uruguay_senaclaft import UruguaySenaclaftExcelScraper
from sanction_parser.scrapers.sources.us_senate import USSenateScraper
from sanction_parser.scrapers.sources.argentina_most_wanted import ArgentinaMostWantedScraper
from sanction_parser.scrapers.sources.belgium_police import PoliceBeMostWantedScraper
from sanction_parser.scrapers.sources.canada_bcsc import BcscDisciplinedListScraper
from sanction_parser.scrapers.sources.cia_world_leaders import CiaWorldLeadersScraper
from sanction_parser.scrapers.sources.eu_most_wanted import EuMostWantedScraper
from sanction_parser.scrapers.sources.interpol_red_notices import InterpolRedNoticesScraper
from sanction_parser.scrapers.sources.interpol_yellow_notices import InterpolYellowNoticesScraper
from sanction_parser.scrapers.sources.indonesia_kpk import KpkWantedPersonsScraper
from sanction_parser.scrapers.sources.nigeria_nass import NigeriaNassHouseMembersScraper
from sanction_parser.scrapers.sources.nigeria_nigsac import NigsacSanctionsScraper
from sanction_parser.scrapers.sources.rwanda_umucyo import UmucyoBlacklistScraper
from sanction_parser.scrapers.sources.uk_nca import NcaMostWantedScraper
from sanction_parser.scrapers.sources.uk_parliament import UKParliamentMembersScraper
from sanction_parser.scrapers.sources.us_house import USHouseRepresentativesScraper
from sanction_parser.scrapers.sources.us_marshals import USMarshalsMostWantedScraper
from sanction_parser.scrapers.sources.opensanction import OpenSanctionsScraper


class ScraperRegistry:
    """
    Registry to manage available scrapers and retrieve them by key.
    """
    
    
    
    
    
    
    
    _scrapers: Dict[str, Type[BaseSanctionScraper]] = {
        "afdb": AfdbSanctionsScraper,
        "adb": AdbSanctionsPublishedScraper,
        "argentina": ArgentinaRePETScraper,
        "australia": AustralianSanctionsScraper,
        "belgium": BelgiumSanctionsScraper,
        "canada_mps": CanadaMPsScraper,
        "canada_sema": CanadaSEMASanctionsScraper,
        "chile_infoprobidad": ChileInfoProbidadScraper,
        "directorio_legislativo": DirectorioLegislativoPEPsScraper,
        "eu_meps": EUMembersScraper,
        "ebrd_ineligible": EBRDSanctionsScraper,
        "us_fhfa_suspended": FhfaSuspendedScraper,
        "us_bis_denied": BISDeniedPersonsScraper,
        "iadb": IADBSanctionsScraper,
        "israel_nbctf": IsraelNBCTFScraper,
        "kyrgyzstan_fiu": KyrgyzstanFiuScraper,
        "lebanon_isf": LebanonISFTerrorismListScraper,
        "netherlands_terrorism": NetherlandsTerrorismListScraper,
        "nigeria_peps": NigeriaPEPsScraper,
        "nz_police": NZPoliceSanctionsScraper,
        "us_occ_enforcement": OCCEnforcementScraper,
        "ofac_sdn": OFACSanctionsScraper,
        "south_africa_fic": SouthAfricaFICScraper,
        "taiwan_cib": TaiwanCibScraper,
        "ukraine_nsdc": UkraineNSDCScraper,
        "un_aq_sanctions": UNAlQaidaSanctionsScraper,
        "un_consolidated": UNSanctionsScraper,
        "un_yemen_sanctions": UNYemenSanctionsScraper,
        "un_sc_consolidated": UNSCSanctionsScraper,
        "uruguay_senaclaft": UruguaySenaclaftExcelScraper,
        "us_senate": USSenateScraper,
        "argentina_most_wanted": ArgentinaMostWantedScraper,
        "belgium_police": PoliceBeMostWantedScraper,
        "canada_bcsc": BcscDisciplinedListScraper,
        "cia_world_leaders": CiaWorldLeadersScraper,
        "eu_most_wanted": EuMostWantedScraper,
        "interpol_red_notices": InterpolRedNoticesScraper,
        "interpol_yellow_notices": InterpolYellowNoticesScraper,
        "indonesia_kpk": KpkWantedPersonsScraper,
        "nigeria_nass": NigeriaNassHouseMembersScraper,
        "nigeria_nigsac": NigsacSanctionsScraper,
        "rwanda_umucyo": UmucyoBlacklistScraper,
        "uk_nca": NcaMostWantedScraper,
        "uk_parliament": UKParliamentMembersScraper,
        "us_house": USHouseRepresentativesScraper,
        "us_marshals": USMarshalsMostWantedScraper,
        "opensanction": OpenSanctionsScraper,
    }

    @classmethod
    def get_scraper(cls, key: str) -> BaseSanctionScraper:
        """Returns an instance of the requested scraper."""
        scraper_cls = cls._scrapers.get(key.lower())
        if not scraper_cls:
            raise ValueError(f"Scraper '{key}' not found. Available: {list(cls._scrapers.keys())}")
        return scraper_cls()

    @classmethod
    def list_keys(cls):
        """Returns list of available scraper keys."""
        return list(cls._scrapers.keys())
    
    
