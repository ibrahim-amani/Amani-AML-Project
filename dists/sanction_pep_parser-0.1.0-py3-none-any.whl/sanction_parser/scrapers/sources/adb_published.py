"""
src/sanction_parser/scrapers/sources/adb_published.py

Scraper for the ADB Sanctions List (Published) table.
Features:
- Playwright for handling dynamic JS pagination and filtering.
- Libpostal (optional) for advanced address parsing.
- Pycountry for ISO code resolution.
"""

import re
import json
import logging
import asyncio
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Iterator

# Third-party
import pycountry
from playwright.sync_api import Page, sync_playwright

# Optional Libpostal
try:
    from postal.parser import parse_address as libpostal_parse_address
    from postal.expand import expand_address as libpostal_expand_address
    LIBPOSTAL_AVAILABLE = True
except ImportError:
    libpostal_parse_address = None
    libpostal_expand_address = None
    LIBPOSTAL_AVAILABLE = False

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class AdbSanctionsPublishedScraper(BaseSanctionScraper):
    """
    Scrapes the ADB Sanctions List via Playwright.
    
    Strategy:
    1. Extract: Filter table for 'Individual', paginate through all results, save raw JSON.
    2. Transform: Parse address strings (libpostal), normalize dates, map to schema.
    """
    
    name = "ADB – Sanctions (Published)"
    country = "Global"
    BASE_URL = "https://sanctions.adb.org/sanctions/published"
    DATA_FILENAME = "adb_raw_scrape.json"

    # Playwright Configuration
    HEADLESS = True
    SLOW_MO_MS = 200
    DEFAULT_TIMEOUT_MS = 60_000
    PAGE_STABILIZE_MS = 1500

    # -------------------------------------------------------------------
    # Configuration: Constants & Lookups
    # -------------------------------------------------------------------
    COUNTRY_ALIASES_TO_ISO2: Dict[str, str] = {
        "usa": "US", "u.s.a": "US", "us": "US", "u.s.": "US",
        "united states": "US", "united states of america": "US",
        "uk": "GB", "u.k.": "GB", "great britain": "GB", "britain": "GB", "united kingdom": "GB",
        "uae": "AE", "u.a.e": "AE",
        "russia": "RU", "iran": "IR",
        "syria": "SY", "syrian arab republic": "SY",
        "turkey": "TR",
    }

    ROLE_PREFIXES = {
        "DIRECTOR", "OWNER", "PROPRIETOR", "MANAGER", "CEO", 
        "CHAIRMAN", "PRESIDENT", "PARTNER", "FOUNDER", 
        "MR", "MRS", "MS", "DR",
    }

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Scrape data from the website using Playwright and save to Raw JSON.
        """
        self.logger.info(f"Starting Playwright scrape for: {self.BASE_URL}")
        
        # Run blocking Playwright code in a thread
        try:
            raw_entries = await asyncio.to_thread(self._scrape_sync)
        except Exception as e:
            self.logger.error(f"Playwright scraping failed: {e}")
            return None

        if not raw_entries:
            self.logger.warning("No entries extracted from ADB.")
            return None

        # Save extracted list to raw directory
        output_path = self.raw_dir / self.DATA_FILENAME
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(raw_entries, f, ensure_ascii=False, indent=2)
        
        self.logger.info(f"Saved {len(raw_entries)} raw entries to {output_path}")
        return output_path

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform raw JSON entries into Golden Profile schema.
        """
        self.logger.info(f"Transforming file: {raw_path}")
        
        try:
            with open(raw_path, 'r', encoding='utf-8') as f:
                entries = json.load(f)
        except Exception as e:
            self.logger.error(f"Failed to load raw JSON: {e}")
            return

        mapper = ProfileMapper()

        for entry in entries:
            try:
                name = entry.get("name", "")
                nationality = entry.get("nationality", "")
                
                # 1. ID Generation
                seed = f"{name}|{nationality}"
                person_id = self.generate_uuid(seed)

                # 2. Aliases
                aliases = []
                other_name = entry.get("other_name_or_logo", "")
                if other_name:
                    aliases.append(other_name)

                # 3. Dates
                iso_start_date = self._parse_date_to_iso(entry.get("effect_date", ""))
                iso_end_date = self._parse_date_to_iso(entry.get("lapse_date", ""))

                # 4. Status Check
                is_active = True
                lapse_str = entry.get("lapse_date", "").lower()
                if "until further notice" in lapse_str:
                    is_active = True
                elif iso_end_date:
                    try:
                        if datetime.strptime(iso_end_date, "%Y-%m-%d") < datetime.now():
                            is_active = False
                    except ValueError:
                        pass

                # 5. Address Parsing (Complex Libpostal Logic)
                raw_addr = entry.get("address")
                normalized_addresses = self._normalize_addresses_field_libpostal(
                    [raw_addr] if raw_addr else [],
                    address_type="Residence",
                    fallback_country_text=nationality
                )

                # 6. Build Intermediate Record
                raw_record = {
                    "profile": {
                        "id": person_id,
                        "full_name": name,
                        "entity_type": "INDIVIDUAL",
                        "gender": None,
                        "date_of_birth": None,
                        "nationality": nationality if nationality != "Non ADB Member Country" else None,
                        "is_active": is_active,
                        "aliases": aliases,
                        "images": [],
                        "addresses": normalized_addresses,
                    },
                    "risk_events": [
                        {
                            "type": "Sanction",
                            "source_list": self.name,
                            "authority": "Asian Development Bank (ADB)",
                            "reason": entry.get("grounds", ""),
                            "date_listed": iso_start_date,
                            "is_current": is_active,
                            "risk_level": "High",
                        }
                    ],
                    "evidence": [
                        {
                            "url": self.BASE_URL,
                            "scraped_at": datetime.now(timezone.utc).isoformat(),
                            "raw_text_snippet": f"Raw Address: {raw_addr} | Sanction: {entry.get('sanction_type')}"
                        }
                    ]
                }

                # 7. Normalize & Yield
                result = mapper.map_single_profile(raw_record)

                yield result

            except Exception as row_e:
                self.logger.warning(f"Error processing entry {name}: {row_e}")
                continue

    # -------------------------------------------------------------------
    # Playwright Logic (Synchronous, run in thread)
    # -------------------------------------------------------------------
    def _scrape_sync(self) -> List[Dict[str, Any]]:
        """Core scraping logic controlling the browser."""
        all_entries = []

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=self.HEADLESS, slow_mo=self.SLOW_MO_MS)
            page = browser.new_page()
            page.set_default_timeout(self.DEFAULT_TIMEOUT_MS)

            self.logger.info("Navigating to ADB Sanctions...")
            page.goto(self.BASE_URL, wait_until="networkidle")
            page.wait_for_timeout(2000)

            self._apply_individual_filter(page)

            current_page, total_pages = self._get_page_info(page)
            self.logger.info(f"Detected {total_pages} pages of data.")

            while True:
                entries = self._parse_table_rows(page, current_page)
                all_entries.extend(entries)

                if current_page >= total_pages:
                    break

                if not self._click_next_page(page):
                    self.logger.warning("Next button disabled or not found.")
                    break

                new_current, _ = self._get_page_info(page)
                if new_current == current_page:
                    self.logger.warning("Pagination stuck.")
                    break
                
                current_page = new_current

            browser.close()
        
        return all_entries

    def _apply_individual_filter(self, page: Page):
        try:
            trigger = page.locator("button[role='combobox']", has_text="Entity Type")
            if not trigger.is_visible():
                trigger = page.locator("button[role='combobox']").first
            trigger.click()

            option = page.locator('div[role="option"][data-value="Individual"]')
            option.wait_for(state="visible", timeout=3000)
            option.click()
            page.wait_for_timeout(3000) # Wait for table reload
        except Exception as e:
            self.logger.error(f"Failed to apply filter: {e}")

    def _get_page_info(self, page: Page) -> Tuple[int, int]:
        try:
            page.wait_for_selector("div.gap-xl.mt-lg p", timeout=5000)
            label = page.locator("div.gap-xl.mt-lg p").first.inner_text().strip()
            match = re.search(r"Page\s+(\d+)\s+of\s+(\d+)", label)
            if match:
                return int(match.group(1)), int(match.group(2))
        except Exception:
            pass
        return 1, 1

    def _click_next_page(self, page: Page) -> bool:
        try:
            container = page.locator("div.gap-xl.mt-lg div.gap-sm")
            buttons = container.locator("button")
            if buttons.count() < 3: return False
            next_btn = buttons.nth(2)
            if next_btn.is_disabled(): return False
            next_btn.click()
            page.wait_for_timeout(self.PAGE_STABILIZE_MS)
            return True
        except Exception:
            return False

    def _parse_table_rows(self, page: Page, page_num: int) -> List[Dict[str, Any]]:
        entries = []
        try:
            page.wait_for_selector("tbody tr", timeout=5000)
            rows = page.locator("tbody tr")
            for i in range(rows.count()):
                row = rows.nth(i)
                cells = row.locator("td")
                if cells.count() < 8: continue

                text_content = [self._clean_text(cells.nth(j).inner_text()) for j in range(8)]
                
                # Handle dates "Effect | Lapse"
                dates_raw = text_content[5]
                effect, lapse = dates_raw.split("|", 1) if "|" in dates_raw else (dates_raw, "")

                entries.append({
                    "name": text_content[0],
                    "address": text_content[1],
                    "sanction_type": text_content[2],
                    "other_name_or_logo": text_content[3],
                    "nationality": text_content[4],
                    "effect_date": effect.strip(),
                    "lapse_date": lapse.strip(),
                    "grounds": text_content[6],
                    "page": page_num
                })
        except Exception as e:
            self.logger.warning(f"Row parsing error on page {page_num}: {e}")
        return entries

    # -------------------------------------------------------------------
    # Address & Text Utilities (Preserved Logic)
    # -------------------------------------------------------------------
    def _clean_text(self, text: Optional[str]) -> str:
        if not text: return ""
        return re.sub(r"\s+", " ", text.replace("\xa0", " ")).strip()

    def _parse_date_to_iso(self, date_str: str) -> Optional[str]:
        if not date_str: return None
        try:
            return datetime.strptime(date_str.strip(), "%d/%b/%Y").strftime("%Y-%m-%d")
        except ValueError:
            return None

    def _norm_country_key(self, s: str) -> str:
        s = s.strip().lower().replace("&", "and")
        s = re.sub(r"[\.]", "", s)
        return re.sub(r"\s+", " ", s)

    def _country_to_iso2(self, country_text: Optional[str]) -> Optional[str]:
        if not country_text: return None
        key = self._norm_country_key(country_text)
        if key in self.COUNTRY_ALIASES_TO_ISO2:
            return self.COUNTRY_ALIASES_TO_ISO2[key]
        try:
            res = pycountry.countries.search_fuzzy(country_text)
            if res: return res[0].alpha_2
        except LookupError:
            pass
        return None

    def _peel_role_prefix(self, raw: str) -> Tuple[str, Optional[str]]:
        s = raw.strip()
        if not s: return s, None
        
        # Check "DIRECTOR, ..."
        if "," in s:
            first, rest = s.split(",", 1)
            norm = re.sub(r"[^\w\s]", "", first).strip().upper()
            if norm in self.ROLE_PREFIXES:
                return rest.strip(), norm
        
        # Check "DIRECTOR NAME ..."
        first_token = s.split(" ")[0].upper()
        if first_token in self.ROLE_PREFIXES:
            return s[len(first_token):].strip(" ,"), first_token
            
        return s, None

    # -------------------------------------------------------------------
    # Libpostal Wrapping
    # -------------------------------------------------------------------
    def _normalize_addresses_field_libpostal(
        self, addresses: List[str], address_type: str, fallback_country_text: Optional[str]
    ) -> List[Dict[str, Any]]:
        
        results = []
        for raw in addresses:
            cleaned, role = self._peel_role_prefix(self._clean_text(raw))
            
            # 1. Fallback if libpostal missing
            if not LIBPOSTAL_AVAILABLE:
                iso2 = self._country_to_iso2(fallback_country_text)
                results.append({
                    "addressType": address_type,
                    "line1": cleaned,
                    "line2": role,
                    "countryIsoCode": iso2
                })
                continue

            # 2. Use Libpostal
            try:
                # Expand first
                try:
                    expansions = list(libpostal_expand_address(cleaned))
                    candidate = expansions[0] if expansions else cleaned
                except:
                    candidate = cleaned

                parsed = libpostal_parse_address(candidate) # List of (value, label)
                comp = {label: value for value, label in parsed}
            except Exception:
                comp = {}

            # Map components
            line1_parts = [comp.get(k) for k in ["po_box", "house_number", "road", "house", "building"] if comp.get(k)]
            line1 = " ".join(line1_parts) or None
            
            city = comp.get("city") or comp.get("city_district") or comp.get("suburb")
            state = comp.get("state") or comp.get("state_district")
            postcode = comp.get("postcode")
            country_raw = comp.get("country")

            iso2 = self._country_to_iso2(country_raw) or self._country_to_iso2(fallback_country_text)

            results.append({
                "addressType": address_type,
                "line1": line1 if line1 else cleaned, # Fallback to raw if parsing emptied it
                "line2": role,
                "city": city.title() if city else None,
                "county": state.title() if state else None,
                "postcode": postcode,
                "countryIsoCode": iso2
            })
            
        return results

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = AdbSanctionsPublishedScraper()
    asyncio.run(scraper.run(force=True))