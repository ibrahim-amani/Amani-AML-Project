"""
src/sanction_parser/scrapers/sources/afdb.py

Scraper implementation for the African Development Bank (AfDB) Sanctions List.
"""

import csv
import html
import asyncio
import logging
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional

# Third-party libraries
from curl_cffi import requests as curl_requests

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper
from sanction_parser.scrapers.utils.web_client import extract_download_links

# Initialize logger for this specific module
logger = logging.getLogger(__name__)

class AfdbSanctionsScraper(BaseSanctionScraper):
    """
    Scraper for African Development Bank (AfDB).
    
    Source URL: https://www.afdb.org/en/projects-and-operations/procurement/debarment-and-sanctions-procedures
    Format: CSV (primary) with JSON fallback logic.
    """
    
    name = "African Development Bank (AfDB) - Sanctions List"
    country = "Global"  # Although AfDB is African, the entities can be global
    
    BASE_URL = "https://www.afdb.org/en/projects-and-operations/procurement/debarment-and-sanctions-procedures"
    DATA_FILENAME = "afdb_sanctions.csv"
    TARGET_EXTS = ["csv", "json"]

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Download raw data.
        
        Strategy:
        1. Scan the base URL for download links (CSV preferred).
        2. Use curl_cffi to bypass potential WAF/Bot protections.
        3. Save the file to the raw directory defined by the Base Class.
        
        Returns:
            Path to the downloaded file, or None if failed.
        """
        self.logger.info(f"Scanning page for files: {self.BASE_URL}")

        # 1. Extract links (run in a separate thread to avoid blocking the event loop)
        try:
            links = await asyncio.to_thread(extract_download_links, self.BASE_URL, exts=self.TARGET_EXTS)
        except Exception as e:
            self.logger.error(f"Link extraction failed: {e}")
            return None

        if not links:
            self.logger.warning("No download links found via helper extraction.")
            return None

        # Prioritize CSV, fallback to JSON
        target_link = next((l for l in links if "export" in l['url'] or l['ext'] == 'csv'), None)
        
        if not target_link:
            json_link = next((l for l in links if "json" in l['ext']), None)
            if json_link:
                self.logger.warning("CSV not found, falling back to JSON link (schema might mismatch).")
                target_link = json_link
            else:
                self.logger.error("Critical: No CSV or JSON links found.")
                return None

        file_url = target_link['url']
        # self.raw_dir is automatically managed by BaseSanctionScraper
        local_file_path = self.raw_dir / self.DATA_FILENAME
        
        self.logger.info(f"Target URL found: {file_url}")
        self.logger.info(f"Downloading to: {local_file_path}")

        # 2. Download file
        # Defined as a blocking function to run in a thread
        def _download_task():
            # impersonate="chrome110" mimics a real browser to bypass 403 errors
            response = curl_requests.get(file_url, impersonate="chrome110", timeout=60)
            response.raise_for_status()
            
            with open(local_file_path, 'wb') as f:
                f.write(response.content)

        try:
            await asyncio.to_thread(_download_task)
            
            if local_file_path.exists() and local_file_path.stat().st_size > 0:
                return local_file_path
            else:
                self.logger.error("File downloaded but appears empty or missing.")
                return None

        except Exception as e:
            self.logger.error(f"Download failed: {e}")
            # Clean up partial files
            if local_file_path.exists():
                local_file_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform raw CSV data into Golden Profile schema.
        
        Args:
            raw_path: Path to the file downloaded in the extract step.
            
        Yields:
            Dictionaries compliant with the target schema.
        """
        # Ensure we are targeting the right file
        target_file = raw_path
        if raw_path.is_dir():
            # Fallback if raw_path passed was a directory
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            # Retry wildcard globbing if specific filename missing
            csv_files = list(raw_path.parent.glob("*.csv"))
            if csv_files:
                target_file = csv_files[0]
            else:
                self.logger.warning(f"File not found for transformation: {target_file}")
                return

        self.logger.info(f"Processing file: {target_file}")
        
        mapper = ProfileMapper()
        
        try:
            with open(target_file, 'r', encoding='utf-8', errors='replace') as f:
                reader = csv.DictReader(f)
                
                for row in reader:
                    try:
                        # 1. Filter: Only process Individuals
                        entity_type = row.get("Type", "").strip().upper()
                        if entity_type != "INDIVIDUAL":
                            continue

                        # 2. Extract Raw Fields
                        raw_name = row.get("Name", "").strip()
                        name = html.unescape(raw_name) if raw_name else "Unknown Entity"
                        nationality = row.get("Nationality", "").strip()
                        basis = row.get("Basis", "").strip()
                        
                        # 3. Parse Dates & Status
                        start_date = self._parse_afdb_date(row.get("From", ""))
                        end_date = self._parse_afdb_date(row.get("To", ""))
                        is_active = self._determine_active_status(end_date)
                        
                        # 4. Generate Stable ID
                        # Combining Name + Nationality usually creates a unique enough key for this list
                        unique_key = f"{name}{nationality}"
                        record_id = self.generate_uuid(unique_key)

                        # 5. Build Intermediate "Raw Record" for Mapper
                        # This matches the structure expected by ProfileMapper.map_single_profile
                        raw_record = {
                            "profile": {
                                "id": record_id, 
                                "full_name": name,
                                "entity_type": entity_type,
                                "gender": None, 
                                "date_of_birth": None, 
                                "nationality": nationality,
                                "is_active": is_active,
                                "aliases": [],
                                "images": [],
                                "addresses": [],
                            },
                            "risk_events": [
                                {
                                    "type": "Sanction",
                                    "source_list": self.name,
                                    "authority": "African Development Bank Group",
                                    "reason": basis,
                                    "date_listed": start_date,
                                    "is_current": is_active,
                                    "risk_level": "High"
                                }
                            ],
                            "evidence": [
                                {
                                    "url": self.BASE_URL,
                                    "scraped_at": datetime.now().isoformat(),
                                    "raw_text_snippet": str(dict(row))
                                }
                            ]
                        }

                        # 6. Normalize
                        result = mapper.map_single_profile(raw_record)
                        

                        yield result

                    except Exception as row_err:
                        self.logger.warning(f"Skipping row due to error: {row_err} | Row: {row}")
                        continue

        except Exception as e:
            self.logger.error(f"Failed to read/transform CSV file: {e}")
            raise e

    # ---------------------------------------------------------
    # Helper Methods
    # ---------------------------------------------------------

    def _parse_afdb_date(self, date_str: str) -> Optional[str]:
        """
        Parses dates like '01-Jan-2023' to '2023-01-01'.
        """
        if not date_str:
            return None
        try:
            dt = datetime.strptime(date_str.strip(), "%d-%b-%Y")
            return dt.strftime("%Y-%m-%d")
        except ValueError:
            return None 

    def _determine_active_status(self, end_date_str: Optional[str]) -> bool:
        """
        Determines if the sanction is still active based on the end date.
        """
        if not end_date_str:
            # If no end date is provided, assume indefinite/active
            return True
        try:
            end_dt = datetime.strptime(end_date_str, "%Y-%m-%d")
            # Active if end_date is in the future
            return end_dt > datetime.now()
        except ValueError:
            return True

# ---------------------------------------------------------
# Standalone Execution Block (For Debugging)
# ---------------------------------------------------------
if __name__ == "__main__":
    # This allows running the scraper directly: python -m src.sanction_parser.scrapers.sources.afdb
    logging.basicConfig(level=logging.INFO)
    scraper = AfdbSanctionsScraper()
    asyncio.run(scraper.run(force=True))