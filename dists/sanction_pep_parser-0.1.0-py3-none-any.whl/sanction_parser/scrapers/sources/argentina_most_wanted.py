# """
# src/sanction_parser/scrapers/sources/argentina_most_wanted.py

# Scrapes Argentina "Prófugos" (Rewards / Wanted Persons) listings and profiles.
# Source: https://www.argentina.gob.ar/seguridad/recompensas/profugos
# """

# import json
# import re
# import time
# import logging
# import asyncio
# import requests
# from pathlib import Path
# from datetime import datetime, timezone
# from typing import Any, Dict, List, Optional, Iterator
# from urllib.parse import urljoin
# from bs4 import BeautifulSoup

# # Internal Package Imports
# from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
# from sanction_parser.domain.normalizers import ProfileMapper

# # Initialize logger
# logger = logging.getLogger(__name__)

# class ArgentinaMostWantedScraper(BaseSanctionScraper):
#     """
#     Scraper for Argentina Most Wanted (Prófugos).
    
#     Source URL: https://www.argentina.gob.ar/seguridad/recompensas/profugos
#     Format: Web Scraping (HTML -> JSON)
#     Type: Wanted (High Risk)
#     """
#     name = "Argentina – Most Wanted"
#     country = "Argentina"
    
#     BASE_URL = "https://www.argentina.gob.ar"
#     LIST_URL = BASE_URL + "/seguridad/recompensas/profugos"
#     DATA_FILENAME = "argentina_most_wanted_raw.json"
#     USER_AGENT = "Mozilla/5.0 (compatible; SanctionParser/1.0)"

#     def __init__(self):
#         super().__init__()
#         self.session = self._build_session()

#     def _build_session(self) -> requests.Session:
#         """Create a requests Session with consistent headers."""
#         s = requests.Session()
#         s.headers.update({"User-Agent": self.USER_AGENT})
#         return s

#     async def extract(self) -> Optional[Path]:
#         """
#         Step 1: Scrape all pages and profiles, saving raw data to JSON.
#         """
#         self.logger.info(f"Starting scrape of: {self.LIST_URL}")
#         local_path = self.raw_dir / self.DATA_FILENAME

#         def _scrape_sync():
#             # 1. Get total pages
#             self.logger.info("Fetching first page to determine count...")
#             first_html = self._fetch_html(self.LIST_URL)
#             total_pages = self._get_total_pages(first_html)
#             self.logger.info(f"Detected {total_pages} pages.")

#             all_fugitives = []

#             # 2. Iterate Pages
#             for page_idx in range(total_pages):
#                 url = self.LIST_URL if page_idx == 0 else f"{self.LIST_URL}?page={page_idx}"
#                 self.logger.info(f"Scraping page {page_idx + 1}/{total_pages}...")
                
#                 html_text = first_html if page_idx == 0 else self._fetch_html(url)
#                 fugitives = self._parse_list_page(html_text)
#                 all_fugitives.extend(fugitives)

#             self.logger.info(f"Found {len(all_fugitives)} entries. Fetching details...")

#             # 3. Fetch Details for each profile
#             for idx, fug in enumerate(all_fugitives, start=1):
#                 profile_url = fug.get("profile_url")
#                 if not profile_url:
#                     continue
                
#                 if idx % 10 == 0:
#                     self.logger.info(f"Processing profile {idx}/{len(all_fugitives)}")

#                 try:
#                     profile_html = self._fetch_html(profile_url)
#                     fug["profile_details"] = self._parse_profile_page(profile_html)
#                 except Exception as e:
#                     self.logger.warning(f"Failed profile {profile_url}: {e}")
#                     fug["profile_details"] = {}
                
#                 # Be polite
#                 time.sleep(0.5)

#             # 4. Save Raw Data
#             with open(local_path, "w", encoding="utf-8") as f:
#                 json.dump(all_fugitives, f, ensure_ascii=False, indent=2)
            
#             return local_path

#         try:
#             return await asyncio.to_thread(_scrape_sync)
#         except Exception as e:
#             self.logger.error(f"Scraping failed: {e}")
#             if local_path.exists():
#                 local_path.unlink()
#             return None

#     def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
#         """
#         Step 2: Transform raw JSON to Golden Profile.
#         """
#         if not raw_path.exists():
#             return

#         self.logger.info(f"Transforming file: {raw_path}")
#         mapper = ProfileMapper()

#         try:
#             with open(raw_path, "r", encoding="utf-8") as f:
#                 raw_data = json.load(f)

#             for entry in raw_data:
#                 try:
#                     # 1. Basic Info
#                     full_name = entry.get("name")
#                     if not full_name:
#                         continue

#                     details = entry.get("profile_details", {})
                    
#                     # 2. Extract Fields
#                     # Profile page might have a better name header
#                     if details.get("name_in_profile"):
#                         full_name = details["name_in_profile"]

#                     raw_alias = details.get("alias")
#                     aliases = []
#                     if raw_alias:
#                         parts = re.split(r"[,/]", raw_alias)
#                         aliases = [p.strip() for p in parts if p.strip()]

#                     # Images
#                     images = []
#                     if entry.get("picture_url"):
#                         images.append(entry["picture_url"])
#                     if details.get("large_image"):
#                         images.append(details["large_image"])
#                     images = list(dict.fromkeys(images)) # Dedup

#                     # Risk Info
#                     crime = details.get("crime", "Criminal Investigation")
#                     reward = details.get("recompensa", "N/A")
                    
#                     gender = details.get("gender")
#                     dob = details.get("dob")
#                     nationality = details.get("nationality", "Argentina")

#                     # 3. ID Generation
#                     unique_key = f"{full_name}_{crime}"
#                     record_id = self.generate_uuid(unique_key)

#                     # 4. Build Record
#                     mapped_record = {
#                         "profile": {
#                             "id": record_id,
#                             "full_name": full_name,
#                             "entity_type": "INDIVIDUAL",
#                             "gender": gender,
#                             "date_of_birth": dob,
#                             "nationality": nationality,
#                             "is_active": True, 
#                             "aliases": aliases,
#                             "images": images,
#                             "addresses": []
#                         },
#                         "risk_events": [
#                             {
#                                 "type": "Wanted",
#                                 "source_list": self.name,
#                                 "authority": "Ministerio de Seguridad (Argentina)",
#                                 "reason": crime,
#                                 "date_listed": datetime.now().strftime("%Y-%m-%d"), 
#                                 "is_current": True,
#                                 "risk_level": "High"
#                             }
#                         ],
#                         "evidence": [
#                             {
#                                 "url": entry.get("profile_url"),
#                                 "scraped_at": datetime.now(timezone.utc).isoformat(),
#                                 "raw_text_snippet": f"Crime: {crime} | Reward: {reward} | Alias: {raw_alias}"
#                             }
#                         ]
#                     }

#                     # 5. Normalize & Yield
#                     result = mapper.map_single_profile(mapped_record)
#                     if "data" in result:
#                         yield result["data"]
#                     else:
#                         yield result

#                 except Exception as inner_e:
#                     self.logger.warning(f"Error transforming record: {inner_e}")
#                     continue

#         except Exception as e:
#             self.logger.error(f"Failed to process JSON file: {e}")
#             raise e

#     # ---------------------------------------------------------
#     # Internal Helpers (Preserved Logic)
#     # ---------------------------------------------------------

#     def _fetch_html(self, url: str, retries: int = 3, timeout: int = 60) -> str:
#         last_err = None
#         for i in range(retries):
#             try:
#                 resp = self.session.get(url, timeout=timeout)
#                 resp.raise_for_status()
#                 return resp.text
#             except Exception as e:
#                 last_err = e
#                 wait_s = 1.5 * (i + 1)
#                 time.sleep(wait_s)
#         raise last_err

#     def _parse_list_page(self, html_text: str) -> List[Dict[str, Any]]:
#         soup = BeautifulSoup(html_text, "html.parser")
#         cards = soup.select("a.panel.panel-default.panel-icon.panel-secondary")
#         fugitives = []

#         for card in cards:
#             profile_rel = (card.get("href") or "").strip()
#             if not profile_rel: continue

#             profile_url = urljoin(self.BASE_URL, profile_rel)
#             name_tag = card.select_one("h4")
#             name = name_tag.get_text(strip=True) if name_tag else ""

#             picture_url = None
#             img_div = card.select_one(".panel-heading")
#             style = (img_div.get("style") or "") if img_div else ""

#             if "background-image" in style and "url" in style:
#                 m = re.search(r"url\((['\"]?)(.*?)\1\)", style)
#                 if m:
#                     picture_url = urljoin(self.BASE_URL, m.group(2))

#             fugitives.append({
#                 "name": name or None,
#                 "profile_url": profile_url,
#                 "picture_url": picture_url,
#             })
#         return fugitives

#     def _get_total_pages(self, html_text: str) -> int:
#         soup = BeautifulSoup(html_text, "html.parser")
#         links = soup.select("ul.pagination li a[href]")
#         page_numbers = []
#         for a in links:
#             href = a.get("href", "")
#             if "page=" not in href: continue
#             try:
#                 num = int(href.split("page=")[-1])
#                 page_numbers.append(num)
#             except: continue
#         return (max(page_numbers) + 1) if page_numbers else 1

#     def _extract_field(self, soup: BeautifulSoup, label: str) -> Optional[str]:
#         strong = soup.find("strong", string=lambda s: bool(s) and s.strip().startswith(label))
#         if not strong: return None
#         parent = strong.parent
#         next_el = parent.find_next_sibling() if parent else None
#         if next_el:
#             text = next_el.get_text(" ", strip=True)
#             return text.strip() if text else None
#         return None

#     def _parse_profile_page(self, html_text: str) -> Dict[str, Any]:
#         soup = BeautifulSoup(html_text, "html.parser")
#         result = {}

#         h1 = soup.find("h1")
#         if h1: result["name_in_profile"] = h1.get_text(strip=True)

#         labels = {
#             "Alias": "alias",
#             "Recompensa": "recompensa",
#             "Delito": "crime",
#             "Último domicilio conocido": "address",
#             "Fecha de nacimiento": "dob",
#             "Nacionalidad": "nationality",
#             "Sexo": "gender",
#         }

#         for label_text, key in labels.items():
#             val = self._extract_field(soup, label_text)
#             if val: result[key] = val

#         img = soup.find("img")
#         if img and img.get("src"):
#             full_img_url = urljoin(self.BASE_URL, img["src"])
#             if "logo_argentina" not in full_img_url:
#                 result["large_image"] = full_img_url

#         return result

# if __name__ == "__main__":
#     logging.basicConfig(level=logging.INFO)
#     scraper = ArgentinaMostWantedScraper()
#     asyncio.run(scraper.run(force=True))



"""
src/sanction_parser/scrapers/sources/argentina_most_wanted.py

Scrapes Argentina "Prófugos" (Rewards / Wanted Persons) listings and profiles.
Source: https://www.argentina.gob.ar/seguridad/recompensas/profugos
"""

import json
import re
import logging
import asyncio
import aiohttp
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Iterator
from urllib.parse import urljoin
from bs4 import BeautifulSoup

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class ArgentinaMostWantedScraper(BaseSanctionScraper):
    """
    Scraper for Argentina Most Wanted (Prófugos).
    
    Source URL: https://www.argentina.gob.ar/seguridad/recompensas/profugos
    Format: Web Scraping (Async HTML -> JSON)
    Type: Wanted (High Risk)
    """
    name = "Argentina – Most Wanted"
    country = "Argentina"
    
    BASE_URL = "https://www.argentina.gob.ar"
    LIST_URL = BASE_URL + "/seguridad/recompensas/profugos"
    DATA_FILENAME = "argentina_most_wanted_raw.json"
    
    # Tuning
    CONCURRENCY_LIMIT = 10  # Number of simultaneous requests

    async def _fetch_html_async(self, session: aiohttp.ClientSession, url: str, retries: int = 3) -> str:
        """Async helper to fetch HTML with retries."""
        for i in range(retries):
            try:
                async with session.get(url, timeout=30) as response:
                    response.raise_for_status()
                    return await response.text()
            except Exception as e:
                if i == retries - 1:
                    self.logger.warning(f"Failed to fetch {url}: {e}")
                    raise e
                await asyncio.sleep(1.5 * (i + 1))
        return ""

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Scrape all pages and profiles concurrently using aiohttp.
        """
        self.logger.info(f"Starting async scrape of: {self.LIST_URL}")
        local_path = self.raw_dir / self.DATA_FILENAME

        async with aiohttp.ClientSession(headers={"User-Agent": "Mozilla/5.0"}) as session:
            # 1. Get total pages from the first page
            try:
                self.logger.info("Fetching first page to determine count...")
                first_html = await self._fetch_html_async(session, self.LIST_URL)
                total_pages = self._get_total_pages(first_html)
                self.logger.info(f"Detected {total_pages} pages.")
            except Exception as e:
                self.logger.error(f"Initial connection failed: {e}")
                return None

            all_fugitives = []
            
            # Parse Page 1 immediately
            all_fugitives.extend(self._parse_list_page(first_html))

            # 2. Fetch remaining pages concurrently
            if total_pages > 1:
                page_tasks = []
                for page_idx in range(1, total_pages): # Pages are 0-indexed in URL param usually, but verify logic
                    # Based on previous logic: ?page=1 is the second page
                    url = f"{self.LIST_URL}?page={page_idx}"
                    page_tasks.append(self._fetch_html_async(session, url))
                
                self.logger.info(f"Fetching {len(page_tasks)} remaining pages in parallel...")
                pages_html = await asyncio.gather(*page_tasks, return_exceptions=True)

                for html in pages_html:
                    if isinstance(html, str):
                        all_fugitives.extend(self._parse_list_page(html))

            self.logger.info(f"Found {len(all_fugitives)} entries. Fetching details in parallel...")

            # 3. Fetch Details concurrently
            sem = asyncio.Semaphore(self.CONCURRENCY_LIMIT)

            async def process_profile(fug: Dict[str, Any]):
                profile_url = fug.get("profile_url")
                if not profile_url:
                    fug["profile_details"] = {}
                    return

                async with sem:
                    try:
                        html = await self._fetch_html_async(session, profile_url)
                        fug["profile_details"] = self._parse_profile_page(html)
                    except Exception:
                        fug["profile_details"] = {}

            # Create tasks for all profiles
            tasks = [process_profile(fug) for fug in all_fugitives]
            
            # Show progress
            total_tasks = len(tasks)
            # Gather with progress logging roughly
            for i, task in enumerate(asyncio.as_completed(tasks)):
                await task
                if (i + 1) % 10 == 0:
                    self.logger.info(f"Processed {i + 1}/{total_tasks} profiles")

            # 4. Save Raw Data
            with open(local_path, "w", encoding="utf-8") as f:
                json.dump(all_fugitives, f, ensure_ascii=False, indent=2)
            
            return local_path

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform raw JSON to Golden Profile.
        """
        if not raw_path.exists():
            return

        self.logger.info(f"Transforming file: {raw_path}")
        mapper = ProfileMapper()

        try:
            with open(raw_path, "r", encoding="utf-8") as f:
                raw_data = json.load(f)

            for entry in raw_data:
                try:
                    # 1. Basic Info
                    full_name = entry.get("name")
                    if not full_name:
                        continue

                    details = entry.get("profile_details", {})
                    
                    # 2. Extract Fields
                    if details.get("name_in_profile"):
                        full_name = details["name_in_profile"]

                    raw_alias = details.get("alias")
                    aliases = []
                    if raw_alias:
                        parts = re.split(r"[,/]", raw_alias)
                        aliases = [p.strip() for p in parts if p.strip()]

                    # Images
                    images = []
                    if entry.get("picture_url"):
                        images.append(entry["picture_url"])
                    if details.get("large_image"):
                        images.append(details["large_image"])
                    images = list(dict.fromkeys(images)) # Dedup

                    # Risk Info
                    crime = details.get("crime", "Criminal Investigation")
                    reward = details.get("recompensa", "N/A")
                    
                    gender = details.get("gender")
                    dob = details.get("dob")
                    nationality = details.get("nationality", "Argentina")

                    # 3. ID Generation
                    unique_key = f"{full_name}_{crime}"
                    record_id = self.generate_uuid(unique_key)

                    # 4. Build Record
                    mapped_record = {
                        "profile": {
                            "id": record_id,
                            "full_name": full_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": gender,
                            "date_of_birth": dob,
                            "nationality": nationality,
                            "is_active": True, 
                            "aliases": aliases,
                            "images": images,
                            "addresses": []
                        },
                        "risk_events": [
                            {
                                "type": "Wanted",
                                "source_list": self.name,
                                "authority": "Ministerio de Seguridad (Argentina)",
                                "reason": crime,
                                "date_listed": datetime.now().strftime("%Y-%m-%d"), 
                                "is_current": True,
                                "risk_level": "High"
                            }
                        ],
                        "evidence": [
                            {
                                "url": entry.get("profile_url"),
                                "scraped_at": datetime.now(timezone.utc).isoformat(),
                                "raw_text_snippet": f"Crime: {crime} | Reward: {reward} | Alias: {raw_alias}"
                            }
                        ]
                    }

                    # 5. Normalize & Yield
                    result = mapper.map_single_profile(mapped_record)
                    if "data" in result:
                        yield result["data"]
                    else:
                        yield result

                except Exception as inner_e:
                    self.logger.warning(f"Error transforming record: {inner_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process JSON file: {e}")
            raise e

    # ---------------------------------------------------------
    # Parsing Helpers (BeautifulSoup Logic)
    # ---------------------------------------------------------

    def _parse_list_page(self, html_text: str) -> List[Dict[str, Any]]:
        soup = BeautifulSoup(html_text, "html.parser")
        cards = soup.select("a.panel.panel-default.panel-icon.panel-secondary")
        fugitives = []

        for card in cards:
            profile_rel = (card.get("href") or "").strip()
            if not profile_rel: continue

            profile_url = urljoin(self.BASE_URL, profile_rel)
            name_tag = card.select_one("h4")
            name = name_tag.get_text(strip=True) if name_tag else ""

            picture_url = None
            img_div = card.select_one(".panel-heading")
            style = (img_div.get("style") or "") if img_div else ""

            if "background-image" in style and "url" in style:
                m = re.search(r"url\((['\"]?)(.*?)\1\)", style)
                if m:
                    picture_url = urljoin(self.BASE_URL, m.group(2))

            fugitives.append({
                "name": name or None,
                "profile_url": profile_url,
                "picture_url": picture_url,
            })
        return fugitives

    def _get_total_pages(self, html_text: str) -> int:
        soup = BeautifulSoup(html_text, "html.parser")
        links = soup.select("ul.pagination li a[href]")
        page_numbers = []
        for a in links:
            href = a.get("href", "")
            if "page=" not in href: continue
            try:
                num = int(href.split("page=")[-1])
                page_numbers.append(num)
            except: continue
        return (max(page_numbers) + 1) if page_numbers else 1

    def _extract_field(self, soup: BeautifulSoup, label: str) -> Optional[str]:
        strong = soup.find("strong", string=lambda s: bool(s) and s.strip().startswith(label))
        if not strong: return None
        parent = strong.parent
        next_el = parent.find_next_sibling() if parent else None
        if next_el:
            text = next_el.get_text(" ", strip=True)
            return text.strip() if text else None
        return None

    def _parse_profile_page(self, html_text: str) -> Dict[str, Any]:
        soup = BeautifulSoup(html_text, "html.parser")
        result = {}

        h1 = soup.find("h1")
        if h1: result["name_in_profile"] = h1.get_text(strip=True)

        labels = {
            "Alias": "alias",
            "Recompensa": "recompensa",
            "Delito": "crime",
            "Último domicilio conocido": "address",
            "Fecha de nacimiento": "dob",
            "Nacionalidad": "nationality",
            "Sexo": "gender",
        }

        for label_text, key in labels.items():
            val = self._extract_field(soup, label_text)
            if val: result[key] = val

        img = soup.find("img")
        if img and img.get("src"):
            full_img_url = urljoin(self.BASE_URL, img["src"])
            if "logo_argentina" not in full_img_url:
                result["large_image"] = full_img_url

        return result

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = ArgentinaMostWantedScraper()
    asyncio.run(scraper.run(force=True))