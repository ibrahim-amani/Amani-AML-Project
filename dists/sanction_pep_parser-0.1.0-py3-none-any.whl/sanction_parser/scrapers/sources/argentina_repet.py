"""
src/sanction_parser/scrapers/sources/argentina_repet.py

Scraper for Argentina's Public Register of Persons and Entities Linked to Acts of Terrorism (RePET).
"""

import json
import logging
import asyncio
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional, List

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper
from sanction_parser.scrapers.utils.web_client import extract_download_links, get_request

# Initialize logger
logger = logging.getLogger(__name__)

class ArgentinaRePETScraper(BaseSanctionScraper):
    """
    Scraper for Argentina RePET (Registro Público de Personas y Entidades vinculadas a actos de Terrorismo).
    
    Source: https://repet.jus.gob.ar/
    Format: JSON
    """
    name = "Argentina - RePET Sanctions"
    country = "Argentina"
    
    BASE_URL = "https://repet.jus.gob.ar/"
    DATA_FILENAME = "argentina_repet.json"
    TARGET_EXTS = ["json", "jsonl"]

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Download the raw JSON data.
        
        Strategy:
        1. Scan the main page for JSON download links.
        2. Filter specifically for the "Personas" (Individuals) list.
        3. Download the file to the raw directory.
        """
        self.logger.info(f"Scanning page for JSON links: {self.BASE_URL}")

        # 1. Extract Links
        try:
            links = await asyncio.to_thread(extract_download_links, self.BASE_URL, exts=self.TARGET_EXTS)
        except Exception as e:
            self.logger.error(f"Link extraction failed: {e}")
            return None

        if not links:
            self.logger.warning("No JSON download links found on the page.")
            return None

        # 2. Find Target Link (Filter for 'personas')
        target_link = None
        for l in links:
            # Check both text and url for keywords indicating individuals
            if "personas" in l.get("text", "").lower() or "personas" in l.get("url", "").lower():
                target_link = l
                break
        
        # Fallback to the first JSON link if specific one not found
        if not target_link:
            self.logger.warning("Specific 'Personas' link not found. Falling back to first available JSON.")
            target_link = links[0]

        # 3. Construct Full URL
        file_url = target_link['url']
        if not file_url.startswith("http"):
            base = self.BASE_URL.rstrip("/")
            file_url = f"{base}/{file_url.lstrip('/')}"

        self.logger.info(f"Target URL identified: {file_url}")

        # 4. Download
        local_path = self.raw_dir / self.DATA_FILENAME

        def _download_task():
            response = get_request(file_url, stream=True, timeout=60)
            with open(local_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

        try:
            await asyncio.to_thread(_download_task)
            return local_path
        except Exception as e:
            self.logger.error(f"Download failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform raw JSON into Golden Profile schema.
        """
        self.logger.info(f"Processing file: {raw_path}")

        mapper = ProfileMapper()

        try:
            with open(raw_path, 'r', encoding='utf-8') as f:
                raw_content = json.load(f)
                
            # Handle different JSON envelope structures
            items = raw_content if isinstance(raw_content, list) else raw_content.get("data", [])

            for item in items:
                try:
                    # 1. Basic Info
                    first = self._clean_text(item.get("FIRST_NAME"))
                    second = self._clean_text(item.get("SECOND_NAME"))
                    third = self._clean_text(item.get("THIRD_NAME"))
                    fourth = self._clean_text(item.get("FOURTH_NAME"))
                    
                    # Construct Full Name
                    full_name_parts = [p for p in [first, second, third, fourth] if p]
                    if not full_name_parts:
                        continue
                    full_name = " ".join(full_name_parts)

                    # Metadata
                    data_id = self._clean_text(item.get("DATAID"))
                    ref_num = self._clean_text(item.get("REFERENCE_NUMBER"))
                    comments = self._clean_text(item.get("COMMENTS1"))
                    list_type = self._clean_text(item.get("UN_LIST_TYPE"))

                    # 2. Nationalities
                    nationalities = []
                    for nat in item.get("NATIONALITY", []):
                        val = self._clean_text(nat.get("VALUE"))
                        if val:
                            nationalities.append(val)
                    nationality_str = nationalities[0] if nationalities else None

                    # 3. Aliases
                    aliases = []
                    orig_script = self._clean_text(item.get("NAME_ORIGINAL_SCRIPT"))
                    if orig_script:
                        aliases.append(orig_script)
                    
                    for alias in item.get("INDIVIDUAL_ALIAS", []):
                        name = self._clean_text(alias.get("ALIAS_NAME"))
                        if name:
                            aliases.append(name)

                    # 4. Documents
                    id_docs = []
                    for doc in item.get("INDIVIDUAL_DOCUMENT", []):
                        num = self._clean_text(doc.get("NUMBER"))
                        dtype = self._clean_text(doc.get("TYPE_OF_DOCUMENT"))
                        country = self._clean_text(doc.get("ISSUING_COUNTRY"))
                        if num:
                            id_docs.append(f"{dtype or 'ID'}: {num} ({country or 'Unknown'})")

                    # 5. Addresses 
                    addresses = []
                    for addr in item.get("INDIVIDUAL_ADDRESS", []):
                        city = self._clean_text(addr.get("CITY"))
                        country = self._clean_text(addr.get("COUNTRY"))
                        note = self._clean_text(addr.get("NOTE"))
                        
                        parts = [p for p in [city, country] if p]
                        addr_str = ", ".join(parts)
                        if note:
                            addr_str += f" (Note: {note})"
                        if addr_str:
                            addresses.append(addr_str)

                    # 6. Dates
                    date_listed = self._parse_repet_date(item.get("LISTED_ON"))
                    
                    # Date of Birth
                    dob_list = item.get("INDIVIDUAL_DATE_OF_BIRTH", [])
                    dob = None
                    if dob_list:
                        # Taking the first available year or full date
                        d_entry = dob_list[0]
                        # Some entries have specific dates, others just years
                        dob = self._clean_text(d_entry.get("DATE")) or \
                              self._clean_text(d_entry.get("YEAR")) or \
                              self._clean_text(d_entry.get("FROM_YEAR"))

                    # 7. Generate IDs
                    unique_key = f"{data_id}_{ref_num}_{full_name}"
                    record_id = self.generate_uuid(unique_key)

                    # 8. Build Intermediate Record
                    raw_record = {
                        "profile": {
                            "id": record_id,
                            "full_name": full_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": self._clean_text(item.get("GENDER")),
                            "date_of_birth": dob,
                            "nationality": nationality_str,
                            "is_active": True,
                            "aliases": aliases,
                            "images": [],
                            "addresses": addresses,
                        },
                        "risk_events": [
                            {
                                "type": "Sanction",
                                "source_list": self.name,
                                "authority": "Ministry of Justice and Human Rights (Argentina)",
                                "reason": f"List Type: {list_type} | Ref: {ref_num}",
                                "date_listed": date_listed,
                                "is_current": True,
                                "risk_level": "High",
                            }
                        ],
                        "evidence": [
                            {
                                "url": self.BASE_URL,
                                "scraped_at": datetime.now().isoformat(),
                                "raw_text_snippet": f"DataID: {data_id} | Docs: {id_docs} | Comments: {comments}"
                            }
                        ]
                    }

                    # 9. Normalize & Yield
                    result = mapper.map_single_profile(raw_record)

                    yield result

                except Exception as row_e:
                    self.logger.warning(f"Error parsing item {item.get('DATAID', 'unknown')}: {row_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process JSON file: {e}")
            raise e

    # ---------------------------------------------------------
    # Helper Methods
    # ---------------------------------------------------------

    def _clean_text(self, text: Any) -> Optional[str]:
        """Utility to strip whitespace and handle None."""
        if not text:
            return None
        return str(text).strip()

    def _parse_repet_date(self, date_str: Optional[str]) -> Optional[str]:
        
        """
        Parses dates format dd/mm/yyyy often found in RePET JSON.
        Handles escaped slashes like '20/10/2023'.
        """
        if not date_str:
            return None
        
        # Clean escaped slashes
        clean_d = date_str.replace("\\/", "/")
        
        try:
            return datetime.strptime(clean_d, "%d/%m/%Y").strftime("%Y-%m-%d")
        except ValueError:
            return None

# ---------------------------------------------------------
# Standalone Execution Block
# ---------------------------------------------------------
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = ArgentinaRePETScraper()
    asyncio.run(scraper.run(force=True))