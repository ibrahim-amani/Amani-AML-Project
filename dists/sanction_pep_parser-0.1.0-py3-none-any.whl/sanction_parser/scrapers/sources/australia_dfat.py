"""
src/sanction_parser/scrapers/sources/australia_dfat.py

Scraper for the Australian Government (DFAT) Consolidated Sanctions List.
"""

import re
import os
import logging
import asyncio
from pathlib import Path
from datetime import datetime
from collections import defaultdict
from typing import Iterator, Dict, Any, Optional, List

# Third-party
import pandas as pd

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper
from sanction_parser.scrapers.utils.web_client import get_request

# Initialize logger
logger = logging.getLogger(__name__)

class AustralianSanctionsScraper(BaseSanctionScraper):
    """
    Scraper for Australian Sanctions Consolidated List (DFAT).
    
    Source: https://www.dfat.gov.au/sites/default/files/Australian_Sanctions_Consolidated_List.xlsx
    Format: Excel (.xlsx)
    Structure: Rows are grouped by 'Reference' ID. One entity = Multiple rows.
    """
    
    name = "Australian Sanctions List (DFAT)"
    country = "Australia"
    
    FILE_URL = "https://www.dfat.gov.au/sites/default/files/Australian_Sanctions_Consolidated_List.xlsx"
    DATA_FILENAME = "Australian_Sanctions_Consolidated_List.xlsx"
    
    # Boolean columns indicating specific sanctions
    PROVISION_FIELDS = [
        "travel_ban",
        "arms_embargo",
        "maritime_restriction",
        "targeted_financial_sanction",
    ]

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Download the Excel file.
        """
        self.logger.info(f"Downloading file from: {self.FILE_URL}")
        
        local_path = self.raw_dir / self.DATA_FILENAME

        def _download_task():
            # stream=True is good for large files
            response = get_request(self.FILE_URL, stream=True, timeout=120)
            with open(local_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

        try:
            await asyncio.to_thread(_download_task)
            
            if local_path.exists() and local_path.stat().st_size > 0:
                return local_path
            else:
                self.logger.error("Download failed or file is empty.")
                return None

        except Exception as e:
            self.logger.error(f"Failed to download file: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform Excel data into Golden Profile schema.
        Includes grouping rows by Reference ID.
        """
        # Ensure target file exists
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            # Fallback scan
            excel_files = list(raw_path.parent.glob("*.xlsx"))
            if not excel_files:
                self.logger.warning(f"No Excel files found in {raw_path.parent}.")
                return
            target_file = excel_files[0]

        self.logger.info(f"Transforming file: {target_file}")
        mapper = ProfileMapper()

        try:
            # Read Excel
            # 'dtype=str' to prevent pandas from mangling ID numbers or dates upfront
            df = pd.read_excel(target_file, dtype=str)
            df = self._slugify_headers(df)
            
            # Group rows by the cleaned Reference ID
            grouped_rows = defaultdict(list)
            
            for _, row in df.iterrows():
                raw_ref = row.get("reference")
                if pd.isna(raw_ref) or str(raw_ref).strip() == "":
                    continue
                    
                clean_ref = self._clean_reference(raw_ref)
                grouped_rows[clean_ref].append(row)

            self.logger.info(f"Found {len(grouped_rows)} unique entities. Processing...")

            # Process groups
            for ref_id, rows in grouped_rows.items():
                try:
                    record = self._process_entity_group(ref_id, rows)

                    # Only yield if record exists (it might be skipped if not Individual)
                    if record:
                        result = mapper.map_single_profile(record)

                        yield result

                except Exception as inner_e:
                    self.logger.warning(f"Error processing group {ref_id}: {inner_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process Excel file: {e}")
            raise e

    # ---------------------------------------------------------
    # Business Logic: Group Processing
    # ---------------------------------------------------------

    def _process_entity_group(self, ref_id: str, rows: List[pd.Series]) -> Optional[Dict[str, Any]]:
        """
        Merges multiple rows belonging to the same entity into a single record.
        **Strictly filters for INDIVIDUALS.**
        """
        primary_row = None
        aliases = []
        addresses = set()
        nationalities = set()
        pobs = set()
        
        detected_type = None
        control_date = None
        program_set = set()
        provisions_set = set()
        primary_name = None

        # --- 1. Iterate Rows to Aggregate Data ---
        for row in rows:
            # Detect Type
            row_type = str(row.get("type", "")).strip().lower()
            
            if row_type == "individual":
                detected_type = "individual"
                if primary_row is None: 
                    primary_row = row
            elif row_type in ["entity", "vessel"]:
                if detected_type != "individual":
                    detected_type = row_type

            if primary_row is None:
                primary_row = row

            # Name Extraction
            name = str(row.get("name_of_individual_or_entity", "")).strip()
            name_type = str(row.get("name_type", "")).strip().lower()
            
            if name_type == "primary_name" or (not primary_name and name):
                primary_name = name
            elif name and name != primary_name:
                aliases.append(name)

            # Address Cleaning
            addr = str(row.get("address", "")).strip()
            if addr and addr.lower() != "nan":
                addr = addr.replace("_x000D_", " ").strip()
                addresses.add(addr)

            # Citizenship / Nationality
            cit = str(row.get("citizenship", "")).strip()
            if cit and cit.lower() != "nan":
                nationalities.add(cit)
            
            # Place of Birth
            pob = str(row.get("place_of_birth", "")).strip()
            if pob and pob.lower() != "nan":
                pobs.add(pob)

            # Sanction Programs
            comm = str(row.get("committees", "")).strip()
            if comm and comm.lower() != "nan":
                program_set.add(comm)
            
            # Dates
            c_date = self._parse_date(row.get("control_date"))
            if c_date: 
                control_date = c_date

            # Provisions (Boolean checks)
            for field in self.PROVISION_FIELDS:
                val = str(row.get(field, "")).strip().lower()
                if val in ["yes", "true", "1"]:
                    provisions_set.add(field.replace("_", " ").title())

        # --- 2. FILTER: INDIVIDUALS ONLY ---
        if detected_type != "individual":
            return None 

        if not primary_name or primary_name.lower() == "nan":
            primary_name = "Unknown Name"

        # --- 3. Construct Final Fields ---
        dob_str = self._parse_date(primary_row.get("date_of_birth"))
        
        # Build composite strings for snippet/reason
        full_address = " | ".join(addresses) if addresses else None
        nationality = ", ".join(nationalities) if nationalities else None
        
        reasons = []
        if program_set: reasons.append(f"Program: {', '.join(program_set)}")
        if provisions_set: reasons.append(f"Provisions: {', '.join(provisions_set)}")
        reason_text = " | ".join(reasons)
        
        # Generate ID
        unique_key = f"DFAT_{ref_id}_{primary_name}"
        record_id = self.generate_uuid(unique_key)

        # --- 4. Return Raw Record for Mapper ---
        return {
            "profile": {
                "id": record_id,
                "full_name": primary_name,
                "entity_type": "INDIVIDUAL",
                "gender": None, 
                "date_of_birth": dob_str,
                "nationality": nationality,
                "is_active": True,
                "aliases": list(set(aliases)), 
                "images": [],
                "addresses": list(addresses)
            },
            "risk_events": [
                {
                    "type": "Sanction",
                    "source_list": self.name,
                    "authority": "Australian Government (DFAT)",
                    "reason": reason_text,
                    "date_listed": control_date,
                    "is_current": True,
                    "risk_level": "High",
                }
            ],
            "evidence": [
                {
                    "url": self.FILE_URL,
                    "scraped_at": datetime.now().isoformat(),
                    "raw_text_snippet": f"Ref: {ref_id} | Type: {detected_type} | DOB: {dob_str} | POB: {', '.join(pobs)} | Addr: {full_address}"
                }
            ]
        }

    # ---------------------------------------------------------
    # Helpers
    # ---------------------------------------------------------

    def _clean_reference(self, ref: Any) -> str:
        """
        Extracts base ID from references like '101a', '101b' -> '101'.
        """
        ref_str = str(ref).strip().lower()
        match = re.match(r"^(\d+)", ref_str)
        if match:
            return match.group(1)
        return ref_str

    def _parse_date(self, date_val: Any) -> Optional[str]:
        """Safely parses mixed format Excel dates."""
        if pd.isna(date_val) or str(date_val).strip().lower() in ["", "nan", "nat"]:
            return None
        
        try:
            # If it's already a pandas Timestamp
            if isinstance(date_val, (pd.Timestamp, datetime)):
                return date_val.strftime("%Y-%m-%d")
            
            # Clean strings like "Approximately 1980"
            s = str(date_val).replace("Approximately", "").strip()
            
            # Try parsing known format
            try:
                return datetime.strptime(s, "%Y-%m-%d %H:%M:%S").strftime("%Y-%m-%d")
            except ValueError:
                pass
            
            return s # Return string if parse fails (mapper handles it best effort)
        except:
            return str(date_val)

    def _slugify_headers(self, df: pd.DataFrame) -> pd.DataFrame:
        """Normalizes dataframe columns."""
        df.columns = [
            str(col).strip().lower().replace(" ", "_").replace("/", "_").replace("-", "_")
            for col in df.columns
        ]
        return df

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = AustralianSanctionsScraper()
    asyncio.run(scraper.run(force=True))