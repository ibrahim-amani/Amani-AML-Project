"""
src/sanction_parser/scrapers/sources/belgium_finance.py

Scraper for Belgium FPS Finance - National Financial Sanctions List.
Source: https://finance.belgium.be/en/about_fps/structure_and_services/general_administrations/treasury/financial-sanctions/national
"""

import re
import logging
import asyncio
import requests
import unicodedata
import openpyxl
from pathlib import Path
from datetime import datetime
from urllib.parse import urljoin
from typing import Any, List, Dict, Generator, Optional, Iterator

# Third-party
from bs4 import BeautifulSoup
from playwright.async_api import async_playwright

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class BelgiumSanctionsScraper(BaseSanctionScraper):
    """
    Scraper for Belgium FPS Finance - National Sanctions.
    
    Source URL: https://finance.belgium.be/.../financial-sanctions/national
    Format: Excel (Dynamic Header)
    Type: Sanction (High Risk)
    """
    name = "Belgium FPS Finance - National Sanctions"
    country = "Belgium"
    
    BASE_URL = "https://finance.belgium.be/en/about_fps/structure_and_services/general_administrations/treasury/financial-sanctions/national"
    DATA_FILENAME = "belgium_sanctions.xlsx"
    
    HEADERS_UA = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Scrape the page for the Excel link (using Playwright) and download it.
        """
        self.logger.info(f"Scanning page for Excel files: {self.BASE_URL}")
        
        # --- 1. Scrape Link via Playwright (Handles JS/Blocking) ---
        async def _find_link_playwright():
            async with async_playwright() as p:
                browser = await p.chromium.launch(headless=True)
                page = await browser.new_page(user_agent=self.HEADERS_UA["User-Agent"])
                try:
                    await page.goto(self.BASE_URL, wait_until="domcontentloaded", timeout=60000)
                    
                    # Wait for any link containing 'xls' to appear
                    try:
                        await page.wait_for_selector('a[href*=".xls"]', timeout=15000)
                    except:
                        self.logger.warning("Timeout waiting for .xls link selector, checking content anyway.")

                    content = await page.content()
                    soup = BeautifulSoup(content, 'html.parser')
                    
                    # Strategy 1: Targeted class search (from your snippet)
                    target_btn = soup.find('a', class_="fin-04")
                    if target_btn and target_btn.get('href'):
                        return urljoin(self.BASE_URL, target_btn['href'])

                    # Strategy 2: Search for 'national list' text
                    for a in soup.find_all('a', href=True):
                        text = a.get_text(" ", strip=True).lower()
                        if "national list" in text and ("xls" in text or "xls" in a['href'].lower()):
                            return urljoin(self.BASE_URL, a['href'])

                    # Strategy 3: Generic fallback (any xlsx link)
                    for a_tag in soup.find_all('a', href=True):
                        href = a_tag['href'].lower()
                        if 'xls' in href: 
                            return urljoin(self.BASE_URL, a_tag['href'])
                            
                    return None
                finally:
                    await browser.close()

        target_url = await _find_link_playwright()

        if not target_url:
            self.logger.warning("No Excel link found in the HTML content.")
            return None

        self.logger.info(f"Found candidate link: {target_url}")
        
        # Determine extension
        ext = "xls" if ".xls" in target_url.lower() and not ".xlsx" in target_url.lower() else "xlsx"
        self.DATA_FILENAME = f"belgium_sanctions.{ext}"
        local_path = self.raw_dir / self.DATA_FILENAME

        # --- 2. Download via Requests (Efficient Stream) ---
        def _download_task():
            with requests.Session() as s:
                s.headers.update(self.HEADERS_UA)
                # Verify=False sometimes helps with specific gov certs, but try True first
                response = s.get(target_url, stream=True, timeout=60)
                response.raise_for_status()
                with open(local_path, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        f.write(chunk)

        try:
            await asyncio.to_thread(_download_task)
            
            if local_path.exists() and local_path.stat().st_size > 0:
                return local_path
            return None

        except Exception as e:
            self.logger.error(f"Download failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform Excel to Golden Profile.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            # Fallback scan
            xlsx_files = list(raw_path.parent.glob("*.xlsx")) + list(raw_path.parent.glob("*.xls"))
            if not xlsx_files:
                self.logger.warning("No Excel files found.")
                return
            target_file = xlsx_files[0]

        self.logger.info(f"Transforming Excel file: {target_file}")
        mapper = ProfileMapper()

        try:
            wb = openpyxl.load_workbook(target_file, read_only=True, data_only=True)
            sheet = wb.worksheets[0]
            
            rows_generator = self._sheet_to_dicts(sheet)

            for row in rows_generator:
                try:
                    # --- Data Extraction ---
                    last_name = row.get("naam") or row.get("name") or row.get("nom")
                    first_name = row.get("voornam-en") or row.get("voornam-en-") or row.get("voornaam") or row.get("first-name") or row.get("prénom")
                    
                    if not last_name:
                        continue

                    first_name = str(first_name).strip() if first_name else ""
                    last_name = str(last_name).strip()
                    full_name = f"{first_name} {last_name}".strip()

                    national_id = row.get("rijksregisternummer") or row.get("national-number") or row.get("numéro-national")
                    national_id = str(national_id).strip() if national_id else ""

                    link_kb = row.get("link-naar-de-publicatie") or ""
                    
                    # Dates
                    dob = self._parse_date(row.get("geboortedatum") or row.get("date-de-naissance"))
                    date_listed = self._parse_date(row.get("datum-kb") or row.get("date-ar")) or datetime.now().strftime("%Y-%m-%d")

                    # --- UUID Generation ---
                    unique_str = f"{full_name}_{national_id}"
                    record_id = self.generate_uuid(unique_str)

                    # --- Build Record ---
                    mapped_record = {
                        "profile": {
                            "id": record_id,
                            "full_name": full_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": None,
                            "date_of_birth": dob, 
                            "nationality": "BE", 
                            "is_active": True,
                            "aliases": [],
                            "images": []
                        },
                        "risk_events": [
                            {
                                "type": "Sanction",
                                "source_list": self.name,
                                "authority": "Belgium Federal Public Service Finance",
                                "reason": "Terrorist Financing (National List)",
                                "date_listed": date_listed, 
                                "is_current": True,
                                "risk_level": "High"
                            }
                        ],
                        "evidence": [
                            {
                                "url": self.BASE_URL,
                                "scraped_at": datetime.now().isoformat(),
                                "raw_text_snippet": str(row),
                                "comments": f"National ID: {national_id}, Link: {link_kb}"
                            }
                        ]
                    }
                    
                    # Normalize & Yield
                    result = mapper.map_single_profile(mapped_record)

                    yield result

                except Exception as inner_e:
                    self.logger.warning(f"Error processing row: {inner_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process Excel file: {e}")
            raise e

    # ---------------------------------------------------------
    # Helper Methods
    # ---------------------------------------------------------

    def _slugify(self, text: str) -> Optional[str]:
        if not text: return None
        text = str(text).lower().strip()
        text = unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode('ascii')
        text = re.sub(r'[^\w\s-]', '-', text)
        text = re.sub(r'[-\s]+', '-', text).strip('-_')
        return text

    def _parse_date(self, value: Any) -> Optional[str]:
        """Helper to safely convert Excel datetime objects to ISO string."""
        if not value: return None
        if isinstance(value, datetime):
            return value.strftime("%Y-%m-%d")
        return str(value).strip()

    def _sheet_to_dicts(self, sheet) -> Generator[Dict[str, Any], None, None]:
        """Iterates over rows, dynamically detects the header row."""
        headers: Optional[List[str]] = None
        
        for row in sheet.rows:
            cells = [c.value for c in row]
            clean_cells_str = [str(c).strip().lower() if c else "" for c in cells]
            line_str = " ".join(clean_cells_str)

            if headers is None:
                # Expanded keywords to catch French/Dutch headers
                keywords = ["naam", "name", "nom", "voornam", "first", "prénom", "rijksregisternummer", "national"]
                matches = sum(1 for k in keywords if k in line_str)
                
                if matches >= 2:
                    headers = [self._slugify(h) if h else None for h in cells]
                    self.logger.info(f"Header detected: {headers}")
                    continue
                else:
                    continue

            if headers:
                if not any(clean_cells_str): continue
                
                row_dict = {}
                for h, val in zip(headers, cells):
                    if h is not None:
                        row_dict[h] = val
                yield row_dict

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = BelgiumSanctionsScraper()
    asyncio.run(scraper.run(force=True))