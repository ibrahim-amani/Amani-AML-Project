"""
src/sanction_parser/scrapers/sources/belgium_police.py

Scrapes Belgium Police 'Most Wanted' list.
Source: https://www.police.be/wanted/en/wanted/most-wanted
"""

import re
import json
import asyncio
import platform
import logging
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Set, Iterator
from urllib.parse import parse_qs, urljoin, urlparse

# Third-party
from bs4 import BeautifulSoup
from playwright.async_api import async_playwright
from crawl4ai import AsyncWebCrawler, BrowserConfig, CacheMode, CrawlerRunConfig
from crawl4ai.markdown_generation_strategy import DefaultMarkdownGenerator

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class PoliceBeMostWantedScraper(BaseSanctionScraper):
    """
    Scraper for Belgium Police 'Most Wanted' list.
    
    Source URL: https://www.police.be/wanted/en/wanted/most-wanted
    Format: Web Scraping (Playwright + Crawl4AI)
    Type: Wanted (High Risk)
    """
    name = "Belgium – Police Most Wanted"
    country = "Belgium"
    
    BASE_URL = "https://www.police.be"
    START_URL = "https://www.police.be/wanted/en/wanted/most-wanted"
    DATA_FILENAME = "police_be_most_wanted.json"

    # Tuning
    CONCURRENCY = 6
    HEADFUL = True  # Kept as requested

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Scrape listing pages and profile details.
        """
        self.logger.info(f"Starting extraction from: {self.START_URL}")
        
        # Windows loop policy fix
        if platform.system() == "Windows":
            asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

        local_path = self.raw_dir / self.DATA_FILENAME

        try:
            # 1. Discover Pagination
            listing_urls = await self._discover_listing_urls()
            
            # 2. Collect Profile URLs
            profile_urls = await self._collect_profile_urls(listing_urls)
            
            if not profile_urls:
                self.logger.warning("No profiles found.")
                return None

            # 3. Scrape Profiles (Crawl4AI)
            records = await self._scrape_profiles(profile_urls)

            # 4. Save Raw Data
            with open(local_path, "w", encoding="utf-8") as f:
                json.dump(records, f, indent=2, ensure_ascii=False)
            
            return local_path

        except Exception as e:
            self.logger.error(f"Extraction failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform raw JSON to Golden Profile.
        """
        if not raw_path.exists():
            return

        self.logger.info(f"Transforming file: {raw_path}")
        mapper = ProfileMapper()

        try:
            with open(raw_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            for entry in data:
                try:
                    # 1. Basic Info
                    name = entry.get("name")
                    if not name: continue

                    profile_url = entry.get("profile_url")
                    
                    # 2. Dates & Nationality
                    dob_raw = entry.get("date_of_birth")
                    dob_iso = self._parse_dob_from_text(dob_raw)
                    
                    nat_raw = entry.get("nationality")
                    nationality_list = self._normalize_nationality_list(nat_raw)

                    # 3. ID Generation
                    unique_key = profile_url if profile_url else name
                    record_id = self.generate_uuid(unique_key)

                    # 4. Evidence Construction
                    intro = entry.get("intro") or ""
                    content = entry.get("content_text") or ""
                    age = entry.get("age") or ""
                    
                    snippet = f"{intro} | Age: {age} | Details: {content[:300]}..."

                    # 5. Build Record
                    mapped_record = {
                        "profile": {
                            "id": record_id,
                            "full_name": name,
                            "entity_type": "INDIVIDUAL",
                            "gender": None, 
                            "date_of_birth": dob_iso,
                            "nationality": nationality_list, # List[str] handled by mapper
                            "is_active": True,
                            "aliases": [],
                            "images": entry.get("image_urls", []),
                            "addresses": []
                        },
                        "risk_events": [
                            {
                                "type": "Wanted",
                                "source_list": self.name,
                                "authority": "Belgian Federal Police",
                                "reason": "Criminal Investigation",
                                "date_listed": None, # Could parse 'published_date' if reliable
                                "is_current": True,
                                "risk_level": "High"
                            }
                        ],
                        "evidence": [
                            {
                                "url": profile_url,
                                "scraped_at": entry.get("scraped_at", datetime.now(timezone.utc).isoformat()),
                                "raw_text_snippet": snippet
                            }
                        ]
                    }

                    # 6. Normalize & Yield
                    result = mapper.map_single_profile(mapped_record)

                    yield result

                except Exception as inner_e:
                    self.logger.warning(f"Error transforming record: {inner_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process JSON file: {e}")
            raise e

    # ---------------------------------------------------------
    # Scraping Logic (Async Helpers)
    # ---------------------------------------------------------

    async def _discover_listing_urls(self) -> List[str]:
        self.logger.info("Discovering pagination...")
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=not self.HEADFUL)
            page = await browser.new_page()

            try:
                await page.goto(self.START_URL, wait_until="domcontentloaded", timeout=90000)
                try:
                    await page.wait_for_selector("nav.pager", timeout=15000)
                except Exception:
                    pass

                page_nums: Set[int] = set()
                anchors = await page.locator("nav.pager a[href*='page=']").all()
                for a in anchors:
                    href = await a.get_attribute("href")
                    if href:
                        n = self._extract_page_param(href)
                        if n is not None:
                            page_nums.add(n)

                if not page_nums:
                    return [self.START_URL]

                max_page = max(page_nums)
                return [f"{self.START_URL}?page={i}" for i in range(0, max_page + 1)]
            finally:
                await browser.close()

    async def _collect_profile_urls(self, listing_urls: List[str]) -> List[str]:
        self.logger.info(f"Collecting profiles from {len(listing_urls)} pages...")
        seen_profiles: Set[str] = set()
        out: List[str] = []

        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=not self.HEADFUL)
            page = await browser.new_page()

            for u in listing_urls:
                try:
                    await page.goto(u, wait_until="domcontentloaded", timeout=60000)
                    anchors = await page.locator(".field--name-title a[href]").all()
                    for a in anchors:
                        href = await a.get_attribute("href")
                        if not href:
                            continue

                        full = urljoin(self.BASE_URL, href)
                        if "/wanted/en/wanted/most-wanted/" in full and full not in seen_profiles:
                            seen_profiles.add(full)
                            out.append(full)
                except Exception as e:
                    self.logger.warning(f"Failed listing page {u}: {e}")

            await browser.close()
        return sorted(out)

    async def _scrape_profiles(self, profile_urls: List[str]) -> List[Dict[str, Any]]:
        self.logger.info(f"Scraping {len(profile_urls)} profiles...")

        browser_config = BrowserConfig(headless=True)
        run_config = CrawlerRunConfig(
            cache_mode=CacheMode.BYPASS,
            markdown_generator=DefaultMarkdownGenerator(),
        )

        sem = asyncio.Semaphore(self.CONCURRENCY)
        records: List[Dict[str, Any]] = []

        async with AsyncWebCrawler(config=browser_config) as crawler:
            async def process(url: str):
                async with sem:
                    try:
                        res = await crawler.arun(url=url, config=run_config)
                        html = res.html or ""
                        md = (res.markdown or "").strip()

                        data = self._parse_profile_structured(html, url)
                        data["markdown"] = md
                        data["scraped_at"] = datetime.now(timezone.utc).isoformat()
                        records.append(data)
                    except Exception as e:
                        self.logger.warning(f"Failed profile {url}: {e}")

            await asyncio.gather(*[process(u) for u in profile_urls])

        return records

    # ---------------------------------------------------------
    # Parsing Logic (BeautifulSoup)
    # ---------------------------------------------------------

    def _parse_profile_structured(self, html: str, page_url: str) -> Dict[str, Any]:
        soup = BeautifulSoup(html, "lxml")

        def get_text(selector: str) -> Optional[str]:
            el = soup.select_one(selector)
            return self._clean_text(el.get_text(" ", strip=True)) if el else None

        name = (
            get_text("h1 .field--name-title")
            or get_text(".layout--detail-node-compact__title .field--name-title")
            or "Unknown"
        )

        published_date = get_text(".field--name-field-requestor-date time")
        wanted_date = get_text(".field--name-field-wanted-date time")

        age_el = soup.select_one(".field--name-field-wanted-age .field--item") or soup.select_one(
            ".field--name-field-wanted-age"
        )
        age = self._clean_text(age_el.get_text(" ", strip=True)) if age_el else None

        intro = get_text(".field--name-field-intro")

        content_el = soup.select_one(".field--name-field-content")
        content_text = self._clean_text(content_el.get_text("\n", strip=True)) if content_el else None

        dob = None
        nat = None
        if content_text:
            m = re.search(r"Date of birth\s*:\s*(.+)", content_text, re.IGNORECASE)
            if m:
                dob = self._clean_text(m.group(1).split("\n")[0])

            m2 = re.search(r"Nationality\s*:\s*(.+)", content_text, re.IGNORECASE)
            if m2:
                nat = self._clean_text(m2.group(1).split("\n")[0])

        image_urls: Set[str] = set()
        for a in soup.select(".layout--detail-node-compact__main_image a[href]"):
            if a.get("href"):
                image_urls.add(urljoin(self.BASE_URL, a["href"]))

        for img in soup.select(".field--name-field-wanted-photos img[src]"):
            if img.get("src"):
                image_urls.add(urljoin(self.BASE_URL, img["src"]))

        nationality_list = [nat] if isinstance(nat, str) and nat.strip() else []

        return {
            "name": name,
            "profile_url": page_url,
            "published_date": published_date,
            "wanted_date": wanted_date,
            "age": age,
            "intro": intro,
            "content_text": content_text,
            "date_of_birth": dob,
            "nationality": nationality_list,
            "image_urls": sorted(image_urls),
        }

    # ---------------------------------------------------------
    # Helper Methods
    # ---------------------------------------------------------

    @staticmethod
    def _clean_text(s: Optional[str]) -> Optional[str]:
        if not s:
            return None
        s = re.sub(r"\s+", " ", s).strip()
        return s or None

    def _extract_page_param(self, href: str) -> Optional[int]:
        try:
            full = urljoin(self.START_URL, href)
            q = parse_qs(urlparse(full).query)
            if "page" in q and q["page"]:
                return int(q["page"][0])
        except Exception:
            return None
        return None

    def _parse_dob_from_text(self, text: Optional[str]) -> Optional[str]:
        """Tries to parse date like 'July 30, 1993' or '11/01/1983'."""
        if not text:
            return None

        # Clean up
        text = text.split("Nationality")[0].strip()
        text = text.replace("Date of birth", "").replace(":", "").strip()

        formats = ["%B %d, %Y", "%d/%m/%Y"]
        for fmt in formats:
            try:
                dt = datetime.strptime(text, fmt)
                return dt.strftime("%Y-%m-%d")
            except ValueError:
                pass
        return None

    @staticmethod
    def _normalize_nationality_list(value: Any) -> List[str]:
        if value is None:
            items: List[Any] = []
        elif isinstance(value, str):
            items = [value]
        elif isinstance(value, list):
            items = value
        else:
            items = [str(value)]

        seen: Set[str] = set()
        out: List[str] = []

        for nat in items:
            if isinstance(nat, list) and nat and all(isinstance(ch, str) and len(ch) == 1 for ch in nat):
                nat = "".join(nat)

            if not isinstance(nat, str):
                continue

            nat = nat.strip()
            if not nat:
                continue

            parts = re.split(r"\s+and\s+", nat, flags=re.IGNORECASE) if re.search(r"\sand\s", nat, re.IGNORECASE) else [nat]

            for part in parts:
                v = part.strip()
                if not v:
                    continue
                if v not in seen:
                    seen.add(v)
                    out.append(v)

        return out

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = PoliceBeMostWantedScraper()
    asyncio.run(scraper.run(force=True))