"""
src/sanction_parser/scrapers/sources/canada_bcsc.py

Scraper for the British Columbia Securities Commission (BCSC) Disciplined List.
Source: https://www.bcsc.bc.ca/enforcement/administrative-enforcement/administrative-sanctions/disciplined-list
"""

import re
import json
import asyncio
import platform
import logging
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Iterator
from urllib.parse import urljoin

# Third-party
from bs4 import BeautifulSoup
from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError
from crawl4ai import AsyncWebCrawler, BrowserConfig, CacheMode, CrawlerRunConfig

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class BcscDisciplinedListScraper(BaseSanctionScraper):
    """
    Scraper for Canada (BC) BCSC Disciplined List.
    
    Source URL: https://www.bcsc.bc.ca/.../disciplined-list
    Format: Web Scraping (Playwright Listing + Crawl4AI Details)
    Type: Sanction (High Risk)
    """
    name = "Canada (BC) – BCSC Disciplined List"
    country = "Canada"
    
    BASE_URL = "https://www.bcsc.bc.ca"
    LIST_URL = "https://www.bcsc.bc.ca/enforcement/administrative-enforcement/administrative-sanctions/disciplined-list"
    DATA_FILENAME = "canada_bcsc.json"

    # Tuning
    CONCURRENCY = 10
    PAGE_SIZE = 100
    HEADLESS = True

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Scrape listing with Playwright (filtering for Persons), then scrape details.
        """
        self.logger.info(f"Starting extraction from: {self.LIST_URL}")
        
        # Windows loop policy fix
        if platform.system() == "Windows":
            asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

        local_path = self.raw_dir / self.DATA_FILENAME

        try:
            # 1. Scrape Listing (Playwright)
            listing_items = await self._scrape_listing()
            
            if not listing_items:
                self.logger.warning("No items found in listing.")
                return None

            # 2. Scrape Details (Crawl4AI)
            detailed_data = await self._scrape_details(listing_items)

            # 3. Save Raw Data
            with open(local_path, "w", encoding="utf-8") as f:
                json.dump(detailed_data, f, indent=2, ensure_ascii=False)
            
            return local_path

        except Exception as e:
            self.logger.error(f"Extraction failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform raw JSON to Golden Profile.
        """
        if not raw_path.exists():
            return

        self.logger.info(f"Transforming file: {raw_path}")
        mapper = ProfileMapper()

        try:
            with open(raw_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            for entry in data:
                try:
                    # 1. Basic Info
                    name = entry.get("name", "Unknown")
                    url = entry.get("url")
                    
                    # 2. Status & Dates
                    date_listed = self._parse_date(entry.get("date_of_order_or_settlement"))
                    banned_until = entry.get("banned_until")
                    
                    is_active = True
                    if banned_until:
                        # Simple check if ban expired
                        try:
                            if "permanent" not in banned_until.lower():
                                ban_dt = datetime.strptime(banned_until, "%Y-%m-%d")
                                if ban_dt < datetime.now():
                                    is_active = False
                        except: pass

                    # 3. ID Generation
                    unique_key = url if url else name
                    record_id = self.generate_uuid(unique_key)

                    # 4. Risk Details
                    ruling_body = entry.get("ruling_body") or "British Columbia Securities Commission"
                    sanctions_list = entry.get("sanctions") or []
                    reason = "; ".join(sanctions_list[:3]) if sanctions_list else "Administrative Sanction / Disciplined"
                    
                    # 5. Evidence
                    docs = entry.get("supporting_documents", [])
                    doc_links = [f"{d['title']}: {d['url']}" for d in docs]
                    doc_str = " | ".join(doc_links)
                    
                    full_sanctions = "; ".join(sanctions_list)
                    snippet_parts = []
                    if full_sanctions: snippet_parts.append(f"Sanctions: {full_sanctions}")
                    if banned_until: snippet_parts.append(f"Banned Until: {banned_until}")
                    if doc_str: snippet_parts.append(f"Docs: {doc_str}")

                    # 6. Build Record
                    mapped_record = {
                        "profile": {
                            "id": record_id,
                            "full_name": name,
                            "entity_type": "INDIVIDUAL", # Filtered for 'Person' in extraction
                            "gender": None, 
                            "date_of_birth": None,
                            "nationality": None,
                            "is_active": is_active,
                            "aliases": [],
                            "images": [],
                            "addresses": []
                        },
                        "risk_events": [
                            {
                                "type": "Sanction",
                                "source_list": self.name,
                                "authority": ruling_body,
                                "reason": reason,
                                "date_listed": date_listed,
                                "is_current": is_active,
                                "risk_level": "High" if is_active else "Medium"
                            }
                        ],
                        "evidence": [
                            {
                                "url": url,
                                "scraped_at": datetime.now(timezone.utc).isoformat(),
                                "raw_text_snippet": " | ".join(snippet_parts)
                            }
                        ]
                    }

                    # 7. Normalize & Yield
                    result = mapper.map_single_profile(mapped_record)
                    yield result

                except Exception as inner_e:
                    self.logger.warning(f"Error transforming record: {inner_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process JSON file: {e}")
            raise e

    # ---------------------------------------------------------
    # Scraping Logic (Playwright Listing)
    # ---------------------------------------------------------

    async def _scrape_listing(self) -> List[Dict[str, Any]]:
        self.logger.info("Scraping listing page via Playwright...")
        results = []
        seen_urls = set()

        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=self.HEADLESS)
            page = await browser.new_page()

            try:
                await page.goto(self.LIST_URL, wait_until="domcontentloaded", timeout=90000)
                try:
                    await page.wait_for_selector("table#inlineSearchTable", timeout=60000)
                except:
                    self.logger.error("Table selector not found.")
                    return []

                # --- Apply "Person" Filter ---
                try:
                    self.logger.info("Applying 'Person' filter...")
                    await page.locator("a.dropdown-toggle").filter(has_text="Type").click()
                    await page.wait_for_selector(".dropdown-menu.show", state="visible", timeout=5000)
                    await page.locator("label").filter(has_text="Person").click(force=True)
                    await page.wait_for_load_state("networkidle")
                    await page.wait_for_timeout(2000)
                except Exception as e:
                    self.logger.warning(f"Failed to apply filter: {e}")

                # --- Set Page Size ---
                try:
                    await page.select_option("select[name='inlineSearchTable_length']", str(self.PAGE_SIZE))
                    await page.wait_for_timeout(1500)
                except: pass

                # --- Pagination Loop ---
                while True:
                    rows = page.locator("table#inlineSearchTable tbody tr")
                    await rows.first.wait_for(state="visible", timeout=10000)
                    count = await rows.count()
                    self.logger.info(f"Processing page with {count} rows...")

                    for i in range(count):
                        tr = rows.nth(i)
                        a_tag = tr.locator("td").first.locator("a")
                        
                        if await a_tag.count() == 0: continue

                        name = (await a_tag.inner_text() or "").strip()
                        href = await a_tag.get_attribute("href") or ""
                        
                        if not href: continue
                        url = urljoin(self.BASE_URL, href)
                        
                        if url in seen_urls: continue
                        seen_urls.add(url)

                        td_date = tr.locator("td").nth(1)
                        date_raw = (await td_date.inner_text() or "").strip()

                        results.append({
                            "name": name,
                            "date_of_order_or_settlement": date_raw,
                            "url": url
                        })

                    # Next Page
                    next_btn = page.locator("#inlineSearchTable_next")
                    cls = await next_btn.get_attribute("class") or ""
                    
                    if "disabled" in cls:
                        break

                    # Helper to wait for table refresh
                    first_href = await page.locator("table#inlineSearchTable tbody tr td a").first.get_attribute("href")
                    
                    await next_btn.scroll_into_view_if_needed()
                    await next_btn.click()

                    try:
                        await page.wait_for_function(
                            f"""(oldHref) => {{
                                const a = document.querySelector("table#inlineSearchTable tbody tr td a");
                                return a && a.getAttribute('href') !== oldHref;
                            }}""",
                            arg=first_href,
                            timeout=60000
                        )
                    except PlaywrightTimeoutError:
                        await page.wait_for_timeout(2000)

            finally:
                await browser.close()

        self.logger.info(f"Found {len(results)} items in listing.")
        return results

    # ---------------------------------------------------------
    # Scraping Logic (Crawl4AI Details)
    # ---------------------------------------------------------

    async def _scrape_details(self, listing: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        self.logger.info(f"Scraping {len(listing)} detail pages...")
        
        browser_config = BrowserConfig(headless=True, verbose=False)
        run_config = CrawlerRunConfig(
            cache_mode=CacheMode.BYPASS,
            wait_for="css:div.col-lg-8.content-page-wrapper", # Wait for main content
            page_timeout=60000,
        )

        sem = asyncio.Semaphore(self.CONCURRENCY)
        detailed_records = []

        async with AsyncWebCrawler(config=browser_config) as crawler:
            async def worker(row):
                async with sem:
                    try:
                        res = await crawler.arun(url=row["url"], config=run_config)
                        html = getattr(res, "html", None) or ""
                        return self._parse_detail_page(html, row["url"], row["name"], row)
                    except Exception as e:
                        self.logger.warning(f"Failed detail {row['url']}: {e}")
                        return None

            tasks = [worker(r) for r in listing]
            for coro in asyncio.as_completed(tasks):
                res = await coro
                if res: detailed_records.append(res)

        return detailed_records

    def _parse_detail_page(self, html: str, url: str, fallback_name: str, base_data: Dict) -> Dict[str, Any]:
        soup = BeautifulSoup(html or "", "lxml")
        
        # Merge base listing data
        out = base_data.copy()

        # 1. Extract Fields
        party_div = soup.select_one("div.dates-detail-wrapper.disciplined-party-web-control")
        
        def get_val(label_contains):
            if not party_div: return None
            for li in party_div.select("li"):
                h3 = li.find("h3")
                if h3 and label_contains.lower() in h3.get_text().lower():
                    val = li.find("div")
                    return val.get_text(" ", strip=True) if val else None
            return None

        out["banned_until"] = get_val("banned until")
        
        # 2. Sanctions & Docs
        sanctions = []
        docs = []
        
        content_root = soup.select_one("div.content-page-wrapper") or soup
        for h4 in content_root.find_all("h4"):
            title = h4.get_text().strip().lower().rstrip(":")
            
            if title == "sanction":
                ul = h4.find_next_sibling("ul")
                if ul:
                    sanctions = [li.get_text(strip=True) for li in ul.find_all("li")]
            
            elif title == "supporting documents":
                ul = h4.find_next_sibling("ul")
                if ul:
                    for a in ul.select("a[href]"):
                        docs.append({
                            "title": a.get_text(strip=True),
                            "url": urljoin(self.BASE_URL, a["href"])
                        })
            
            elif "ruling body" in title:
                out["ruling_body"] = h4.parent.get_text().replace(h4.get_text(), "").strip()

        out["sanctions"] = sanctions
        out["supporting_documents"] = docs
        return out

    def _parse_date(self, date_str: Optional[str]) -> Optional[str]:
        if not date_str: return None
        try:
            return datetime.strptime(date_str.strip(), "%b %d, %Y").strftime("%Y-%m-%d")
        except: return None

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = BcscDisciplinedListScraper()
    asyncio.run(scraper.run(force=True))