"""
src/sanction_parser/scrapers/sources/canada_mps.py

Scraper for Canadian Members of Parliament (House of Commons).
Target: Politically Exposed Persons (PEPs).
"""

import os
import logging
import asyncio
import xml.etree.ElementTree as ET
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper
from sanction_parser.scrapers.utils.web_client import extract_download_links, get_request

# Initialize logger
logger = logging.getLogger(__name__)

class CanadaMPsScraper(BaseSanctionScraper):
    """
    Scraper for Canadian Members of Parliament.
    
    Source URL: https://www.ourcommons.ca/members/en/search
    Format: XML
    Type: PEP (Medium Risk)
    """
    name = "Canada - House of Commons MPs"
    country = "Canada"
    
    BASE_URL = "https://www.ourcommons.ca/members/en/search"
    TARGET_EXTS = ["xml"]
    DATA_FILENAME = "canada_mps.xml"

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Download the XML data.
        """
        self.logger.info(f"Scanning page for XML link: {self.BASE_URL}")

        # 1. Try dynamic extraction first
        try:
            links = await asyncio.to_thread(extract_download_links, self.BASE_URL, exts=self.TARGET_EXTS)
        except Exception as e:
            self.logger.warning(f"Helper extraction warning: {e}")
            links = []

        # 2. Use Fallback URL if extraction fails
        if not links:
            fallback_url = "https://www.ourcommons.ca/members/en/search/xml"
            self.logger.info("No links found via helper. Using known fallback URL.")
            xml_url = fallback_url
        else:
            # Prefer links that look like the full list
            xml_url = links[0]['url']

        self.logger.info(f"Target XML URL: {xml_url}")
        
        local_path = self.raw_dir / self.DATA_FILENAME

        def _download_task():
            response = get_request(xml_url, stream=True, timeout=60)
            with open(local_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

        try:
            await asyncio.to_thread(_download_task)
            if local_path.exists() and local_path.stat().st_size > 0:
                return local_path
            return None
        except Exception as e:
            self.logger.error(f"Download failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Parse XML -> Golden Profile.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            xml_files = list(raw_path.parent.glob("*.xml"))
            if not xml_files:
                self.logger.warning("No XML files found.")
                return
            target_file = xml_files[0]

        self.logger.info(f"Processing XML file: {target_file}")
        mapper = ProfileMapper()

        try:
            tree = ET.parse(target_file)
            root = tree.getroot()

            # Root is usually <ArrayOfMemberOfParliament>
            # Children are <MemberOfParliament>
            for member in root.findall("MemberOfParliament"):
                try:
                    # Helper to get text safely
                    def get_val(tag):
                        node = member.find(tag)
                        return node.text.strip() if node is not None and node.text else None

                    # 1. Extract Fields
                    first_name = get_val("PersonOfficialFirstName")
                    last_name = get_val("PersonOfficialLastName")
                    
                    if not first_name or not last_name:
                        continue
                        
                    honorific = get_val("PersonShortHonorific")
                    full_name_parts = [p for p in [honorific, first_name, last_name] if p]
                    full_name = " ".join(full_name_parts)

                    person_id = get_val("PersonId")
                    constituency = get_val("ConstituencyName")
                    province = get_val("ConstituencyProvinceTerritoryName")
                    party = get_val("CaucusShortName")
                    
                    # 2. Dates
                    from_date_raw = get_val("FromDateTime")
                    to_date_raw = get_val("ToDateTime")
                    
                    start_date = self._parse_mp_date(from_date_raw)
                    end_date = self._parse_mp_date(to_date_raw)
                    
                    # 3. Status
                    is_active = True
                    if end_date:
                        try:
                            if datetime.strptime(end_date, "%Y-%m-%d") < datetime.now():
                                is_active = False
                        except ValueError:
                            pass

                    # 4. Generate ID
                    unique_key = person_id if person_id else f"{full_name}_{constituency}"
                    record_id = self.generate_uuid(unique_key)

                    # 5. Build Record
                    raw_record = {
                        "profile": {
                            "id": record_id,
                            "full_name": full_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": None, 
                            "date_of_birth": None,
                            "nationality": "Canada",
                            "is_active": is_active,
                            "aliases": [],
                            "images": [],
                            "addresses": [constituency] if constituency else []
                        },
                        "risk_events": [
                            {
                                "type": "PEP", # Specific Type for MPs
                                "source_list": self.name,
                                "authority": "Parliament of Canada",
                                "reason": f"Member of Parliament (MP) | Party: {party} | Constituency: {constituency}",
                                "date_listed": start_date,
                                "is_current": is_active,
                                "risk_level": "Medium",
                            }
                        ],
                        "evidence": [
                            {
                                "url": self.BASE_URL,
                                "scraped_at": datetime.now().isoformat(),
                                "raw_text_snippet": f"ID: {person_id} | Prov: {province} | Dates: {start_date} to {end_date}" 
                            }
                        ]
                    }

                    # 6. Normalize & Yield
                    result = mapper.map_single_profile(raw_record)

                    yield result

                except Exception as row_e:
                    self.logger.warning(f"Error parsing member: {row_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process XML file: {e}")
            raise e

    # ---------------------------------------------------------
    # Helpers
    # ---------------------------------------------------------

    def _parse_mp_date(self, date_str: Optional[str]) -> Optional[str]:
        """
        Parses dates like '2025-04-28T00:00:00' to '2025-04-28'.
        """
        if not date_str:
            return None
        try:
            return datetime.strptime(date_str.split("T")[0], "%Y-%m-%d").strftime("%Y-%m-%d")
        except ValueError:
            return None

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = CanadaMPsScraper()
    asyncio.run(scraper.run(force=True))