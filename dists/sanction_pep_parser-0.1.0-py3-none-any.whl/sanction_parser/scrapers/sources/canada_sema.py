"""
src/sanction_parser/scrapers/sources/canada_sema.py

Scraper for Canada Consolidated Autonomous Sanctions List (SEMA).
Source: Global Affairs Canada (XML).
"""

import re
import logging
import asyncio
import requests
import xml.etree.ElementTree as ET
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional, List

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class CanadaSEMASanctionsScraper(BaseSanctionScraper):
    """
    Scraper for Canada SEMA Sanctions.
    
    Source URL: https://www.international.gc.ca/.../sema-lmes.xml
    Format: XML
    Filters: Individuals only.
    """
    name = "Canada - SEMA Sanctions"
    country = "Canada"
    
    BASE_URL = "https://www.international.gc.ca/world-monde/assets/office_docs/international_relations-relations_internationales/sanctions/sema-lmes.xml"
    DATA_FILENAME = "canada_sema.xml"
    
    # Regex delimiters for splitting complex alias strings
    ALIAS_SPLITS = [
        ", ", "; ", " (a.k.a.", " (also known as", "; a.k.a. ",
        "ALIAS: ", "Hebrew: ", "Arabic: ", "Belarusian:",
        "Belarussian:", "Russian:", "Ukrainian:", " / "
    ]

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Download the XML file.
        Uses requests with verify=False due to frequent GAC SSL issues.
        """
        self.logger.info(f"Downloading data from: {self.BASE_URL}")
        
        local_path = self.raw_dir / self.DATA_FILENAME
        
        # Custom headers to mimic a browser
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
        }

        def _download_task():
            # Suppress InsecureRequestWarning for this specific call
            requests.packages.urllib3.disable_warnings()
            with requests.get(self.BASE_URL, headers=headers, timeout=60, verify=False, stream=True) as r:
                r.raise_for_status()
                with open(local_path, 'wb') as f:
                    for chunk in r.iter_content(chunk_size=8192):
                        f.write(chunk)

        try:
            await asyncio.to_thread(_download_task)
            if local_path.exists() and local_path.stat().st_size > 0:
                return local_path
            return None
        except Exception as e:
            self.logger.error(f"Download failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Parse XML -> Golden Profile.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            # Fallback scan
            xml_files = list(raw_path.parent.glob("*.xml"))
            if not xml_files:
                self.logger.warning("No XML files found.")
                return
            target_file = xml_files[0]

        self.logger.info(f"Processing file: {target_file}")
        mapper = ProfileMapper()

        try:
            tree = ET.parse(target_file)
            root = tree.getroot()

            # Iterate over all <record> elements
            for record in root.findall(".//record"):
                try:
                    # Helper to get text safely
                    row = {child.tag: self._clean_text(child.text) for child in record}
                    
                    given_name = row.get("GivenName")
                    last_name = row.get("LastName")
                    entity_name_raw = row.get("EntityOrShip")
                    
                    # --- 1. FILTER: INDIVIDUALS ONLY ---
                    # If no given/last name, it's likely an entity or vessel
                    if not given_name and not last_name:
                        continue

                    # Construct Full Name
                    parts = [p for p in [given_name, last_name] if p]
                    full_name = " ".join(parts) if parts else entity_name_raw

                    # --- 2. Extract Data ---
                    dob_raw = row.get("DateOfBirthOrShipBuildDate")
                    title = row.get("TitleOrShip")
                    schedule = row.get("Schedule", "")
                    country_program = row.get("Country")
                    listing_date_raw = row.get("DateOfListing")
                    item_id = row.get("Item")
                    aliases_raw = row.get("Aliases")

                    # Program/Country extraction
                    country = None
                    program = country_program
                    if country_program and "/" in country_program:
                        country = country_program.split("/")[0].strip()
                    else:
                        country = country_program

                    # --- 3. Dates ---
                    dob = self._parse_sema_date(dob_raw)
                    listing_date = self._parse_sema_date(listing_date_raw)

                    # --- 4. Aliases ---
                    aliases_list = self._split_aliases(aliases_raw)

                    # --- 5. Generate ID ---
                    unique_key = f"{schedule}_{country}_{full_name}_{dob_raw or ''}"
                    record_id = self.generate_uuid(unique_key)

                    # --- 6. Build Record ---
                    raw_record = {
                        "profile": {
                            "id": record_id,
                            "full_name": full_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": None, 
                            "date_of_birth": dob,
                            "nationality": country, # Usually the program country is the nationality
                            "is_active": True,
                            "aliases": aliases_list,
                            "images": [],
                            "addresses": []
                        },
                        "risk_events": [
                            {
                                "type": "Sanction",
                                "source_list": self.name,
                                "authority": "Global Affairs Canada",
                                "reason": f"Schedule: {schedule} | Program: {program} | Title: {title}",
                                "date_listed": listing_date,
                                "is_current": True,
                                "risk_level": "High",
                            }
                        ],
                        "evidence": [
                            {
                                "url": self.BASE_URL,
                                "scraped_at": datetime.now().isoformat(),
                                "raw_text_snippet": f"Item: {item_id} | Aliases: {aliases_raw}"
                            }
                        ]
                    }

                    # --- 7. Normalize & Yield ---
                    result = mapper.map_single_profile(raw_record)

                    yield result

                except Exception as row_e:
                    self.logger.warning(f"Error parsing record: {row_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process XML file: {e}")
            raise e

    # ---------------------------------------------------------
    # Helper Methods
    # ---------------------------------------------------------

    def _clean_text(self, text: Optional[str]) -> Optional[str]:
        if not text: return None
        text = text.strip()
        return text if text else None

    def _split_aliases(self, text: str) -> List[str]:
        """
        Splits complex alias strings like "Name 1; a.k.a. Name 2 (also known as Name 3)".
        """
        if not text:
            return []
        
        # Escape special chars for regex
        pattern = '|'.join(map(re.escape, self.ALIAS_SPLITS))
        parts = re.split(pattern, text)
        
        cleaned_parts = []
        for p in parts:
            # Remove trailing parens/semicolons often left over
            p = p.strip().rstrip(");").strip()
            if p:
                cleaned_parts.append(p)
        
        return list(set(cleaned_parts))

    def _parse_sema_date(self, d_str: Optional[str]) -> Optional[str]:
        """
        Parses mixed SEMA dates: "2022-02-24", "October 17, 2023", "1978".
        """
        if not d_str: return None
        
        formats = [
            "%Y-%m-%d",       # 2022-02-24
            "%B %d, %Y",      # October 17, 2023
            "%d %B %Y",       # 17 October 2023
            "%Y"              # 1978
        ]
        
        for fmt in formats:
            try:
                return datetime.strptime(d_str.strip(), fmt).strftime("%Y-%m-%d")
            except ValueError:
                continue
        return None

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = CanadaSEMASanctionsScraper()
    asyncio.run(scraper.run(force=True))