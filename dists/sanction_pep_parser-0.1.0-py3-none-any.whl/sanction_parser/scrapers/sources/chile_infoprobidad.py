"""
src/sanction_parser/scrapers/sources/chile_infoprobidad.py

Scraper for Chile InfoProbidad Declarations (PEP).
Source: https://www.infoprobidad.cl/
Method: Direct extraction of 'datos' JS variable via Playwright.
"""

import re
import json
import logging
import asyncio
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional, List

# Third-party
from playwright.async_api import async_playwright

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class ChileInfoProbidadScraper(BaseSanctionScraper):
    """
    Scraper for Chile InfoProbidad (Politically Exposed Persons).
    
    The site loads data into a global JS variable 'datos'. 
    We extract this variable directly to get the full dataset in one go.
    """
    name = "Chile InfoProbidad - PEPs"
    country = "Chile"
    
    BASE_URL = "https://www.infoprobidad.cl/Home/Listado"
    DATA_FILENAME = "chile_declarations.json"

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Extract the 'datos' JSON object from the page context.
        """
        self.logger.info(f"Scanning page for data: {self.BASE_URL}")
        
        local_path = self.raw_dir / self.DATA_FILENAME

        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            context = await browser.new_context(
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            )
            page = await context.new_page()

            try:
                page.set_default_timeout(60000)
                await page.goto(self.BASE_URL, wait_until="domcontentloaded")
                
                self.logger.info("Waiting for data variable to initialize...")
                
                # Smart wait for the variable 'datos'
                try:
                    await page.wait_for_function("typeof datos !== 'undefined' && datos.length > 0", timeout=30000)
                except Exception:
                    self.logger.warning("Smart wait timed out, attempting extraction anyway...")

                # Method A: Extract directly from JS execution
                json_data = await page.evaluate("""() => {
                    try {
                        if (typeof datos !== 'undefined') return JSON.stringify(datos);
                        return null;
                    } catch (e) { return null; }
                }""")

                # Method B: Regex Fallback on raw HTML
                if not json_data:
                    self.logger.info("JS variable access failed. Attempting Regex extraction...")
                    content = await page.content()
                    match = re.search(r"var\s+datos\s*=\s*(\[.+?\]);", content, re.DOTALL)
                    if match:
                        json_data = match.group(1)
                    else:
                        raise Exception("Critical: Could not find 'datos' variable in page source.")

                # Validate and Save
                if isinstance(json_data, str):
                    parsed_data = json.loads(json_data)
                else:
                    parsed_data = json_data

                if not parsed_data:
                    self.logger.error("Extracted data is empty.")
                    return None

                with open(local_path, 'w', encoding='utf-8') as f:
                    json.dump(parsed_data, f, ensure_ascii=False, indent=2)
                
                self.logger.info(f"Successfully extracted {len(parsed_data)} raw records.")
                return local_path

            except Exception as e:
                self.logger.error(f"Extraction failed: {e}")
                if local_path.exists():
                    local_path.unlink()
                return None
            finally:
                await browser.close()

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Aggregate records by person and map to schema.
        One person = Many declarations. We group them to create one profile.
        """
        self.logger.info(f"Transforming file: {raw_path}")
        
        try:
            with open(raw_path, 'r', encoding='utf-8') as f:
                all_declarations = json.load(f)
        except Exception as e:
            self.logger.error(f"Failed to load JSON: {e}")
            return

        mapper = ProfileMapper()
        
        # --- Aggregation Step ---
        # Group by Full Name to build a single profile per person
        people_map = {}
        
        for item in all_declarations:
            nombres = str(item.get("Nombres") or "").strip()
            paterno = str(item.get("ApellidoPaterno") or "").strip()
            materno = str(item.get("ApellidoMaterno") or "").strip()
            
            if not nombres: 
                continue

            full_name = f"{nombres} {paterno} {materno}".strip()
            
            if full_name not in people_map:
                people_map[full_name] = []
            
            people_map[full_name].append(item)

        self.logger.info(f"Processing {len(people_map)} unique individuals...")

        # --- Processing Step ---
        for full_name, records in people_map.items():
            try:
                # Sort by date descending to get the latest status
                records.sort(key=lambda x: str(x.get("FechaDeclaracion") or ""), reverse=True)
                latest_record = records[0]
                
                # 1. Profile Data
                institution = str(latest_record.get("ServicioEntidad") or "").strip()
                position_name = str(latest_record.get("Cargo") or "").strip()
                
                # Determine Active Status
                latest_type = str(latest_record.get("TipoDeclaracion") or "").upper()
                is_active = True
                if "CESE" in latest_type: # Cese de funciones = Ceased functions
                    is_active = False

                # 2. Generate ID
                unique_key = f"{full_name}_CL_PEP" 
                record_id = self.generate_uuid(unique_key)

                # 3. Build History (Risk Events & Evidence)
                risk_events = []
                evidence_list = []
                
                for rec in records:
                    decl_id = rec.get("IdDeclaracion")
                    decl_date = str(rec.get("FechaDeclaracion") or "")[:10]
                    decl_type = str(rec.get("TipoDeclaracion") or "Unknown").strip()
                    rec_inst = str(rec.get("ServicioEntidad") or "").strip()
                    rec_cargo = str(rec.get("Cargo") or "").strip()

                    evidence_list.append({
                        "url": f"https://www.infoprobidad.cl/Declaracion/Declaracion?ID={decl_id}",
                        "scraped_at": datetime.now().isoformat(),
                        "raw_text_snippet": f"Date: {decl_date} | Type: {decl_type} | Position: {rec_cargo} at {rec_inst}"
                    })

                # Main Event (Latest Position)
                risk_events.append({
                    "type": "PEP",
                    "source_list": self.name,
                    "authority": institution,
                    "reason": f"Position: {position_name}",
                    "date_listed": str(latest_record.get("FechaDeclaracion") or "")[:10],
                    "is_current": is_active,
                    "risk_level": "Medium"
                })

                # 4. Build Record
                raw_record = {
                    "profile": {
                        "id": record_id,
                        "full_name": full_name,
                        "entity_type": "INDIVIDUAL",
                        "gender": None,
                        "date_of_birth": None,
                        "nationality": "CL",
                        "is_active": is_active,
                        "aliases": [],
                        "images": [],
                    },
                    "risk_events": risk_events,
                    "evidence": evidence_list
                }

                # 5. Normalize & Yield
                result = mapper.map_single_profile(raw_record)

                yield result

            except Exception as e:
                self.logger.warning(f"Error processing profile {full_name}: {e}")
                continue

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = ChileInfoProbidadScraper()
    asyncio.run(scraper.run(force=True))