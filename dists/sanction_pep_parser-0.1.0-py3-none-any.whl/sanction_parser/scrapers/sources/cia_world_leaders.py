"""
src/sanction_parser/scrapers/sources/cia_world_leaders.py

Scrapes CIA "World Leaders - Foreign Governments" pages.
Source: https://www.cia.gov/resources/world-leaders/foreign-governments/
"""

import re
import json
import asyncio
import logging
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Dict, List, Tuple, Optional, Iterator
from urllib.parse import urljoin

# Third-party
from playwright.sync_api import Page, sync_playwright

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class CiaWorldLeadersScraper(BaseSanctionScraper):
    """
    Scraper for CIA World Leaders.
    
    Source URL: https://www.cia.gov/resources/world-leaders/foreign-governments/
    Format: Web Scraping (Playwright Sync - Robust Pagination)
    Type: PEP (High Risk)
    """
    name = "CIA – World Leaders"
    country = "USA"
    
    BASE_URL = "https://www.cia.gov/resources/world-leaders/foreign-governments/"
    DATA_FILENAME = "cia_world_leaders.json"

    # Playwright settings
    HEADLESS = False  
    SLOW_MO_MS = 150
    DEFAULT_TIMEOUT_MS = 60_000
    VIEWPORT = {"width": 1500, "height": 900}

    _PAGE_RE = re.compile(r"Page\s*(\d+)\s*of\s*(\d+)", re.IGNORECASE)

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Scrape using the specific Sync Playwright logic provided.
        """
        self.logger.info(f"Starting extraction from: {self.BASE_URL}")
        local_path = self.raw_dir / self.DATA_FILENAME

        try:
            # Run the sync logic in a thread to not block the asyncio loop
            raw_data = await asyncio.to_thread(self._scrape_sync)
            
            if not raw_data or not raw_data.get("countries"):
                self.logger.warning("No countries scraped.")
                return None

            # Save Raw Data
            with open(local_path, "w", encoding="utf-8") as f:
                json.dump(raw_data, f, indent=2, ensure_ascii=False)
            
            return local_path

        except Exception as e:
            self.logger.error(f"Extraction failed: {e}")
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform raw JSON to Golden Profile.
        """
        if not raw_path.exists():
            return

        self.logger.info(f"Transforming file: {raw_path}")
        mapper = ProfileMapper()

        try:
            with open(raw_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            countries = data.get("countries", [])
            bad_names = {"vacant", "tbd", "unknown", "none", "-", "n/a"}

            for country in countries:
                country_name = country.get("country_name", "Unknown")
                country_url = country.get("url", self.BASE_URL)
                last_updated = country.get("last_updated", "")

                for leader in country.get("leaders", []):
                    try:
                        name = leader.get("name", "").strip()
                        position = leader.get("position", "").strip()

                        if not name: continue
                        if name.lower() in bad_names: continue
                        if name.lower() == "vacant": continue

                        unique_string = f"{country_name}_{name}_{position}"
                        person_id = self.generate_uuid(unique_string)

                        # Build Record
                        mapped_record = {
                            "profile": {
                                "id": person_id,
                                "full_name": name,
                                "entity_type": "INDIVIDUAL",
                                "gender": None, 
                                "date_of_birth": None,
                                "nationality": country_name,
                                "is_active": True,
                                "aliases": [],
                                "images": [],
                                "addresses": []
                            },
                            "risk_events": [
                                {
                                    "type": "PEP",
                                    "source_list": self.name,
                                    "authority": "US Central Intelligence Agency",
                                    "reason": position if position else "Senior Government Official",
                                    "date_listed": None,
                                    "is_current": True,
                                    "risk_level": "High"
                                }
                            ],
                            "evidence": [
                                {
                                    "url": country_url,
                                    "scraped_at": data.get("run_at", datetime.now(timezone.utc).isoformat()),
                                    "raw_text_snippet": f"Position: {position} | Country: {country_name} | Updated: {last_updated}"
                                }
                            ]
                        }

                        result = mapper.map_single_profile(mapped_record)
                        yield result 

                    except Exception as inner_e:
                        self.logger.warning(f"Error transforming leader: {inner_e}")
                        continue

        except Exception as e:
            self.logger.error(f"Failed to process JSON file: {e}")
            raise e

    # ---------------------------------------------------------
    # ORIGINAL SCRAPING LOGIC (Restored & Enhanced with Scroll)
    # ---------------------------------------------------------

    def _scrape_sync(self) -> Dict[str, Any]:
        self.logger.info("Starting Playwright sync session...")
        countries_data = []

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=self.HEADLESS, slow_mo=self.SLOW_MO_MS)
            page = browser.new_page(viewport=self.VIEWPORT)
            page.set_default_timeout(self.DEFAULT_TIMEOUT_MS)

            try:
                self.logger.info("Opening main page...")
                page.goto(self.BASE_URL, wait_until="domcontentloaded")
                
                # --- NEW: Scroll to bottom to trigger lazy loading ---
                self.logger.info("Scrolling page to ensure content loads...")
                page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
                page.wait_for_timeout(2000) # Wait for React/Gatsby to react
                # -----------------------------------------------------

                # Collect Links
                countries_list = self._collect_all_country_links(page)
                total = len(countries_list)
                self.logger.info(f"Total country links collected: {total}")

                # Scrape Details
                for idx, c in enumerate(countries_list, start=1):
                    url = c["url"]
                    if idx % 10 == 0:
                        self.logger.info(f"Scraping country {idx}/{total}: {c['country_name']}")
                    
                    try:
                        page.goto(url, wait_until="domcontentloaded")
                        page.wait_for_timeout(650)
                        countries_data.append(self._parse_country_detail(page, url))
                    except Exception as e:
                        self.logger.warning(f"Failed {url}: {e}")

            finally:
                browser.close()

        return {
            "source": {"name": self.name, "url": self.BASE_URL},
            "run_at": datetime.now(timezone.utc).isoformat(),
            "countries": countries_data,
        }

    # --- Helpers from Original Code ---

    def _clean_text(self, text: Optional[str]) -> str:
        if text is None: return ""
        text = text.replace("\xa0", " ")
        text = re.sub(r"\s+", " ", text)
        return text.strip()

    def _extract_page_label(self, page: Page) -> str:
        # Important: React might re-render this, checking explicitly
        label_loc = page.locator("[data-testid='page-label']").first
        if label_loc.count():
            return self._clean_text(label_loc.inner_text())
        txt = page.inner_text("body")
        m = self._PAGE_RE.search(txt)
        return m.group(0) if m else ""

    def _get_page_numbers(self, page: Page) -> Tuple[int, int]:
        label = self._extract_page_label(page)
        m = self._PAGE_RE.search(label)
        if not m:
            label = label.replace("\xa0", " ")
            m = self._PAGE_RE.search(label)
        if not m: return 1, 1 
        return int(m.group(1)), int(m.group(2))

    def _wait_until_page_changes(self, page: Page, old_label: str, old_url: str) -> bool:
        """
        Gatsby specific wait: wait for label text change or URL change.
        """
        try:
            page.wait_for_function(
                """(args) => {
                    const oldLabel = args.oldLabel;
                    const oldUrl = args.oldUrl;
                    const el = document.querySelector("[data-testid='page-label']");
                    const t = el ? (el.innerText || "").replace(/\\u00a0/g, " ").trim() : "";
                    const urlChanged = (location.href !== oldUrl);
                    const labelChanged = (t && t !== oldLabel);
                    return urlChanged || labelChanged;
                }""",
                arg={"oldLabel": old_label, "oldUrl": old_url},
                timeout=15_000,
            )
            return True
        except Exception:
            return False

    def _click_next_page(self, page: Page, current_page: int) -> bool:
        next_btn = page.locator("[data-testid='right-arrow']").first
        if next_btn.count() == 0: return False

        aria = (next_btn.get_attribute("aria-label") or "").lower()
        if "disabled" in aria: return False

        old_label = self._extract_page_label(page)
        old_url = page.url

        # Retry logic
        for _ in range(3):
            try:
                next_btn.scroll_into_view_if_needed()
                next_btn.click(timeout=5000)
                
                if self._wait_until_page_changes(page, old_label, old_url):
                    return True
                
                # JS Click Fallback
                page.evaluate("""() => {
                    const el = document.querySelector("[data-testid='right-arrow']");
                    if (el) el.click();
                }""")
                if self._wait_until_page_changes(page, old_label, old_url):
                    return True
                    
            except:
                page.wait_for_timeout(500)
                
        return False

    def _collect_all_country_links(self, page: Page) -> List[Dict[str, str]]:
        all_countries = []
        seen = set()
        
        current_page, total_pages = self._get_page_numbers(page)
        self.logger.info(f"Pagination: Page {current_page} of {total_pages}")

        while True:
            # Scroll before reading links on each page to trigger any lazy loading within the list
            page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
            page.wait_for_timeout(500)

            anchors = page.locator("main#main-content a[href^='/resources/world-leaders/foreign-governments/']")
            
            # Ensure elements are present
            try:
                anchors.first.wait_for(state="visible", timeout=10000)
            except:
                self.logger.warning("Timeout waiting for country links.")

            for i in range(anchors.count()):
                a = anchors.nth(i)
                href = a.get_attribute("href")
                if not href or href.rstrip("/") == "/resources/world-leaders/foreign-governments":
                    continue
                
                if not re.search(r"/resources/world-leaders/foreign-governments/[^/]+/?$", href.rstrip("/")):
                    continue

                name = self._clean_text(a.inner_text())
                full_url = urljoin(self.BASE_URL, href)
                
                if full_url not in seen and name:
                    seen.add(full_url)
                    all_countries.append({"country_name": name, "url": full_url})

            if current_page >= total_pages:
                break

            if not self._click_next_page(page, current_page):
                break
            
            current_page, _ = self._get_page_numbers(page)
            if current_page > total_pages + 5: break 

        return all_countries

    def _parse_country_detail(self, page: Page, url: str) -> Dict[str, Any]:
        h1 = page.locator("main#main-content h1.hero-title").first
        country_name = self._clean_text(h1.inner_text()) if h1.count() else ""

        last_updated = ""
        last_updated_span = page.locator("main#main-content div.last-updated span").first
        if last_updated_span.count():
            last_updated = self._clean_text(last_updated_span.inner_text())

        leaders = []
        blocks = page.locator("main#main-content div.article-content div.leader-info")
        for i in range(blocks.count()):
            b = blocks.nth(i)
            pos = self._clean_text(b.locator("h4").first.inner_text()) if b.locator("h4").count() else ""
            nm = self._clean_text(b.locator("p").first.inner_text()) if b.locator("p").count() else ""
            if pos or nm:
                leaders.append({"position": pos, "name": nm})

        return {
            "country_name": country_name,
            "url": url,
            "last_updated": last_updated,
            "leaders": leaders,
        }

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = CiaWorldLeadersScraper()
    asyncio.run(scraper.run(force=True))