"""
src/sanction_parser/scrapers/sources/directorio_legislativo.py

Scraper for Directorio Legislativo - PEPs (Politically Exposed Persons).
Source: https://peps.directoriolegislativo.org/
"""

import logging
import asyncio
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional, List

# Third-party
import pandas as pd

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper
from sanction_parser.scrapers.utils.web_client import get_request

# Initialize logger
logger = logging.getLogger(__name__)

class DirectorioLegislativoPEPsScraper(BaseSanctionScraper):
    """
    Scraper for Directorio Legislativo PEPs.
    
    Source URL: https://peps.directoriolegislativo.org/datasets/peps.csv
    Format: CSV
    Type: PEP
    """
    name = "Directorio Legislativo - PEPs"
    country = "Global" # Though focused on LatAm, it covers multiple countries
    
    FILE_URL = "https://peps.directoriolegislativo.org/datasets/peps.csv"
    DATA_FILENAME = "directorio_peps.csv"

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Download the CSV file directly.
        """
        self.logger.info(f"Downloading file from: {self.FILE_URL}")
        
        local_path = self.raw_dir / self.DATA_FILENAME

        def _download_task():
            # Stream download to handle potential large file size
            response = get_request(self.FILE_URL, stream=True, timeout=120)
            with open(local_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

        try:
            await asyncio.to_thread(_download_task)
            
            if local_path.exists() and local_path.stat().st_size > 0:
                return local_path
            else:
                self.logger.error("Download failed or file is empty.")
                return None

        except Exception as e:
            self.logger.error(f"Failed to download file: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform CSV to Golden Profile schema.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            # Fallback scan
            csv_files = list(raw_path.parent.glob("*.csv"))
            if not csv_files:
                self.logger.warning("No CSV files found.")
                return
            target_file = csv_files[0]

        self.logger.info(f"Transforming file: {target_file}")
        mapper = ProfileMapper()

        try:
            # Attempt to read with different encodings
            try:
                df = pd.read_csv(target_file, encoding='utf-8')
            except UnicodeDecodeError:
                df = pd.read_csv(target_file, encoding='latin-1')
            
            # Fill NaN with empty strings for easier string manipulation
            df = df.fillna("")

            for index, row in df.iterrows():
                try:
                    # 1. Name Construction
                    p_nombre = str(row.get("Primer Nombre", "")).strip()
                    s_nombre = str(row.get("Segundo Nombre", "")).strip()
                    p_apellido = str(row.get("Primer Apellido", "")).strip()
                    s_apellido = str(row.get("Segundo Apellido", "")).strip()
                    
                    name_parts = [p_nombre, s_nombre, p_apellido, s_apellido]
                    full_name = " ".join([part for part in name_parts if part])
                    
                    if not full_name:
                        continue 

                    # 2. Extract Identifiers
                    national_id = str(row.get("ID / CC", "")).strip()
                    if national_id == "0": 
                        national_id = None 
                    
                    # 3. Address Construction
                    dept = str(row.get("Departamento", "")).strip()
                    muni = str(row.get("Municipio", "")).strip()
                    address_parts = [muni, dept]
                    address_full = ", ".join([p for p in address_parts if p])

                    # 4. Details
                    entity_name = str(row.get("Entidad", "")).strip()
                    position = str(row.get("Cargo", "")).strip()
                    
                    # 5. Generate ID
                    unique_key = f"{full_name}_{national_id}_{entity_name}"
                    record_id = self.generate_uuid(unique_key)

                    # 6. Build Record
                    raw_record = {
                        "profile": {
                            "id": record_id,
                            "full_name": full_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": None, 
                            "date_of_birth": None,
                            "nationality": "Colombia", # Dataset is heavily Colombia focused, but could be dynamic
                            "is_active": True, 
                            "aliases": [],
                            "images": [],
                            "addresses": [address_full] if address_full else []
                        },
                        "risk_events": [
                            {
                                "type": "PEP", 
                                "source_list": self.name,
                                "authority": "Directorio Legislativo",
                                "reason": f"Entity: {entity_name} | Position: {position}",
                                "date_listed": self.execution_date, 
                                "is_current": True,
                                "risk_level": "High", 
                            }
                        ],
                        "evidence": [
                            {
                                "url": self.FILE_URL,
                                "scraped_at": datetime.now().isoformat(),
                                "raw_text_snippet": f"ID: {national_id} | {entity_name} - {position}"
                            }
                        ]
                    }

                    # 7. Normalize & Yield
                    result = mapper.map_single_profile(raw_record)

                    yield result

                except Exception as inner_e:
                    self.logger.warning(f"Error processing row {index}: {inner_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process CSV file: {e}")
            raise e

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = DirectorioLegislativoPEPsScraper()
    asyncio.run(scraper.run(force=True))