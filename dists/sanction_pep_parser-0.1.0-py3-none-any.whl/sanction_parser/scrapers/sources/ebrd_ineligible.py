"""
src/sanction_parser/scrapers/sources/ebrd_ineligible.py

Scraper for European Bank for Reconstruction and Development (EBRD) Ineligible Entities.
Source: https://www.ebrd.com/.../ineligible-entities.html
"""

import logging
import asyncio
import pandas as pd
import pycountry
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional

# Third-party
from playwright.async_api import async_playwright

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class EBRDSanctionsScraper(BaseSanctionScraper):
    """
    Scraper for EBRD Ineligible Entities.
    
    Source URL: https://www.ebrd.com/home/who-we-are/strategies-governance-compliance/ebrd-sanctions-system/ineligible-entities.html
    Format: CSV (Dynamic Download via JS)
    """
    name = "EBRD - Ineligible Entities"
    country = "Global"
    
    BASE_URL = "https://www.ebrd.com/home/who-we-are/strategies-governance-compliance/ebrd-sanctions-system/ineligible-entities.html"
    DATA_FILENAME = "ebrd_ineligible.csv"

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Download CSV via Playwright by clicking the export button.
        """
        self.logger.info(f"Starting Playwright session for: {self.BASE_URL}")
        
        local_path = self.raw_dir / self.DATA_FILENAME

        async with async_playwright() as p:
            # Launch with specific args to ensure elements are visible/clickable
            browser = await p.chromium.launch(headless=True, args=["--start-maximized"])
            context = await browser.new_context(accept_downloads=True, viewport={"width": 1920, "height": 1080})
            page = await context.new_page()

            try:
                self.logger.info("Navigating to page...")
                await page.goto(self.BASE_URL, timeout=90000, wait_until="domcontentloaded")

                # The download button ID
                button_selector = "#downloadFilterResult"
                
                # Wait for the button to be present in DOM
                await page.wait_for_selector(button_selector, state="visible", timeout=30000)
                
                # Small wait for any JS handlers to attach
                await page.wait_for_timeout(2000)

                self.logger.info("Clicking download button...")
                
                async with page.expect_download(timeout=60000) as download_info:
                    await page.click(button_selector, force=True)

                download = await download_info.value
                
                await download.save_as(local_path)
                self.logger.info(f"Downloaded to: {local_path}")
                
                return local_path

            except Exception as e:
                self.logger.error(f"Playwright download failed: {e}")
                if local_path.exists():
                    local_path.unlink()
                return None
            finally:
                await browser.close()

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform CSV to Golden Profile schema.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            csv_files = list(raw_path.parent.glob("*.csv"))
            if not csv_files:
                self.logger.warning("No CSV files found.")
                return
            target_file = csv_files[0]

        self.logger.info(f"Transforming file: {target_file}")
        mapper = ProfileMapper()

        try:
            # Read CSV with Pandas
            df = pd.read_csv(target_file, on_bad_lines='skip', dtype=str)
            # Normalize headers
            df.columns = [str(c).strip() for c in df.columns]

            for _, row in df.iterrows():
                try:
                    # 1. Filter: Individuals Only
                    notice_type = str(row.get("Notice type", "")).strip()
                    if notice_type.lower() != "individual":
                        continue

                    # 2. Extract Data
                    entity_name = str(row.get("Name Of Entity", "")).strip()
                    special_name = str(row.get("Name (special charcters)", "")).strip()
                    
                    # Handle name priority
                    if (not entity_name or entity_name.lower() == 'nan') and special_name:
                        entity_name = special_name
                    
                    if not entity_name or entity_name.lower() == 'nan':
                        continue

                    # Nationality
                    nationality_raw = str(row.get("Nationality", "")).strip()
                    if nationality_raw.lower() == 'nan': 
                        nationality_raw = None
                    country_iso2 = self._country_to_iso2(nationality_raw)

                    # Address
                    address = str(row.get("Address", "")).strip()
                    if address.lower() == 'nan': address = None

                    # Reasons
                    reason_raw = str(row.get("Reason for debarment", "")).strip()
                    grounds_raw = str(row.get("Grounds", "")).strip()
                    
                    full_reason_parts = []
                    if reason_raw and reason_raw.lower() != 'nan': full_reason_parts.append(reason_raw)
                    if grounds_raw and grounds_raw.lower() != 'nan': full_reason_parts.append(f"Grounds: {grounds_raw}")
                    full_reason = " | ".join(full_reason_parts)

                    # Dates
                    start_date = self._parse_ebrd_date(row.get("Start date"))
                    end_date = self._parse_ebrd_date(row.get("End date"))
                    
                    # Status
                    is_active = True
                    if end_date:
                        try:
                            if datetime.strptime(end_date, "%Y-%m-%d") < datetime.now():
                                is_active = False
                        except ValueError:
                            pass

                    # 3. Generate ID
                    unique_key = f"{entity_name}_{nationality_raw}_{start_date}"
                    record_id = self.generate_uuid(unique_key)

                    # 4. Build Record
                    mapped_record = {
                        "profile": {
                            "id": record_id,
                            "full_name": entity_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": None,
                            "date_of_birth": None,
                            "nationality": country_iso2,
                            "is_active": is_active,
                            "aliases": [special_name] if (special_name and special_name != entity_name) else [],
                            "images": [],
                            "addresses": [address] if address else []
                        },
                        "risk_events": [
                            {
                                "type": "Sanction",
                                "source_list": self.name,
                                "authority": "European Bank for Reconstruction and Development (EBRD)",
                                "reason": full_reason,
                                "date_listed": start_date,
                                "is_current": is_active,
                                "risk_level": "High",
                            }
                        ],
                        "evidence": [
                            {
                                "url": self.BASE_URL,
                                "scraped_at": datetime.now().isoformat(),
                                "raw_text_snippet": f"Type: {notice_type} | Nationality: {nationality_raw} | End Date: {end_date}"
                            }
                        ]
                    }

                    # 5. Normalize & Yield
                    result = mapper.map_single_profile(mapped_record)

                    yield result

                except Exception as row_e:
                    self.logger.warning(f"Error parsing row: {row_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process CSV file: {e}")
            raise e

    # ---------------------------------------------------------
    # Helper Methods
    # ---------------------------------------------------------

    def _parse_ebrd_date(self, date_str: Any) -> Optional[str]:
        """Parses dates like '28-04-2025' to '2025-04-28'."""
        if pd.isna(date_str) or str(date_str).lower() == 'nan':
            return None
        
        s = str(date_str).strip()
        try:
            return datetime.strptime(s, "%d-%m-%Y").strftime("%Y-%m-%d")
        except ValueError:
            return None

    def _country_to_iso2(self, country_name: Optional[str]) -> Optional[str]:
        """Resolves country name to ISO alpha-2 code."""
        if not country_name:
            return None
        
        name = country_name.strip()
        
        # Exact lookup
        c = pycountry.countries.get(name=name)
        if c: return c.alpha_2
        
        # Fuzzy lookup
        try:
            matches = pycountry.countries.search_fuzzy(name)
            if matches: return matches[0].alpha_2
        except LookupError:
            pass
            
        return None

if __name__ == "__main__":
    import sys
    if sys.platform == 'win32':
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

    logging.basicConfig(level=logging.INFO)
    scraper = EBRDSanctionsScraper()
    asyncio.run(scraper.run(force=True))