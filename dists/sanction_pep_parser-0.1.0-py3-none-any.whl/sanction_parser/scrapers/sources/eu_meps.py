"""
src/sanction_parser/scrapers/sources/eu_meps.py

Scraper for European Parliament Members (MEPs).
Source: https://www.europarl.europa.eu/meps/en/full-list
"""

import logging
import asyncio
import xml.etree.ElementTree as ET
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional, List

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper
from sanction_parser.scrapers.utils.web_client import extract_download_links, get_request

# Initialize logger
logger = logging.getLogger(__name__)

class EUMembersScraper(BaseSanctionScraper):
    """
    Scraper for European Parliament Members (MEPs).
    
    Source URL: https://www.europarl.europa.eu/meps/en/full-list
    Format: XML
    Type: PEP
    """
    name = "European Parliament - MEPs List"
    country = "European Union"
    
    BASE_URL = "https://www.europarl.europa.eu/meps/en/full-list"
    TARGET_EXTS = ["xml"]
    DATA_FILENAME = "eu_meps.xml"

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Download the XML data.
        """
        self.logger.info(f"Scanning page for XML link: {self.BASE_URL}")

        # 1. Try dynamic extraction first
        try:
            links = await asyncio.to_thread(extract_download_links, self.BASE_URL, exts=self.TARGET_EXTS)
        except Exception as e:
            self.logger.warning(f"Helper extraction warning: {e}")
            links = []

        # 2. Use Fallback URL if extraction fails
        if not links:
            fallback_url = "https://www.europarl.europa.eu/meps/en/full-list/xml"
            self.logger.info("No links found via helper. Using known fallback URL.")
            xml_url = fallback_url
        else:
            # Prefer links that contain 'full-list'
            xml_url = links[0]['url']

        self.logger.info(f"Target XML URL: {xml_url}")
        
        local_path = self.raw_dir / self.DATA_FILENAME

        def _download_task():
            response = get_request(xml_url, stream=True, timeout=60)
            with open(local_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

        try:
            await asyncio.to_thread(_download_task)
            if local_path.exists() and local_path.stat().st_size > 0:
                return local_path
            return None
        except Exception as e:
            self.logger.error(f"Download failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Parse XML -> Golden Profile.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            xml_files = list(raw_path.parent.glob("*.xml"))
            if not xml_files:
                self.logger.warning("No XML files found.")
                return
            target_file = xml_files[0]

        self.logger.info(f"Processing XML file: {target_file}")
        mapper = ProfileMapper()

        try:
            tree = ET.parse(target_file)
            root = tree.getroot()

            # The XML structure for MEPs typically has <mep> elements
            for mep in root.findall("mep"):
                try:
                    # Helper to get text safely
                    def get_val(tag):
                        node = mep.find(tag)
                        return node.text.strip() if node is not None and node.text else None

                    # 1. Extract Fields
                    full_name = get_val("fullName")
                    if not full_name:
                        continue

                    country = get_val("country")
                    pol_group = get_val("politicalGroup")
                    mep_id = get_val("id")
                    nat_group = get_val("nationalPoliticalGroup")

                    # 2. Generate ID
                    unique_key = mep_id if mep_id else f"{full_name}_{country}"
                    record_id = self.generate_uuid(unique_key)

                    # 3. Build Record
                    raw_record = {
                        "profile": {
                            "id": record_id,
                            "full_name": full_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": None, 
                            "date_of_birth": None,
                            "nationality": country, 
                            "is_active": True,
                            "aliases": [],
                            "images": [],
                            "addresses": []
                        },
                        "risk_events": [
                            {
                                "type": "PEP", # Politically Exposed Person
                                "source_list": self.name,
                                "authority": "European Parliament",
                                "reason": f"Member of European Parliament (MEP) | Group: {pol_group} | National Party: {nat_group}",
                                "date_listed": self.execution_date,
                                "is_current": True,
                                "risk_level": "Medium",
                            }
                        ],
                        "evidence": [
                            {
                                "url": self.BASE_URL,
                                "scraped_at": datetime.now().isoformat(),
                                "raw_text_snippet": f"ID: {mep_id} | Political Group: {pol_group}" 
                            }
                        ]
                    }

                    # 4. Normalize & Yield
                    result = mapper.map_single_profile(raw_record)
   
                    yield result

                except Exception as row_e:
                    self.logger.warning(f"Error parsing MEP: {row_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process XML file: {e}")
            raise e

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = EUMembersScraper()
    asyncio.run(scraper.run(force=True))