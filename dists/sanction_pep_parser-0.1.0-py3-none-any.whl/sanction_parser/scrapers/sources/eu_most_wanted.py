"""
src/sanction_parser/scrapers/sources/eu_most_wanted.py

Scrapes the EU Most Wanted list and enriches each entry with profile details.
Source: https://www.eumostwanted.eu/list
"""

import json
import re
import time
import logging
import asyncio
import requests
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Iterator
from urllib.parse import urljoin

# Third-party
from bs4 import BeautifulSoup

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class EuMostWantedScraper(BaseSanctionScraper):
    """
    Scrapes the EU Most Wanted list.
    
    Source URL: https://www.eumostwanted.eu/list
    Format: Web Scraping (Requests + BS4)
    Type: Wanted (High Risk)
    """
    name = "EU – Most Wanted"
    country = "EU"
    
    BASE_URL = "https://www.eumostwanted.eu"
    LIST_URL = BASE_URL + "/list"
    DATA_FILENAME = "eu_most_wanted.json"
    
    # Path to country map (relative to this file or project root)
    # Adjust this path if your project structure requires it
    #COUNTRY_MAP_PATH = Path(__file__).parent / "constant/country_map.json"
    COUNTRY_MAP_PATH = Path(__file__).parent.parent.parent / "constant" / "country_map.json"
    


    # HTTP behavior
    RETRIES = 3
    TIMEOUT_SEC = 60
    USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    ACCEPT = "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8"

    def __init__(self) -> None:
        super().__init__()
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": self.USER_AGENT,
            "Accept": self.ACCEPT,
            "Accept-Language": "en-US,en;q=0.9",
            "Connection": "keep-alive",
        })
        self.country_map = self._load_country_map()

    def _load_country_map(self) -> Dict[str, Any]:
        """Loads the JSON mapping from nationality/country name to ISO code."""
        # Try finding map in current dir or up one level if the path logic assumes that
        candidates = [
            self.COUNTRY_MAP_PATH,
            Path(__file__).parent.parent / "constant/country_map.json",
            Path("src/sanction_parser/constant/country_map.json")
        ]
        
        for path in candidates:
            if path.exists():
                try:
                    with path.open("r", encoding="utf-8") as f:
                        return json.load(f)
                except Exception as e:
                    self.logger.warning(f"Failed to load country map from {path}: {e}")
                    return {}
        
        self.logger.warning("Country map file not found. ISO conversion will be skipped.")
        return {}

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Scrape list and details synchronously (in a thread).
        """
        self.logger.info(f"Starting extraction from: {self.LIST_URL}")
        local_path = self.raw_dir / self.DATA_FILENAME

        try:
            # Run sync logic in thread
            raw_data = await asyncio.to_thread(self._scrape_sync)
            
            if not raw_data or not raw_data.get("entries"):
                self.logger.warning("No entries scraped.")
                return None

            # Save Raw Data
            with open(local_path, "w", encoding="utf-8") as f:
                json.dump(raw_data, f, indent=2, ensure_ascii=False)
            
            return local_path

        except Exception as e:
            self.logger.error(f"Extraction failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform raw JSON to Golden Profile.
        """
        if not raw_path.exists():
            return

        self.logger.info(f"Transforming file: {raw_path}")
        mapper = ProfileMapper()

        try:
            with open(raw_path, "r", encoding="utf-8") as f:
                raw_data = json.load(f)

            entries = raw_data.get("entries", [])

            for entry in entries:
                try:
                    profile_data = entry.get("profile", {})
                    
                    # 1. Name
                    full_name = self._clean_name(entry.get("name"))

                    # 2. ID
                    seed = entry.get("nid") or entry.get("profile_url") or full_name
                    person_id = self.generate_uuid(seed)

                    # 3. DOB
                    dob = self._parse_dob(profile_data.get("date_of_birth"))

                    # 4. Nationality
                    raw_nationality = profile_data.get("nationality") or entry.get("country")
                    iso_nationality = self._get_iso_code(raw_nationality)
                    final_nationality = iso_nationality if iso_nationality else raw_nationality

                    # 5. Risk Info
                    is_dangerous = entry.get("is_dangerous_flag") == "1"
                    crime_reason = profile_data.get("crime") or entry.get("crime") or "Criminal Investigation"
                    
                    # 6. Evidence Construction
                    status = entry.get("status")
                    state_of_case = entry.get("state_of_case") or profile_data.get("state_of_case")
                    locations = entry.get("probable_locations")
                    
                    details_parts = []
                    if status: details_parts.append(f"Status: {status}")
                    if state_of_case: details_parts.append(f"Sentence: {state_of_case}")
                    if locations: details_parts.append(f"Locations: {locations}")
                    if is_dangerous: details_parts.append("Flagged as Dangerous")
                    
                    # Add physical details to snippet
                    height = profile_data.get("approximate_height")
                    langs = profile_data.get("spoken_languages")
                    ethnic = profile_data.get("ethnic_origin")
                    
                    if height: details_parts.append(f"Height: {height}")
                    if langs: details_parts.append(f"Languages: {langs}")
                    if ethnic: details_parts.append(f"Ethnicity: {ethnic}")

                    evidence_text = " | ".join(details_parts)

                    # 7. Build Record
                    mapped_record = {
                        "profile": {
                            "id": person_id,
                            "full_name": full_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": profile_data.get("sex"),
                            "date_of_birth": dob,
                            "nationality": final_nationality, 
                            "is_active": True,
                            "aliases": [],
                            "images": [entry.get("picture_url")] if entry.get("picture_url") else [],
                            "addresses": []
                        },
                        "risk_events": [
                            {
                                "type": "Wanted",
                                "source_list": self.name,
                                "authority": f"Europol / {entry.get('country', 'EU')}",
                                "reason": crime_reason,
                                "date_listed": None,
                                "is_current": True,
                                "risk_level": "High" if is_dangerous else "Medium",
                                "comments": "Flagged as Dangerous" if is_dangerous else None,
                            }
                        ],
                        "evidence": [
                            {
                                "url": entry.get("profile_url"),
                                "scraped_at": datetime.now(timezone.utc).isoformat(),
                                "raw_text_snippet": evidence_text
                            }
                        ]
                    }

                    # Normalize & Yield
                    result = mapper.map_single_profile(mapped_record)
                    yield result

                except Exception as inner_e:
                    self.logger.warning(f"Error transforming entry: {inner_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process JSON file: {e}")
            raise e

    # ---------------------------------------------------------
    # Internal Helpers (Original Logic)
    # ---------------------------------------------------------

    def _scrape_sync(self) -> Dict[str, Any]:
        """Full synchronous pipeline running in thread."""
        self.logger.info("Fetching list page...")
        try:
            list_html = self._fetch_html(self.LIST_URL)
        except Exception as e:
            self.logger.error(f"Critical failure fetching list: {e}")
            return {"entries": []}

        fugitives = self._parse_list_page(list_html)
        self.logger.info(f"Found {len(fugitives)} entries.")

        for idx, fug in enumerate(fugitives, start=1):
            if not fug.get("profile_url"): continue
            
            if idx % 10 == 0:
                self.logger.info(f"Enriching {idx}/{len(fugitives)}...")

            try:
                profile_html = self._fetch_html(fug["profile_url"])
                fug["profile"] = self._parse_profile_page(profile_html)
            except Exception as e:
                self.logger.warning(f"Failed profile {fug['profile_url']}: {e}")
                fug["profile"] = {}
            
            # Polite delay
            time.sleep(0.5)

        return {"source_info": {"name": self.name, "url": self.LIST_URL}, "entries": fugitives}

    def _fetch_html(self, url: str, retries: int = 3) -> str:
        for i in range(retries):
            try:
                resp = self.session.get(url, timeout=self.TIMEOUT_SEC)
                resp.raise_for_status()
                return resp.text
            except Exception as e:
                if i == retries - 1: raise e
                time.sleep(1.5 * (i + 1))
        return ""

    def _parse_list_page(self, html: str) -> List[Dict[str, Any]]:
        soup = BeautifulSoup(html, "html.parser")
        container = soup.select_one("div.eumwlist") or soup
        rows = container.select("div.views-row")
        
        fugitives = []
        for row in rows:
            def txt(selector: str) -> str:
                el = row.select_one(selector)
                return el.get_text(strip=True) if el else ""

            profile_rel = txt(".views-field-view-node .field-content")
            if not profile_rel: continue

            profile_url = urljoin(self.BASE_URL, profile_rel)
            
            fugitives.append({
                "nid": txt(".views-field-nid .field-content"),
                "name": txt(".views-field-title .field-content"),
                "country": txt(".views-field-field-enfast-country .field-content"),
                "country_code": txt(".views-field-field-country-code .field-content"),
                "probable_locations": txt(".views-field-field-propable-locations .field-content"),
                "is_dangerous_flag": txt(".views-field-field-is-dangerous .field-content"),
                "status": txt(".views-field-field-status .field-content"),
                "crime": txt(".views-field-field-crime .field-content"),
                "state_of_case": txt(".views-field-field-state-of-case .field-content"),
                "profile_url": profile_url,
                "picture_url": urljoin(self.BASE_URL, txt(".views-field-field-picture .field-content")) or None,
            })
        return fugitives

    def _parse_profile_page(self, html: str) -> Dict[str, Any]:
        soup = BeautifulSoup(html, "html.parser")
        result = {}

        def extract_field_generic(label: str) -> Optional[str]:
            node = soup.find(string=lambda s: isinstance(s, str) and s.strip() == label)
            if not node: return None
            parent = node.parent
            current = parent.find_next_sibling()
            while current is not None and not current.get_text(strip=True):
                current = current.find_next_sibling()
            return current.get_text(" ", strip=True) if current else None

        labels = [
            "Crime", "Sex", "Approximate height", "Eye colour",
            "Identifiers", "Date of birth", "Nationality",
            "Ethnic origin", "Spoken languages", "State of case"
        ]

        for label in labels:
            val = extract_field_generic(label)
            if val: result[label.lower().replace(" ", "_")] = val

        return result

    def _get_iso_code(self, country_name: str) -> Optional[str]:
        if not country_name: return None
        val = self.country_map.get(country_name.strip())
        if val:
            return ", ".join(val) if isinstance(val, list) else val
        return None

    def _clean_name(self, raw_name: str) -> str:
        if not raw_name: return "Unknown"
        if "," in raw_name:
            parts = [p.strip() for p in raw_name.split(",", 1)]
            if len(parts) == 2:
                return f"{parts[1]} {parts[0]}" 
        return raw_name

    def _parse_dob(self, raw_dob: str) -> Optional[str]:
        if not raw_dob: return None
        # Example: "August 4, 1960 (65 years)"
        match = re.search(r"([a-zA-Z]+\s+\d{1,2},?\s+\d{4})", raw_dob)
        if match:
            clean_date = match.group(1).replace(",", "")
            try:
                return datetime.strptime(clean_date, "%B %d %Y").strftime("%Y-%m-%d")
            except ValueError:
                pass
        return None

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = EuMostWantedScraper()
    asyncio.run(scraper.run(force=True))