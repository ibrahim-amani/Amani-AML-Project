"""
src/sanction_parser/scrapers/sources/iadb_sanctions.py

Scraper for Inter-American Development Bank (IADB) Sanctions.
Method: Reverse-engineered PowerBI API call.
"""

import hashlib
import logging
import asyncio
import warnings
import pandas as pd
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional, List

# Third-party
from curl_cffi import requests as curl_requests

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Suppress OpenPyXL warnings
warnings.filterwarnings('ignore', category=UserWarning, module='openpyxl')

# Initialize logger
logger = logging.getLogger(__name__)

class IADBSanctionsScraper(BaseSanctionScraper):
    """
    Scraper for IADB Sanctions List.
    
    Source URL: https://www.iadb.org/en/integrity/sanctioned-firms-and-individuals
    Format: Excel (via PowerBI API)
    Strategy: Content Hashing on Data (not file metadata).
    """
    name = "Inter-American Development Bank (IADB) - Sanctions List"
    country = "Global"
    
    # Constants for API
    GET_TOKEN_URL = "https://www.iadb.org/en/idb_powerbi_refresh_token/0a2a387d-99f5-4bd7-a6f0-78299d886d79"
    EXPORT_URL = "https://wabi-us-east2-redirect.analysis.windows.net/export/xlsx"
    DATA_FILENAME = "iadb_sanctions.xlsx"
    
    # PowerBI Payload (Byte string)
    REQUEST_PAYLOAD = b"""{"exportDataType":2,"executeSemanticQueryRequest":{"version":"1.0.0","queries":[{"Query":{"Commands":[{"SemanticQueryDataShapeCommand":{"Query":{"Version":2,"From":[{"Name":"s","Entity":"Sanctions","Type":0}],"Select":[{"Column":{"Expression":{"SourceRef":{"Source":"s"}},"Property":"Title"},"Name":"Sanctions.Title","NativeReferenceName":"Title"},{"Column":{"Expression":{"SourceRef":{"Source":"s"}},"Property":"Entity"},"Name":"Sanctions.Entity","NativeReferenceName":"Entity"},{"Column":{"Expression":{"SourceRef":{"Source":"s"}},"Property":"Nationality"},"Name":"Sanctions.Nationality","NativeReferenceName":"Nationality"},{"Column":{"Expression":{"SourceRef":{"Source":"s"}},"Property":"Country"},"Name":"Sanctions.Country","NativeReferenceName":"Country"},{"Column":{"Expression":{"SourceRef":{"Source":"s"}},"Property":"Grounds"},"Name":"Sanctions.Grounds","NativeReferenceName":"Grounds"},{"Column":{"Expression":{"SourceRef":{"Source":"s"}},"Property":"Source"},"Name":"Sanctions.Source","NativeReferenceName":"Source"},{"Column":{"Expression":{"SourceRef":{"Source":"s"}},"Property":"IDB Sanction Type"},"Name":"Sanctions.IDB Sanction Type","NativeReferenceName":"IDB Sanction Type"},{"Column":{"Expression":{"SourceRef":{"Source":"s"}},"Property":"IDB Sanction Source"},"Name":"Sanctions.IDB Sanction Source","NativeReferenceName":"IDB Sanction Source"},{"Column":{"Expression":{"SourceRef":{"Source":"s"}},"Property":"Other Name"},"Name":"Sanctions.Other Name","NativeReferenceName":"Other Name"},{"Column":{"Expression":{"SourceRef":{"Source":"s"}},"Property":"From"},"Name":"Sanctions.From","NativeReferenceName":"From1"},{"Column":{"Expression":{"SourceRef":{"Source":"s"}},"Property":"To"},"Name":"Sanctions.To","NativeReferenceName":"To1"}],"Where":[{"Condition":{"Comparison":{"ComparisonKind":2,"Left":{"Column":{"Expression":{"SourceRef":{"Source":"s"}},"Property":"From Date"}},"Right":{"Literal":{"Value":"datetime'2007-03-23T00:00:00'"}}}}}],"OrderBy":[{"Direction":1,"Expression":{"Column":{"Expression":{"SourceRef":{"Source":"s"}},"Property":"Title"}}}]},"Binding":{"Primary":{"Groupings":[{"Projections":[0,1,2,3,4,5,6,7,8,9,10],"Subtotal":1}]},"DataReduction":{"Primary":{"Top":{"Count":1000000}},"Secondary":{"Top":{"Count":100}}},"Version":1}}},{"ExportDataCommand":{"Columns":[{"QueryName":"Sanctions.Title","Name":"Title"},{"QueryName":"Sanctions.Entity","Name":"Entity"},{"QueryName":"Sanctions.Nationality","Name":"Nationality"},{"QueryName":"Sanctions.Country","Name":"Country"},{"QueryName":"Sanctions.Grounds","Name":"Grounds"},{"QueryName":"Sanctions.Source","Name":"Source"},{"QueryName":"Sanctions.IDB Sanction Type","Name":"IDB Sanction Type"},{"QueryName":"Sanctions.IDB Sanction Source","Name":"IDB Sanction Source"},{"QueryName":"Sanctions.Other Name","Name":"Other Name"},{"QueryName":"Sanctions.From","Name":"From"},{"QueryName":"Sanctions.To","Name":"To"}],"Ordering":[0,1,2,3,9,10,4,5,6,7,8],"FiltersDescription":"Applied filters:\nFrom Date is on or after March 23, 2007"}}]}}],"cancelQueries":[],"modelId":8885050,"userPreferredLocale":"en-US"},"artifactId":9296919})"""

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Authenticate and Download Excel from PowerBI API.
        """
        self.logger.info("Initiating download process...")
        
        local_path = self.raw_dir / self.DATA_FILENAME
        temp_path = self.raw_dir / f"{self.DATA_FILENAME}.tmp"

        def _fetch_and_download():
            # 1. Get Token
            self.logger.info("Fetching authentication token...")
            token_resp = curl_requests.get(
                self.GET_TOKEN_URL, 
                timeout=30,
                impersonate="chrome110"
            )
            token_resp.raise_for_status()
            token = token_resp.json().get("token", {}).get("token")
            
            if not token:
                raise Exception("Token retrieval failed.")

            # 2. Download File
            self.logger.info("Downloading Excel export...")
            headers = {
                "Authorization": f"EmbedToken {token}",
                "Content-Type": "application/json",
            }

            response = curl_requests.post(
                self.EXPORT_URL,
                data=self.REQUEST_PAYLOAD,
                headers=headers,
                timeout=120,
                impersonate="chrome110"
            )
            response.raise_for_status()

            with open(temp_path, 'wb') as f:
                f.write(response.content)

        try:
            # Run extraction in thread
            await asyncio.to_thread(_fetch_and_download)

            # --- Custom Hashing Logic ---
            # We override the base class hashing because Excel metadata changes daily
            self.logger.info("Calculating content-based hash (ignoring metadata)...")
            new_hash = await asyncio.to_thread(self._calculate_data_hash, temp_path)
            
            metadata = self._load_metadata()
            if metadata.get("content_hash") == new_hash:
                self.logger.info(f"Data Hash Match ({new_hash[:8]}). Content unchanged.")
                if temp_path.exists(): temp_path.unlink()
                return None
            
            # Update Metadata manually
            metadata.update({
                "content_hash": new_hash,
                "last_updated": datetime.now().isoformat(),
                "last_file_processed": str(local_path.name)
            })
            self._save_metadata(metadata)

            # Commit file
            if local_path.exists(): local_path.unlink()
            temp_path.rename(local_path)

            return local_path

        except Exception as e:
            if temp_path.exists(): temp_path.unlink()
            self.logger.error(f"Download process failed: {e}")
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform Excel -> Golden Profile.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            return

        self.logger.info(f"Processing file: {target_file}")
        mapper = ProfileMapper()

        try:
            df = pd.read_excel(target_file)
            # Normalize Headers
            df.columns = [str(col).strip() for col in df.columns]
            
            # Filter for Individuals
            if "Entity" in df.columns:
                df = df[df["Entity"].astype(str).str.strip().str.lower() == "individual"]
            else:
                self.logger.warning("Column 'Entity' not found. Skipping filtering.")

            self.logger.info(f"Found {len(df)} individual records.")

            for _, row in df.iterrows():
                try:
                    full_name = str(row.get("Title", "")).strip()
                    if not full_name or full_name.lower() == "nan": continue

                    nationality = str(row.get("Nationality", "")).strip()
                    country = str(row.get("Country", "")).strip()
                    
                    if nationality.lower() == "nan": nationality = None
                    if country.lower() == "nan": country = None

                    date_start = self._parse_iadb_date(row.get("From"))
                    date_end = self._parse_iadb_date(row.get("To"))
                    
                    grounds = str(row.get("Grounds", "")).strip()
                    sanction_source = str(row.get("Source", "")).strip()
                    other_name = str(row.get("Other Name", "")).strip()

                    aliases = []
                    if other_name and other_name.lower() != "nan":
                        aliases.append(other_name)

                    # Status
                    is_active = True
                    if date_end:
                        try:
                            if datetime.strptime(date_end, "%Y-%m-%d") < datetime.now():
                                is_active = False
                        except: pass
                    
                    # ID
                    unique_key = f"{full_name}_{nationality}_{date_start}"
                    record_id = self.generate_uuid(unique_key)

                    mapped_record = {
                        "profile": {
                            "id": record_id, 
                            "full_name": full_name, 
                            "entity_type": "INDIVIDUAL",
                            "gender": None, 
                            "date_of_birth": None, 
                            "nationality": nationality,
                            "is_active": is_active, 
                            "aliases": aliases, 
                            "images": [],
                            "addresses": [country] if country else []
                        },
                        "risk_events": [
                            {
                                "type": "Sanction", 
                                "source_list": self.name,
                                "authority": "Inter-American Development Bank (IADB)",
                                "reason": f"{grounds} | Source: {sanction_source}".strip(" |"),
                                "date_listed": date_start, 
                                "is_current": is_active, 
                                "risk_level": "High",
                            }
                        ],
                        "evidence": [
                            {
                                "url": "https://www.iadb.org/en/integrity/sanctioned-firms-and-individuals",
                                "scraped_at": datetime.now().isoformat(),
                                "raw_text_snippet": f"End Date: {date_end}" if date_end else "Sanction: Ongoing"
                            }
                        ]
                    }
                    
                    result = mapper.map_single_profile(mapped_record)
                    yield result

                except Exception: continue

        except Exception as e:
            self.logger.error(f"Failed to process Excel file: {e}")
            raise e

    # ---------------------------------------------------------
    # Helper Methods
    # ---------------------------------------------------------

    def _parse_iadb_date(self, date_str: Any) -> Optional[str]:
        """Parses dates from Pandas timestamp or strings."""
        if pd.isna(date_str): return None
        s = str(date_str).strip()
        if s.lower() == "ongoing": return None
        
        try:
            return pd.to_datetime(s).strftime("%Y-%m-%d")
        except:
            return None

    def _calculate_data_hash(self, file_path: Path) -> str:
        """
        Calculates a hash based on CONTENT ONLY.
        Reads Excel -> Pandas -> JSON -> Hash.
        """
        try:
            df = pd.read_excel(file_path)
            # orient='split' ensures consistent ordering of data/index/columns
            content_str = df.to_json(orient='split', date_format='iso', double_precision=10)
            return hashlib.sha256(content_str.encode('utf-8')).hexdigest()
        except Exception as e:
            self.logger.warning(f"Data hashing failed, falling back to file hash: {e}")
            return self._calculate_file_hash(file_path)

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = IADBSanctionsScraper()
    asyncio.run(scraper.run(force=True))