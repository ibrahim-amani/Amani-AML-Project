"""
src/sanction_parser/scrapers/sources/indonesia_kpk.py

Scrapes Indonesia's Corruption Eradication Commission (KPK) "Wanted Persons" list.
Source: https://kpk.go.id/id/ruang-informasi/daftar-pencarian-orang
"""

import re
import json
import asyncio
import logging
import requests
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Iterator
from urllib.parse import urljoin

# Third-party
from bs4 import BeautifulSoup

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class KpkWantedPersonsScraper(BaseSanctionScraper):
    """
    Scraper for Indonesia (KPK) – Wanted Persons.
    
    Source URL: https://kpk.go.id/id/ruang-informasi/daftar-pencarian-orang
    Format: Web Scraping (Requests + BS4)
    Type: Wanted (High Risk)
    """
    name = "Indonesia (KPK) – Wanted Persons"
    country = "Indonesia"
    
    SITE_BASE = "https://kpk.go.id"
    LIST_URL = SITE_BASE + "/id/ruang-informasi/daftar-pencarian-orang"
    DATA_FILENAME = "indonesia_kpk.json"

    HEADERS = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    }
    DEFAULT_TIMEOUT_SEC = 60

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Scrape list and details synchronously (in thread).
        """
        self.logger.info(f"Starting extraction from: {self.LIST_URL}")
        local_path = self.raw_dir / self.DATA_FILENAME

        try:
            # Run sync scraping logic in thread
            raw_data = await asyncio.to_thread(self._scrape_sync)
            
            if not raw_data or not raw_data.get("persons"):
                self.logger.warning("No persons scraped.")
                return None

            # Save Raw Data
            with open(local_path, "w", encoding="utf-8") as f:
                json.dump(raw_data, f, indent=2, ensure_ascii=False)
            
            return local_path

        except Exception as e:
            self.logger.error(f"Extraction failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform raw JSON to Golden Profile.
        """
        if not raw_path.exists():
            return

        self.logger.info(f"Transforming file: {raw_path}")
        mapper = ProfileMapper()

        try:
            with open(raw_path, "r", encoding="utf-8") as f:
                raw_data = json.load(f)

            for p in raw_data.get("persons", []):
                try:
                    # 1. Name & Aliases
                    raw_name = p.get("name") or p.get("profile_name") or "Unknown"
                    full_name = raw_name
                    aliases = []
                    
                    if " atau " in raw_name.lower():
                        parts = re.split(r"\s+atau\s+", raw_name, flags=re.IGNORECASE)
                        full_name = parts[0].strip()
                        aliases = [alias.strip() for alias in parts[1:] if alias.strip()]

                    # 2. Date & Place of Birth
                    place_and_dob = p.get("place_and_dob", "")
                    dob = self._parse_indo_date(place_and_dob)
                    pob = None
                    if place_and_dob and "," in place_and_dob:
                        pob = place_and_dob.split(",")[0].strip()

                    # 3. ID Generation
                    person_id = self.generate_uuid(p.get("slug") or full_name)

                    # 4. Gender Normalization
                    gender = p.get("gender")
                    if gender:
                        if "Laki" in gender or "Male" in gender: gender = "Male"
                        elif "Perempuan" in gender or "Female" in gender: gender = "Female"
                        else: gender = None

                    # 5. Status
                    is_active = True
                    if p.get("list_status") == "arrested":
                        is_active = False

                    # 6. Build Record
                    mapped_record = {
                        "profile": {
                            "id": person_id,
                            "full_name": full_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": gender,
                            "date_of_birth": dob,
                            "nationality": p.get("nationality") or "Indonesia", 
                            "is_active": is_active,
                            "aliases": aliases,
                            "images": [p.get("image_url")] if p.get("image_url") else [],
                            "addresses": []
                        },
                        "risk_events": [
                            {
                                "type": "Wanted",
                                "source_list": self.name,
                                "authority": "Komisi Pemberantasan Korupsi (KPK)",
                                "reason": p.get("alleged_crimes", "Corruption Investigation"),
                                "legal_basis": p.get("legal_articles"),
                                "date_listed": self._parse_indo_date(p.get("wanted_since_date_raw")),
                                "is_current": is_active,
                                "risk_level": "High"
                            }
                        ],
                        "evidence": [
                            {
                                "url": p.get("profile_url"),
                                "scraped_at": raw_data["source"]["generated_at"],
                                "raw_text_snippet": f"Crimes: {p.get('alleged_crimes', '')[:100]}.. | POB: {pob}"
                            }
                        ]
                    }

                    # Normalize & Yield
                    result = mapper.map_single_profile(mapped_record)

                    yield result

                except Exception as inner_e:
                    self.logger.warning(f"Error transforming person: {inner_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process JSON file: {e}")
            raise e

    # ---------------------------------------------------------
    # Internal Helpers (Scraping Logic)
    # ---------------------------------------------------------

    def _scrape_sync(self) -> Dict[str, Any]:
        """Synchronous scraping orchestration."""
        session = requests.Session()
        self.logger.info("Fetching list page...")
        
        try:
            list_html = self._fetch_html(self.LIST_URL, session)
        except Exception as e:
            self.logger.error(f"Failed to fetch list: {e}")
            return {"persons": []}

        index_persons = self._parse_list_page(list_html)
        self.logger.info(f"Found {len(index_persons)} persons. Scraping details...")

        persons_full = []
        for i, (slug, p) in enumerate(index_persons.items(), start=1):
            profile_url = p["profile_url"]
            if i % 5 == 0:
                self.logger.info(f"Scraping profile {i}/{len(index_persons)}: {p['name']}")
            
            try:
                prof_html = self._fetch_html(profile_url, session)
                prof_data = self._parse_profile_page(prof_html, profile_url)
            except Exception as e:
                self.logger.warning(f"Failed profile {profile_url}: {e}")
                prof_data = {}

            persons_full.append({**p, **prof_data})

        return {
            "source": {
                "name": self.name,
                "url": self.LIST_URL,
                "generated_at": datetime.now(timezone.utc).isoformat(),
                "total_persons": len(persons_full),
            },
            "persons": persons_full,
        }

    def _fetch_html(self, url: str, session: requests.Session) -> str:
        resp = session.get(url, headers=self.HEADERS, timeout=self.DEFAULT_TIMEOUT_SEC)
        resp.raise_for_status()
        return resp.text

    def _parse_list_page(self, html: str) -> Dict[str, Dict[str, Any]]:
        soup = BeautifulSoup(html, "lxml")
        persons = {}

        blocks = soup.select("div.block-2x")
        for block in blocks:
            title_el = block.select_one("span.h3")
            title_text = self._clean_text(title_el.get_text()) if title_el else ""

            list_status = "unknown"
            if "Orang Dalam Pencarian" in title_text: list_status = "wanted"
            if "Telah Tertangkap" in title_text: list_status = "arrested"

            for card in block.select(".card-pencarian"):
                img_el = card.select_one(".card-pencarian-img img")
                img_url = img_el["src"] if img_el and img_el.has_attr("src") else ""

                link_el = card.select_one(".card-pencarian-img a") or card.select_one(".card-pencarian-content a")
                href = link_el["href"] if link_el and link_el.has_attr("href") else ""
                profile_url = urljoin(self.SITE_BASE, href) if href else ""

                if not profile_url: continue

                name_el = card.select_one(".card-pencarian-content .text-title b") or card.select_one(".card-pencarian-content b")
                name = self._clean_text(name_el.get_text()) if name_el else ""

                wanted_since_date_raw = ""
                for s in card.select(".card-pencarian-content span.text-small"):
                    date_span = s.select_one("span.text-primary")
                    if date_span:
                        wanted_since_date_raw = self._clean_text(date_span.get_text())

                slug = self._normalize_slug(profile_url)
                
                person = persons.get(slug, {})
                person.update({
                    "slug": slug,
                    "name": name,
                    "profile_url": profile_url,
                    "image_url": img_url,
                    "wanted_since_date_raw": wanted_since_date_raw,
                    "list_status": list_status 
                })
                persons[slug] = person
        return persons

    def _parse_profile_page(self, html: str, profile_url: str) -> Dict[str, Any]:
        soup = BeautifulSoup(html, "lxml")
        name_el = soup.select_one("span.h1 b") or soup.select_one("span.h1")
        name = self._clean_text(name_el.get_text()) if name_el else ""

        raw_fields = {}
        for row in soup.select("div.block div.bzg.block-half"):
            label_el = row.select_one("div[data-col^='s5']")
            value_el = row.select_one("div[data-col^='s7']")
            if label_el and value_el:
                label = self._clean_text(label_el.get_text())
                value = self._clean_text(value_el.get_text())
                if label: raw_fields[label] = value

        mapped = {
            "gender": raw_fields.get("Jenis Kelamin"),
            "place_and_dob": raw_fields.get("Tempat, Tanggal Lahir"),
            "nationality": raw_fields.get("Kewarganegaraan"),
            "case_status_text": raw_fields.get("Status"),
        }
        
        alleged_crimes = self._extract_section_paragraph(soup, ["Dugaan Tindak Pidana"])
        legal_articles = self._extract_section_paragraph(soup, ["Penerapan Pasal"])

        return {
            "profile_name": name,
            **mapped,
            "alleged_crimes": alleged_crimes,
            "legal_articles": legal_articles,
        }

    # --- Utility Helpers ---

    def _clean_text(self, text: Optional[str]) -> str:
        if not text: return ""
        text = text.replace("\xa0", " ")
        text = re.sub(r"\s+", " ", text)
        return text.strip()

    def _normalize_slug(self, url: str) -> str:
        return url.rstrip("/").split("/")[-1]

    def _extract_section_paragraph(self, soup: BeautifulSoup, header_keywords: List[str]) -> str:
        for span in soup.select("span.d-block.h5.mb-8, span.d-block.h5"):
            header = self._clean_text(span.get_text())
            if any(kw.lower() in header.lower() for kw in header_keywords):
                p = span.find_next("p")
                if p: return self._clean_text(p.get_text())
        return ""

    def _parse_indo_date(self, date_str: Optional[str]) -> Optional[str]:
        if not date_str: return None
        month_map = {
            "januari": "01", "jan": "01", "februari": "02", "feb": "02",
            "maret": "03", "mar": "03", "april": "04", "apr": "04",
            "mei": "05", "juni": "06", "jun": "06", "juli": "07", "jul": "07",
            "agustus": "08", "agu": "08", "aug": "08", "september": "09", "sep": "09",
            "oktober": "10", "okt": "10", "november": "11", "nov": "11",
            "desember": "12", "des": "12"
        }
        parts = self._clean_text(date_str).lower().replace(",", "").split()
        day, month, year = None, None, None

        if len(parts) >= 3:
            for p in parts:
                if p.isdigit() and len(p) == 4: year = p; break
            for p in parts:
                if p in month_map: month = month_map[p]; break
            for p in parts:
                if p.isdigit() and 1 <= len(p) <= 2: day = p.zfill(2); break
            
            if year and month and day: return f"{year}-{month}-{day}"
        return None

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = KpkWantedPersonsScraper()
    asyncio.run(scraper.run(force=True))