"""
src/sanction_parser/scrapers/sources/interpol_yellow_notices.py

Scrapes INTERPOL Yellow Notices via API.
Source: https://ws-public.interpol.int/notices/v1/yellow
"""

import json
import time
import uuid
import random
import asyncio
import logging
from dataclasses import dataclass
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple, Iterable, Iterator

# Third-party
from curl_cffi import requests

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

@dataclass(frozen=True)
class Query:
    nationality: str
    sex_id: Optional[str] = None
    age_min: Optional[int] = None
    age_max: Optional[int] = None

def query_key(q: Query) -> str:
    return f"nat={q.nationality}|sex={q.sex_id}|age={q.age_min}-{q.age_max}"

def default_age_buckets() -> List[Tuple[int, int]]:
    return [
        (0, 10), (11, 20), (21, 30), (31, 40), (41, 50),
        (51, 60), (61, 70), (71, 120),
    ]

class InterpolYellowNoticesScraper(BaseSanctionScraper):
    """
    Scraper for INTERPOL Yellow Notices (Missing Persons).
    
    Source URL: https://ws-public.interpol.int/notices/v1/yellow
    Format: JSON API (Query Splitting required)
    Type: Missing Person (High Risk / Alert)
    """
    name = "INTERPOL – Yellow Notices"
    country = "Global"
    
    API_BASE_URL = "https://ws-public.interpol.int/notices/v1/yellow"
    DATA_FILENAME = "interpol_yellow_notices.json"
    PER_PAGE = 160
    
    # Session settings
    IMPERSONATE = "chrome120"
    RETRIES = 4
    TIMEOUT_S = 30
    MIN_DELAY_S = 0.20
    MAX_DELAY_S = 0.55
    BACKOFF_ON_403_S = 2.0

    HEADERS = {
        "Accept": "application/json, text/javascript, */*; q=0.01",
        "Origin": "https://www.interpol.int",
        "Referer": "https://www.interpol.int/",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    }

    # Truncated country list
    COUNTRIES = (
        "DZ","AO","BJ","BW","BF","BI","CV","CM","CF","TD","KM","CG","CD","CI","DJ",
        "EG","GQ","ER","SZ","ET","GA","GM","GH","GN","GW","KE","LS","LR","LY","MG",
        "MW","ML","MR","MU","MA","MZ","NA","NE","NG","RW","ST","SN","SC","SL","SO",
        "ZA","SS","SD","TZ","TG","TN","UG","ZM","ZW","AE","BH","IQ","IR","IL","JO",
        "KW","LB","OM","PS","QA","SA","SY","TR","YE","AL","AD","AT","BY","BE","BA",
        "BG","HR","CY","CZ","DK","EE","FI","FR","DE","GR","HU","IS","IE","IT","LV",
        "LI","LT","LU","MT","MD","MC","ME","NL","MK","NO","PL","PT","RO","SM",
        "RS","SK","SI","ES","SE","CH","UA","GB","VA","AF","AM","AZ","BD","BT","BN",
        "KH","CN","GE","IN","ID","JP","KZ","KP","KR","KG","LA","MY","MV","MN","MM",
        "NP","PK","PH","SG","LK","TJ","TH","TL","TM","UZ","VN","AG","AR","BS","BB",
        "BZ","BO","BR","CA","CL","CO","CR","CU","DM","DO","EC","SV","GD","GT","GY",
        "HT","HN","JM","MX","NI","PA","PY","PE","KN","LC","VC","SR","TT","US","UY",
        "VE","AU","FJ","KI","MH","FM","NR","NZ","PW","PG","WS","SB","TO","TV","VU"
    )

    async def extract(self) -> Optional[Path]:
        """Step 1: Scrape API using query splitting logic."""
        self.logger.info(f"Starting extraction from: {self.API_BASE_URL}")
        local_path = self.raw_dir / self.DATA_FILENAME

        try:
            raw_data = await asyncio.to_thread(self._scrape_sync)
            
            if not raw_data or not raw_data.get("entries"):
                self.logger.warning("No notices scraped.")
                return None

            with open(local_path, "w", encoding="utf-8") as f:
                json.dump(raw_data, f, indent=2, ensure_ascii=False)
            
            return local_path

        except Exception as e:
            self.logger.error(f"Extraction failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """Step 2: Transform raw JSON to Golden Profile."""
        if not raw_path.exists():
            return

        self.logger.info(f"Transforming file: {raw_path}")
        mapper = ProfileMapper()

        try:
            with open(raw_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            for details in data.get("entries", []):
                try:
                    entity_id = str(details.get("entity_id") or "").strip()
                    if not entity_id: continue

                    # 1. ID Generation
                    ns = uuid.uuid5(uuid.NAMESPACE_DNS, "interpol.int")
                    person_id = str(uuid.uuid5(ns, f"yellow:{entity_id}"))

                    # 2. Profile
                    forename = (details.get("forename") or "").strip()
                    family = (details.get("name") or "").strip()
                    full_name = f"{forename} {family}".strip() or "Unknown"

                    images = []
                    thumb = (details.get("_links") or {}).get("thumbnail", {}).get("href")
                    if thumb: images.append(thumb)

                    nationality = self._to_country_string(details.get("nationalities"))

                    # 3. Risk Info
                    pob = details.get("place_of_birth")
                    reason = "Yellow Notice (Missing Person)"
                    
                    # 4. Evidence
                    snippet_parts = [f"ID: {entity_id}"]
                    if pob: snippet_parts.append(f"POB: {pob}")
                    marks = details.get("distinguishing_marks")
                    if marks: snippet_parts.append(f"Marks: {marks}")

                    mapped_record = {
                        "profile": {
                            "id": person_id,
                            "full_name": full_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": details.get("sex_id"),
                            "date_of_birth": details.get("date_of_birth"),
                            "nationality": nationality,
                            "is_active": True,
                            "aliases": [],
                            "images": images,
                            "addresses": []
                        },
                        "risk_events": [
                            {
                                "type": "Missing Person", # Specific for Yellow
                                "source_list": self.name,
                                "authority": "INTERPOL",
                                "reason": reason,
                                "date_listed": details.get("date_of_publication"),
                                "is_current": True,
                                "risk_level": "High" # Missing persons are critical alerts
                            }
                        ],
                        "evidence": [
                            {
                                "url": details.get("_source_url"),
                                "scraped_at": details.get("_scraped_at"),
                                "raw_text_snippet": " | ".join(snippet_parts)
                            }
                        ]
                    }

                    result = mapper.map_single_profile(mapped_record)
                    yield result

                except Exception as inner_e:
                    self.logger.warning(f"Error transforming notice: {inner_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process JSON file: {e}")
            raise e

    # ---------------------------------------------------------
    # Scraping Logic (Sync in Thread)
    # ---------------------------------------------------------

    def _scrape_sync(self) -> Dict[str, Any]:
        """Runs the scraping loop synchronously."""
        results = []
        seen_ids = set()

        with requests.Session(impersonate=self.IMPERSONATE) as session:
            total_countries = len(self.COUNTRIES)
            for idx, iso2 in enumerate(self.COUNTRIES, 1):
                self.logger.info(f"[{idx}/{total_countries}] Search nationality={iso2}")
                base_q = Query(nationality=iso2)
                qs = self._split_query(session, base_q)
                
                if not qs:
                    time.sleep(1)
                    continue

                for q in qs:
                    total = self._get_total_for_query(session, q) or 0
                    if total == 0: continue

                    for notice in self._iterate_list_pages(session, q):
                        entity_id = notice.get("entity_id")
                        if not entity_id or entity_id in seen_ids: continue
                        
                        details_url = (((notice.get("_links") or {}).get("self") or {}).get("href") or "").strip()
                        if not details_url: continue

                        time.sleep(random.uniform(self.MIN_DELAY_S, self.MAX_DELAY_S))
                        
                        details = self._request_json(session, details_url)
                        if not details: continue
                        
                        details["_source_url"] = details_url
                        details["_scraped_at"] = datetime.now(timezone.utc).isoformat()

                        results.append(details)
                        seen_ids.add(entity_id)

        return {
            "source_info": {"name": self.name, "url": self.API_BASE_URL},
            "entries": results
        }

    # --- API Helpers ---

    def _request_json(self, session: requests.Session, url: str, params: Optional[Dict] = None) -> Optional[Dict]:
        for attempt in range(1, self.RETRIES + 1):
            try:
                resp = session.get(url, params=params, headers=self.HEADERS, timeout=self.TIMEOUT_S)
                if resp.status_code == 200: return resp.json()
                if resp.status_code == 404: return None
                
                if resp.status_code == 403:
                    time.sleep(self.BACKOFF_ON_403_S * attempt)
                    continue
                
                time.sleep(0.5 * attempt)
            except Exception:
                time.sleep(0.5 * attempt)
        return None

    def _search(self, session: requests.Session, q: Query, page: int) -> Optional[Dict]:
        params = {
            "nationality": q.nationality,
            "resultPerPage": self.PER_PAGE,
            "page": page,
        }
        if q.sex_id: params["sexId"] = q.sex_id
        if q.age_min is not None: params["ageMin"] = q.age_min
        if q.age_max is not None: params["ageMax"] = q.age_max
        return self._request_json(session, self.API_BASE_URL, params=params)

    def _get_total_for_query(self, session: requests.Session, q: Query) -> Optional[int]:
        data = self._search(session, q, page=1)
        if not data: return None
        return int(data.get("total") or 0)

    def _split_query(self, session: requests.Session, q: Query) -> List[Query]:
        total = self._get_total_for_query(session, q)
        if total is None: return []
        if total <= self.PER_PAGE: return [q]

        # 1. Split by Sex
        if q.sex_id is None:
            children = [
                Query(nationality=q.nationality, sex_id="M", age_min=q.age_min, age_max=q.age_max),
                Query(nationality=q.nationality, sex_id="F", age_min=q.age_min, age_max=q.age_max),
                Query(nationality=q.nationality, sex_id="U", age_min=q.age_min, age_max=q.age_max),
            ]
            child_totals = [self._get_total_for_query(session, c) for c in children]
            
            if all((t or 0) == total for t in child_totals if t is not None): return [q]

            out = []
            for c, t in zip(children, child_totals):
                if t is None or t == 0: continue
                if t <= self.PER_PAGE: out.append(c)
                else: out.extend(self._split_query(session, c))
            return out

        # 2. Split by Age
        if q.age_min is None and q.age_max is None:
            buckets = default_age_buckets()
            children = [Query(nationality=q.nationality, sex_id=q.sex_id, age_min=a, age_max=b) for a, b in buckets]
            child_totals = [self._get_total_for_query(session, c) for c in children]
            
            if all((t or 0) == total for t in child_totals if t is not None): return [q]

            out = []
            for c, t in zip(children, child_totals):
                if t is None or t == 0: continue
                out.append(c) 
            return out

        return [q]

    def _iterate_list_pages(self, session: requests.Session, q: Query) -> Iterable[Dict]:
        page = 1
        while True:
            data = self._search(session, q, page)
            if not data or "_embedded" not in data: break
            
            notices = data["_embedded"].get("notices", [])
            if not notices: break
            
            for n in notices: yield n
            
            if len(notices) < self.PER_PAGE: break
            page += 1
            time.sleep(random.uniform(0.25, 0.5))

    def _to_country_string(self, nats: Any) -> Optional[str]:
        if isinstance(nats, list) and nats:
            return str(nats[0]).strip() or None
        return str(nats).strip() if nats else None

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = InterpolYellowNoticesScraper()
    asyncio.run(scraper.run(force=True))