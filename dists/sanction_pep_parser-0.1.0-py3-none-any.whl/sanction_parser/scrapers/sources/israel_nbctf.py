"""
src/sanction_parser/scrapers/sources/israel_nbctf.py

Scraper for Israel National Bureau for Counter Terror Financing (NBCTF).
Source: https://nbctf.mod.gov.il/en/Minister%20Sanctions/Designation/Pages/downloads.aspx
"""

import logging
import asyncio
import pandas as pd
import os
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional

# Third-party
from playwright.async_api import async_playwright

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class IsraelNBCTFScraper(BaseSanctionScraper):
    """
    Scraper for Israel NBCTF (Counter Terror Financing) Designations.
    
    Source URL: https://nbctf.mod.gov.il/.../downloads.aspx
    Format: CSV (Dynamic link)
    Strategy: Dynamic header detection to handle file metadata rows.
    """
    name = "Israel NBCTF - Designation List"
    country = "Israel"
    
    BASE_URL = "https://nbctf.mod.gov.il/en/Minister%20Sanctions/Designation/Pages/downloads.aspx"
    DATA_FILENAME = "israel_nbctf_individuals.csv"

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Download the CSV file via Playwright.
        Scans for links ending in .csv and prefers those with 'ind' in the name.
        """
        self.logger.info(f"Starting Playwright session for: {self.BASE_URL}")
        
        local_path = self.raw_dir / self.DATA_FILENAME

        async with async_playwright() as p:
            # Launch headless for production
            browser = await p.chromium.launch(headless=True, args=["--start-maximized"])
            context = await browser.new_context(accept_downloads=True, viewport={"width": 1920, "height": 1080})
            page = await context.new_page()

            try:
                self.logger.info("Navigating to page...")
                await page.goto(self.BASE_URL, timeout=90000, wait_until="domcontentloaded")

                # Wait for CSV links
                try:
                    await page.wait_for_selector("a[href$='.csv']", state="attached", timeout=30000)
                except Exception:
                    self.logger.warning("Timeout waiting for .csv selector. Attempting text search...")

                # Find all CSV links
                csv_locators = page.locator("a[href$='.csv']")
                count = await csv_locators.count()
                
                # Fallback to text search if regex fails
                if count == 0:
                    csv_locators = page.locator("a:has-text('Press Here')")
                    count = await csv_locators.count()

                if count == 0:
                    self.logger.error("No download links found on the page.")
                    return None

                self.logger.info(f"Found {count} CSV links. Looking for 'Individual' list...")
                
                target_link = None
                
                # 1. Try to find a link that looks like the Individuals list
                for i in range(count):
                    link = csv_locators.nth(i)
                    href = await link.get_attribute("href")
                    # If href or text implies individual
                    if href and ("ind" in href.lower() or "person" in href.lower()):
                        target_link = link
                        break
                
                # 2. Fallback: Take the first one if no specific individual list found
                if not target_link:
                    target_link = csv_locators.first

                # Download
                self.logger.info("Initiating download...")
                async with page.expect_download(timeout=60000) as download_info:
                    await target_link.click(force=True)

                download = await download_info.value
                await download.save_as(local_path)
                
                self.logger.info(f"Downloaded to: {local_path}")
                return local_path

            except Exception as e:
                self.logger.error(f"Playwright error: {e}")
                if local_path.exists():
                    local_path.unlink()
                return None
            finally:
                await browser.close()

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform CSV to Golden Profile.
        Handles dynamic header location and Hebrew encoding.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            csv_files = list(raw_path.parent.glob("*.csv"))
            if not csv_files:
                self.logger.warning("No CSV files found.")
                return
            target_file = csv_files[0]

        self.logger.info(f"Processing file: {target_file}")
        mapper = ProfileMapper()

        try:
            # 1. Read Raw (Handle Encoding)
            try:
                df_raw = pd.read_csv(target_file, header=None, encoding='utf-8', on_bad_lines='skip')
            except UnicodeDecodeError:
                df_raw = pd.read_csv(target_file, header=None, encoding='cp1255', on_bad_lines='skip')

            # 2. Detect Header Row Dynamically
            header_idx = -1
            for i, row in df_raw.head(20).iterrows():
                row_str = str(row.values).lower()
                if "name of individual" in row_str and "english" in row_str:
                    header_idx = i
                    break
            
            if header_idx == -1:
                self.logger.warning("Could not detect valid header row (looking for 'Name of Individual').")
                return

            # Re-frame DataFrame using detected header
            df_raw.columns = df_raw.iloc[header_idx]
            df = df_raw[header_idx + 1:].reset_index(drop=True)
            df.columns = [str(col).strip() for col in df.columns]

            # 3. Iterate Rows
            for _, row in df.iterrows():
                try:
                    name_eng = str(row.get("Name of Individual - English", "")).strip()
                    
                    # Fallback to Hebrew name if English missing
                    if not name_eng or name_eng.lower() in ["nan", "-", "none", ""]:
                        name_heb = str(row.get("Name of Individual - Hebrew", "")).strip()
                        if not name_heb or name_heb.lower() in ["nan", "-"]:
                            continue
                        name_eng = name_heb 

                    # Skip metadata footer rows
                    if "file was update" in name_eng.lower():
                        continue

                    # Extract basic fields
                    nationality = str(row.get("Nationality / Residency", "")).strip()
                    if nationality in ["-", "nan", ""]: nationality = None

                    raw_id = str(row.get("Individual ID", "")).strip()
                    if raw_id in ["-", "nan", ""]: raw_id = None

                    # Dates
                    dob = self._parse_nbctf_date(row.get("D.O.B (DD/MM/YYYY)"))
                    date_listed = self._parse_nbctf_date(row.get("Date of Designation In Israel (DD/MM/YYYY)"))

                    # Aliases (Hebrew, Arabic, "A.k.a")
                    aliases = []
                    name_heb = str(row.get("Name of Individual - Hebrew", "")).strip()
                    if name_heb and name_heb not in ["-", "nan"]: aliases.append(name_heb)
                    
                    name_ara = str(row.get("Name of Individual - Arabic", "")).strip()
                    if name_ara and name_ara not in ["-", "nan"]: aliases.append(name_ara)

                    add_info = str(row.get("Additional information", "")).strip()
                    if add_info and add_info not in ["-", "nan"]:
                        # Extract "A.k.a: ..." lines
                        if "A.k.a:" in add_info:
                            for line in add_info.split('\n'):
                                if "A.k.a:" in line:
                                    clean = line.replace("A.k.a:", "").replace("•", "").strip()
                                    if clean: aliases.append(clean)

                    # Reason
                    designation_reason = str(row.get("Designation", "")).strip()
                    foreign_desig = str(row.get("Foreign Designation", "")).strip()
                    
                    reason_parts = []
                    if designation_reason and designation_reason not in ["-", "nan"]: 
                        reason_parts.append(designation_reason)
                    if foreign_desig and foreign_desig not in ["-", "nan"]: 
                        reason_parts.append(f"Foreign Designation: {foreign_desig}")
                    
                    full_reason = " | ".join(reason_parts)

                    # Generate ID
                    unique_key = f"{name_eng}_{date_listed}_{raw_id}" 
                    record_id = self.generate_uuid(unique_key)

                    # Build Record
                    mapped_record = {
                        "profile": {
                            "id": record_id,
                            "full_name": name_eng,
                            "entity_type": "INDIVIDUAL",
                            "gender": None,
                            "date_of_birth": dob,
                            "nationality": nationality,
                            "is_active": True,
                            "aliases": list(set(aliases)),
                            "images": [],
                            "addresses": []
                        },
                        "risk_events": [
                            {
                                "type": "Sanction",
                                "source_list": self.name,
                                "authority": "Israel NBCTF",
                                "reason": full_reason,
                                "date_listed": date_listed,
                                "is_current": True,
                                "risk_level": "High",
                            }
                        ],
                        "evidence": [
                            {
                                "url": self.BASE_URL,
                                "scraped_at": datetime.now().isoformat(),
                                "raw_text_snippet": f"ID: {raw_id} | Details: {add_info[:200] if add_info else ''}"
                            }
                        ]
                    }

                    # Yield result
                    result = mapper.map_single_profile(mapped_record)
                    yield result

                except Exception as row_e:
                    self.logger.warning(f"Error parsing row: {row_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process CSV file: {e}")
            raise e

    # ---------------------------------------------------------
    # Helpers
    # ---------------------------------------------------------
    def _parse_nbctf_date(self, d: Any) -> Optional[str]:
        """Parses dates like '25/12/2023' or '2023-12-25'."""
        if pd.isna(d) or str(d).strip() in ["-", "nan", ""]:
            return None
        
        d_str = str(d).strip()
        formats = ["%d/%m/%Y", "%d.%m.%Y", "%Y-%m-%d"]
        
        for fmt in formats:
            try:
                return datetime.strptime(d_str, fmt).strftime("%Y-%m-%d")
            except ValueError:
                continue
        return None

if __name__ == "__main__":
    import sys
    if sys.platform == 'win32':
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

    logging.basicConfig(level=logging.INFO)
    scraper = IsraelNBCTFScraper()
    asyncio.run(scraper.run(force=True))