"""
src/sanction_parser/scrapers/sources/kyrgyzstan_fiu.py

Scraper for Kyrgyzstan FIU (Financial Intelligence Unit) Sanctions List.
Source: https://fiu.gov.kg/sked/9
"""

import logging
import asyncio
import requests
from lxml import etree
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper
from sanction_parser.scrapers.utils.web_client import extract_download_links, get_request

# Initialize logger
logger = logging.getLogger(__name__)

class KyrgyzstanFiuScraper(BaseSanctionScraper):
    """
    Scraper for Kyrgyzstan FIU Sanctions List.
    
    Source URL: https://fiu.gov.kg/sked/9
    Format: XML
    Type: Sanction (High Risk)
    """
    name = "Kyrgyzstan FIU - Sanctions List"
    country = "Kyrgyzstan"
    
    BASE_URL = "https://fiu.gov.kg/sked/9"
    TARGET_EXTS = ["xml"]
    DATA_FILENAME = "kg_fiu_sanctions.xml"

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Discover and download the XML file.
        """
        self.logger.info(f"Scanning page for XML files: {self.BASE_URL}")
        
        local_path = self.raw_dir / self.DATA_FILENAME

        # 1. Extract Links
        try:
            links = await asyncio.to_thread(extract_download_links, self.BASE_URL, exts=self.TARGET_EXTS)
        except Exception as e:
            self.logger.error(f"Link extraction failed: {e}")
            return None

        if not links:
            self.logger.warning("No XML download links found.")
            return None

        # Take first valid link
        file_url = links[0]['url']
        self.logger.info(f"Target XML URL: {file_url}")

        def _download_task():
            response = get_request(file_url, stream=True, timeout=60)
            with open(local_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

        try:
            await asyncio.to_thread(_download_task)
            if local_path.exists() and local_path.stat().st_size > 0:
                return local_path
            return None
        except Exception as e:
            self.logger.error(f"Download failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Parse XML -> Golden Profile.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            xml_files = list(raw_path.parent.glob("*.xml"))
            if not xml_files:
                self.logger.warning("No XML files found.")
                return
            target_file = xml_files[0]

        self.logger.info(f"Processing XML file: {target_file}")
        mapper = ProfileMapper()

        try:
            # Parse XML and strip namespaces for easier find() calls
            tree = etree.parse(str(target_file))
            root = self._remove_namespace(tree.getroot())

            # 1. Process Individuals
            for node in root.findall(".//KyrgyzPhysicPerson"):
                try:
                    record = self._parse_person(node)
                    if record:
                        result = mapper.map_single_profile(record)

                        yield result
                except Exception as e:
                    self.logger.warning(f"Error parsing person: {e}")

            # 2. Process Legal Entities
            for node in root.findall(".//KyrgyzLegalPerson"):
                try:
                    record = self._parse_legal(node)
                    if record:
                        result = mapper.map_single_profile(record)
                        yield result
                except Exception as e:
                    self.logger.warning(f"Error parsing entity: {e}")

        except Exception as e:
            self.logger.error(f"Failed to parse XML file: {e}")
            raise e

    # ---------------------------------------------------------
    # Helper Methods
    # ---------------------------------------------------------

    def _remove_namespace(self, element):
        """Removes XML namespaces to simplify tag searching."""
        for elem in element.iter():
            if not hasattr(elem.tag, 'find'): continue
            i = elem.tag.find('}')
            if i >= 0:
                elem.tag = elem.tag[i+1:]
        return element

    def _parse_person(self, node) -> Optional[Dict[str, Any]]:
        """Parses <KyrgyzPhysicPerson> node."""
        name = node.findtext("./Name")
        surname = node.findtext("./Surname")
        patronymic = node.findtext("./Patronomic")
        
        parts = [p.strip() for p in [surname, name, patronymic] if p and p.strip() != "-"]
        full_name = " ".join(parts)
        
        if not full_name: return None

        dob = node.findtext("./DataBirth")
        pob = node.findtext("./PlaceBirth")
        date_inclusion = node.findtext("./DateInclusion")
        reason = node.findtext("./BasicInclusion")
        program = node.findtext("./CategoryPerson")

        unique_key = f"Person_{full_name}_{dob}_{date_inclusion}"
        record_id = self.generate_uuid(unique_key)

        return {
            "profile": {
                "id": record_id,
                "full_name": full_name,
                "entity_type": "INDIVIDUAL",
                "gender": None,
                "date_of_birth": dob if dob else None,
                "nationality": "Kyrgyzstan", 
                "is_active": True,
                "aliases": [],
                "images": [],
                "addresses": [pob] if pob else []
            },
            "risk_events": [
                {
                    "type": "Sanction",
                    "source_list": self.name,
                    "authority": "State Financial Intelligence Service (Kyrgyzstan)",
                    "reason": reason,
                    "date_listed": date_inclusion,
                    "is_current": True,
                    "risk_level": "High"
                }
            ],
            "evidence": [
                {
                    "url": self.BASE_URL,
                    "scraped_at": datetime.now().isoformat(),
                    "raw_text_snippet": f"Category: {program} | Reason: {reason}"
                }
            ]
        }

    def _parse_legal(self, node) -> Optional[Dict[str, Any]]:
        """Parses <KyrgyzLegalPerson> node."""
        raw_name = node.findtext("./Name")
        if not raw_name: return None

        # Sometimes names are comma separated aliases
        names = [n.strip() for n in raw_name.split(", ") if n.strip()]
        primary_name = names[0] if names else "Unknown Entity"
        aliases = names[1:] if len(names) > 1 else []

        date_inclusion = node.findtext("./DateInclusion")
        reason = node.findtext("./BasicInclusion")
        
        unique_key = f"Legal_{primary_name}_{date_inclusion}"
        record_id = self.generate_uuid(unique_key)

        return {
            "profile": {
                "id": record_id,
                "full_name": primary_name,
                "entity_type": "FIRM",
                "gender": None,
                "date_of_birth": None,
                "nationality": "Kyrgyzstan",
                "is_active": True,
                "aliases": aliases,
                "images": []
            },
            "risk_events": [
                {
                    "type": "Sanction",
                    "source_list": self.name,
                    "authority": "State Financial Intelligence Service (Kyrgyzstan)",
                    "reason": reason,
                    "date_listed": date_inclusion,
                    "is_current": True,
                    "risk_level": "High"
                }
            ],
            "evidence": [
                {
                    "url": self.BASE_URL,
                    "scraped_at": datetime.now().isoformat(),
                    "raw_text_snippet": f"Raw Name: {raw_name}"
                }
            ]
        }

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = KyrgyzstanFiuScraper()
    asyncio.run(scraper.run(force=True))