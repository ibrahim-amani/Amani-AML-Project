"""
src/sanction_parser/scrapers/sources/lebanon_isf.py

Scraper for Lebanon Internal Security Forces (ISF) - National Terrorism Financial List.
Source: https://isf.gov.lb/national-terrorism-financial-list/
"""

import logging
import asyncio
import requests
import pandas as pd
import urllib3
import pycountry
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional
from bs4 import BeautifulSoup

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Suppress InsecureRequestWarning for ISF website
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Initialize logger
logger = logging.getLogger(__name__)

class LebanonISFTerrorismListScraper(BaseSanctionScraper):
    """
    Scraper for Lebanon ISF Terrorism List.
    
    Source URL: https://isf.gov.lb/national-terrorism-financial-list/
    Format: Excel (Dynamic Link)
    Strategy: Dynamic header detection and date parsing.
    """
    name = "Lebanon - National Terrorism Financial List"
    country = "Lebanon"
    
    BASE_URL = "https://isf.gov.lb/national-terrorism-financial-list/"
    DATA_FILENAME = "lebanon_isf_list.xls" # Default, might update based on extension

    def _get_headers(self) -> Dict[str, str]:
        return {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"
        }

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Scrape the page for the Excel link and download it.
        """
        self.logger.info(f"Scanning page: {self.BASE_URL}")
        
        # We need to find the link first
        def _find_link():
            try:
                response = requests.get(self.BASE_URL, headers=self._get_headers(), timeout=30, verify=False)
                response.raise_for_status()
                soup = BeautifulSoup(response.text, 'html.parser')

                download_link = None
                target_exts = ('.xls', '.xlsx')
                
                # Search by extension
                for a_tag in soup.find_all('a', href=True):
                    href = a_tag['href'].strip()
                    if href.lower().endswith(target_exts):
                        if href.startswith('http'):
                            download_link = href
                        else:
                            base_domain = "https://isf.gov.lb"
                            download_link = f"{base_domain}{href}" if href.startswith('/') else f"{base_domain}/{href}"
                        break
                
                # Fallback search by text
                if not download_link:
                    for a_tag in soup.find_all('a', href=True):
                        if "download" in a_tag.text.lower() or "تحميل" in a_tag.text:
                             href = a_tag['href']
                             if href.startswith('http'):
                                download_link = href
                                break
                return download_link
            except Exception as e:
                self.logger.error(f"Failed to find link: {e}")
                return None

        download_link = await asyncio.to_thread(_find_link)

        if not download_link:
            self.logger.error("No Excel file found on the page.")
            return None

        self.logger.info(f"Found file: {download_link}")

        # Update filename based on extension
        ext = download_link.split('.')[-1]
        if len(ext) > 4: ext = "xls" # Safe fallback
        
        self.DATA_FILENAME = f"lebanon_isf_list.{ext}"
        local_path = self.raw_dir / self.DATA_FILENAME

        def _download_task():
            file_response = requests.get(download_link, headers=self._get_headers(), stream=True, verify=False)
            file_response.raise_for_status()
            with open(local_path, 'wb') as f:
                for chunk in file_response.iter_content(chunk_size=8192):
                    f.write(chunk)

        try:
            await asyncio.to_thread(_download_task)
            
            if local_path.exists() and local_path.stat().st_size > 0:
                return local_path
            return None

        except Exception as e:
            self.logger.error(f"Failed to download data: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform Excel to Golden Profile.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            # Fallback
            excel_files = list(raw_path.parent.glob("*.xls*"))
            if not excel_files:
                self.logger.warning("No Excel files found.")
                return
            target_file = excel_files[0]

        self.logger.info(f"Processing file: {target_file}")
        mapper = ProfileMapper()

        try:
            # Read without header first to find the real header row
            engine = 'xlrd' if target_file.suffix == '.xls' else 'openpyxl'
            df_raw = pd.read_excel(target_file, header=None, engine=engine)
            
            header_idx = -1
            for i, row in df_raw.iterrows():
                row_str = " ".join([str(val) for val in row.values if pd.notna(val)])
                if "First Name" in row_str and "Family Name" in row_str:
                    header_idx = i
                    break
            
            if header_idx == -1:
                self.logger.error("Could not find header row containing 'First Name'.")
                return
            
            self.logger.info(f"Header found at row index: {header_idx}")

            # Re-read with correct header
            df_raw.columns = df_raw.iloc[header_idx]
            df = df_raw[header_idx + 1:].reset_index(drop=True)
            df.columns = [str(col).strip() for col in df.columns]

            for _, row in df.iterrows():
                try:
                    full_name = str(row.get("First Name and Family Name", "")).strip()
                    
                    if not full_name or full_name.lower() in ["nan", "none", ""]:
                        continue

                    # Extract fields
                    nationality = str(row.get("Nationality", "")).strip()
                    dob_raw = row.get("DOB")
                    pob = str(row.get("Place of Birth - Town and Country", "")).strip()
                    listed_on_raw = row.get("Listed on")
                    
                    father = str(row.get("Father's Name", "")).strip()
                    mother = str(row.get("Mother Name", "")).strip()
                    passport = str(row.get("Passport Details", "")).strip()
                    id_card = str(row.get("Identity Card Details", "")).strip()
                    position = str(row.get("Position", "")).strip()
                    residence = str(row.get("Place of Residence", "")).strip()
                    regime = str(row.get("Regime", "")).strip()
                    group_type = str(row.get("Group Type", "")).strip()
                    remarks = str(row.get("Remarks", "")).strip()
                    res_num = str(row.get("Security Council Resolution #", "")).strip()

                    # Dates
                    dob = self._parse_isf_date(dob_raw)
                    date_listed = self._parse_isf_date(listed_on_raw)

                    # Details
                    details_parts = []
                    if father and father != "nan": details_parts.append(f"Father: {father}")
                    if mother and mother != "nan": details_parts.append(f"Mother: {mother}")
                    if passport and passport != "nan": details_parts.append(f"Passport: {passport}")
                    if id_card and id_card != "nan": details_parts.append(f"ID: {id_card}")
                    if position and position != "nan": details_parts.append(f"Position: {position}")
                    if res_num and res_num != "nan": details_parts.append(f"UN Res: {res_num}")

                    full_details = " | ".join(details_parts)

                    # ID Generation
                    unique_key = f"{full_name}_{nationality}_{dob}"
                    record_id = self.generate_uuid(unique_key)
                    n_iso = self._country_to_iso2(nationality) if nationality != "nan" else None
                    
                    # Build Record
                    mapped_record = {
                        "profile": {
                            "id": record_id,
                            "full_name": full_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": None,
                            "date_of_birth": dob,
                            "nationality": n_iso,
                            "is_active": True,
                            "aliases": [],
                            "images": [],
                            "addresses": [residence] if residence and residence != "nan" else [],
                        },
                        "risk_events": [
                            {
                                "type": "Sanction",
                                "source_list": self.name,
                                "authority": "Lebanese Republic - Special Investigation Commission",
                                "reason": f"{regime} - {group_type}".strip(" -"),
                                "date_listed": date_listed,
                                "is_current": True,
                                "risk_level": "High",
                            }
                        ],
                        "evidence": [
                            {
                                "url": self.BASE_URL,
                                "scraped_at": datetime.now().isoformat(),
                                "raw_text_snippet": f"{full_details} | POB: {pob if pob != 'nan' else ''} | Remarks: {remarks if remarks != 'nan' else ''}"
                            }
                        ]
                    }
                    
                    result = mapper.map_single_profile(mapped_record)

                    yield result

                except Exception as row_e:
                    self.logger.warning(f"Error parsing row: {row_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process Excel file: {e}")
            raise e

    # ---------------------------------------------------------
    # Helper Methods
    # ---------------------------------------------------------

    def _parse_isf_date(self, d: Any) -> Optional[str]:
        """Parses dates from various formats found in ISF lists."""
        if pd.isna(d) or str(d).lower() in ["nan", "unknown", "none"]:
            return None
        
        if isinstance(d, datetime):
            return d.strftime("%Y-%m-%d")
        
        d_str = str(d).strip()
        formats = ["%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y", "%Y/%m/%d", "%d.%m.%Y"]
        
        for fmt in formats:
            try:
                return datetime.strptime(d_str, fmt).strftime("%Y-%m-%d")
            except ValueError:
                continue
        return None 

    def _country_to_iso2(self, country_name: Optional[str]) -> Optional[str]:
        if not country_name: return None
        name = country_name.strip()
        c = pycountry.countries.get(name=name)
        if c: return c.alpha_2
        try:
            matches = pycountry.countries.search_fuzzy(name)
            if matches: return matches[0].alpha_2
        except LookupError:
            pass
        return None

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = LebanonISFTerrorismListScraper()
    asyncio.run(scraper.run(force=True))