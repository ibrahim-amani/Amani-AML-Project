"""
src/sanction_parser/scrapers/sources/netherlands_terrorism.py

Scraper for the Netherlands National Terrorism List.
Source: https://www.government.nl/documents/reports/2016/01/15/national-terrorism-list
"""

import logging
import asyncio
import requests
import pandas as pd
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional
from bs4 import BeautifulSoup

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class NetherlandsTerrorismListScraper(BaseSanctionScraper):
    """
    Scraper for Netherlands National Terrorism List.
    
    Source URL: https://www.government.nl/documents/reports/2016/01/15/national-terrorism-list
    Format: ODS (OpenDocument Spreadsheet)
    Strategy: Dynamic link scraping and header detection.
    """
    name = "Netherlands - National Terrorism List"
    country = "Netherlands"
    
    BASE_URL = "https://www.government.nl/documents/reports/2016/01/15/national-terrorism-list"
    DATA_FILENAME = "nl_terrorism_list.ods"

    def _get_headers(self) -> Dict[str, str]:
        return {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Scrape the page for the ODS link and download it.
        """
        self.logger.info(f"Scanning page: {self.BASE_URL}")
        
        # 1. Find Download Link
        def _find_link():
            try:
                response = requests.get(self.BASE_URL, headers=self._get_headers(), timeout=30)
                response.raise_for_status()
                soup = BeautifulSoup(response.text, 'html.parser')

                download_link = None
                for a_tag in soup.find_all('a', href=True):
                    href = a_tag['href']
                    if href.lower().endswith('.ods'):
                        if href.startswith('http'):
                            download_link = href
                        else:
                            download_link = f"https://www.government.nl{href}" if href.startswith('/') else href
                        break
                return download_link
            except Exception as e:
                self.logger.error(f"Failed to find link: {e}")
                return None

        download_link = await asyncio.to_thread(_find_link)

        if not download_link:
            self.logger.error("No .ods file found on the page.")
            return None

        self.logger.info(f"Found file: {download_link}")
        
        local_path = self.raw_dir / self.DATA_FILENAME

        # 2. Download File
        def _download_task():
            file_response = requests.get(download_link, headers=self._get_headers(), stream=True)
            file_response.raise_for_status()
            with open(local_path, 'wb') as f:
                for chunk in file_response.iter_content(chunk_size=8192):
                    f.write(chunk)

        try:
            await asyncio.to_thread(_download_task)
            
            if local_path.exists() and local_path.stat().st_size > 0:
                return local_path
            return None

        except Exception as e:
            self.logger.error(f"Failed to download data: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform ODS to Golden Profile.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            # Fallback
            ods_files = list(raw_path.parent.glob("*.ods"))
            if not ods_files:
                self.logger.warning("No ODS files found.")
                return
            target_file = ods_files[0]

        self.logger.info(f"Processing file: {target_file}")
        mapper = ProfileMapper()

        try:
            # Need 'odfpy' installed for pandas to read ods
            try:
                df_raw = pd.read_excel(target_file, engine="odf", header=None)
            except Exception as e:
                self.logger.error(f"Error reading ODS file (is odfpy installed?): {e}")
                return

            # Dynamic Header Detection
            header_idx = -1
            for i, row in df_raw.iterrows():
                row_text = " ".join([str(val) for val in row.values if pd.notna(val)])
                if "Surname" in row_text and "Date of Birth" in row_text:
                    header_idx = i
                    break
            
            if header_idx == -1:
                self.logger.error("Could not find the header row containing 'Surname'.")
                return

            self.logger.info(f"Header found at row index: {header_idx}")

            # Re-frame DataFrame
            df_raw.columns = df_raw.iloc[header_idx]
            df = df_raw[header_idx + 1:].reset_index(drop=True)
            df.columns = [str(col).strip() for col in df.columns]

            for _, row in df.iterrows():
                try:
                    surname = str(row.get("Surname", "")).strip()
                    first_name = str(row.get("First name(s)", "")).strip()
                    
                    if (not surname or surname.lower() == "nan") and (not first_name or first_name.lower() == "nan"):
                        continue
                        
                    full_name = f"{first_name} {surname}".strip()
                    
                    # Extract fields
                    alias_raw = str(row.get("Alias", "")).strip()
                    place_of_birth = str(row.get("Place of Birth", "")).strip()
                    notification_link = str(row.get("Link official notification", "")).strip()
                    
                    # Handle varied column names for dates
                    dob_col = next((c for c in df.columns if "Date of Birth" in c), None)
                    decision_col = next((c for c in df.columns if "Date of ministerial decision" in c), None)
                    
                    dob_raw = row.get(dob_col) if dob_col else None
                    decision_date_raw = row.get(decision_col) if decision_col else None

                    # Parsing
                    aliases = [a.strip() for a in alias_raw.split(",")] if alias_raw and alias_raw.lower() != "nan" else []
                    dob = self._parse_dutch_date(dob_raw)
                    date_listed = self._parse_dutch_date(decision_date_raw)

                    # ID Generation
                    unique_key = f"{full_name}_{dob}_{place_of_birth}"
                    record_id = self.generate_uuid(unique_key)

                    # Build Record
                    mapped_record = {
                        "profile": {
                            "id": record_id,
                            "full_name": full_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": None,
                            "date_of_birth": dob,
                            "nationality": "NL", 
                            "is_active": True,
                            "aliases": aliases,
                            "images": [],
                            "addresses": [place_of_birth] if place_of_birth and place_of_birth != "nan" else [],
                        },
                        "risk_events": [
                            {
                                "type": "Sanction",
                                "source_list": self.name,
                                "authority": "Government of the Netherlands",
                                "reason": "Terrorism Sanctions",
                                "date_listed": date_listed,
                                "is_current": True,
                                "risk_level": "High",
                            }
                        ],
                        "evidence": [
                            {
                                "url": self.BASE_URL,
                                "scraped_at": datetime.now().isoformat(),
                                "raw_text_snippet": f"Notification: {notification_link if notification_link != 'nan' else ''}"
                            }
                        ]
                    }
                    
                    result = mapper.map_single_profile(mapped_record)

                    yield result

                except Exception as row_e:
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process ODS file: {e}")
            raise e

    # ---------------------------------------------------------
    # Helper Methods
    # ---------------------------------------------------------

    def _parse_dutch_date(self, d: Any) -> Optional[str]:
        """Parses Dutch dates like '12-05-1980'."""
        if pd.isna(d) or str(d).lower() == "nan":
            return None
        
        d_str = str(d).strip().split(" ")[0] # Remove time if present
        
        # Replace common separators
        d_str = d_str.replace("/", "-").replace("\\", "-")
        
        formats = ["%d-%m-%Y", "%Y-%m-%d", "%d/%m/%Y"]
        
        for fmt in formats:
            try:
                return datetime.strptime(d_str, fmt).strftime("%Y-%m-%d")
            except ValueError:
                continue
        return None

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = NetherlandsTerrorismListScraper()
    asyncio.run(scraper.run(force=True))