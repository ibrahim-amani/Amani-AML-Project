"""
src/sanction_parser/scrapers/sources/nigeria_nass.py

Nigeria – National Assembly (House of Representatives) members scraper.
Source: https://nass.gov.ng/mps/members
"""

import re
import json
import asyncio
import logging
import platform
import requests
import urllib3
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Iterator
from urllib.parse import urljoin

# Third-party
from bs4 import BeautifulSoup
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from crawl4ai import AsyncWebCrawler, BrowserConfig, CrawlerRunConfig, CacheMode

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

# Suppress SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class NigeriaNassHouseMembersScraper(BaseSanctionScraper):
    """
    Scraper for Nigeria National Assembly (House of Representatives).
    
    Source URL: https://nass.gov.ng/mps/members
    Format: JSON API + Web Scraping (Crawl4AI)
    Type: PEP (Medium Risk)
    """
    name = "Nigeria – NASS House of Representatives"
    country = "Nigeria"
    
    BASE_URL = "https://nass.gov.ng"
    LIST_URL = f"{BASE_URL}/mps/members"
    API_URL = f"{BASE_URL}/mps/get_legislators/?chamber=2"
    DATA_FILENAME = "nigeria_nass_house.json"

    UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    
    # Tuning
    PROFILE_CONCURRENCY = 6

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Fetch list via API, then crawl profiles for enrichment.
        """
        self.logger.info(f"Starting extraction from: {self.API_URL}")
        
        # Windows loop policy fix
        if platform.system() == "Windows":
            asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

        local_path = self.raw_dir / self.DATA_FILENAME

        try:
            # 1. Fetch Basic List (Sync)
            session = self._build_session()
            members = await asyncio.to_thread(self._fetch_legislators_from_api, session)
            
            if not members:
                self.logger.warning("No members found from API.")
                return None

            # 2. Enrich with Profile Details (Async Crawl4AI)
            await self._enrich_members_with_profiles(members)

            # 3. Save Raw Data
            with open(local_path, "w", encoding="utf-8") as f:
                json.dump(members, f, indent=2, ensure_ascii=False)
            
            return local_path

        except Exception as e:
            self.logger.error(f"Extraction failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform raw JSON to Golden Profile.
        """
        if not raw_path.exists():
            return

        self.logger.info(f"Transforming file: {raw_path}")
        mapper = ProfileMapper()

        try:
            with open(raw_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            for entry in data:
                try:
                    full_name = entry.get("full_name")
                    if not full_name: continue

                    # 1. ID Generation
                    # Use member_id if stable, else name
                    unique_key = entry.get("member_id") or full_name
                    uid = self.generate_uuid(unique_key)

                    # 2. Details
                    party = entry.get("party", "")
                    state = entry.get("state", "")
                    constituency = entry.get("constituency", "")
                    role = entry.get("office_role") or entry.get("position_or_role") or "Member of Parliament"
                    
                    dob = entry.get("date_of_birth") # Parsed/Extracted in extract step

                    # 3. Build Record
                    mapped_record = {
                        "profile": {
                            "id": uid,
                            "full_name": full_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": None, 
                            "date_of_birth": dob,
                            "nationality": "Nigeria",
                            "is_active": True,
                            "aliases": [],
                            "images": [entry.get("photo_url")] if entry.get("photo_url") else [],
                            "addresses": []
                        },
                        "risk_events": [
                            {
                                "type": "PEP", 
                                "source_list": self.name,
                                "authority": "National Assembly of Nigeria",
                                "reason": f"Member of Parliament ({party}) - {constituency}, {state}. Role: {role}",
                                "date_listed": datetime.now().strftime("%Y-%m-%d"),
                                "is_current": True,
                                "risk_level": "Medium" 
                            }
                        ],
                        "evidence": [
                            {
                                "url": entry.get("profile_url"),
                                "scraped_at": datetime.now(timezone.utc).isoformat(),
                                "raw_text_snippet": (
                                    f"Name: {entry.get('display_name')}. Party: {party}. "
                                    f"State: {state}. Office: {role}. "
                                    f"Email: {entry.get('email')}"
                                )
                            }
                        ]
                    }

                    # 4. Normalize & Yield
                    result = mapper.map_single_profile(mapped_record)

                    yield result

                except Exception as inner_e:
                    self.logger.warning(f"Error transforming record: {inner_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process JSON file: {e}")
            raise e

    # ---------------------------------------------------------
    # Scraping Logic
    # ---------------------------------------------------------

    def _build_session(self) -> requests.Session:
        s = requests.Session()
        s.headers.update({"User-Agent": self.UA})
        retry_strategy = Retry(
            total=3, backoff_factor=2, status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET"]
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        s.mount("https://", adapter)
        s.mount("http://", adapter)
        return s

    def _fetch_legislators_from_api(self, session: requests.Session) -> List[Dict[str, Any]]:
        self.logger.info(f"Fetching legislators from API: {self.API_URL}")
        try:
            resp = session.get(self.API_URL, timeout=60, verify=False)
            resp.raise_for_status()
            payload = resp.json()
        except Exception as e:
            self.logger.error(f"API connection failed: {e}")
            return []

        data = payload.get("data", []) or []
        entries = []

        for row in data:
            if not isinstance(row, list) or len(row) < 5: continue

            raw_name = self._clean_text(str(row[0]))
            state = self._clean_text(str(row[1]))
            constituency = self._clean_text(str(row[2]))
            party = self._clean_text(str(row[3]))
            member_id = self._clean_text(str(row[4]))
            profile_url = f"{self.BASE_URL}/mps/single/{member_id}"

            # Honorific cleanup
            honorific = ""
            full_name = raw_name
            lower = raw_name.lower()
            if lower.startswith("hon. "):
                honorific = "Hon."
                full_name = raw_name[5:].strip()
            elif lower.startswith("hon "):
                honorific = "Hon."
                full_name = raw_name[4:].strip()

            entries.append({
                "honorific": honorific,
                "full_name": full_name,
                "display_name": raw_name,
                "member_id": member_id,
                "state": state,
                "constituency": constituency,
                "party": party,
                "profile_url": profile_url,
            })
        
        self.logger.info(f"Parsed {len(entries)} legislators from API.")
        return entries

    async def _enrich_members_with_profiles(self, members: List[Dict[str, Any]]) -> None:
        self.logger.info(f"Enriching {len(members)} profiles via Crawl4AI...")
        
        browser_cfg = BrowserConfig(headless=True, verbose=False)
        run_cfg = CrawlerRunConfig(cache_mode=CacheMode.BYPASS)
        sem = asyncio.Semaphore(self.PROFILE_CONCURRENCY)

        async with AsyncWebCrawler(config=browser_cfg) as crawler:
            async def process_one(entry: Dict[str, Any], idx: int):
                url = entry.get("profile_url")
                if not url: return
                
                async with sem:
                    try:
                        res = await crawler.arun(url=url, config=run_cfg)
                        if not res.success:
                            self.logger.warning(f"Failed to load profile: {url}")
                            return

                        html_text = res.html or ""
                        extra = self._parse_member_profile(html_text)
                        entry.update(extra)
                        
                        if idx % 10 == 0:
                            self.logger.info(f"Enriched {idx}/{len(members)}")
                    except Exception as e:
                        entry["profile_error"] = str(e)

            tasks = [process_one(m, i) for i, m in enumerate(members, start=1)]
            await asyncio.gather(*tasks)

    def _parse_member_profile(self, html_text: str) -> Dict[str, Any]:
        soup = BeautifulSoup(html_text or "", "html.parser")
        extra = {}

        # 1. Image
        img_tag = soup.select_one("div.card-body img") or soup.select_one("img[src*='/images/mps/']")
        if img_tag and img_tag.get("src"):
            src = img_tag["src"]
            if "default-avatar" not in src:
                extra["photo_url"] = urljoin(self.BASE_URL, src)

        # 2. Key-Values (DOB, Party, Office)
        for li in soup.select("ul.list-group li.list-group-item"):
            strong = li.find("strong")
            meta = li.find("div", class_="meta")
            if strong and meta:
                key = strong.get_text(strip=True).lower()
                val = self._clean_text(meta.get_text(strip=True))
                
                if "date of birth" in key: extra["date_of_birth"] = val
                elif "office" in key: extra["office_role"] = val
                elif "chamber" in key: extra["chamber"] = val
                elif "party" in key: extra["party"] = val

        # 3. Contact Info
        address_block = soup.select_one("address")
        if address_block:
            phone_tag = address_block.find("a", href=re.compile(r"^tel:"))
            if phone_tag: extra["phone"] = self._clean_text(phone_tag.get_text(strip=True))
            
            email_tag = address_block.find("a", href=re.compile(r"^mailto:"))
            if email_tag: extra["email"] = self._clean_text(email_tag.get_text(strip=True))

            for div in address_block.find_all("div"):
                text = div.get_text(" ", strip=True)
                lower = text.lower()
                if "parliament address" in lower:
                    extra["parliament_address"] = self._clean_text(text.replace("Parliament Address:", ""))
                elif "address" in lower and "parliament" not in lower and "email" not in lower:
                    extra["address"] = self._clean_text(text.replace("Address:", ""))

        return extra

    @staticmethod
    def _clean_text(text: str) -> str:
        if not text: return ""
        text = re.sub(r"^(Phone|Email|Address|Parliament Address|Parliament Number):", "", text, flags=re.IGNORECASE)
        return " ".join(text.replace("\xa0", " ").split())

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = NigeriaNassHouseMembersScraper()
    asyncio.run(scraper.run(force=True))