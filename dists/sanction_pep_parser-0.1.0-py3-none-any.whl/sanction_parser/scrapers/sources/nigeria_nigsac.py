"""
src/sanction_parser/scrapers/sources/nigeria_nigsac.py

Scrapes the Nigerian sanctions list (NIGSAC) for Individuals and Entities.
Source: https://nigsac.gov.ng/IndSancList
"""

import re
import json
import asyncio
import logging
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Iterator
from urllib.parse import urljoin

# Third-party
from playwright.sync_api import sync_playwright, Page

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class NigsacSanctionsScraper(BaseSanctionScraper):
    """
    Scraper for Nigeria – NIGSAC Sanctions.
    
    Source URL: https://nigsac.gov.ng/IndSancList
    Format: Web Scraping (Playwright Sync - Dynamic Tabs)
    Type: Sanction (High Risk)
    """
    name = "Nigeria – NIGSAC Sanctions"
    country = "Nigeria"
    
    BASE_URL = "https://nigsac.gov.ng"
    LIST_URL = "https://nigsac.gov.ng/IndSancList"
    DATA_FILENAME = "nigeria_nigsac.json"

    # Playwright tuning
    DEFAULT_TIMEOUT_MS = 60_000
    WAIT_AFTER_NAV_MS = 2000
    WAIT_AFTER_CLICK_MS = 1000

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Scrape Individuals (Tab 1) and Entities (Tab 2) using Playwright.
        """
        self.logger.info(f"Starting extraction from: {self.LIST_URL}")
        local_path = self.raw_dir / self.DATA_FILENAME

        try:
            # Run sync logic in thread
            raw_data = await asyncio.to_thread(self._scrape_sync)
            
            total = len(raw_data.get("individuals", [])) + len(raw_data.get("entities", []))
            if total == 0:
                self.logger.warning("No records scraped.")
                return None

            # Save Raw Data
            with open(local_path, "w", encoding="utf-8") as f:
                json.dump(raw_data, f, indent=2, ensure_ascii=False)
            
            return local_path

        except Exception as e:
            self.logger.error(f"Extraction failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform raw JSON to Golden Profile.
        """
        if not raw_path.exists():
            return

        self.logger.info(f"Transforming file: {raw_path}")
        mapper = ProfileMapper()

        try:
            with open(raw_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            # 1. Process Individuals
            for entry in data.get("individuals", []):
                try:
                    full_name = entry.get("full_name")
                    if not full_name: continue

                    uid = self.generate_uuid(f"ind_{full_name}")
                    iso_date = self._parse_date(entry.get("record_date"))

                    mapped_record = {
                        "profile": {
                            "id": uid,
                            "full_name": full_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": None,
                            "date_of_birth": None,
                            "nationality": entry.get("nationality"),
                            "is_active": True,
                            "aliases": [],
                            "images": [],
                            "addresses": []
                        },
                        "risk_events": [
                            {
                                "type": "Sanction",
                                "source_list": self.name,
                                "authority": "Nigeria Sanctions Committee",
                                "reason": "Designated Individual",
                                "date_listed": iso_date,
                                "is_current": True,
                                "risk_level": "High"
                            }
                        ],
                        "evidence": [
                            {
                                "url": entry.get("detail_url") or self.LIST_URL,
                                "scraped_at": data.get("source_info", {}).get("run_at", datetime.now(timezone.utc).isoformat()),
                                "raw_text_snippet": f"Name: {full_name}, Nationality: {entry.get('nationality')}, Birth Country: {entry.get('birth_country')}"
                            }
                        ]
                    }
                    
                    result = mapper.map_single_profile(mapped_record)
             
                    yield result

                except Exception as e:
                    self.logger.warning(f"Error processing individual: {e}")

            # # 2. Process Entities
            # for entry in data.get("entities", []):
            #     try:
            #         name = entry.get("name")
            #         if not name: continue

            #         uid = self.generate_uuid(f"ent_{name}")
            #         iso_date = self._parse_date(entry.get("record_date"))

            #         mapped_record = {
            #             "profile": {
            #                 "id": uid,
            #                 "full_name": name,
            #                 "entity_type": "ORGANIZATION",
            #                 "gender": None,
            #                 "date_of_birth": None,
            #                 "nationality": "NG", # Presumed jurisdiction
            #                 "is_active": True,
            #                 "aliases": [],
            #                 "images": [],
            #                 "addresses": []
            #             },
            #             "risk_events": [
            #                 {
            #                     "type": "Sanction",
            #                     "source_list": self.name,
            #                     "authority": "Nigeria Sanctions Committee",
            #                     "reason": entry.get("comments") or "Designated Entity",
            #                     "date_listed": iso_date,
            #                     "is_current": True,
            #                     "risk_level": "High"
            #                 }
            #             ],
            #             "evidence": [
            #                 {
            #                     "url": entry.get("detail_url") or self.LIST_URL,
            #                     "scraped_at": data.get("source_info", {}).get("run_at", datetime.now(timezone.utc).isoformat()),
            #                     "raw_text_snippet": f"Entity Name: {name}, Comments: {entry.get('comments')}"
            #                 }
            #             ]
            #         }

            #         result = mapper.map_single_profile(mapped_record)
            #         yield result

                # except Exception as e:
                #     self.logger.warning(f"Error processing entity: {e}")

        except Exception as e:
            self.logger.error(f"Failed to process JSON file: {e}")
            raise e

    # ---------------------------------------------------------
    # Scraping Logic (Sync Playwright)
    # ---------------------------------------------------------

    def _scrape_sync(self) -> Dict[str, Any]:
        self.logger.info("Starting scrape via Playwright...")
        data = {
            "source_info": {
                "name": self.name, "url": self.LIST_URL,
                "run_at": datetime.now(timezone.utc).isoformat(),
            },
            "individuals": [],
            "entities": []
        }

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()
            page.set_default_timeout(self.DEFAULT_TIMEOUT_MS)

            self.logger.info(f"Navigating to {self.LIST_URL}")
            page.goto(self.LIST_URL, wait_until="networkidle")
            page.wait_for_timeout(self.WAIT_AFTER_NAV_MS)

            # 1. Individuals
            self.logger.info("Extracting Individuals...")
            data["individuals"] = self._extract_individuals_pagination(page)
            self.logger.info(f"Found {len(data['individuals'])} individuals.")

            # 2. Entities
            self.logger.info("Extracting Entities...")
            data["entities"] = self._extract_entities_pagination(page)
            self.logger.info(f"Found {len(data['entities'])} entities.")

            browser.close()

        return data

    def _extract_individuals_pagination(self, page: Page) -> List[Dict[str, Any]]:
        individuals = []
        seen_ids = set()
        panel_sel = "#tab-panel-1"

        while True:
            try:
                page.wait_for_selector(f"{panel_sel} table tbody tr", timeout=5000)
            except: break

            rows = page.query_selector_all(f"{panel_sel} table tbody tr")
            for row in rows:
                tds = row.query_selector_all("td")
                if len(tds) < 6: continue

                sn_text = self._clean_text(tds[0].inner_text())
                if sn_text in seen_ids: continue
                seen_ids.add(sn_text)

                first_name = self._clean_text(tds[1].inner_text())
                surname = self._clean_text(tds[2].inner_text())
                nationality = self._clean_text(tds[3].inner_text())
                birth_country = self._clean_text(tds[4].inner_text())
                record_date = self._clean_text(tds[5].inner_text())

                detail_url = None
                detail_a = row.query_selector("a[href*='IndSancDetails']")
                if detail_a:
                    href = detail_a.get_attribute("href")
                    if href: detail_url = urljoin(self.BASE_URL, href)

                individuals.append({
                    "id": sn_text,
                    "first_name": first_name,
                    "surname": surname,
                    "full_name": (first_name + " " + surname).strip(),
                    "nationality": nationality,
                    "birth_country": birth_country,
                    "record_date": record_date,
                    "detail_url": detail_url,
                })

            next_btn = page.query_selector(f"{panel_sel} a[id$='_next']")
            if not next_btn: break
            
            classes = next_btn.get_attribute("class") or ""
            if "disabled" in classes: break

            next_btn.click()
            page.wait_for_timeout(self.WAIT_AFTER_CLICK_MS)

        return individuals

    def _extract_entities_pagination(self, page: Page) -> List[Dict[str, Any]]:
        entities = []
        seen_ids = set()

        try:
            page.click('label[for="tab-2"]')
            page.wait_for_timeout(self.WAIT_AFTER_CLICK_MS)
        except Exception as e:
            self.logger.warning(f"Could not switch to Tab 2: {e}")
            return []

        panel_sel = "#tab-panel-2"

        while True:
            try:
                page.wait_for_selector(f"{panel_sel} table tbody tr", timeout=5000)
            except: break

            rows = page.query_selector_all(f"{panel_sel} table tbody tr")
            for row in rows:
                tds = row.query_selector_all("td")
                if len(tds) < 4: continue

                sn_text = self._clean_text(tds[0].inner_text())
                if sn_text in seen_ids: continue
                seen_ids.add(sn_text)

                name = self._clean_text(tds[1].inner_text())
                comments = self._clean_text(tds[2].inner_text())
                record_date = self._clean_text(tds[3].inner_text())

                detail_url = None
                detail_a = row.query_selector("a[href*='EntSancDetails']")
                if detail_a:
                    href = detail_a.get_attribute("href")
                    if href: detail_url = urljoin(self.BASE_URL, href)

                entities.append({
                    "id": sn_text,
                    "name": name,
                    "comments": comments,
                    "record_date": record_date,
                    "detail_url": detail_url,
                })

            next_btn = page.query_selector(f"{panel_sel} a[id$='_next']")
            if not next_btn: break

            classes = next_btn.get_attribute("class") or ""
            if "disabled" in classes: break

            next_btn.click()
            page.wait_for_timeout(self.WAIT_AFTER_CLICK_MS)

        return entities

    # --- Helpers ---

    def _clean_text(self, x: Optional[str]) -> str:
        if not x: return ""
        x = x.replace("\xa0", " ")
        x = re.sub(r"\s+", " ", x)
        return x.strip()

    def _parse_date(self, date_str: str) -> Optional[str]:
        if not date_str: return None
        try:
            dt = datetime.strptime(date_str, "%m/%d/%Y %I:%M:%S %p")
            return dt.strftime("%Y-%m-%d")
        except ValueError:
            try:
                dt = datetime.strptime(date_str, "%m/%d/%Y")
                return dt.strftime("%Y-%m-%d")
            except ValueError:
                return None

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = NigsacSanctionsScraper()
    asyncio.run(scraper.run(force=True))