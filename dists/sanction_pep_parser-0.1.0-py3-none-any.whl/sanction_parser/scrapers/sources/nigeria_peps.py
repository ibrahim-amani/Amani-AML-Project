"""
src/sanction_parser/scrapers/sources/nigeria_peps.py

Scraper for Nigeria PEPs (Politically Exposed Persons).
Source: https://peps.directoriolegislativo.org/
"""

import logging
import asyncio
import pandas as pd
import re
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper
from sanction_parser.scrapers.utils.web_client import get_request

# Initialize logger
logger = logging.getLogger(__name__)

class NigeriaPEPsScraper(BaseSanctionScraper):
    """
    Scraper for Nigeria PEPs.
    
    Source URL: https://peps.directoriolegislativo.org/datasets/nigeria/PEP_data.xlsx
    Format: Excel
    Type: PEP
    """
    name = "Directorio Legislativo - Nigeria PEPs"
    country = "Nigeria"
    
    FILE_URL = "https://peps.directoriolegislativo.org/datasets/nigeria/PEP_data.xlsx"
    DATA_FILENAME = "nigeria_peps.xlsx"

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Download the Excel file directly.
        """
        self.logger.info(f"Downloading file from: {self.FILE_URL}")
        
        local_path = self.raw_dir / self.DATA_FILENAME

        def _download_task():
            response = get_request(self.FILE_URL, stream=True, timeout=120)
            with open(local_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

        try:
            await asyncio.to_thread(_download_task)
            
            if local_path.exists() and local_path.stat().st_size > 0:
                return local_path
            else:
                self.logger.error("Download failed or file is empty.")
                return None

        except Exception as e:
            self.logger.error(f"Failed to download file: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform Excel to Golden Profile schema.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            # Fallback
            excel_files = list(raw_path.parent.glob("*.xlsx"))
            if not excel_files:
                self.logger.warning("No Excel files found.")
                return
            target_file = excel_files[0]

        self.logger.info(f"Transforming file: {target_file}")
        mapper = ProfileMapper()

        try:
            df = pd.read_excel(target_file)
            
            # Fill NaNs for string columns
            obj_cols = df.select_dtypes(include=['object']).columns
            df[obj_cols] = df[obj_cols].fillna("")

            for index, row in df.iterrows():
                try:
                    # 1. Basic Info
                    full_name = str(row.get("Name", "")).strip()
                    if not full_name:
                        continue

                    position = str(row.get("Position", "")).strip()
                    
                    # 2. Gender
                    gender = str(row.get("Gender", "")).strip()
                    if not gender or gender.lower() == "nan":
                        gender = None
                    
                    # 3. Date of Birth
                    dob_val = row.get("Date of Birth")
                    dob_str = None
                    if pd.notnull(dob_val):
                        try:
                            if isinstance(dob_val, (pd.Timestamp, datetime)):
                                dob_str = dob_val.strftime("%Y-%m-%d")
                            else:
                                # Try parsing string
                                dob_str = pd.to_datetime(dob_val).strftime("%Y-%m-%d")
                        except:
                            pass
                    
                    # 4. Location
                    district = str(row.get("District", "")).strip()
                    address_parts = [p for p in [district, "Nigeria"] if p]
                    full_address = ", ".join(address_parts)

                    # 5. Active Status
                    period = str(row.get("Period", "")).strip()
                    is_active = self._is_still_active(period)
      
                    # 6. ID Generation
                    unique_key = f"{full_name}_{position}_{district}"
                    record_id = self.generate_uuid(unique_key)

                    # 7. Build Record
                    raw_record = {
                        "profile": {
                            "id": record_id,
                            "full_name": full_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": gender,
                            "date_of_birth": dob_str,
                            "nationality": "Nigeria",
                            "is_active": is_active,
                            "aliases": [],
                            "images": [],
                            "addresses": [full_address] if full_address else []
                        },
                        "risk_events": [
                            {
                                "type": "PEP",
                                "source_list": self.name,
                                "authority": "Nigerian Government",
                                "reason": position,
                                "date_listed": self.execution_date, 
                                "is_current": is_active,
                                "risk_level": "High",
                            }
                        ],
                        "evidence": [
                            {
                                "url": self.FILE_URL,
                                "scraped_at": datetime.now().isoformat(),
                                "raw_text_snippet": f"Position: {position} | Period: {period}"
                            }
                        ]
                    }

                    # 8. Normalize & Yield
                    result = mapper.map_single_profile(raw_record)

                    yield result

                except Exception as inner_e:
                    self.logger.warning(f"Error processing row {index}: {inner_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process Excel file: {e}")
            raise e

    # ---------------------------------------------------------
    # Helper Methods
    # ---------------------------------------------------------

    def _is_still_active(self, date_range: str) -> bool:
        """
        Parses ranges like '2019 - Present', '2020 - 2024'.
        """
        if not date_range:
            return False

        date_range = date_range.strip().upper()

        if "PRESENT" in date_range or "CURRENT" in date_range or "NA" in date_range:
            return True

        years = re.findall(r"\d{4}", date_range)
        if not years:
            return False

        # Take the last year found as the end year
        try:
            end_year = int(years[-1])
            current_year = datetime.now().year
            return end_year >= current_year
        except:
            return False

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = NigeriaPEPsScraper()
    asyncio.run(scraper.run(force=True))