"""
src/sanction_parser/scrapers/sources/nz_police.py

Scraper for New Zealand Police - Designated Entities (UNSC Resolutions).
Source: https://www.police.govt.nz/.../designated-entities/...
"""

import logging
import asyncio
import pandas as pd
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper
from sanction_parser.scrapers.utils.web_client import extract_download_links, get_request

# Initialize logger
logger = logging.getLogger(__name__)

class NZPoliceSanctionsScraper(BaseSanctionScraper):
    """
    Scraper for NZ Police - Designated Individuals (UNSC).
    
    Source URL: https://www.police.govt.nz/advice/personal-community/counterterrorism/designated-entities/lists-associated-with-resolutions-1267-1989-2253-1988
    Format: Excel (Dynamic Link)
    Strategy: Targeted sheet processing ('Individuals').
    """
    name = "NZ Police - UNSC Designated Individuals"
    country = "New Zealand"
    
    BASE_URL = "https://www.police.govt.nz/advice/personal-community/counterterrorism/designated-entities/lists-associated-with-resolutions-1267-1989-2253-1988"
    DATA_FILENAME = "nz_police_unsc.xlsx"
    TARGET_EXTS = ["xlsx", "xls"]

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Scrape the page for the Excel file and download it.
        """
        self.logger.info(f"Scanning page for Excel files: {self.BASE_URL}")
        
        # 1. Extract Links
        try:
            links = await asyncio.to_thread(extract_download_links, self.BASE_URL, exts=self.TARGET_EXTS)
        except Exception as e:
            self.logger.error(f"Link extraction failed: {e}")
            return None

        if not links:
            self.logger.warning("No Excel download links found on the target page.")
            return None

        # Assume first link is the target list
        target_link = links[0]
        file_url = target_link['url']
        ext = target_link.get('ext', 'xlsx')
        
        self.logger.info(f"Found file ({ext}): {file_url}")

        # Update filename based on extension
        self.DATA_FILENAME = f"nz_police_unsc.{ext}"
        local_path = self.raw_dir / self.DATA_FILENAME

        def _download_task():
            response = get_request(file_url, stream=True, timeout=60)
            with open(local_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

        try:
            await asyncio.to_thread(_download_task)
            if local_path.exists() and local_path.stat().st_size > 0:
                return local_path
            return None
        except Exception as e:
            self.logger.error(f"Download failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform Excel (Individuals Sheet) to Golden Profile.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            # Fallback
            excel_files = list(raw_path.parent.glob("*.xls*"))
            if not excel_files:
                self.logger.warning("No Excel files found.")
                return
            target_file = excel_files[0]

        self.logger.info(f"Transforming file: {target_file}")
        mapper = ProfileMapper()

        try:
            # Load specific sheet
            try:
                df = pd.read_excel(target_file, sheet_name="Individuals", dtype=str)
            except ValueError:
                # If sheet name not found, try reading default
                self.logger.warning("Sheet 'Individuals' not found. Reading first sheet.")
                df = pd.read_excel(target_file, dtype=str)

            df = df.fillna("")

            for index, row in df.iterrows():
                try:
                    # 1. Name Construction
                    name_parts = [
                        row.get("Name_1", ""),
                        row.get("Name_2", ""),
                        row.get("Name_3", ""),
                        row.get("Name_4", ""),
                        row.get("LastName", "")
                    ]
                    full_name = " ".join([part.strip() for part in name_parts if part.strip()])
                    
                    if not full_name or full_name.lower() == "unknown individual":
                        continue

                    # 2. Extract Fields
                    title = row.get("Title", "").strip()
                    gender = None # Not typically in this dataset explicitly as M/F code
                    
                    # Dates
                    dob_iso = self._parse_nz_date(row.get("DOB_1", ""))
                    designation_date_iso = self._parse_nz_date(row.get("NZ_designation_date", ""))

                    # Nationality & POB
                    nationality = row.get("Nationality_1", "").strip()
                    pob_parts = [row.get("POB_1", ""), row.get("POB_1_Country", "")]
                    place_of_birth = ", ".join([p.strip() for p in pob_parts if p.strip()])

                    # Identifiers
                    ref_number = row.get("Sanctions_List_Permanent_Reference_Number", "").strip()
                    un_id = row.get("ID", "").strip() 

                    # 3. Generate ID
                    unique_key = f"{ref_number}_{un_id}_{full_name}"
                    record_id = self.generate_uuid(unique_key)

                    # 4. Build Record
                    mapped_record = {
                        "profile": {
                            "id": record_id,
                            "full_name": full_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": gender,
                            "date_of_birth": dob_iso,
                            "nationality": nationality if nationality else None,
                            "is_active": True, 
                            "aliases": [], 
                            "images": [],
                            "addresses": [place_of_birth] if place_of_birth else []
                        },
                        "risk_events": [
                            {
                                "type": "Sanction",
                                "source_list": self.name,
                                "authority": "UN Security Council / NZ Police",
                                "reason": f"Associated with Resolutions 1267/1989/2253/1988. UN Ref: {ref_number}",
                                "date_listed": designation_date_iso,
                                "is_current": True,
                                "risk_level": "Critical",
                            }
                        ],
                        "evidence": [
                            {
                                "url": self.BASE_URL,
                                "scraped_at": datetime.now().isoformat(),
                                "raw_text_snippet": f"Title: {title} | ID: {un_id}"
                            }
                        ]
                    }
                    
                    # 5. Normalize & Yield
                    result = mapper.map_single_profile(mapped_record)

                    yield result

                except Exception as inner_e:
                    self.logger.warning(f"Error processing row {index}: {inner_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process Excel file: {e}")
            raise e

    # ---------------------------------------------------------
    # Helper Methods
    # ---------------------------------------------------------

    def _parse_nz_date(self, date_str: Any) -> Optional[str]:
        """
        Parses mixed date formats found in Excel (Strings or Timestamps).
        """
        if not date_str or str(date_str).lower() in ['nan', 'nat', '']:
            return None
            
        try:
            dt = pd.to_datetime(date_str, errors='coerce')
            if pd.notnull(dt):
                return dt.strftime("%Y-%m-%d")
        except:
            pass
            
        return None

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = NZPoliceSanctionsScraper()
    asyncio.run(scraper.run(force=True))