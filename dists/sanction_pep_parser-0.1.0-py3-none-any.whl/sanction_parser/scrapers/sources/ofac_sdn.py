"""
src/sanction_parser/scrapers/sources/ofac_sdn.py

Scraper for US Department of the Treasury (OFAC) - SDN Advanced XML List.
Source: https://sanctionslistservice.ofac.treas.gov/.../SDN_ADVANCED.XML
"""

import logging
import asyncio
import requests
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path
from datetime import datetime, timezone
from typing import Iterator, Dict, Any, Optional

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class OFACSanctionsScraper(BaseSanctionScraper):
    """
    Scraper for OFAC SDN Advanced List.
    
    Source URL: https://sanctionslistservice.ofac.treas.gov/api/PublicationPreview/exports/SDN_ADVANCED.XML
    Format: Complex XML
    Type: Sanction (High Risk)
    """
    name = "US Department of the Treasury (OFAC) - SDN Advanced"
    country = "USA"
    
    BASE_URL = "https://sanctionslistservice.ofac.treas.gov/api/PublicationPreview/exports/SDN_ADVANCED.XML"
    DATA_FILENAME = "ofac_sdn.xml"

    def __init__(self):
        super().__init__()
        # Parsing state containers
        self.sanctions_data = defaultdict(lambda: {
            'programs': set(),
            'dates': set(),
            'legal_basis': set(),
            'list_ids': set()
        })
        self.identity_documents = defaultdict(list)
        self.lookups = {
            'PartySubType': {'1': 'Vessel', '2': 'Aircraft', '3': 'Entity', '4': 'Individual'},
            'AliasType': {},
            'FeatureType': {},
            'IDRegDocType': {}
        }
        self.parsed_parties = []
        self.tree = None
        self.root = None

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Stream download the large XML file.
        """
        self.logger.info(f"Downloading data from: {self.BASE_URL}")
        
        local_path = self.raw_dir / self.DATA_FILENAME

        def _download_task():
            # Use stream=True for large files
            with requests.get(self.BASE_URL, stream=True, timeout=120) as response:
                response.raise_for_status()
                with open(local_path, 'wb') as f:
                    for chunk in response.iter_content(chunk_size=8192):
                        f.write(chunk)

        try:
            await asyncio.to_thread(_download_task)
            if local_path.exists() and local_path.stat().st_size > 0:
                return local_path
            return None
        except Exception as e:
            self.logger.error(f"Download failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Parse complex XML structure and yield Profiles.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            xml_files = list(raw_path.parent.glob("*.xml"))
            if not xml_files:
                self.logger.warning("No XML files found.")
                return
            target_file = xml_files[0]

        self.logger.info(f"Processing XML file: {target_file}")
        
        # Reset state for fresh run
        self.sanctions_data.clear()
        self.identity_documents.clear()
        self.parsed_parties = []
        self.lookups['AliasType'] = {} # Reset dynamic lookups

        mapper = ProfileMapper()

        try:
            self.tree = ET.parse(target_file)
            self.root = self.tree.getroot()

            # Execute Parsing Chain
            self._parse_reference_values()
            self._parse_sanctions_entries()
            self._parse_id_reg_documents()
            self._parse_distinct_parties()
            
            self.logger.info(f"Parsed {len(self.parsed_parties)} total parties. Filtering for Individuals...")
            
            for party in self.parsed_parties:
                # 1. Filter: Individuals Only
                if party['Party_Type'] != 'Individual':
                    continue

                # 2. Extract Data
                generated_id = self.generate_uuid(f"ofac_sdn_{party['SDN_UID']}")
                feats = party.get('Features', {})
                
                dob = feats.get('Birthdate', [None])[0] 
                nationality = feats.get('Nationality', feats.get('Citizenship', [None]))[0]
                gender = feats.get('Gender', [None])[0]

                # Documents
                id_docs = []
                for doc in party.get('Documents', []):
                    doc_str = f"{doc['Type']}: {doc['Number']} ({doc['Country'] or 'N/A'})"
                    id_docs.append(doc_str)

                # Risk Events
                programs_str = ", ".join(party['Sanctions_Programs'])
                risk_events = []
                dates = party.get('Entry_Dates', [])
                
                # Create events for each date, or one generic if no dates
                if dates:
                    for date_entry in dates:
                        risk_events.append(self._build_risk_event(programs_str, date_entry))
                else:
                    risk_events.append(self._build_risk_event(programs_str, None))

                # 3. Build Record
                raw_record = {
                    "profile": {
                        "id": generated_id,
                        "full_name": party['Full_Name'],
                        "entity_type": "INDIVIDUAL",
                        "gender": gender,
                        "date_of_birth": dob,
                        "nationality": nationality,
                        "is_active": True,
                        "aliases": party.get("Aliases", []),
                        "images": [],
                        "addresses": []
                    },
                    "risk_events": risk_events,
                    "evidence": [
                        {
                            "url": f"https://sanctionssearch.ofac.treas.gov/Details.aspx?id={party['SDN_UID']}",
                            "scraped_at": datetime.now(timezone.utc).isoformat(),
                            "raw_text_snippet": f"SDN UID: {party['SDN_UID']} | IDs: {', '.join(id_docs)}"
                        }
                    ]
                }

                # 4. Normalize & Yield
                result = mapper.map_single_profile(raw_record)

                yield result

        except Exception as e:
            self.logger.error(f"Failed to process XML file: {e}")
            raise e

    # ---------------------------------------------------------
    # Parsing Logic Helpers
    # ---------------------------------------------------------

    def _build_risk_event(self, programs: str, date: Optional[str]) -> Dict[str, Any]:
        return {
            "type": "Sanction",
            "source_list": self.name,
            "authority": "US Department of the Treasury (OFAC)",
            "reason": f"Program: {programs}",
            "date_listed": date,
            "is_current": True,
            "risk_level": "High"
        }

    def _get_local_tag(self, tag):
        if '}' in tag: return tag.split('}', 1)[1]
        return tag

    def _iter_elements(self, parent, local_tag_name):
        for child in parent:
            if self._get_local_tag(child.tag) == local_tag_name: yield child

    def _find_first(self, parent, local_tag_name):
        for child in parent:
            if self._get_local_tag(child.tag) == local_tag_name: return child
        return None

    def _get_text_safe(self, element):
        return element.text.strip() if element is not None and element.text else None

    def _extract_date(self, parent_element):
        date_elem = self._find_first(parent_element, 'Date')
        if date_elem is None:
            date_period = self._find_first(parent_element, 'DatePeriod')
            if date_period is not None:
                start = self._find_first(date_period, 'Start')
                if start is not None:
                    date_elem = self._find_first(start, 'From')
        
        if date_elem is not None:
            y = self._get_text_safe(self._find_first(date_elem, 'Year')) or "0000"
            m = (self._get_text_safe(self._find_first(date_elem, 'Month')) or "00").zfill(2)
            d = (self._get_text_safe(self._find_first(date_elem, 'Day')) or "00").zfill(2)
            if y != "0000": return f"{y}-{m}-{d}"
        return None

    def _parse_reference_values(self):
        ref_root = self._find_first(self.root, 'ReferenceValueSets')
        if ref_root is None: return

        def fill_lookup(tag_name, target_dict):
            container = self._find_first(ref_root, tag_name + 'Values')
            if container is not None:
                for item in self._iter_elements(container, tag_name):
                    val = self._get_text_safe(item)
                    if val: target_dict[item.get('ID')] = val

        fill_lookup('AliasType', self.lookups['AliasType'])
        fill_lookup('FeatureType', self.lookups['FeatureType'])
        fill_lookup('IDRegDocType', self.lookups['IDRegDocType'])

    def _parse_sanctions_entries(self):
        entries_root = self._find_first(self.root, 'SanctionsEntries')
        if entries_root is None: return

        for entry in self._iter_elements(entries_root, 'SanctionsEntry'):
            pid = entry.get('ProfileID')
            lid = entry.get('ListID')
            if lid: self.sanctions_data[pid]['list_ids'].add(lid)

            for event in self._iter_elements(entry, 'EntryEvent'):
                d = self._extract_date(event)
                if d: self.sanctions_data[pid]['dates'].add(d)
                lb = event.get('LegalBasisID')
                if lb: self.sanctions_data[pid]['legal_basis'].add(lb)

            for measure in self._iter_elements(entry, 'SanctionsMeasure'):
                comment = self._find_first(measure, 'Comment')
                if comment is not None and comment.text:
                    self.sanctions_data[pid]['programs'].add(comment.text.strip())

    def _parse_id_reg_documents(self):
        docs_root = self._find_first(self.root, 'IDRegDocuments')
        if docs_root is None: return

        for doc in self._iter_elements(docs_root, 'IDRegDocument'):
            identity_id = doc.get('IdentityID')
            doc_type_id = doc.get('IDRegDocTypeID')
            doc_type_str = self.lookups['IDRegDocType'].get(doc_type_id, 'Unknown Doc')
            doc_num = self._get_text_safe(self._find_first(doc, 'IDRegistrationNo'))
            issued_by = doc.get('IssuedBy-CountryID')
            
            if doc_num:
                self.identity_documents[identity_id].append({
                    'Type': doc_type_str,
                    'Number': doc_num,
                    'Country': issued_by
                })

    def _parse_distinct_parties(self):
        parties_root = self._find_first(self.root, 'DistinctParties')
        if parties_root is None: return

        for party in self._iter_elements(parties_root, 'DistinctParty'):
            uid = party.get('FixedRef')
            profile = self._find_first(party, 'Profile')
            if profile is None: continue

            profile_id = profile.get('ID')
            raw_type = profile.get('PartySubTypeID')
            party_type = self.lookups['PartySubType'].get(raw_type, raw_type)
            
            aliases_list = []
            features_dict = defaultdict(list)
            
            identity = self._find_first(profile, 'Identity')
            identity_id = identity.get('ID') if identity is not None else None
            full_name = "Unknown"
            
            if identity is not None:
                for alias in self._iter_elements(identity, 'Alias'):
                    is_primary = (alias.get('Primary') == 'true')
                    
                    doc_name = self._find_first(alias, 'DocumentedName')
                    curr_name_parts = []
                    if doc_name is not None:
                        for part in self._iter_elements(doc_name, 'DocumentedNamePart'):
                            val = self._find_first(part, 'NamePartValue')
                            txt = self._get_text_safe(val)
                            if txt: curr_name_parts.append(txt)
                    
                    curr_name_str = " ".join(curr_name_parts)
                    if is_primary: 
                        full_name = curr_name_str
                    else:
                        aliases_list.append(curr_name_str)

            for feature in self._iter_elements(profile, 'Feature'):
                feat_type_id = feature.get('FeatureTypeID')
                feat_label = self.lookups['FeatureType'].get(feat_type_id, f'Feature_{feat_type_id}')
                version = self._find_first(feature, 'FeatureVersion')
                if version is not None:
                    date_val = self._extract_date(version)
                    if date_val:
                        features_dict[feat_label].append(date_val)
                    else:
                        detail = self._find_first(version, 'VersionDetail')
                        text_val = self._get_text_safe(detail)
                        if text_val: features_dict[feat_label].append(text_val)

            documents = self.identity_documents.get(identity_id, [])
            sanctions = self.sanctions_data.get(profile_id, {})
            
            self.parsed_parties.append({
                'SDN_UID': uid,
                'Full_Name': full_name,
                'Party_Type': party_type,
                'Sanctions_Programs': list(sorted(sanctions.get('programs', []))),
                'Entry_Dates': list(sorted(sanctions.get('dates', []))),
                'Aliases': aliases_list,
                'Features': dict(features_dict),
                'Documents': documents
            })

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = OFACSanctionsScraper()
    asyncio.run(scraper.run(force=True))