
"""
src/sanction_parser/scrapers/sources/opensanctions.py
"""

from __future__ import annotations

import asyncio
import logging
import os
import time
from pathlib import Path
from typing import Optional

from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.scrapers.utils.opensanctions_helper import OpenSanctionsDownloader, OpenSanctionsETL

logger = logging.getLogger(__name__)


class OpenSanctionsScraper(BaseSanctionScraper):
    """
    OpenSanctions dataset scraper (eg_terrorists) using:
      - OpenSanctionsDownloader.check_and_download()
      - OpenSanctionsETL.load_data()
      - OpenSanctionsETL.export()

    NOTE:
    This scraper is EXPORT-ONLY (OpenSanctionsETL already writes the final JSONL),
    so we override run() to avoid BaseSanctionScraper._save_processed_data() and
    prevent writing output twice.
    """

    name = "OpenSanctions - Default"
    country = "Default"

    METADATA_URL = "https://data.opensanctions.org/datasets/latest/default/index.json"
    DATA_DIR_NAME = "opensanctions"

    async def extract(self) -> Optional[Path]:
        self.logger.info(f"Checking OpenSanctions metadata: {self.METADATA_URL}")

        data_dir = self.raw_dir / self.DATA_DIR_NAME
        data_dir.mkdir(parents=True, exist_ok=True)

        downloader = OpenSanctionsDownloader(data_dir=str(data_dir), metadata_url=self.METADATA_URL)

        try:
            input_path = await asyncio.to_thread(downloader.check_and_download)
            if not input_path:
                self.logger.info("Data is up-to-date. Skipping.")
                return None

            p = Path(input_path)
            if p.exists() and p.stat().st_size > 0:
                return p

            self.logger.error("Downloader returned an invalid/empty file.")
            return None

        except Exception as e:
            self.logger.error(f"OpenSanctions extract failed: {e}", exc_info=True)
            return None

    def transform(self, raw_path: Path) -> Optional[Path]:
        """
        Export-only transform:
          - build output_prefix
          - create fresh sqlite db
          - etl.load_data(raw_path)
          - etl.export(output_prefix, is_target="1")

        Returns:
          - Path to the exported JSONL (output_prefix.jsonl) if created
          - None if export produced no file
        """
        if not raw_path:
            self.logger.info("No input file provided. Skipping transform.")
            return None

        output_prefix = str(self.processed_dir / f"{self.slug}_export")
        exported_jsonl = Path(f"{output_prefix}.jsonl")

        tmp_root = self.processed_dir / ".tmp"
        tmp_root.mkdir(parents=True, exist_ok=True)
        db_path = tmp_root / f"opensanctions_{int(time.time())}.db"

        # Ensure output dir exists
        out_dir = os.path.dirname(output_prefix)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)

        # Remove db if exists
        try:
            if db_path.exists():
                db_path.unlink()
        except Exception as e:
            self.logger.warning(f"Failed to remove existing DB_PATH={db_path}: {e}")

        try:
            self.logger.info(f"Running OpenSanctions ETL | db={db_path} | output_prefix={output_prefix}")
            with OpenSanctionsETL(db_path=str(db_path)) as etl:
                etl.load_data(str(raw_path))
                etl.export(output_prefix, is_target="1")

            if not exported_jsonl.exists() or exported_jsonl.stat().st_size == 0:
                self.logger.warning(f"ETL export produced no output: {exported_jsonl}")
                return None

            self.logger.info(f"OpenSanctions ETL export completed. Output: {exported_jsonl}")
            return exported_jsonl

        finally:
            try:
                if db_path.exists():
                    db_path.unlink()
                    self.logger.info(f"Deleted ETL sqlite DB: {db_path}")
            except Exception as e:
                self.logger.warning(f"Failed to delete ETL sqlite DB: {e}")

    async def run(self, force: bool = False) -> None:
        """
        Override BaseSanctionScraper.run() to prevent double-saving.

        Pipeline:
          1) interval check
          2) extract
          3) hash check
          4) transform (export-only)
        """
        self.logger.info(f"Starting pipeline for: {self.name}")

        # 1) Check interval
        if not force and not self.should_run_update():
            return

        # 2) Extract
        try:
            raw_path = await self.extract()
        except Exception as e:
            self.logger.error(f"Extraction failed: {e}", exc_info=True)
            return

        if not raw_path:
            self.logger.warning("Extraction returned no file.")
            return

        # 3) Hash check (idempotency)
        if not force and not self.verify_content_changed(raw_path):
            return

        # 4) Transform/export ONLY (no _save_processed_data)
        try:
            exported = self.transform(raw_path)
            if exported:
                self.logger.info(f"Pipeline completed. Export output: {exported}")
            else:
                self.logger.warning("Pipeline completed but no export file was produced.")
        except Exception as e:
            self.logger.error(f"Transformation failed: {e}", exc_info=True)
            raise


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = OpenSanctionsScraper()
    asyncio.run(scraper.run(force=True))
