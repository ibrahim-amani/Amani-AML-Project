"""
src/sanction_parser/scrapers/sources/rwanda_umucyo.py

Scrapes Rwanda Umucyo blacklist (RPPA) across all pages.
Source: https://www.umucyo.gov.rw/um/ubl/moveUmUblBlacLstComListPubBlacklisted.do
"""

import re
import json
import asyncio
import logging
import platform
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Iterator
from urllib.parse import urlencode

# Third-party
from lxml import html
from crawl4ai import AsyncWebCrawler, BrowserConfig, CrawlerRunConfig, CacheMode

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class UmucyoBlacklistScraper(BaseSanctionScraper):
    """
    Scraper for Rwanda – Umucyo Blacklist.
    
    Source URL: https://www.umucyo.gov.rw/um/ubl/moveUmUblBlacLstComListPubBlacklisted.do
    Format: Web Scraping (Crawl4AI - Pagination)
    Type: Debarment (High Risk)
    """
    name = "Rwanda – Umucyo Blacklist"
    country = "Rwanda"
    
    BASE_URL = "https://www.umucyo.gov.rw/um/ubl/moveUmUblBlacLstComListPubBlacklisted.do"
    DATA_FILENAME = "rwanda_umucyo.json"
    
    DEFAULT_HEADLESS = True

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Scrape all pages via Crawl4AI.
        """
        self.logger.info(f"Starting extraction from: {self.BASE_URL}")
        
        # Windows loop policy fix
        if platform.system() == "Windows":
            asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

        local_path = self.raw_dir / self.DATA_FILENAME

        try:
            # Run Crawl4AI logic
            raw_data = await self._scrape_blacklist()
            
            if not raw_data or not raw_data.get("entries"):
                self.logger.warning("No entries scraped.")
                return None

            # Save Raw Data
            with open(local_path, "w", encoding="utf-8") as f:
                json.dump(raw_data, f, indent=2, ensure_ascii=False)
            
            return local_path

        except Exception as e:
            self.logger.error(f"Extraction failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform raw JSON to Golden Profile.
        """
        if not raw_path.exists():
            return

        self.logger.info(f"Transforming file: {raw_path}")
        mapper = ProfileMapper()

        try:
            with open(raw_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            source_info = data.get("source_info", {})
            scraped_at = source_info.get("scraped_at", datetime.now(timezone.utc).isoformat())

            for entry in data.get("entries", []):
                try:
                    company_name = entry.get("company_name")
                    if not company_name: continue

                    # 1. ID Generation
                    uid = self.generate_uuid(company_name)

                    # 2. Dates & Status
                    start_date = self._parse_rwandan_date(entry.get("sanction_start_date"))
                    end_date = self._parse_rwandan_date(entry.get("sanction_end_date"))
                    
                    is_active = True
                    if end_date:
                        try:
                            if datetime.strptime(end_date, "%Y-%m-%d") < datetime.now():
                                is_active = False
                        except: pass

                    # 3. Build Record
                    mapped_record = {
                        "profile": {
                            "id": uid,
                            "full_name": company_name,
                            "entity_type": "ORGANIZATION", # It's a company list
                            "gender": None,
                            "date_of_birth": None,
                            "nationality": "RW",
                            "is_active": is_active,
                            "aliases": [],
                            "images": [],
                            "addresses": []
                        },
                        "risk_events": [
                            {
                                "type": "Debarment",
                                "source_list": self.name,
                                "authority": "Rwanda Public Procurement Authority (RPPA)",
                                "reason": entry.get("reason", "Violations of procurement regulations"),
                                "date_listed": start_date,
                                "is_current": is_active,
                                "risk_level": "High"
                            }
                        ],
                        "evidence": [
                            {
                                "url": self.BASE_URL,
                                "scraped_at": scraped_at,
                                "raw_text_snippet": (
                                    f"Company: {company_name}. Owner: {entry.get('owner_name')}. "
                                    f"Reason: {entry.get('reason')}. "
                                    f"Period: {entry.get('sanction_start_date')} to {entry.get('sanction_end_date')}."
                                )
                            }
                        ]
                    }

                    # 4. Normalize & Yield
                    result = mapper.map_single_profile(mapped_record)
   
                    yield result

                except Exception as inner_e:
                    self.logger.warning(f"Error transforming entry: {inner_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process JSON file: {e}")
            raise e

    # ---------------------------------------------------------
    # Scraping Logic (Async Crawl4AI)
    # ---------------------------------------------------------

    async def _scrape_blacklist(self) -> Dict[str, Any]:
        """Core scraping pipeline: Walk pages -> Parse -> Return Dict."""
        browser_config = BrowserConfig(headless=self.DEFAULT_HEADLESS)
        all_entries = []

        async with AsyncWebCrawler(config=browser_config) as crawler:
            # 1. Fetch First Page
            try:
                first_html = await self._fetch_html(crawler, page_no=1)
                first_doc = html.fromstring(first_html)
            except Exception as e:
                self.logger.error(f"Failed to fetch first page: {e}")
                return {}

            total_pages = self._detect_total_pages(first_doc)
            self.logger.info(f"Detected {total_pages} pages.")

            # Parse Page 1
            entries_page_1 = self._parse_table(first_doc)
            all_entries.extend(entries_page_1)

            # 2. Fetch Remaining Pages
            for page_no in range(2, total_pages + 1):
                try:
                    page_html = await self._fetch_html(crawler, page_no=page_no)
                    doc = html.fromstring(page_html)
                    entries = self._parse_table(doc)
                    
                    if not entries:
                        self.logger.warning(f"No entries on page {page_no}, stopping.")
                        break
                    
                    all_entries.extend(entries)
                    if page_no % 5 == 0:
                        self.logger.info(f"Processed {page_no}/{total_pages} pages...")
                        
                except Exception as exc:
                    self.logger.warning(f"Failed to fetch page {page_no}: {exc}")
                    continue

        return {
            "source_info": {
                "url": self.BASE_URL,
                "authority": "RPPA",
                "scraped_at": datetime.now(timezone.utc).isoformat(),
            },
            "entries": all_entries,
        }

    async def _fetch_html(self, crawler: AsyncWebCrawler, page_no: int) -> str:
        params = {"currentPageNo": page_no}
        url = f"{self.BASE_URL}?{urlencode(params)}"
        
        run_config = CrawlerRunConfig(cache_mode=CacheMode.BYPASS)
        result = await crawler.arun(url=url, config=run_config)

        if not getattr(result, "success", False):
            raise RuntimeError(f"Crawl failed for {url}")

        html_text = getattr(result, "html", None) or getattr(result, "cleaned_html", None)
        if not html_text:
            raise RuntimeError(f"Empty HTML from {url}")
        return html_text

    def _parse_table(self, doc: html.HtmlElement) -> List[Dict[str, Any]]:
        table_nodes = doc.xpath('//table[contains(@class, "article_table")]')
        if not table_nodes: return []

        rows = table_nodes[0].xpath(".//tbody/tr")
        entries = []

        for tr in rows:
            tds = tr.xpath("./td")
            if len(tds) < 6: continue

            index_text = self._normalize_space("".join(tds[0].xpath(".//text()")))
            company_text = self._normalize_space("".join(tds[1].xpath(".//text()")))
            owner_text = self._normalize_space("".join(tds[2].xpath(".//text()")))
            reason_text = self._normalize_space("".join(tds[3].xpath(".//text()")))
            start_date_text = self._normalize_space("".join(tds[4].xpath(".//text()")))
            end_date_text = self._normalize_space("".join(tds[5].xpath(".//text()")))

            entries.append({
                "index": index_text,
                "company_name": company_text,
                "owner_name": owner_text,
                "reason": reason_text,
                "sanction_start_date": start_date_text,
                "sanction_end_date": end_date_text,
            })
        return entries

    def _detect_total_pages(self, doc: html.HtmlElement) -> int:
        text_nodes = doc.xpath('//div[contains(@class,"pagination")]//p[contains(@class,"pagefuntion")]//text()')
        text = self._normalize_space(" ".join(text_nodes))
        
        match = re.search(r"page\s+(\d+)\s*/\s*(\d+)", text, flags=re.IGNORECASE)
        if match:
            return int(match.group(2))
        
        # Fallback
        pages = set()
        links = doc.xpath('//div[contains(@class,"pagination")]//a[contains(@onclick, "fn_pageview")]')
        for a in links:
            m = re.search(r"fn_pageview\((\d+)\)", a.get("onclick", ""))
            if m: pages.add(int(m.group(1)))
            
        return max(pages) if pages else 1

    # --- Helpers ---

    def _normalize_space(self, value: str) -> str:
        return " ".join(value.split()) if value else ""

    def _parse_rwandan_date(self, date_str: Optional[str]) -> Optional[str]:
        if not date_str: return None
        try:
            return datetime.strptime(date_str, "%d/%m/%Y").strftime("%Y-%m-%d")
        except ValueError:
            return None

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = UmucyoBlacklistScraper()
    asyncio.run(scraper.run(force=True))