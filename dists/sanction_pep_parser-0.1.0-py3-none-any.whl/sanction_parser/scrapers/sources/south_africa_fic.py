"""
src/sanction_parser/scrapers/sources/south_africa_fic.py

Scraper for South Africa Financial Intelligence Centre (FIC) Targeted Financial Sanctions.
Source: https://tfs.fic.gov.za/Pages/TFSListDownload
"""

import re
import logging
import asyncio
import xml.etree.ElementTree as ET
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional, List, Tuple

# Third-party
from playwright.async_api import async_playwright

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class SouthAfricaFICScraper(BaseSanctionScraper):
    """
    Scraper for South Africa FIC Sanctions (TFS).
    
    Source URL: https://tfs.fic.gov.za/Pages/TFSListDownload
    Format: XML (Dynamic Download)
    Filters: Individuals Only.
    """
    name = "South Africa FIC - TFS List"
    country = "South Africa"
    
    BASE_URL = "https://tfs.fic.gov.za/Pages/TFSListDownload"
    DATA_FILENAME = "south_africa_fic.xml"
    
    # Regex Constants
    REGEX_PASSPORT = re.compile(r"^[A-Z0-9-]{6,20}$")
    
    ALIAS_SPLITS = [
        "a.k.a.,", "f.k.a.,", "; ", "f.k.a,", "f.n.a.,",
        "Formerly known as,", " Good,", "Formerly Known As,",
        ", ", "Good", "Low"
    ]
    
    ADDRESS_SPLITS = [
        "Branch Office 1:", "Branch Office 2:", "Branch Office 3:",
        "v)", "iv)", "iii)", "ii)", "i)", "(Formerly located at)",
    ]

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Download XML using Playwright.
        """
        self.logger.info(f"Starting Playwright session for: {self.BASE_URL}")
        
        local_path = self.raw_dir / self.DATA_FILENAME

        async with async_playwright() as p:
            # Launch headless for production
            browser = await p.chromium.launch(headless=True, args=["--start-maximized"])
            context = await browser.new_context(accept_downloads=True, ignore_https_errors=True)
            page = await context.new_page()

            try:
                self.logger.info("Navigating to page...")
                await page.goto(self.BASE_URL, timeout=90000, wait_until="domcontentloaded")

                # The specific button for XML
                button_selector = "button:has-text('XML')"
                
                self.logger.info("Waiting for XML button...")
                await page.wait_for_selector(button_selector, timeout=30000)

                self.logger.info("Clicking download button...")
                
                async with page.expect_download(timeout=60000) as download_info:
                    await page.click(button_selector)

                download = await download_info.value
                await download.save_as(local_path)
                
                self.logger.info(f"Downloaded to: {local_path}")
                return local_path

            except Exception as e:
                self.logger.error(f"Playwright error: {e}")
                if local_path.exists():
                    local_path.unlink()
                return None
            finally:
                await browser.close()

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Parse XML -> Golden Profile.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            xml_files = list(raw_path.parent.glob("*.xml"))
            if not xml_files:
                self.logger.warning("No XML files found.")
                return
            target_file = xml_files[0]

        self.logger.info(f"Processing file: {target_file}")
        mapper = ProfileMapper()

        try:
            tree = ET.parse(target_file)
            root = tree.getroot()

            # The XML usually contains Table (Individuals) and Table1 (Entities)
            # We iterate both but filter by content
            tables_to_parse = [".//Table", ".//Table1"]
            
            for table_tag in tables_to_parse:
                for row_node in root.findall(table_tag):
                    try:
                        # Convert node to dict
                        data = {}
                        for child in row_node:
                            val = self._clean_text(child.text)
                            if val:
                                data[child.tag] = val

                        # 1. Entity Classification
                        full_name = data.get("FullName")
                        first_name = data.get("FirstName")
                        
                        entity_type = "LegalEntity"
                        name = "Unknown"
                        source_id = None

                        if full_name:
                            entity_type = "Individual"
                            name = full_name
                            source_id = data.get("IndividualID")
                        else:
                            entity_type = "LegalEntity"
                            name = first_name 
                            source_id = data.get("EntityID")

                        # Filter: Individuals Only
                        if entity_type != "Individual":
                            continue
                        
                        if not name:
                            continue

                        # 2. Extract Fields
                        dob = self._parse_fic_date(data.get("IndividualDateOfBirth"))
                        listing_date = self._parse_fic_date(data.get("ListedOn"))
                        nationality = data.get("Nationality")
                        designation = data.get("Designation") 
                        place_of_birth = data.get("IndividualPlaceOfBirth")
                        unsc_ref = data.get("ReferenceNumber")
                        comments = data.get("Comments")

                        # Addresses
                        addresses = []
                        raw_addr = data.get("IndividualAddress")
                        if raw_addr:
                            addresses = self._multi_split(raw_addr, self.ADDRESS_SPLITS)

                        # Aliases
                        aliases_list = []
                        raw_aliases = data.get("IndividualAlias")
                        if raw_aliases:
                            aliases_list = self._multi_split(raw_aliases, self.ALIAS_SPLITS)

                        # IDs
                        id_docs = []
                        raw_docs = data.get("IndividualDocument")
                        passports, ids = self._clean_passports(raw_docs)
                        for p in passports:
                            id_docs.append(f"Passport: {p}")
                        for i in ids:
                            id_docs.append(f"National ID: {i}")

                        # 3. Generate ID
                        unique_key = f"{source_id}_{name}_{listing_date}"
                        record_id = self.generate_uuid(unique_key)

                        # 4. Build Record
                        raw_record = {
                            "profile": {
                                "id": record_id,
                                "full_name": name,
                                "entity_type": "INDIVIDUAL",
                                "gender": None,
                                "date_of_birth": dob,
                                "nationality": nationality,
                                "is_active": True,
                                "aliases": aliases_list,
                                "images": [],
                                "addresses": addresses
                            },
                            "risk_events": [
                                {
                                    "type": "Sanction",
                                    "source_list": self.name,
                                    "authority": "South Africa Financial Intelligence Centre",
                                    "reason": f"UNSC Ref: {unsc_ref}" if unsc_ref else "TFS Listing",
                                    "date_listed": listing_date,
                                    "is_current": True,
                                    "risk_level": "High",
                                }
                            ],
                            "evidence": [
                                {
                                    "url": self.BASE_URL,
                                    "scraped_at": datetime.now().isoformat(),
                                    "raw_text_snippet": f"Source ID: {source_id} | Designation: {designation} | IDs: {id_docs}"
                                }
                            ]
                        }

                        # 5. Normalize & Yield
                        result = mapper.map_single_profile(raw_record)

                        yield result

                    except Exception as row_e:
                        self.logger.warning(f"Error parsing row: {row_e}")
                        continue

        except Exception as e:
            self.logger.error(f"Failed to process XML file: {e}")
            raise e

    # ---------------------------------------------------------
    # Helper Methods
    # ---------------------------------------------------------

    def _clean_text(self, text: Any) -> Optional[str]:
        if not text or text == "NA":
            return None
        return str(text).strip()

    def _multi_split(self, text: str, delimiters: List[str]) -> List[str]:
        if not text:
            return []
        pattern = '|'.join(map(re.escape, delimiters))
        parts = re.split(pattern, text)
        cleaned_parts = []
        for p in parts:
            p = p.strip().rstrip(",").strip()
            if p and not all(c in {"?", " "} for c in p):
                cleaned_parts.append(p)
        return list(set(cleaned_parts))

    def _clean_passports(self, text: str) -> Tuple[List[str], List[str]]:
        if not text:
            return [], []
        values = text.split(", ")
        passports = []
        ids = []
        is_id_context = False 

        for value in values:
            if not value: continue
            val_lower = value.lower()
            if "national identification number" in val_lower:
                is_id_context = True
                continue 
            elif "passport" in val_lower:
                is_id_context = False
                continue 
            
            if self.REGEX_PASSPORT.search(value):
                if is_id_context:
                    ids.append(value)
                else:
                    passports.append(value)
                is_id_context = False 
            else:
                passports.append(value)
                is_id_context = False
        return passports, ids

    def _parse_fic_date(self, date_str: str) -> Optional[str]:
        if not date_str or date_str == "NA":
            return None
        formats = ["%d/%m/%Y", "%Y-%m-%d", "%Y-%m-%dT%H:%M:%S"]
        for fmt in formats:
            try:
                return datetime.strptime(date_str.split('T')[0], fmt).strftime("%Y-%m-%d")
            except ValueError:
                continue
        return None

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = SouthAfricaFICScraper()
    asyncio.run(scraper.run(force=True))