"""
src/sanction_parser/scrapers/sources/taiwan_cib.py

Scraper for Taiwan Criminal Investigation Bureau (CIB) - Most Wanted.
Source: https://www.cib.npa.gov.tw/en/app/globalcase/list?module=globalcase&id=2160
"""

import json
import logging
import asyncio
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper
from sanction_parser.scrapers.utils.web_client import extract_download_links, get_request

# Initialize logger
logger = logging.getLogger(__name__)

class TaiwanCibScraper(BaseSanctionScraper):
    """
    Scraper for Taiwan CIB Most Wanted.
    
    Source URL: https://www.cib.npa.gov.tw/en/app/globalcase/list?module=globalcase&id=2160
    Format: JSON (via API endpoint construction)
    Type: Wanted (High Risk)
    """
    name = "Taiwan CIB - Most Wanted"
    country = "Taiwan"
    
    BASE_URL = "https://www.cib.npa.gov.tw/en/app/globalcase/list?module=globalcase&id=2160"
    TARGET_EXTS = ["json"]
    DATA_FILENAME = "cib_wanted.json"

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Download JSON data.
        Tries to find a link first, otherwise constructs the API endpoint.
        """
        self.logger.info(f"Scanning page for files: {self.BASE_URL}")
        
        # 1. Extract Links
        links = await asyncio.to_thread(extract_download_links, self.BASE_URL, exts=self.TARGET_EXTS)
        
        if not links:
            self.logger.info("No direct JSON links found. Constructing API endpoint...")
            # Construct API URL: https://.../list? -> https://.../json?
            json_endpoint = self.BASE_URL.replace("/list?", "/json?")
            links.append({
                "url": json_endpoint,
                "ext": "json",
                "text": "Constructed JSON Endpoint"
            })
        
        target_link = links[0]
        file_url = target_link['url']
        self.logger.info(f"Targeting URL: {file_url}")

        local_path = self.raw_dir / self.DATA_FILENAME

        def _download_task():
            response = get_request(file_url, stream=True, timeout=60)
            with open(local_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

        try:
            await asyncio.to_thread(_download_task)
            
            if local_path.exists() and local_path.stat().st_size > 0:
                return local_path
            
            self.logger.error("Downloaded file is empty.")
            return None

        except Exception as e:
            self.logger.error(f"Error downloading {file_url}: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform JSON to Golden Profile.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            # Fallback
            json_files = list(raw_path.parent.glob("*.json"))
            if not json_files:
                self.logger.warning("No JSON files found.")
                return
            target_file = json_files[0]

        self.logger.info(f"Transforming file: {target_file}")
        mapper = ProfileMapper()

        try:
            with open(target_file, 'r', encoding='utf-8') as f:
                try:
                    raw_data = json.load(f)
                except json.JSONDecodeError:
                    self.logger.error("File is not valid JSON.")
                    return
                
                # Normalize structure (list vs dict)
                if isinstance(raw_data, dict):
                    raw_data = [raw_data]
                elif not isinstance(raw_data, list):
                    self.logger.error("JSON structure is not a list or dict.")
                    return

                for row in raw_data:
                    try:
                        # 1. Names
                        chinese_name = row.get("subject", "").strip()
                        english_name = row.get("secSubject", "").strip()
                        
                        full_name = english_name if english_name else chinese_name
                        if not full_name:
                            continue

                        # 2. Details
                        id_number = row.get("idNumber", "").strip()
                        accusation = row.get("accusation", "").strip()
                        wanted_unit = row.get("pubUnitName", "Criminal Investigation Bureau")
                        poster_date = row.get("posterDate", "")

                        # 3. Images
                        images = []
                        raw_images = row.get("images", [])
                        if isinstance(raw_images, list):
                            for img in raw_images:
                                if isinstance(img, dict) and "fileurl" in img:
                                    images.append(img["fileurl"])

                        # 4. Generate ID
                        # Prefer ID number for uniqueness
                        unique_key = id_number if id_number else full_name
                        record_id = self.generate_uuid(unique_key)

                        # 5. Build Record
                        raw_record = {
                            "profile": {
                                "id": record_id,
                                "full_name": full_name,
                                "entity_type": "INDIVIDUAL",
                                "gender": None, 
                                "date_of_birth": None,
                                "nationality": "Taiwan", 
                                "is_active": True,
                                "aliases": [chinese_name] if chinese_name and chinese_name != full_name else [],
                                "images": images,
                                "addresses": []
                            },
                            "risk_events": [
                                {
                                    "type": "Wanted",
                                    "source_list": self.name,
                                    "authority": wanted_unit,
                                    "reason": accusation,
                                    "date_listed": poster_date,
                                    "is_current": True,
                                    "risk_level": "High"
                                }
                            ],
                            "evidence": [
                                {
                                    "url": self.BASE_URL,
                                    "scraped_at": datetime.now().isoformat(),
                                    "raw_text_snippet": json.dumps(row, ensure_ascii=False),
                                    "comments": f"ID Number: {id_number}" if id_number else ""
                                }
                            ]
                        }

                        # 6. Normalize & Yield
                        result = mapper.map_single_profile(raw_record)

                        yield result

                    except Exception as inner_e:
                        self.logger.warning(f"Error processing row: {inner_e}")
                        continue

        except Exception as e:
            self.logger.error(f"Failed to process JSON file: {e}")
            raise e

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = TaiwanCibScraper()
    asyncio.run(scraper.run(force=True))