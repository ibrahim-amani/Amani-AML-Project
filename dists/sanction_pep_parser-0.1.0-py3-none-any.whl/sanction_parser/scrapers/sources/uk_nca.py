"""
src/sanction_parser/scrapers/sources/uk_nca.py

Scrapes UK National Crime Agency (NCA) Most Wanted list.
Source: https://www.nationalcrimeagency.gov.uk/most-wanted
"""

import re
import json
import asyncio
import logging
import platform
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Iterator
from urllib.parse import urljoin

# Third-party
from bs4 import BeautifulSoup
from crawl4ai import AsyncWebCrawler, BrowserConfig, CrawlerRunConfig, CacheMode

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class NcaMostWantedScraper(BaseSanctionScraper):
    """
    Scraper for UK – NCA Most Wanted.
    
    Source URL: https://www.nationalcrimeagency.gov.uk/most-wanted
    Format: Web Scraping (Crawl4AI)
    Type: Wanted (High Risk)
    """
    name = "UK – NCA Most Wanted"
    country = "UK"
    
    BASE_URL = "https://www.nationalcrimeagency.gov.uk"
    LIST_URL = f"{BASE_URL}/most-wanted"
    DATA_FILENAME = "uk_nca.json"

    # Tuning
    CONCURRENCY = 6

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Scrape list page then profile pages via Crawl4AI.
        """
        self.logger.info(f"Starting extraction from: {self.LIST_URL}")
        
        # Windows loop policy fix
        if platform.system() == "Windows":
            asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

        local_path = self.raw_dir / self.DATA_FILENAME

        try:
            # Run Crawl4AI logic
            raw_data = await self._scrape_nca()
            
            if not raw_data or not raw_data.get("entries"):
                self.logger.warning("No entries scraped.")
                return None

            # Save Raw Data
            with open(local_path, "w", encoding="utf-8") as f:
                json.dump(raw_data, f, indent=2, ensure_ascii=False)
            
            return local_path

        except Exception as e:
            self.logger.error(f"Extraction failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform raw JSON to Golden Profile.
        """
        if not raw_path.exists():
            return

        self.logger.info(f"Transforming file: {raw_path}")
        mapper = ProfileMapper()

        try:
            with open(raw_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            source_info = data.get("source_info", {})
            scraped_at = source_info.get("generated_at", datetime.now(timezone.utc).isoformat())

            for entry in data.get("entries", []):
                try:
                    if "error" in entry and "name" not in entry: continue

                    full_name = entry.get("name", "Unknown")
                    
                    # 1. ID Generation
                    uid = self.generate_uuid(entry.get("profile_url") or full_name)

                    # 2. Status
                    status_text = entry.get("status", "").lower()
                    is_active = True
                    if "captured" in status_text or "expired" in status_text or "extradited" in status_text:
                        is_active = False

                    # 3. Build Record
                    mapped_record = {
                        "profile": {
                            "id": uid,
                            "full_name": full_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": entry.get("sex"),
                            "date_of_birth": None, # Often missing/range
                            "nationality": None,   # Ethnic appearance is not nationality
                            "is_active": is_active,
                            "aliases": [],
                            "images": [img for img in [entry.get("image_url"), entry.get("list_image_url")] if img],
                            "addresses": []
                        },
                        "risk_events": [
                            {
                                "type": "Wanted Person",
                                "source_list": self.name,
                                "authority": "National Crime Agency (UK)",
                                "reason": entry.get("crime") or entry.get("list_intro") or "Criminal Investigation",
                                "date_listed": None, 
                                "is_current": is_active,
                                "risk_level": "High"
                            }
                        ],
                        "evidence": [
                            {
                                "url": entry.get("profile_url"),
                                "scraped_at": scraped_at,
                                "raw_text_snippet": (
                                    f"Status: {entry.get('status')}. Location: {entry.get('location')}. "
                                    f"Summary: {entry.get('summary')}. "
                                    f"Ethnic Appearance: {entry.get('ethnic_appearance')}"
                                )
                            }
                        ]
                    }

                    # 4. Normalize & Yield
                    result = mapper.map_single_profile(mapped_record)

                    yield result

                except Exception as inner_e:
                    self.logger.warning(f"Error transforming entry: {inner_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process JSON file: {e}")
            raise e

    # ---------------------------------------------------------
    # Scraping Logic (Async Crawl4AI)
    # ---------------------------------------------------------

    async def _scrape_nca(self) -> Dict[str, Any]:
        """Core scraping pipeline."""
        browser_config = BrowserConfig(headless=True, verbose=False)
        run_config = CrawlerRunConfig()

        async with AsyncWebCrawler(config=browser_config) as crawler:
            # 1. Fetch List
            self.logger.info(f"Fetching list page: {self.LIST_URL}")
            list_res = await crawler.arun(url=self.LIST_URL, config=run_config)
            
            html_text = list_res.html or ""
            entries_basic = self._parse_list(html_text)
            self.logger.info(f"Found {len(entries_basic)} profiles.")

            # 2. Fetch Details Concurrently
            sem = asyncio.Semaphore(self.CONCURRENCY)
            detailed_entries = []

            async def process_one(idx: int, entry: Dict[str, Any]):
                url = entry["profile_url"]
                async with sem:
                    try:
                        if idx % 5 == 0:
                            self.logger.info(f"Scraping profile {idx}/{len(entries_basic)}...")
                        
                        res = await crawler.arun(url=url, config=run_config)
                        html_text = res.html or ""
                        prof = self._parse_profile(html_text, url)
                        
                        return {**prof, "list_image_url": entry.get("list_image_url"), "list_intro": entry.get("list_intro")}
                    except Exception as e:
                        self.logger.warning(f"Failed profile {url}: {e}")
                        return {**entry, "error": str(e)}

            tasks = [process_one(i, e) for i, e in enumerate(entries_basic, start=1)]
            detailed_entries = await asyncio.gather(*tasks)

        return {
            "source_info": {
                "name": self.name, "url": self.LIST_URL,
                "generated_at": datetime.now(timezone.utc).isoformat(),
            },
            "entries": detailed_entries,
        }

    def _parse_list(self, html_text: str) -> List[Dict[str, Any]]:
        soup = BeautifulSoup(html_text, "html.parser")
        records = []
        container = soup.select_one("div.blog.most-wanted-grid")
        if not container: return []

        for item in container.select("div.item"):
            h2_link = item.select_one("div.page-header h2 a")
            if not h2_link: continue
            
            name = self._clean_text(h2_link.get_text())
            href = h2_link.get("href")
            if not href: continue
            
            profile_url = urljoin(self.BASE_URL, href)
            img_tag = item.select_one("div.item-image img")
            list_image_url = urljoin(self.BASE_URL, img_tag["src"]) if img_tag and img_tag.get("src") else ""
            
            intro_div = item.select_one("div.intro-text")
            intro_text = self._clean_text(intro_div.get_text(" ")) if intro_div else ""

            records.append({
                "name": name,
                "profile_url": profile_url,
                "list_image_url": list_image_url,
                "list_intro": intro_text
            })
        
        # Dedup
        seen = set()
        deduped = []
        for r in records:
            if r["profile_url"] not in seen:
                seen.add(r["profile_url"])
                deduped.append(r)
        return deduped

    def _parse_profile(self, html_text: str, profile_url: str) -> Dict[str, Any]:
        soup = BeautifulSoup(html_text, "html.parser")
        data = {"profile_url": profile_url}
        root = soup.select_one("div.item-page.most-wanted-grid") or soup

        h2 = root.select_one("h2[itemprop='headline']")
        data["name"] = self._clean_text(h2.get_text()) if h2 else ""

        status_span = root.select_one("span.label")
        data["status"] = self._clean_text(status_span.get_text()) if status_span else ""

        img = root.select_one("figure.item-image img")
        if img and img.get("src"):
            data["image_url"] = urljoin(self.BASE_URL, img["src"])

        body_div = root.select_one("[itemprop='articleBody']")
        if body_div:
            p = body_div.find("p")
            data["summary"] = self._clean_text(p.get_text()) if p else self._clean_text(body_div.get_text(" "))

        # Key-Value Fields
        label_map = {
            "Location": "location", "Date of Incident": "date_of_incident",
            "Crime": "crime", "Sex": "sex", "Age Range": "age_range",
            "Height": "height", "Build": "build", "Ethnic Appearance": "ethnic_appearance",
        }

        for col in root.select("div.most-wanted-customfields"):
            for lbl in col.select("span.field-label"):
                label_text = self._clean_text(lbl.get_text()).rstrip(":").strip()
                val_span = lbl.find_next_sibling("span", class_="field-value")
                val = self._clean_text(val_span.get_text()) if val_span else ""
                
                key = label_map.get(label_text)
                if not key:
                    key = label_text.lower().replace(" ", "_").replace("-", "_")
                if key: data[key] = val

        return data

    def _clean_text(self, text: str) -> str:
        if not text: return ""
        return " ".join(text.replace("\xa0", " ").split())

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = NcaMostWantedScraper()
    asyncio.run(scraper.run(force=True))