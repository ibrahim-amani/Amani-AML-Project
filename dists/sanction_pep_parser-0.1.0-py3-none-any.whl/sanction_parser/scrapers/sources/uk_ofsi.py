"""
src/sanction_parser/scrapers/sources/uk_ofsi.py

Scrapes UK OFSI enforcement actions (financial sanctions).
Source: https://www.gov.uk/government/collections/enforcement-of-financial-sanctions
"""

import re
import json
import asyncio
import logging
import platform
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple, Iterator
from urllib.parse import urljoin

# Third-party
from bs4 import BeautifulSoup
from crawl4ai import AsyncWebCrawler, BrowserConfig, CrawlerRunConfig, CacheMode

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class UkOfsiEnforcementActionsScraper(BaseSanctionScraper):
    """
    Scraper for UK – OFSI Enforcement Actions.
    
    Source URL: https://www.gov.uk/government/collections/enforcement-of-financial-sanctions
    Format: Web Scraping (Crawl4AI + BS4)
    Type: Sanction (Enforcement Action)
    """
    name = "UK – OFSI Enforcement Actions"
    country = "UK"
    
    BASE_URL = "https://www.gov.uk"
    TARGET_URL = "https://www.gov.uk/government/collections/enforcement-of-financial-sanctions"
    DATA_FILENAME = "uk_ofsi_enforcement.json"

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Fetch page via Crawl4AI and parse enforcement actions table.
        """
        self.logger.info(f"Starting extraction from: {self.TARGET_URL}")
        
        # Windows loop policy fix
        if platform.system() == "Windows":
            asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

        local_path = self.raw_dir / self.DATA_FILENAME

        try:
            # 1. Fetch HTML
            html_content = await self._fetch_html_crawl4ai()
            
            # 2. Parse Actions
            actions = self._extract_actions_from_html(html_content)
            
            if not actions:
                self.logger.warning("No enforcement actions found.")
                return None

            self.logger.info(f"Extracted {len(actions)} enforcement actions.")

            # 3. Save Raw Data
            with open(local_path, "w", encoding="utf-8") as f:
                json.dump(actions, f, indent=2, ensure_ascii=False)
            
            return local_path

        except Exception as e:
            self.logger.error(f"Extraction failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform raw JSON to Golden Profile.
        """
        if not raw_path.exists():
            return

        self.logger.info(f"Transforming file: {raw_path}")
        mapper = ProfileMapper()

        try:
            with open(raw_path, "r", encoding="utf-8") as f:
                actions = json.load(f)

            for entry in actions:
                try:
                    name = entry.get("name")
                    if not name: continue

                    # 1. ID Generation
                    # Use notice URL + name for uniqueness
                    seed = f"{entry.get('notice_url')}_{name}"
                    uid = self.generate_uuid(seed)

                    # 2. Dates
                    date_listed = entry.get("date_iso")

                    # 3. Profile
                    mapped_record = {
                        "profile": {
                            "id": uid,
                            "full_name": name,
                            "entity_type": entry.get("entity_type", "ORGANIZATION").upper(),
                            "gender": None,
                            "date_of_birth": None,
                            "nationality": None, 
                            "is_active": True, # Enforcement records stay relevant
                            "aliases": [],
                            "images": [],
                            "addresses": []
                        },
                        "risk_events": [
                            {
                                "type": "Sanction", # Enforcement Action
                                "source_list": self.name,
                                "authority": "Office of Financial Sanctions Implementation (UK)",
                                "reason": f"{entry.get('reason', 'Financial Sanctions Breach')} ({entry.get('regulations', '')})",
                                "date_listed": date_listed,
                                "is_current": True,
                                "risk_level": "High"
                            }
                        ],
                        "evidence": [
                            {
                                "url": entry.get("notice_url") or entry.get("source_url"),
                                "scraped_at": datetime.now(timezone.utc).isoformat(),
                                "raw_text_snippet": (
                                    f"Penalty: {entry.get('penalty_raw')}. "
                                    f"Sector: {entry.get('sector')}. "
                                    f"Amount: {entry.get('penalty_amount_gbp')} GBP"
                                )
                            }
                        ]
                    }

                    # 4. Normalize & Yield
                    result = mapper.map_single_profile(mapped_record)
                    if "data" in result:
                        yield result["data"]
                    else:
                        yield result

                except Exception as inner_e:
                    self.logger.warning(f"Error transforming action: {inner_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process JSON file: {e}")
            raise e

    # ---------------------------------------------------------
    # Scraping Logic
    # ---------------------------------------------------------

    async def _fetch_html_crawl4ai(self) -> str:
        """Fetches page content using Crawl4AI."""
        browser_config = BrowserConfig(headless=True, verbose=False)
        run_config = CrawlerRunConfig(cache_mode=CacheMode.BYPASS)

        async with AsyncWebCrawler(config=browser_config) as crawler:
            result = await crawler.arun(url=self.TARGET_URL, config=run_config)
            
            html = getattr(result, "cleaned_html", None) or getattr(result, "html", None)
            if html: return html
            
            # Fallback to markdown conversion if HTML fails but markdown exists
            md = getattr(result, "markdown", "")
            if md: return md # Crude, but usually sufficient for simple extraction logic if parsing MD
            
            raise RuntimeError("No content returned from crawler.")

    def _extract_actions_from_html(self, html_content: str) -> List[Dict[str, Any]]:
        """Parses the specific 'govspeak' structure of the OFSI page."""
        soup = BeautifulSoup(html_content, "lxml")
        govspeak = soup.find("div", class_="govspeak") or soup
        
        actions = []

        for h3 in govspeak.find_all("h3"):
            link = h3.find("a")
            if not link: continue

            name = self._clean_text(link.get_text())
            if not name: continue

            anchor_id = h3.get("id")
            href = link.get("href")
            notice_url = urljoin(self.BASE_URL, href) if href else None

            # The details are usually in a table immediately following the H3
            table = h3.find_next_sibling("table")
            if not table: continue

            details = {}
            for tr in table.find_all("tr"):
                th = tr.find("th")
                td = tr.find("td")
                if not th or not td: continue
                key = self._clean_text(th.get_text()).lower()
                val = self._clean_text(td.get_text(" ", strip=True))
                details[key] = val

            date_raw = details.get("date")
            date_iso = self._parse_date(date_raw)
            penalty_raw = details.get("penalty")
            penalty_type, penalty_amount = self._parse_penalty(penalty_raw)

            actions.append({
                "anchor_id": anchor_id,
                "name": name,
                "entity_type": self._guess_entity_type(name),
                "sector": details.get("sector"),
                "penalty_raw": penalty_raw,
                "penalty_type": penalty_type,
                "penalty_amount_gbp": penalty_amount,
                "date_raw": date_raw,
                "date_iso": date_iso,
                "reason": details.get("reason"),
                "regulations": details.get("regulations"),
                "notice_url": notice_url,
                "source_url": self.TARGET_URL,
            })
        
        return actions

    # ---------------------------------------------------------
    # Parsing Helpers
    # ---------------------------------------------------------

    def _clean_text(self, s: Optional[str]) -> str:
        if not s: return ""
        return re.sub(r"\s+", " ", s.strip())

    def _guess_entity_type(self, name: str) -> str:
        name_lower = name.lower()
        org_keywords = ["limited", "ltd", "bank", "plc", "company", "services", "charities"]
        if any(k in name_lower for k in org_keywords):
            return "ORGANIZATION"
        return "INDIVIDUAL" # Default guess, mapper can refine

    def _parse_penalty(self, penalty_raw: Optional[str]) -> Tuple[Optional[str], Optional[float]]:
        if not penalty_raw: return None, None
        text = penalty_raw.lower()
        
        if "disclosure" in text: return "disclosure", None

        # "£ 30,000" or "£1m"
        match = re.search(r"£\s*([\d.,]+)\s*([mMkK])?", penalty_raw)
        if match:
            num_str = match.group(1).replace(",", "")
            unit = match.group(2)
            try:
                amount = float(num_str)
                if unit:
                    if unit.lower() == "m": amount *= 1_000_000
                    elif unit.lower() == "k": amount *= 1_000
                return "monetary", amount
            except: pass
        
        return "other", None

    def _parse_date(self, date_raw: Optional[str]) -> Optional[str]:
        if not date_raw: return None
        date_raw = self._clean_text(date_raw)
        for fmt in ("%d %B %Y", "%d %b %Y"):
            try:
                return datetime.strptime(date_raw, fmt).date().isoformat()
            except ValueError: continue
        return None

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = UkOfsiEnforcementActionsScraper()
    asyncio.run(scraper.run(force=True))