"""
src/sanction_parser/scrapers/sources/uk_parliament.py

Scrapes UK Parliament MPs (House of Commons) from:
https://members.parliament.uk/members/commons
"""

import re
import json
import asyncio
import logging
import platform
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple, Iterator
from urllib.parse import urljoin, urlencode

# Third-party
from lxml import html
from crawl4ai import AsyncWebCrawler, BrowserConfig, CrawlerRunConfig, CacheMode

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class UKParliamentMembersScraper(BaseSanctionScraper):
    """
    Scraper for UK – MPs (House of Commons).
    
    Source URL: https://members.parliament.uk/members/commons
    Format: Web Scraping (Crawl4AI + lxml)
    Type: PEP (Medium Risk)
    """
    name = "UK – MPs (House of Commons)"
    country = "UK"
    
    BASE_LIST_URL = "https://members.parliament.uk/members/commons"
    BASE_SITE_URL = "https://members.parliament.uk"
    DATA_FILENAME = "uk_parliament_mps.json"

    IMAGE_URL_RE = re.compile(r"background-image:\s*url\((.*?)\)", re.IGNORECASE)
    COLOR_RE = re.compile(r"border-color:\s*([^;]+);?", re.IGNORECASE)

    DEFAULT_HEADLESS = True

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Scrape all member pages via Crawl4AI.
        """
        self.logger.info(f"Starting extraction from: {self.BASE_LIST_URL}")
        
        # Windows loop policy fix
        if platform.system() == "Windows":
            asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

        local_path = self.raw_dir / self.DATA_FILENAME

        try:
            # Run scraping logic
            raw_data = await self._scrape_all_members()
            
            if not raw_data or not raw_data.get("members"):
                self.logger.warning("No members scraped.")
                return None

            # Save Raw Data
            with open(local_path, "w", encoding="utf-8") as f:
                json.dump(raw_data, f, indent=2, ensure_ascii=False)
            
            return local_path

        except Exception as e:
            self.logger.error(f"Extraction failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform raw JSON to Golden Profile.
        """
        if not raw_path.exists():
            return

        self.logger.info(f"Transforming file: {raw_path}")
        mapper = ProfileMapper()

        try:
            with open(raw_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            scraped_at = data.get("scraped_at", datetime.now(timezone.utc).isoformat())

            for member in data.get("members", []):
                try:
                    full_name = member.get("name")
                    if not full_name: continue

                    # 1. ID Generation
                    # Use member_id if available for stability
                    uid_seed = member.get("member_id") or full_name
                    uid = self.generate_uuid(uid_seed)

                    # 2. Details
                    party = member.get("party")
                    constituency = member.get("constituency")
                    
                    # 3. Build Record
                    mapped_record = {
                        "profile": {
                            "id": uid,
                            "full_name": full_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": None, 
                            "date_of_birth": None,
                            "nationality": "United Kingdom",
                            "is_active": True,
                            "aliases": [],
                            "images": [member.get("image_url")] if member.get("image_url") else [],
                            "addresses": []
                        },
                        "risk_events": [
                            {
                                "type": "PEP", 
                                "source_list": self.name,
                                "authority": "UK Parliament",
                                "reason": f"Member of Parliament for {constituency} ({party})",
                                "date_listed": None,
                                "is_current": True,
                                "risk_level": "Medium"
                            }
                        ],
                        "evidence": [
                            {
                                "url": member.get("profile_url") or self.BASE_LIST_URL,
                                "scraped_at": scraped_at,
                                "raw_text_snippet": (
                                    f"Name: {full_name}. Party: {party}. "
                                    f"Constituency: {constituency}. "
                                    f"ID: {member.get('member_id')}."
                                )
                            }
                        ]
                    }

                    # 4. Normalize & Yield
                    result = mapper.map_single_profile(mapped_record)
  
                    yield result

                except Exception as inner_e:
                    self.logger.warning(f"Error transforming member: {inner_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process JSON file: {e}")
            raise e

    # ---------------------------------------------------------
    # Scraping Logic (Async Crawl4AI)
    # ---------------------------------------------------------

    async def _scrape_all_members(self) -> Dict[str, Any]:
        """Core scraping pipeline."""
        browser_config = BrowserConfig(headless=self.DEFAULT_HEADLESS)
        all_members = []

        async with AsyncWebCrawler(config=browser_config) as crawler:
            # 1. Fetch First Page
            try:
                first_html = await self._fetch_page_html(crawler, 1)
                members_page_1, doc = self._parse_members_from_page(first_html)
                all_members.extend(members_page_1)
            except Exception as e:
                self.logger.error(f"Failed to fetch first page: {e}")
                return {}

            total_pages = self._parse_total_pages(doc)
            self.logger.info(f"Detected {total_pages} pages.")

            # 2. Fetch Remaining Pages
            for page in range(2, total_pages + 1):
                try:
                    html_text = await self._fetch_page_html(crawler, page)
                    members_page, _ = self._parse_members_from_page(html_text)
                    
                    if not members_page:
                        self.logger.warning(f"No members on page {page}, stopping.")
                        break
                    
                    all_members.extend(members_page)
                    if page % 5 == 0:
                        self.logger.info(f"Processed {page}/{total_pages} pages...")
                        
                except Exception as exc:
                    self.logger.warning(f"Failed to fetch page {page}: {exc}")
                    continue

        self.logger.info(f"Total members scraped: {len(all_members)}")
        
        return {
            "source_url": self.BASE_LIST_URL,
            "total": len(all_members),
            "members": all_members,
            "scraped_at": datetime.now(timezone.utc).isoformat()
        }

    async def _fetch_page_html(self, crawler: AsyncWebCrawler, page: int) -> str:
        url = f"{self.BASE_LIST_URL}?{urlencode({'page': page})}"
        
        run_config = CrawlerRunConfig(cache_mode=CacheMode.BYPASS)
        result = await crawler.arun(url=url, config=run_config)

        if not getattr(result, "success", False):
            raise RuntimeError(f"Crawl failed for {url}")

        html_text = getattr(result, "html", None) or getattr(result, "cleaned_html", None)
        if not html_text:
            raise RuntimeError(f"Empty HTML from {url}")
        return html_text

    def _parse_members_from_page(self, html_text: str) -> Tuple[List[Dict[str, Optional[str]]], html.HtmlElement]:
        doc = html.fromstring(html_text)
        members = []

        card_nodes = doc.xpath('//a[contains(@class,"card-member")]')
        for card in card_nodes:
            relative_url = (card.get("href", "") or "").strip()
            profile_url = urljoin(self.BASE_SITE_URL, relative_url)

            member_id = None
            parts = relative_url.strip("/").split("/")
            if len(parts) >= 2 and parts[0] == "member":
                member_id = parts[1]

            name_nodes = card.xpath('.//div[contains(@class,"primary-info")]/text()')
            name = name_nodes[0].strip() if name_nodes else None

            party_nodes = card.xpath('.//div[contains(@class,"secondary-info")]/text()')
            party = party_nodes[0].strip() if party_nodes else None

            const_nodes = card.xpath('.//div[contains(@class,"indicator-label")]/text()')
            constituency = const_nodes[0].strip() if const_nodes else None

            img_divs = card.xpath('.//div[contains(@class,"image")]')
            image_url = None
            party_color = None
            
            if img_divs:
                style_attr = img_divs[0].get("style", "") or ""
                image_url, party_color = self._extract_style_values(style_attr)
                if image_url and image_url.startswith("/"):
                    image_url = urljoin(self.BASE_SITE_URL, image_url)

            members.append({
                "member_id": member_id,
                "name": name,
                "party": party,
                "constituency": constituency,
                "profile_url": profile_url,
                "image_url": image_url,
                "party_color": party_color,
            })

        return members, doc

    def _parse_total_pages(self, doc: html.HtmlElement) -> int:
        strongs = doc.xpath('//div[contains(@class,"result-text")]//strong')
        if len(strongs) >= 3 and (strongs[2].text or "").strip().isdigit():
            return int(strongs[2].text.strip())
        return 1

    def _extract_style_values(self, style_str: str) -> Tuple[Optional[str], Optional[str]]:
        image_url = None
        color = None

        if style_str:
            m_img = self.IMAGE_URL_RE.search(style_str)
            if m_img:
                image_url = m_img.group(1).strip().strip('"').strip("'")

            m_color = self.COLOR_RE.search(style_str)
            if m_color:
                color = m_color.group(1).strip()

        return image_url, color

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = UKParliamentMembersScraper()
    asyncio.run(scraper.run(force=True))