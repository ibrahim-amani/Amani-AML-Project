"""
src/sanction_parser/scrapers/sources/ukraine_nsdc.py

Scraper for Ukraine National Security and Defense Council (NSDC) Sanctions.
Uses Botasaurus to bypass Cloudflare/Turnstile protection and download CSV.
"""

import logging
import asyncio
import pandas as pd
import shutil
import time
import os
from pathlib import Path
from datetime import datetime
from typing import Any, List, Dict, Optional, Iterator

# Botasaurus Imports
from botasaurus.browser import browser, Driver

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class UkraineNSDCScraper(BaseSanctionScraper):
    """
    Scraper for Ukraine NSDC Sanctions.
    Uses Botasaurus to bypass Cloudflare/Turnstile protection and download CSV.
    Strategy: Content Hashing via BaseSourceETL.
    """
    name = "Ukraine - NSDC Sanctions"
    country = "Ukraine"
    
    BASE_URL = "https://drs.nsdc.gov.ua/export/actions"
    DATA_FILENAME = "ukraine_nsdc_individuals.csv"

    # --- Helper Methods for Botasaurus Logic ---
    def _get_default_download_dir(self) -> Path:
        """Determines the default browser download directory."""
        candidates = [
            Path.home() / "Downloads",
            Path.home() / "Download",
        ]
        for p in candidates:
            if p.exists() and p.is_dir():
                return p
        return Path.home()

    def _list_files(self, dir_path: Path) -> set[str]:
        """Lists all files in a directory."""
        return {p.name for p in dir_path.iterdir() if p.is_file()}

    def _wait_for_new_download(self, download_dir: Path, before: set[str], timeout: int = 180) -> Path | None:
        """Waits for a new file to appear in the download directory."""
        start = time.time()
        while time.time() - start < timeout:
            now = self._list_files(download_dir)
            new_names = now - before

            candidates = []
            for name in new_names:
                # Ignore temporary download files
                if name.endswith((".crdownload", ".part", ".tmp")):
                    continue
                
                p = download_dir / name
                # Double check not partially downloaded
                if (download_dir / f"{name}.crdownload").exists():
                    continue
                if p.exists() and p.is_file():
                    candidates.append(p)

            if candidates:
                # Return the most recently modified file among candidates
                return max(candidates, key=lambda x: x.stat().st_mtime)

            time.sleep(1)
        return None

    # --- ETL Methods ---
    async def extract(self) -> Optional[Path]:
        """
        Step 1: Download data via Botasaurus (Browser Automation).
        """
        self.logger.info("Starting Botasaurus download process...")
        
        # Temp path for verification
        temp_file_path = self.raw_dir / f"{self.DATA_FILENAME}.tmp"
        local_file_path = self.raw_dir / self.DATA_FILENAME

        # --- Botasaurus Task Definition ---
        @browser(
            window_size=(1280, 720),
            headless=False,
            profile="nsdc_scraper_profile",
            block_images=False,
            output=None 
        )
        def scrape_task(driver: Driver, data):
            download_dir = self._get_default_download_dir()
            self.logger.info(f"Watching download dir: {download_dir}")

            driver.get(self.BASE_URL)
            self.logger.info("Navigating to site...")

            # Captcha / Cloudflare Handling
            if not driver.is_element_present(".download", wait=5):
                self.logger.info("Checking for Captcha...")
                cf_iframe = driver.select("iframe[src*='cloudflare'], iframe[src*='turnstile']", wait=5)
                if cf_iframe:
                    self.logger.info("Captcha found. Attempting to click...")
                    driver.switch_to.frame(cf_iframe)
                    checkbox = driver.select("input[type='checkbox'], .cb-lb, body", wait=2)
                    if checkbox:
                        driver.mouse_move_and_click(checkbox)
                    driver.switch_to.default_content()

            try:
                driver.wait_for_element(".download", wait=60)
                self.logger.info("Page loaded successfully!")
            except Exception:
                self.logger.warning("Page load timeout. Please solve captcha manually if present.")
                time.sleep(10)

            buttons = driver.select_all(".download .action button")
            self.logger.info(f"Found {len(buttons)} download buttons.")

            before = self._list_files(download_dir)
            target_downloaded_path = None

            # Iterate buttons to find the 'Individuals' list
            for i, btn in enumerate(buttons, start=1):
                text = (btn.text or "").strip().lower()
                self.logger.info(f"Clicking button #{i}: {text}")
                
                btn.click()
                
                file_path = self._wait_for_new_download(download_dir, before, timeout=60)
                
                if file_path:
                    self.logger.info(f"Downloaded: {file_path.name}")
                    # Check if it contains 'individual' in name (English or transliterated)
                    if "individual" in file_path.name.lower():
                        target_downloaded_path = file_path
                        break # Found it, stop clicking
                    
                    # Update 'before' set to ignore this file if we loop again
                    before = self._list_files(download_dir)
                else:
                    self.logger.warning(f"Download timeout for button #{i}")

            return target_downloaded_path

        # --- Execution of Botasaurus Task ---
        try:
            # Run the synchronous Botasaurus task
            downloaded_path = scrape_task() 
            
            if not downloaded_path or not downloaded_path.exists():
                self.logger.error("Failed to download Individuals CSV.")
                return None

            # Move to temp location for processing
            shutil.move(str(downloaded_path), str(temp_file_path))
            self.logger.info(f"Moved file to: {temp_file_path}")
            
            # Commit File (Replace old with new)
            if local_file_path.exists():
                os.remove(local_file_path)
            os.rename(temp_file_path, local_file_path)

            # --- التصحيح هنا: استخدام local_file_path بدلاً من local_path ---
            return local_file_path
            
        except Exception as e:
            if temp_file_path.exists():
                os.remove(temp_file_path)
            self.logger.error(f"Botasaurus task failed: {e}")
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform CSV to Golden Profile.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            # Fallback scan in parent folder
            csv_files = [p for p in raw_path.parent.glob("*.csv") if "individual" in p.name.lower()]
            if not csv_files:
                self.logger.warning("No CSV files found.")
                return
            # Use most recent file
            target_file = sorted(csv_files, key=lambda x: x.stat().st_mtime)[-1]

        self.logger.info(f"Processing file: {target_file}")
        mapper = ProfileMapper()
        
        try:
            # Read CSV as strings to preserve IDs
            df = pd.read_csv(target_file, dtype=str)
            df.columns = [str(col).strip() for col in df.columns]

            for _, row in df.iterrows():
                try:
                    full_name = str(row.get("name", "")).strip()
                    if not full_name or full_name.lower() == "nan":
                        continue

                    # Status Check
                    sanction_end = str(row.get("sanctions_end_date", "")).strip()
                    is_active = True
                    
                    if sanction_end and sanction_end.lower() != "nan":
                        try:
                            end_date_obj = datetime.strptime(sanction_end, "%Y-%m-%d")
                            if end_date_obj < datetime.now():
                                is_active = False 
                        except ValueError:
                            pass

                    # Aliases Construction
                    aliases = []
                    translit_name = str(row.get("translit_name", "")).strip()
                    if translit_name and translit_name.lower() != "nan":
                        aliases.append(translit_name)
                    
                    raw_aliases = str(row.get("aliases", "")).strip()
                    if raw_aliases and raw_aliases.lower() != "nan":
                        for a in raw_aliases.split(";"):
                            if a.strip(): aliases.append(a.strip())

                    # Dates
                    all_dob = str(row.get("birthdate", "")).strip()
                    dob = str(row.get("birthdate", "")).strip().split(',')[0]
                    if dob.lower() == "nan": dob = None
                    
                    decree_date = str(row.get("decree_date", "")).strip()
                    if decree_date.lower() == "nan": decree_date = None
                    
                    # Citizenship
                    citizenship_raw = str(row.get("citizenship", "")).strip()
                    if not citizenship_raw or citizenship_raw.lower() == "nan":
                        citizenship = []
                    else:
                        citizenship = [c.strip() for c in citizenship_raw.split(";") if c.strip()]

                    # Identifiers
                    id_docs = []
                    tax_id = str(row.get("tax_id", "")).strip()
                    if tax_id and tax_id.lower() != "nan":
                        id_docs.append(f"Tax ID: {tax_id}")
                    
                    raw_docs = str(row.get("identity_docs", "")).strip()
                    if raw_docs and raw_docs.lower() != "nan":
                        id_docs.append(f"Identity Docs: {raw_docs}")

                    sanction_reason = str(row.get("sanctions", "")).strip()
                    if sanction_reason.lower() == "nan": sanction_reason = "Sanctions Applied"

                    # Generate ID
                    unique_key = f"{full_name}_{dob}_{citizenship}"
                    record_id = self.generate_uuid(unique_key)

                    # Build Record
                    mapped_record = {
                        "profile": {
                            "id": record_id,
                            "full_name": full_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": None,
                            "date_of_birth": dob,
                            "nationality": citizenship[0] if citizenship else None,
                            "is_active": is_active, 
                            "aliases": aliases,
                            "images": [],
                            "addresses": []
                        },
                        "risk_events": [
                            {
                                "type": "Sanction",
                                "source_list": self.name,
                                "authority": "National Security and Defense Council of Ukraine",
                                "reason": sanction_reason[:500],
                                "date_listed": decree_date,
                                "is_current": is_active, 
                                "risk_level": "High",
                            }
                        ],
                        "evidence": [
                            {
                                "url": self.BASE_URL,
                                "scraped_at": datetime.now().isoformat(),
                                "raw_text_snippet": f"ID: {row.get('id')} | Decree: {row.get('decree')} | End: {sanction_end} | IDs: {', '.join(id_docs)}"
                            }
                        ]
                    }
                    
                    # Normalize & Yield
                    result = mapper.map_single_profile(mapped_record)

                    yield result

                except Exception as row_e:
                    self.logger.warning(f"Error parsing row: {row_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process CSV file: {e}")
            raise e

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = UkraineNSDCScraper()
    asyncio.run(scraper.run(force=True))