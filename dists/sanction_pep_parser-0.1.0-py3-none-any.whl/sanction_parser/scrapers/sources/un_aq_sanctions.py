"""
src/sanction_parser/scrapers/sources/un_aq_sanctions.py

Scraper for UN Security Council - ISIL (Da'esh) & Al-Qaida Sanctions List (1267/1989/2253).
Source: https://main.un.org/securitycouncil/en/sanctions/1267/aq_sanctions_list
"""

import re
import logging
import asyncio
import requests
import xml.etree.ElementTree as ET
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional, List, Tuple
from bs4 import BeautifulSoup

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper
from sanction_parser.scrapers.utils.web_client import get_request

# Initialize logger
logger = logging.getLogger(__name__)

class UNAlQaidaSanctionsScraper(BaseSanctionScraper):
    """
    Scraper for UN Security Council - ISIL & Al-Qaida Sanctions.
    
    Source URL: https://main.un.org/securitycouncil/en/sanctions/1267/aq_sanctions_list
    Format: XML (Dynamic Link)
    Strategy: Complex XML parsing with alias/document extraction.
    """
    name = "UN Security Council - ISIL & Al-Qaida Sanctions"
    country = "United Nations" # Global
    
    BASE_URL = "https://main.un.org/securitycouncil/en/sanctions/1267/aq_sanctions_list"
    DATA_FILENAME = "un_aq_sanctions.xml"
    
    REGEX_PASSPORT = re.compile(r"^[A-Z0-9-]{6,20}$")
    
    ALIAS_SPLITS = [
        "a.k.a.,", "f.k.a.,", "; ", "f.k.a,", "f.n.a.,",
        "Formerly known as,", " Good,", "Formerly Known As,",
        ", ", "Good", "Low"
    ]
    
    ADDRESS_SPLITS = [
        "Branch Office 1:", "Branch Office 2:", "Branch Office 3:",
        "v)", "iv)", "iii)", "ii)", "i)", "(Formerly located at)",
    ]

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Scrape the page for the XML link and download it.
        """
        self.logger.info(f"Scanning page for XML link: {self.BASE_URL}")
        
        # 1. Find Link
        def _find_link():
            try:
                # Use standard headers
                headers = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                }
                response = requests.get(self.BASE_URL, headers=headers, timeout=30)
                response.raise_for_status()
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # Look for XML link
                xml_link_tag = soup.find('a', string=lambda t: t and "XML" in t.upper(), class_="documentlinks")
                
                if not xml_link_tag:
                    # Fallback search by href extension
                    for a in soup.find_all('a', href=True):
                        if a['href'].lower().endswith('.xml'):
                            xml_link_tag = a
                            break
                            
                if not xml_link_tag:
                    return None

                xml_url = xml_link_tag['href']
                if not xml_url.startswith("http"):
                    xml_url = f"https://main.un.org{xml_url}" if xml_url.startswith("/") else xml_url
                return xml_url
            except Exception as e:
                self.logger.error(f"Link finding failed: {e}")
                return None

        xml_url = await asyncio.to_thread(_find_link)

        if not xml_url:
            self.logger.error("Could not find XML download link.")
            return None

        self.logger.info(f"Found XML URL: {xml_url}")
        
        local_path = self.raw_dir / self.DATA_FILENAME

        def _download_task():
            response = get_request(xml_url, stream=True, timeout=120)
            with open(local_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

        try:
            await asyncio.to_thread(_download_task)
            
            if local_path.exists() and local_path.stat().st_size > 0:
                return local_path
            return None

        except Exception as e:
            self.logger.error(f"Download failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Parse XML -> Golden Profile.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            xml_files = list(raw_path.parent.glob("*.xml"))
            if not xml_files:
                self.logger.warning("No XML files found.")
                return
            target_file = xml_files[0]

        self.logger.info(f"Processing XML file: {target_file}")
        mapper = ProfileMapper()

        try:
            tree = ET.parse(target_file)
            root = tree.getroot()

            # Process Individuals
            individuals_node = root.find("INDIVIDUALS")
            if individuals_node is not None:
                for ind in individuals_node.findall("INDIVIDUAL"):
                    yield from self._process_entity(ind, "Individual", mapper)

            # Process Entities
            entities_node = root.find("ENTITIES")
            if entities_node is not None:
                for ent in entities_node.findall("ENTITY"):
                    yield from self._process_entity(ent, "LegalEntity", mapper)

        except Exception as e:
            self.logger.error(f"Failed to parse XML: {e}")
            raise e

    def _process_entity(self, node: ET.Element, entity_type: str, mapper: ProfileMapper) -> Iterator[Dict[str, Any]]:
        try:
            # 1. Names
            first = self._get_xml_text(node, "FIRST_NAME")
            second = self._get_xml_text(node, "SECOND_NAME")
            third = self._get_xml_text(node, "THIRD_NAME")
            full_name = " ".join([p for p in [first, second, third] if p])
            
            if not full_name: return

            # 2. Identifiers
            data_id = self._get_xml_text(node, "DATAID")
            un_ref = self._get_xml_text(node, "REFERENCE_NUMBER")
            listed_on = self._get_xml_text(node, "LISTED_ON")
            comments = self._get_xml_text(node, "COMMENTS1")

            # 3. Lists
            titles = self._get_list_values(node, "TITLE")
            designations = self._get_list_values(node, "DESIGNATION")
            nationalities = self._get_list_values(node, "NATIONALITY")
            
            nationality_str = nationalities[0] if nationalities else None
            role_str = ", ".join(designations) if designations else "Sanctioned Entity"

            # 4. Aliases
            aliases = []
            orig_script = self._get_xml_text(node, "NAME_ORIGINAL_SCRIPT")
            if orig_script:
                aliases.append(orig_script)

            for alias_node in node.findall(f"{entity_type.upper()}_ALIAS"):
                name = self._get_xml_text(alias_node, "ALIAS_NAME")
                if name:
                    aliases.append(name)

            # 5. Specific Fields
            dob = None
            id_docs = []

            if entity_type == "Individual":
                dob = self._parse_dob(node)
                
                # Try structured docs first
                structured_docs = self._parse_documents(node)
                for doc in structured_docs:
                    id_docs.append(f"{doc['type']}: {doc['number']}")
                
                # Fallback to raw text
                if not id_docs:
                    doc_wrapper = node.find("INDIVIDUAL_DOCUMENT")
                    if doc_wrapper is not None and doc_wrapper.text:
                        passports, ids = self._clean_passports(doc_wrapper.text)
                        for p in passports: id_docs.append(f"Passport: {p}")
                        for i in ids: id_docs.append(f"National ID: {i}")

            # 6. Addresses
            addresses = []
            for addr in node.findall(f"{entity_type.upper()}_ADDRESS"):
                country = self._get_xml_text(addr, "COUNTRY")
                city = self._get_xml_text(addr, "CITY")
                note = self._get_xml_text(addr, "NOTE")
                
                addr_str = []
                if city: addr_str.append(city)
                if country: addr_str.append(country)
                
                if addr_str: addresses.append(", ".join(addr_str))
                
                if note:
                    addresses.extend(self._multi_split(note, self.ADDRESS_SPLITS))

            # 7. Generate ID
            unique_key = f"{data_id}_{un_ref}"
            record_id = self.generate_uuid(unique_key)

            # 8. Build Record
            raw_record = {
                "profile": {
                    "id": record_id,
                    "full_name": full_name,
                    "entity_type": "INDIVIDUAL" if entity_type == "Individual" else "FIRM",
                    "gender": None,
                    "date_of_birth": dob,
                    "nationality": nationality_str,
                    "is_active": True, 
                    "aliases": aliases,
                    "images": [],
                    "addresses": addresses
                },
                "risk_events": [
                    {
                        "type": "Sanction",
                        "source_list": self.name,
                        "authority": "United Nations Security Council",
                        "reason": f"{role_str} | Ref: {un_ref}",
                        "date_listed": listed_on,
                        "is_current": True,
                        "risk_level": "High",
                    }
                ],
                "evidence": [
                    {
                        "url": self.BASE_URL,
                        "scraped_at": datetime.now().isoformat(),
                        "raw_text_snippet": f"Data ID: {data_id} | Details: {comments[:200] if comments else ''} | IDs: {', '.join(id_docs)}"
                    }
                ]
            }
            
            # 9. Yield Result
            result = mapper.map_single_profile(raw_record)

            yield result

        except Exception as e:
            self.logger.warning(f"Error parsing entity {self._get_xml_text(node, 'DATAID')}: {e}")

    # ---------------------------------------------------------
    # Helper Methods
    # ---------------------------------------------------------

    def _get_xml_text(self, parent: ET.Element, tag: str) -> Optional[str]:
        if parent is None: return None
        node = parent.find(tag)
        if node is not None and node.text:
            cleaned = node.text.strip()
            return cleaned if cleaned else None
        return None

    def _get_list_values(self, parent: ET.Element, tag: str) -> List[str]:
        if parent is None: return []
        container = parent.find(tag)
        if container is None: return []
        return [v.text.strip() for v in container.findall("VALUE") if v.text]

    def _parse_dob(self, node: ET.Element) -> Optional[str]:
        dob_node = node.find("INDIVIDUAL_DATE_OF_BIRTH")
        if dob_node is None: return None
        
        date_type = self._get_xml_text(dob_node, "TYPE_OF_DATE")
        year = self._get_xml_text(dob_node, "YEAR")
        
        if date_type == "EXACT" and year:
            # Construct YYYY-MM-DD if possible? Usually only Year is reliably consistent in this tag
            # Or retrieve specific DATE sub-element if exists.
            date_node = dob_node.find("DATE")
            if date_node is not None and date_node.text:
                return date_node.text.strip()
            return year
        elif year:
            return f"{year}" # Approx
        return None

    def _parse_documents(self, node: ET.Element) -> List[Dict[str, str]]:
        docs = []
        for doc_node in node.findall("INDIVIDUAL_DOCUMENT"):
            doc_type = self._get_xml_text(doc_node, "TYPE_OF_DOCUMENT")
            number = self._get_xml_text(doc_node, "NUMBER")
            country = self._get_xml_text(doc_node, "ISSUING_COUNTRY")
            
            if number:
                docs.append({
                    "number": number,
                    "type": doc_type or "Unknown",
                    "country": country
                })
        return docs

    def _clean_passports(self, text: str) -> Tuple[List[str], List[str]]:
        if not text: return [], []
        values = text.split(", ")
        passports = []
        ids = []
        is_id_context = False
        for value in values:
            if not value: continue
            val_lower = value.lower()
            if "national identification number" in val_lower:
                is_id_context = True; continue 
            elif "passport" in val_lower:
                is_id_context = False; continue 
            
            if self.REGEX_PASSPORT.search(value):
                if is_id_context: ids.append(value)
                else: passports.append(value)
                is_id_context = False 
            else:
                passports.append(value)
                is_id_context = False
        return passports, ids

    def _multi_split(self, text: str, delimiters: List[str]) -> List[str]:
        if not text: return []
        pattern = '|'.join(map(re.escape, delimiters))
        parts = re.split(pattern, text)
        return list(set([p.strip().rstrip(",").strip() for p in parts if p.strip()]))

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = UNAlQaidaSanctionsScraper()
    asyncio.run(scraper.run(force=True))