"""
src/sanction_parser/scrapers/sources/un_consolidated.py

Scraper for UN Security Council Consolidated List (includes Taliban/1988 List).
Source: https://main.un.org/securitycouncil/en/sanctions/1988/materials
"""

import re
import logging
import asyncio
import requests
import xml.etree.ElementTree as ET
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional, List, Tuple
from bs4 import BeautifulSoup

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper
from sanction_parser.scrapers.utils.web_client import get_request

# Initialize logger
logger = logging.getLogger(__name__)

class UNSanctionsScraper(BaseSanctionScraper):
    """
    Scraper for UN Security Council Consolidated List.
    
    Source URL: https://main.un.org/securitycouncil/en/sanctions/1988/materials
    Format: XML (Dynamic Link)
    Type: Sanction (High Risk)
    """
    name = "UN Security Council - Consolidated List"
    country = "United Nations" # Global
    
    BASE_URL = "https://main.un.org/securitycouncil/en/sanctions/1988/materials"
    DATA_FILENAME = "un_sanctions.xml"
    
    # Regex Constants
    REGEX_PASSPORT = re.compile(r"^[A-Z0-9-]{6,20}$")
    
    ALIAS_SPLITS = [
        "a.k.a.,", "f.k.a.,", "; ", "f.k.a,", "f.n.a.,",
        "Formerly known as,", " Good,", "Formerly Known As,",
        ", ", "Good", "Low"
    ]
    
    ADDRESS_SPLITS = [
        "Branch Office 1:", "Branch Office 2:", "Branch Office 3:",
        "v)", "iv)", "iii)", "ii)", "i)", "(Formerly located at)",
    ]

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Scrape the page for the XML link and download it.
        """
        self.logger.info(f"Scanning page for XML link: {self.BASE_URL}")
        
        # 1. Find Link
        def _find_link():
            try:
                headers = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                }
                response = requests.get(self.BASE_URL, headers=headers, timeout=30)
                response.raise_for_status()
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # Try finding link with "Xml" text
                xml_link_tag = soup.find('a', string=re.compile(r"Xml", re.IGNORECASE))
                
                # Fallback: href ending in .xml
                if not xml_link_tag:
                    xml_link_tag = soup.find('a', href=re.compile(r"\.xml$", re.IGNORECASE))

                if not xml_link_tag:
                    return None

                xml_url = xml_link_tag['href']
                if not xml_url.startswith("http"):
                    xml_url = f"https://main.un.org{xml_url}" if xml_url.startswith("/") else xml_url
                
                return xml_url
            except Exception as e:
                self.logger.error(f"Link finding failed: {e}")
                return None

        xml_url = await asyncio.to_thread(_find_link)

        if not xml_url:
            self.logger.error("Could not find XML download link.")
            return None

        self.logger.info(f"Found XML URL: {xml_url}")
        
        local_path = self.raw_dir / self.DATA_FILENAME

        def _download_task():
            response = get_request(xml_url, stream=True, timeout=120)
            with open(local_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

        try:
            await asyncio.to_thread(_download_task)
            if local_path.exists() and local_path.stat().st_size > 0:
                return local_path
            return None
        except Exception as e:
            self.logger.error(f"Download failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Parse XML -> Golden Profile.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            xml_files = list(raw_path.parent.glob("*.xml"))
            if not xml_files:
                self.logger.warning("No XML files found.")
                return
            target_file = xml_files[0]

        self.logger.info(f"Processing XML file: {target_file}")
        mapper = ProfileMapper()

        try:
            tree = ET.parse(target_file)
            root = tree.getroot()

            # Process Individuals
            individuals_node = root.find("INDIVIDUALS")
            if individuals_node is not None:
                for ind in individuals_node.findall("INDIVIDUAL"):
                    yield from self._process_entity(ind, "Individual", mapper)

            # Process Entities
            entities_node = root.find("ENTITIES")
            if entities_node is not None:
                for ent in entities_node.findall("ENTITY"):
                    yield from self._process_entity(ent, "LegalEntity", mapper)

        except Exception as e:
            self.logger.error(f"Failed to parse XML: {e}")
            raise e

    def _process_entity(self, node: ET.Element, entity_type: str, mapper: ProfileMapper) -> Iterator[Dict[str, Any]]:
        try:
            # 1. Names
            first = self._get_xml_text(node, "FIRST_NAME")
            second = self._get_xml_text(node, "SECOND_NAME")
            third = self._get_xml_text(node, "THIRD_NAME")
            fourth = self._get_xml_text(node, "FOURTH_NAME")
            
            full_name = " ".join([p for p in [first, second, third, fourth] if p])
            if not full_name: return

            # 2. Identifiers
            data_id = self._get_xml_text(node, "DATAID")
            un_ref = self._get_xml_text(node, "REFERENCE_NUMBER")
            listed_on = self._get_xml_text(node, "LISTED_ON")
            comments = self._get_xml_text(node, "COMMENTS1")

            # 3. Lists
            designations = []
            title_node = node.find("TITLE")
            if title_node is not None:
                for val in title_node.findall("VALUE"):
                    if val.text: designations.append(val.text.strip())
            
            designation_node = node.find("DESIGNATION")
            if designation_node is not None:
                for val in designation_node.findall("VALUE"):
                    if val.text: designations.append(val.text.strip())

            nationality_str = None
            nat_node = node.find("NATIONALITY")
            if nat_node is not None:
                vals = nat_node.findall("VALUE")
                if vals and vals[0].text:
                    nationality_str = vals[0].text.strip()

            role_str = ", ".join(designations) if designations else "Sanctioned Entity"

            # 4. Aliases
            aliases = []
            orig_script = self._get_xml_text(node, "NAME_ORIGINAL_SCRIPT")
            if orig_script: aliases.append(orig_script)

            for alias_node in node.findall(f"{entity_type.upper()}_ALIAS"):
                alias_name = self._get_xml_text(alias_node, "ALIAS_NAME")
                if alias_name:
                    split_names = self._multi_split(alias_name, self.ALIAS_SPLITS)
                    aliases.extend(split_names)

            # 5. Specific Fields
            dob = None
            pob = None
            id_docs = []

            if entity_type == "Individual":
                # DOB
                dob_node = node.find("INDIVIDUAL_DATE_OF_BIRTH")
                if dob_node is not None:
                    year = self._get_xml_text(dob_node, "YEAR")
                    if year: dob = year # Often only year is available
                
                # POB
                pob_node = node.find("INDIVIDUAL_PLACE_OF_BIRTH")
                if pob_node is not None:
                    city = self._get_xml_text(pob_node, "CITY")
                    country = self._get_xml_text(pob_node, "COUNTRY")
                    pob = f"{city}, {country}" if city and country else (city or country)

                # Documents
                doc_wrapper = node.find("INDIVIDUAL_DOCUMENT")
                if doc_wrapper is not None and doc_wrapper.text:
                    passports, ids = self._clean_passports(doc_wrapper.text)
                    for p in passports: id_docs.append(f"Passport: {p}")
                    for i in ids: id_docs.append(f"National ID: {i}")

            # 6. Addresses
            addresses = []
            for addr_node in node.findall(f"{entity_type.upper()}_ADDRESS"):
                country = self._get_xml_text(addr_node, "COUNTRY")
                city = self._get_xml_text(addr_node, "CITY")
                street = self._get_xml_text(addr_node, "STREET")
                note = self._get_xml_text(addr_node, "NOTE")
                
                addr_parts = [p for p in [street, city, country] if p]
                if addr_parts: addresses.append(", ".join(addr_parts))
                
                if note:
                    addresses.extend(self._multi_split(note, self.ADDRESS_SPLITS))

            # 7. Generate ID
            unique_key = f"{data_id}_{un_ref}"
            record_id = self.generate_uuid(unique_key)

            # 8. Build Record
            raw_record = {
                "profile": {
                    "id": record_id,
                    "full_name": full_name,
                    "entity_type": "INDIVIDUAL" if entity_type == "Individual" else "FIRM",
                    "gender": None,
                    "date_of_birth": dob,
                    "nationality": nationality_str,
                    "is_active": True, 
                    "aliases": list(set(aliases)),
                    "images": [],
                    "addresses": list(set(addresses))
                },
                "risk_events": [
                    {
                        "type": "Sanction",
                        "source_list": self.name,
                        "authority": "United Nations Security Council",
                        "reason": f"{role_str} | Ref: {un_ref}",
                        "date_listed": listed_on,
                        "is_current": True,
                        "risk_level": "High",
                    }
                ],
                "evidence": [
                    {
                        "url": self.BASE_URL,
                        "scraped_at": datetime.now().isoformat(),
                        "raw_text_snippet": f"Data ID: {data_id} | POB: {pob} | IDs: {', '.join(id_docs)} | Details: {comments[:200] if comments else ''}"
                    }
                ]
            }
            
            # 9. Yield Result
            result = mapper.map_single_profile(raw_record)
            yield result

        except Exception as e:
            self.logger.warning(f"Error parsing entity {self._get_xml_text(node, 'DATAID')}: {e}")

    # ---------------------------------------------------------
    # Helper Methods
    # ---------------------------------------------------------

    def _get_xml_text(self, parent: ET.Element, tag: str) -> Optional[str]:
        if parent is None: return None
        node = parent.find(tag)
        if node is not None and node.text:
            cleaned = node.text.strip()
            return cleaned if cleaned else None
        return None

    def _multi_split(self, text: str, delimiters: List[str]) -> List[str]:
        if not text: return []
        pattern = '|'.join(map(re.escape, delimiters))
        parts = re.split(pattern, text)
        return list(set([p.strip().rstrip(",").strip() for p in parts if p.strip()]))

    def _clean_passports(self, text: str) -> Tuple[List[str], List[str]]:
        if not text: return [], []
        values = text.split(", ")
        passports = []
        ids = []
        is_id_context = False # State to track if we just saw "National ID" label

        for value in values:
            if not value: continue
            val_lower = value.lower()
            
            # Detect context labels
            if "national identification number" in val_lower or "national id" in val_lower:
                is_id_context = True; continue 
            elif "passport" in val_lower:
                is_id_context = False; continue 
            
            # Heuristic check
            if self.REGEX_PASSPORT.search(value):
                if is_id_context: ids.append(value)
                else: passports.append(value)
                # Reset context after capture usually? Or keep it? keeping it is safer for lists
            else:
                # If it doesn't match regex but is in a list, assume context holds
                if is_id_context: ids.append(value)
                else: passports.append(value)
                
        return passports, ids

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = UNSanctionsScraper()
    asyncio.run(scraper.run(force=True))