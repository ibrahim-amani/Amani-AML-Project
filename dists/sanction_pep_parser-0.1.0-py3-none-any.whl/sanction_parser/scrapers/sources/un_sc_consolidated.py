"""
src/sanction_parser/scrapers/sources/un_sc_consolidated.py

Scraper for UN Security Council Consolidated List.
Source: https://main.un.org/securitycouncil/en/content/un-sc-consolidated-list
"""

import logging
import asyncio
import requests
import xml.etree.ElementTree as ET
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional
from bs4 import BeautifulSoup

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper
from sanction_parser.scrapers.utils.web_client import get_request

# Initialize logger
logger = logging.getLogger(__name__)

class UNSCSanctionsScraper(BaseSanctionScraper):
    """
    Scraper for UN Security Council Consolidated List.
    
    Source URL: https://main.un.org/securitycouncil/en/content/un-sc-consolidated-list
    Format: XML (Dynamic Link)
    Type: Sanction (High Risk)
    """
    name = "UN Security Council - Consolidated List"
    country = "United Nations" # Global
    
    BASE_URL = "https://main.un.org/securitycouncil/en/content/un-sc-consolidated-list"
    DATA_FILENAME = "unsc_consolidated.xml"

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Scrape the page for the XML link and download it.
        """
        self.logger.info(f"Scanning page for XML files: {self.BASE_URL}")
        
        # 1. Find Link
        def _find_link():
            try:
                headers = {
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                }
                response = requests.get(self.BASE_URL, headers=headers, timeout=30)
                response.raise_for_status()
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # The UN page usually has a link with text "XML"
                xml_link_tag = soup.find('a', string=lambda t: t and "XML" in t.upper())
                
                if not xml_link_tag:
                    # Fallback: look for href ending in .xml or containing 'xml'
                    for a in soup.find_all('a', href=True):
                        if 'xml' in a['href'].lower():
                            xml_link_tag = a
                            break
                            
                if not xml_link_tag:
                    return None

                file_url = xml_link_tag['href']
                if not file_url.startswith("http"):
                    file_url = f"https://main.un.org{file_url}" if file_url.startswith("/") else file_url
                
                return file_url
            except Exception as e:
                self.logger.error(f"Link finding failed: {e}")
                return None

        file_url = await asyncio.to_thread(_find_link)

        if not file_url:
            self.logger.error("No XML download link found.")
            return None

        self.logger.info(f"Found XML URL: {file_url}")
        
        local_path = self.raw_dir / self.DATA_FILENAME

        def _download_task():
            response = get_request(file_url, stream=True, timeout=120)
            with open(local_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

        try:
            await asyncio.to_thread(_download_task)
            if local_path.exists() and local_path.stat().st_size > 0:
                return local_path
            return None
        except Exception as e:
            self.logger.error(f"Download failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Parse XML -> Golden Profile.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            xml_files = list(raw_path.parent.glob("*.xml"))
            if not xml_files:
                self.logger.warning("No XML files found.")
                return
            target_file = xml_files[0]

        self.logger.info(f"Processing XML file: {target_file}")
        mapper = ProfileMapper()

        try:
            tree = ET.parse(target_file)
            root = tree.getroot()
            individuals_node = root.find('INDIVIDUALS')
            
            if individuals_node is None:
                self.logger.warning("No INDIVIDUALS tag found in XML.")
                return

            for ind in individuals_node.findall('INDIVIDUAL'):
                try:
                    # 1. Names
                    name_parts = [
                        self._get_text(ind, 'FIRST_NAME'),
                        self._get_text(ind, 'SECOND_NAME'),
                        self._get_text(ind, 'THIRD_NAME'),
                        self._get_text(ind, 'FOURTH_NAME')
                    ]
                    full_name = " ".join([p for p in name_parts if p])
                    if not full_name:
                        continue

                    # 2. Identifiers
                    data_id = self._get_text(ind, 'DATAID')
                    ref_number = self._get_text(ind, 'REFERENCE_NUMBER')
                    
                    # 3. Personal Details
                    gender = self._get_text(ind, 'GENDER')
                    
                    # Nationality
                    nationalities = []
                    for nat in ind.findall('NATIONALITY'):
                        val = self._get_text(nat, 'VALUE')
                        if val: nationalities.append(val)
                    primary_nationality = nationalities[0] if nationalities else None

                    # DOB
                    dobs = []
                    for dob_node in ind.findall('INDIVIDUAL_DATE_OF_BIRTH'):
                        d = self._get_text(dob_node, 'DATE')
                        y = self._get_text(dob_node, 'YEAR')
                        if d: dobs.append(d)
                        elif y: dobs.append(y)
                    dob_final = dobs[0] if dobs else None

                    # Place of Birth
                    pob_node = ind.find('INDIVIDUAL_PLACE_OF_BIRTH')
                    place_of_birth = self._get_text(pob_node, 'COUNTRY') if pob_node is not None else None

                    # 4. Aliases
                    aliases = []
                    for alias_node in ind.findall('INDIVIDUAL_ALIAS'):
                        alias_name = self._get_text(alias_node, 'ALIAS_NAME')
                        quality = self._get_text(alias_node, 'QUALITY')
                        if alias_name:
                            aliases.append(alias_name) 

                    # 5. Sanction Details
                    un_list_type = self._get_text(ind, 'UN_LIST_TYPE')
                    listed_on = self._get_text(ind, 'LISTED_ON') 
                    comments = self._get_text(ind, 'COMMENTS1')
                    
                    # 6. Addresses
                    addresses = []
                    for addr in ind.findall('INDIVIDUAL_ADDRESS'):
                        country = self._get_text(addr, 'COUNTRY')
                        note = self._get_text(addr, 'NOTE')
                        city = self._get_text(addr, 'CITY')
                        
                        addr_parts = [p for p in [city, country, note] if p]
                        full_addr = ", ".join(addr_parts)
                        if full_addr: addresses.append(full_addr)

                    # 7. Generate ID
                    unique_key = f"UNSC_{data_id}_{ref_number}"
                    record_id = self.generate_uuid(unique_key)

                    # 8. Build Record
                    mapped_record = {
                        "profile": {
                            "id": record_id,
                            "full_name": full_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": gender,
                            "date_of_birth": dob_final,
                            "nationality": primary_nationality,
                            "is_active": True, 
                            "aliases": aliases,
                            "images": [],
                            "addresses": addresses
                        },
                        "risk_events": [
                            {
                                "type": "Sanction",
                                "source_list": self.name,
                                "authority": "United Nations Security Council",
                                "reason": f"UN List Type: {un_list_type}. Ref: {ref_number}", 
                                "date_listed": listed_on,
                                "is_current": True,
                                "risk_level": "Critical",
                            }
                        ],
                        "evidence": [
                            {
                                "url": self.BASE_URL,
                                "scraped_at": datetime.now().isoformat(),
                                "raw_text_snippet": f"DataID: {data_id} | Comments: {comments[:200] if comments else ''}"
                            }
                        ]
                    }
                    
                    # 9. Normalize & Yield
                    result = mapper.map_single_profile(mapped_record)
 
                    yield result

                except Exception as inner_e:
                    self.logger.warning(f"Error processing individual node: {inner_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to parse XML file: {e}")
            raise e

    def _get_text(self, element, tag, default=""):
        """Helper to safely extract text from a child element."""
        if element is None:
            return default
        child = element.find(tag)
        return child.text.strip() if child is not None and child.text else default

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = UNSCSanctionsScraper()
    asyncio.run(scraper.run(force=True))