"""
src/sanction_parser/scrapers/sources/uruguay_senaclaft.py

Scraper for Uruguay SENACLAFT - Politically Exposed Persons (PEP) List.
Source: https://www.gub.uy/.../lista-pep
"""

import re
import logging
import asyncio
import unicodedata
import openpyxl
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional, List, Generator

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper
from sanction_parser.scrapers.utils.web_client import extract_download_links, get_request

# Initialize logger
logger = logging.getLogger(__name__)

class UruguaySenaclaftExcelScraper(BaseSanctionScraper):
    """
    Scraper for Uruguay SENACLAFT - PEP List.
    
    Source URL: https://www.gub.uy/secretaria-nacional-lucha-contra-lavado-activos-financiamiento-terrorismo/comunicacion/publicaciones/lista-pep
    Format: Excel (Dynamic Header)
    Type: PEP (Medium Risk)
    """
    name = "Uruguay SENACLAFT - PEP List"
    country = "Uruguay"
    
    BASE_URL = "https://www.gub.uy/secretaria-nacional-lucha-contra-lavado-activos-financiamiento-terrorismo/comunicacion/publicaciones/lista-pep"
    TARGET_EXTS = ["xlsx", "xls"]
    DATA_FILENAME = "uruguay_pep.xlsx"

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Scrape the page for the Excel file and download it.
        """
        self.logger.info(f"Scanning page for Excel files: {self.BASE_URL}")
        
        # 1. Extract Links
        try:
            links = await asyncio.to_thread(extract_download_links, self.BASE_URL, exts=self.TARGET_EXTS)
        except Exception as e:
            self.logger.error(f"Link extraction failed: {e}")
            return None

        if not links:
            self.logger.warning("No Excel download links found.")
            return None

        # Prefer links with 'lista' and 'pep' in text
        target_link = None
        for link in links:
            text = link.get('text', '').lower()
            if "lista" in text and "pep" in text:
                target_link = link
                break
        
        if not target_link:
            target_link = links[0]

        file_url = target_link['url']
        ext = target_link.get('ext', 'xlsx')
        self.logger.info(f"Found file ({ext}): {file_url}")

        # Update filename based on extension
        self.DATA_FILENAME = f"uruguay_pep.{ext}"
        local_path = self.raw_dir / self.DATA_FILENAME

        def _download_task():
            response = get_request(file_url, stream=True, timeout=60)
            with open(local_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

        try:
            await asyncio.to_thread(_download_task)
            if local_path.exists() and local_path.stat().st_size > 0:
                return local_path
            return None
        except Exception as e:
            self.logger.error(f"Download failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform Excel to Golden Profile.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            xlsx_files = list(raw_path.parent.glob("*.xlsx")) + list(raw_path.parent.glob("*.xls"))
            if not xlsx_files:
                self.logger.warning("No Excel files found.")
                return
            target_file = xlsx_files[0]

        self.logger.info(f"Transforming Excel file: {target_file}")
        mapper = ProfileMapper()

        try:
            wb = openpyxl.load_workbook(target_file, read_only=True, data_only=True)
            sheet = wb.worksheets[0] 

            rows_generator = self._sheet_to_dicts(sheet)

            for row in rows_generator:
                try:
                    # Clean keys are slugified: 'c-i', 'nombre', 'cargo'
                    id_number = row.get("c-i") or row.get("c-i-")
                    person_name = row.get("nombre")
                    role = row.get("cargo")
                    organization = row.get("organismo")

                    if not person_name or not str(person_name).strip():
                        continue

                    id_number = str(id_number).strip() if id_number else ""
                    person_name = str(person_name).strip()
                    role = str(role).strip() if role else ""
                    organization = str(organization).strip() if organization else ""

                    # ID Generation
                    unique_str = f"{person_name}_{id_number}"
                    record_id = self.generate_uuid(unique_str)

                    # Build Record
                    mapped_record = {
                        "profile": {
                            "id": record_id,
                            "full_name": person_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": None,
                            "date_of_birth": None,
                            "nationality": "UY",
                            "is_active": True,
                            "aliases": [],
                            "images": [],
                            "addresses": []
                        },
                        "risk_events": [
                            {
                                "type": "PEP",
                                "source_list": self.name,
                                "authority": organization,
                                "reason": role,
                                "date_listed": datetime.now().strftime("%Y-%m-%d"),
                                "is_current": True,
                                "risk_level": "Medium"
                            }
                        ],
                        "evidence": [
                            {
                                "url": self.BASE_URL,
                                "scraped_at": datetime.now().isoformat(),
                                "raw_text_snippet": f"Role: {role} | Org: {organization} | ID: {id_number}",
                            }
                        ]
                    }
                    
                    # Normalize & Yield
                    result = mapper.map_single_profile(mapped_record)
 
                    yield result

                except Exception as inner_e:
                    self.logger.warning(f"Error processing row: {inner_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process Excel file: {e}")
            raise e

    # ---------------------------------------------------------
    # Helper Methods
    # ---------------------------------------------------------

    def _slugify(self, text: str) -> str:
        """Helper to clean headers."""
        if not text: return ""
        text = str(text).lower().strip()
        text = unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode('ascii')
        text = re.sub(r'[^\w\s-]', '-', text)
        text = re.sub(r'[-\s]+', '-', text).strip('-_')
        return text

    def _sheet_to_dicts(self, sheet) -> Generator[Dict[str, Any], None, None]:
        """Iterates over rows, finds the header dynamically, and yields row dicts."""
        headers: Optional[List[str]] = None
        
        for row in sheet.rows:
            cells = [c.value for c in row]
            clean_cells = [str(c).strip() if c else "" for c in cells]
            
            if headers is None:
                line_str = " ".join(clean_cells).lower()
                # Heuristic to find the header row
                if "nombre" in line_str and "cargo" in line_str:
                    headers = [self._slugify(h) for h in clean_cells if h]
                    continue
                else:
                    continue

            if headers:
                # Map headers to current row values
                current_cells = cells[:len(headers)]
                row_dict = dict(zip(headers, current_cells))
                yield row_dict

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = UruguaySenaclaftExcelScraper()
    asyncio.run(scraper.run(force=True))