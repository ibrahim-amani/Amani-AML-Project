"""
src/sanction_parser/scrapers/sources/us_bis_denied.py

Scraper for US Bureau of Industry and Security (BIS) - Denied Persons List (DPL).
"""

import os
import asyncio
import logging
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional

# Third-party
import pandas as pd
from playwright.async_api import async_playwright

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class BISDeniedPersonsScraper(BaseSanctionScraper):
    """
    Scraper for US BIS Denied Persons List (DPL).
    
    Source URL: https://www.bis.gov/licensing/end-user-guidance/denied-persons-list-dpl
    Format: CSV (Exported via dynamic JS button).
    """
    name = "US BIS - Denied Persons List"
    country = "USA"
    
    BASE_URL = "https://www.bis.gov/licensing/end-user-guidance/denied-persons-list-dpl"
    DATA_FILENAME = "bis_dpl.csv"
    
    async def extract(self) -> Optional[Path]:
        """
        Step 1: Download CSV via Playwright.
        The download link is often generated via JS, so a headless browser is safer.
        """
        self.logger.info(f"Starting Playwright extraction for: {self.BASE_URL}")
        
        local_path = self.raw_dir / self.DATA_FILENAME

        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            # Create context that accepts downloads
            context = await browser.new_context(accept_downloads=True)
            page = await context.new_page()

            try:
                self.logger.info("Navigating...")
                await page.goto(self.BASE_URL, timeout=60000, wait_until="domcontentloaded")

                self.logger.info("Searching for 'Export as CSV' button...")
                
                # Try multiple selector strategies
                download_locator = page.locator("a:has-text('Export as CSV')")
                if await download_locator.count() == 0:
                    download_locator = page.get_by_role("link", name="Export as CSV")
                
                if await download_locator.count() == 0:
                    # Fallback: look for generic CSV links
                    download_locator = page.locator("a[href$='.csv']")
                
                if await download_locator.count() == 0:
                    self.logger.error("Download button not found.")
                    return None

                # Trigger download
                async with page.expect_download(timeout=60000) as download_info:
                    await download_locator.first.click()

                download = await download_info.value
                
                # Save to raw_dir
                await download.save_as(local_path)
                self.logger.info(f"Downloaded to: {local_path}")
                
                return local_path

            except Exception as e:
                self.logger.error(f"Playwright download failed: {e}")
                if local_path.exists():
                    local_path.unlink()
                return None
            finally:
                await browser.close()

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform CSV to Golden Profile.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME

        if not target_file.exists():
            # Fallback scan
            csv_files = list(raw_path.parent.glob("*.csv"))
            if not csv_files:
                self.logger.warning("No CSV files found.")
                return
            target_file = csv_files[0]
        
        self.logger.info(f"Transforming file: {target_file}")
        mapper = ProfileMapper()
        
        try:
            # Handle encoding issues common in government files
            try:
                df = pd.read_csv(target_file, encoding='utf-8', on_bad_lines='skip')
            except UnicodeDecodeError:
                df = pd.read_csv(target_file, encoding='latin-1', on_bad_lines='skip')

            df.columns = df.columns.str.strip()

            for index, row in df.iterrows():
                try:
                    # 1. Parse Name & Address
                    # The field is often "Name_and_Address" combined
                    raw_combined = str(row.get("Name_and_Address", "")).strip()
                    
                    full_name = "Unknown"
                    address = None
                    
                    if raw_combined:
                        # Heuristic: Split on first comma? 
                        # Or usually it's "NAME, Address Part 1, Address Part 2"
                        parts = raw_combined.split(',', 1)
                        full_name = parts[0].strip()
                        if len(parts) > 1:
                            address = parts[1].strip()

                    # 2. Dates
                    effective_date = self._parse_date(row.get("Effective_Date"))
                    expiration_date = self._parse_date(row.get("Expiration_Date"))
                    
                    # 3. Status
                    is_active = True
                    if expiration_date:
                        try:
                            exp_dt = datetime.strptime(expiration_date, "%Y-%m-%d")
                            if exp_dt < datetime.now():
                                is_active = False
                        except ValueError:
                            pass 

                    # 4. Details
                    citation = str(row.get("Appropriate Federal Register Citations", "")).strip()
                    denial_type = str(row.get("Type of Denial", "")).strip()
                    
                    # 5. Generate ID
                    unique_key = f"{full_name}_{effective_date}"
                    record_id = self.generate_uuid(unique_key)

                    # 6. Build Record
                    raw_record = {
                        "profile": {
                            "id": record_id,
                            "full_name": full_name,
                            "entity_type": "INDIVIDUAL", # Defaulting to Individual, logic could be improved
                            "gender": None,
                            "date_of_birth": None, 
                            "nationality": None, 
                            "is_active": is_active,
                            "aliases": [],
                            "images": [],
                            "addresses": [address] if address else []
                        },
                        "risk_events": [
                            {
                                "type": "Sanction",
                                "source_list": self.name,
                                "authority": "US Bureau of Industry and Security (BIS)",
                                "reason": f"Type: {denial_type} | Citation: {citation}",
                                "date_listed": effective_date,
                                "is_current": is_active,
                                "risk_level": "High",
                            }
                        ],
                        "evidence": [
                            {
                                "url": self.BASE_URL,
                                "scraped_at": datetime.now().isoformat(),
                                "raw_text_snippet": f"Raw: {raw_combined} | Citation: {citation}",
                            }
                        ]
                    }

                    # 7. Normalize & Yield
                    result = mapper.map_single_profile(raw_record)
                    yield result

                except Exception as inner_e:
                    self.logger.warning(f"Error processing row {index}: {inner_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process CSV file: {e}")
            raise e

    # ---------------------------------------------------------
    # Helper Methods
    # ---------------------------------------------------------

    def _parse_date(self, date_str: Any) -> Optional[str]:
        """
        Parses US dates (M/D/Y) to YYYY-MM-DD.
        """
        if pd.isna(date_str) or str(date_str).strip() == "":
            return None
        
        clean_str = str(date_str).strip()
        formats = ["%m/%d/%Y", "%Y-%m-%d", "%d-%b-%y"]
        
        for fmt in formats:
            try:
                return datetime.strptime(clean_str, fmt).strftime("%Y-%m-%d")
            except ValueError:
                continue
                
        return None

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = BISDeniedPersonsScraper()
    asyncio.run(scraper.run(force=True))