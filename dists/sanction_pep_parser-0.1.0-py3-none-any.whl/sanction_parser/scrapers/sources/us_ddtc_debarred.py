"""
src/sanction_parser/scrapers/sources/us_ddtc_debarred.py

Scraper for US State Department - DDTC Statutory Debarred Parties List.
"""

import re
import csv
import logging
import asyncio
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional, List

# Third-party
from playwright.async_api import async_playwright

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class DdtcDebarredPartiesScraper(BaseSanctionScraper):
    """
    Scraper for US DDTC Statutory Debarred Parties.
    
    Source URL: https://www.pmddtc.state.gov/ddtc_public?id=ddtc_kb_article_page&sys_id=c22d1833dbb8d300d0a370131f9619f0
    Format: CSV (via Browser Interaction)
    Filters: Individuals only (based on presence of DOB).
    """
    name = "US DDTC - Statutory Debarred Parties"
    country = "USA"
    
    BASE_URL = "https://www.pmddtc.state.gov/ddtc_public?id=ddtc_kb_article_page&sys_id=c22d1833dbb8d300d0a370131f9619f0"
    DATA_FILENAME = "ddtc_debarred_parties.csv"

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Download CSV via Playwright.
        """
        self.logger.info(f"Launching Browser to fetch: {self.BASE_URL}")
        
        local_path = self.raw_dir / self.DATA_FILENAME

        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            page = await browser.new_page()

            try:
                await page.goto(self.BASE_URL, timeout=60000, wait_until="domcontentloaded")
                
                self.logger.info("Waiting for page content...")
                try:
                    # Wait for download link to appear
                    await page.wait_for_selector("a[href*='.csv'], a:has-text('CSV')", timeout=30000)
                except Exception:
                    self.logger.warning("Timeout waiting for CSV selector. Attempting search anyway...")

                # Find the download link
                download_locator = page.locator("a[href*='.csv' i]")
                
                if await download_locator.count() == 0:
                    self.logger.info("No href ending in .csv found, searching by text...")
                    download_locator = page.locator("a:has-text('CSV')")

                if await download_locator.count() == 0:
                    self.logger.error("Could not locate a CSV download link on the page.")
                    return None

                self.logger.info("Clicking download link...")
                async with page.expect_download(timeout=60000) as download_info:
                    await download_locator.first.click()

                download = await download_info.value
                
                await download.save_as(local_path)
                self.logger.info(f"Downloaded to: {local_path}")
                
                return local_path

            except Exception as e:
                self.logger.error(f"Browser automation failed: {e}")
                if local_path.exists():
                    local_path.unlink()
                return None
            finally:
                await browser.close()

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform CSV to Golden Profile.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            csv_files = list(raw_path.parent.glob("*.csv"))
            if not csv_files:
                self.logger.warning("No CSV files found.")
                return
            target_file = csv_files[0]

        self.logger.info(f"Transforming file: {target_file}")
        mapper = ProfileMapper()

        try:
            # encoding='utf-8-sig' to handle potential BOM
            with open(target_file, 'r', encoding='utf-8-sig', errors='replace') as f:
                reader = csv.DictReader(f)
                
                for row in reader:
                    try:
                        # --- 1. FILTER: Individuals Only ---
                        # If Date Of Birth is empty, it's likely a company.
                        dob_raw = row.get("Date Of Birth", "")
                        dob_parsed = self._parse_ddtc_dob(dob_raw)

                        if not dob_parsed:
                            continue 

                        # --- 2. Extract Data ---
                        raw_name = row.get("Party Name", "").strip()
                        if not raw_name:
                            continue

                        aliases = []
                        main_name = raw_name
                        
                        # Extract aliases: "John Doe (a.k.a. Johnny)"
                        alias_match = re.search(r'\((?:a\.?k\.?a\.?|also known as)\s*(.*?)\)', raw_name, re.IGNORECASE)
                        if alias_match:
                            alias_text = alias_match.group(1)
                            main_name = re.sub(r'\s*\(.*?\)', '', raw_name).strip()
                            # Split multiple aliases
                            aliases = [a.strip() for a in alias_text.replace(';', ',').split(',') if a.strip()]

                        # Date listed parsing
                        notice_date = row.get("Notice Date", "")
                        federal_register = row.get("Federal Register Notice", "")
                        
                        date_listed = self._parse_ddtc_date(notice_date)

                        # --- 3. Generate ID ---
                        unique_key = f"{main_name}_{dob_parsed}"
                        record_id = self.generate_uuid(unique_key)

                        # --- 4. Build Record ---
                        raw_record = {
                            "profile": {
                                "id": record_id,
                                "full_name": main_name,
                                "entity_type": "INDIVIDUAL",
                                "gender": None, 
                                "date_of_birth": dob_parsed,
                                "nationality": None, 
                                "is_active": True,
                                "aliases": aliases,
                                "images": [],
                                "addresses": []
                            },
                            "risk_events": [
                                {
                                    "type": "Sanction",
                                    "source_list": self.name,
                                    "authority": "US Department of State (DDTC)",
                                    "reason": "Statutory Debarment (Arms Export Control Act)",
                                    "date_listed": date_listed,
                                    "is_current": True,
                                    "risk_level": "High"
                                }
                            ],
                            "evidence": [
                                {
                                    "url": self.BASE_URL,
                                    "scraped_at": datetime.now().isoformat(),
                                    "raw_text_snippet": f"Raw Name: {raw_name} | Fed Register: {federal_register}"
                                }
                            ]
                        }

                        # --- 5. Normalize & Yield ---
                        result = mapper.map_single_profile(raw_record)

                        yield result

                    except Exception as inner_e:
                        self.logger.warning(f"Error processing row: {inner_e}")
                        continue

        except Exception as e:
            self.logger.error(f"Failed to read CSV file: {e}")
            raise e

    # ---------------------------------------------------------
    # Helper Methods
    # ---------------------------------------------------------

    def _parse_ddtc_dob(self, date_str: str) -> Optional[str]:
        """
        Parses DOBs like 'November, 1975', '1975', or '11/20/1975'.
        """
        if not date_str:
            return None
        
        date_str = date_str.strip()
        if not date_str: return None
        
        # Format: "November, 1975" -> "1975-11"
        try:
            dt = datetime.strptime(date_str, "%B, %Y")
            return dt.strftime("%Y-%m")
        except ValueError:
            pass
            
        # Format: "11/20/1975"
        try:
            dt = datetime.strptime(date_str, "%m/%d/%Y")
            return dt.strftime("%Y-%m-%d")
        except ValueError:
            pass

        # Format: "1975"
        if len(date_str) == 4 and date_str.isdigit():
            return date_str
            
        return None 

    def _parse_ddtc_date(self, date_str: str) -> Optional[str]:
        """Parses MM/DD/YYYY notice dates."""
        if not date_str: return None
        try:
            dt = datetime.strptime(date_str.strip(), "%m/%d/%Y")
            return dt.strftime("%Y-%m-%d")
        except ValueError:
            return None

if __name__ == "__main__":
    import sys
    # Windows specific fix for Playwright asyncio loop
    if sys.platform == 'win32':
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

    logging.basicConfig(level=logging.INFO)
    scraper = DdtcDebarredPartiesScraper()
    asyncio.run(scraper.run(force=True))