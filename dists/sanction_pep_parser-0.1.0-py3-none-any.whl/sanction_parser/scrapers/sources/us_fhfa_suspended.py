"""
src/sanction_parser/scrapers/sources/us_fhfa_suspended.py

Scraper for Federal Housing Finance Agency (FHFA) Suspended Counterparty Program.
"""

import os
import logging
import asyncio
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional, List

# Third-party
import pandas as pd

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper
from sanction_parser.scrapers.utils.web_client import extract_download_links, get_request

# Initialize logger
logger = logging.getLogger(__name__)

class FhfaSuspendedScraper(BaseSanctionScraper):
    """
    Scraper for FHFA Suspended Counterparty Program.
    
    Source URL: https://www.fhfa.gov/regulation/suspended-counterparty-program
    Format: XLSX or CSV (Dynamic Link)
    """
    name = "FHFA - Suspended Counterparty Program"
    country = "USA"
    
    BASE_URL = "https://www.fhfa.gov/regulation/suspended-counterparty-program"
    # Placeholder filename, will be updated based on extension
    DATA_FILENAME = "fhfa_suspended.xlsx" 
    TARGET_EXTS = ["xlsx", "xls", "csv"]

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Find the latest file link and download it.
        """
        self.logger.info(f"Scanning page for files: {self.BASE_URL}")
        
        # 1. Extract Links
        try:
            links = await asyncio.to_thread(extract_download_links, self.BASE_URL, exts=self.TARGET_EXTS)
        except Exception as e:
            self.logger.error(f"Extraction failed: {e}")
            return None

        if not links:
            self.logger.warning("No download links found.")
            return None

        # Logic to pick the best link
        target_link = None
        for link in links:
            text = link.get('text', '').lower()
            if "suspended" in text or "list" in text or "spreadsheet" in text:
                target_link = link
                break
        
        if not target_link:
            # Fallback to the first valid file link
            target_link = links[0]

        file_url = target_link['url']
        ext = target_link.get('ext', 'xlsx')
        
        # Update filename based on actual extension
        self.DATA_FILENAME = f"fhfa_suspended.{ext}"
        local_path = self.raw_dir / self.DATA_FILENAME

        self.logger.info(f"Target file ({ext}): {file_url}")

        def _download_task():
            response = get_request(file_url, stream=True, timeout=60)
            with open(local_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

        try:
            await asyncio.to_thread(_download_task)
            
            if local_path.exists() and local_path.stat().st_size > 0:
                return local_path
            return None

        except Exception as e:
            self.logger.error(f"Failed to download file: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Parse Excel/CSV -> Golden Profile.
        """
        # Ensure we are targeting the right file
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        # Fallback if filename changed (e.g., xlsx vs csv)
        if not target_file.exists():
            files = list(raw_path.parent.glob("*.xls*")) + list(raw_path.parent.glob("*.csv"))
            if not files:
                self.logger.warning(f"No compatible files found in {raw_path.parent}.")
                return
            target_file = files[0]

        self.logger.info(f"Transforming file: {target_file}")
        mapper = ProfileMapper()

        try:
            # Read Data
            if target_file.suffix in ['.xlsx', '.xls', '.xlsm']:
                df = pd.read_excel(target_file)
            else:
                df = pd.read_csv(target_file)

            # Normalize headers
            df.columns = [str(c).strip().replace(' ', '_') for c in df.columns]
            df = df.fillna("") 

            for _, row in df.iterrows():
                try:
                    # 1. Entity Resolution
                    first_name = str(row.get("First_Name", "")).strip()
                    last_name = str(row.get("Last_Name", "")).strip()
                    company = str(row.get("Company", "")).strip()
                    
                    full_name = ""
                    entity_type = "INDIVIDUAL" 

                    if company:
                        full_name = company
                        entity_type = "FIRM"
                        if first_name or last_name:
                            full_name = f"{company} (Related: {first_name} {last_name})"
                    else:
                        full_name = f"{first_name} {last_name}".strip()

                    if not full_name:
                        continue 

                    # 2. Address Construction
                    city = str(row.get("City", "")).strip()
                    state = str(row.get("State", "")).strip()
                    
                    address_parts = [p for p in [city, state] if p] 
                    full_address = ", ".join(address_parts)
                    
                    # 3. Dates
                    eff_date_str = str(row.get("Effective_Date", ""))
                    end_date_str = str(row.get("Suspension_End_Date", "")).strip()
                    
                    date_listed = None
                    try:
                        if isinstance(row.get("Effective_Date"), (pd.Timestamp, datetime)):
                             date_listed = row.get("Effective_Date").strftime("%Y-%m-%d")
                        elif eff_date_str:
                             dt = pd.to_datetime(eff_date_str)
                             date_listed = dt.strftime("%Y-%m-%d")
                    except:
                        pass 

                    # 4. Status
                    is_active = True
                    is_indefinite = "indefinite" in end_date_str.lower()
                    
                    if not is_indefinite and end_date_str:
                        try:
                            end_dt = pd.to_datetime(end_date_str)
                            if end_dt < datetime.now():
                                is_active = False
                        except:
                            pass

                    # 5. Details
                    order_link = row.get("Order_Link", "")

                    # 6. Generate ID
                    unique_key = f"{full_name}_{eff_date_str}_{city}"
                    record_id = self.generate_uuid(unique_key)

                    # 7. Build Record
                    raw_record = {
                        "profile": {
                            "id": record_id,
                            "full_name": full_name,
                            "entity_type": entity_type,
                            "gender": None,
                            "date_of_birth": None,
                            "nationality": "US" if state else None, 
                            "is_active": is_active,
                            "aliases": [],
                            "images": [],
                            "addresses": [full_address] if full_address else [],
                        },
                        "risk_events": [
                            {
                                "type": "Sanction",
                                "source_list": self.name,
                                "authority": "Federal Housing Finance Agency (FHFA)",
                                "reason": "Suspended Counterparty",
                                "date_listed": date_listed,
                                "is_current": is_active,
                                "risk_level": "High",
                            }
                        ],
                        "evidence": [
                            {
                                "url": self.BASE_URL,
                                "scraped_at": datetime.now().isoformat(),
                                "raw_text_snippet": f"End Date: {end_date_str} | Order PDF: {order_link}"
                            }
                        ]   
                    }

                    # 8. Normalize & Yield
                    result = mapper.map_single_profile(raw_record)

                    yield result

                except Exception as inner_e:
                    self.logger.warning(f"Error processing row: {inner_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to read file {target_file}: {e}")
            raise e

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = FhfaSuspendedScraper()
    asyncio.run(scraper.run(force=True))