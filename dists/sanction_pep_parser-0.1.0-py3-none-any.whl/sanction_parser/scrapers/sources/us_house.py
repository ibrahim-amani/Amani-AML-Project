"""
src/sanction_parser/scrapers/sources/us_house.py

US House of Representatives scraper.
Source: https://www.house.gov/representatives
"""

import re
import json
import asyncio
import logging
import requests
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Iterator
from urllib.parse import urljoin

# Third-party
from lxml import html

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class USHouseRepresentativesScraper(BaseSanctionScraper):
    """
    Scraper for US House of Representatives.
    
    Source URL: https://www.house.gov/representatives
    Format: Web Scraping (Requests + lxml)
    Type: PEP (High Risk)
    """
    name = "US – House of Representatives"
    country = "US"
    
    BASE_URL = "https://www.house.gov/representatives"
    DATA_FILENAME = "us_house_representatives.json"

    HEADERS = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0.0.0 Safari/537.36"
        )
    }

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Fetch and parse the representatives table.
        """
        self.logger.info(f"Starting extraction from: {self.BASE_URL}")
        local_path = self.raw_dir / self.DATA_FILENAME

        try:
            # Run sync logic in thread
            raw_data = await asyncio.to_thread(self._scrape_sync)
            
            if not raw_data or not raw_data.get("entries"):
                self.logger.warning("No representatives scraped.")
                return None

            # Save Raw Data
            with open(local_path, "w", encoding="utf-8") as f:
                json.dump(raw_data, f, indent=2, ensure_ascii=False)
            
            return local_path

        except Exception as e:
            self.logger.error(f"Extraction failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform raw JSON to Golden Profile.
        """
        if not raw_path.exists():
            return

        self.logger.info(f"Transforming file: {raw_path}")
        mapper = ProfileMapper()

        try:
            with open(raw_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            scraped_at = data.get("source", {}).get("run_at", datetime.now(timezone.utc).isoformat())

            for entry in data.get("entries", []):
                try:
                    raw_name = entry.get("name", "")
                    if not raw_name: continue

                    # 1. Name Formatting (Last, First -> First Last)
                    full_name = raw_name
                    if "," in raw_name:
                        parts = raw_name.split(",", 1)
                        if len(parts) == 2:
                            full_name = f"{parts[1].strip()} {parts[0].strip()}"

                    # 2. ID Generation
                    uid = self.generate_uuid(full_name)

                    # 3. Party
                    party_code = entry.get("party", "")
                    party_map = {"R": "Republican", "D": "Democrat", "I": "Independent"}
                    party_full = party_map.get(party_code, party_code)

                    # 4. Build Record
                    mapped_record = {
                        "profile": {
                            "id": uid,
                            "full_name": full_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": None, 
                            "date_of_birth": None,
                            "nationality": "US",
                            "is_active": True, # Current directory
                            "aliases": [],
                            "images": [],
                            "addresses": []
                        },
                        "risk_events": [
                            {
                                "type": "PEP",
                                "source_list": self.name,
                                "authority": "United States Congress",
                                "reason": f"Member of the House of Representatives ({party_full}) - District {entry.get('district')}",
                                "date_listed": scraped_at[:10],
                                "is_current": True,
                                "risk_level": "High"
                            }
                        ],
                        "evidence": [
                            {
                                "url": entry.get("member_url") or self.BASE_URL,
                                "scraped_at": scraped_at,
                                "raw_text_snippet": (
                                    f"Name: {full_name}. Party: {party_code}. "
                                    f"District: {entry.get('district')}. "
                                    f"Committees: {entry.get('committees')}. "
                                    f"Office: {entry.get('room')}. Phone: {entry.get('phone')}."
                                )
                            }
                        ]
                    }

                    # 5. Normalize & Yield
                    result = mapper.map_single_profile(mapped_record)

                    yield result

                except Exception as inner_e:
                    self.logger.warning(f"Error transforming representative: {inner_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process JSON file: {e}")
            raise e

    # ---------------------------------------------------------
    # Scraping Logic (Sync in Thread)
    # ---------------------------------------------------------

    def _scrape_sync(self) -> Dict[str, Any]:
        """Synchronous scraping pipeline."""
        session = requests.Session()
        session.headers.update(self.HEADERS)
        
        self.logger.info(f"Fetching: {self.BASE_URL}")
        try:
            resp = session.get(self.BASE_URL, timeout=60)
            resp.raise_for_status()
            html_text = resp.text
        except Exception as e:
            self.logger.error(f"Failed to fetch page: {e}")
            return {"entries": []}

        reps = self._parse_representatives(html_text)
        self.logger.info(f"Parsed {len(reps)} representatives")

        return {
            "source": {
                "name": self.name,
                "url": self.BASE_URL,
                "run_at": datetime.now(timezone.utc).isoformat(),
            },
            "entries": reps,
        }

    def _parse_representatives(self, html_text: str) -> List[Dict[str, Any]]:
        """Parses the main representatives table."""
        doc = html.fromstring(html_text)
        reps = []

        # Iterate over all rows in all tables
        rows = doc.xpath("//table//tr")

        for tr in rows:
            # Skip header rows
            if tr.xpath("./th"): continue

            tds = tr.xpath("./td")
            if not tds or len(tds) < 5: continue

            # 1. District
            district = self._clean_text("".join(tds[0].xpath(".//text()")))

            # 2. Member Name & Link
            member_links = tds[1].xpath(".//a")
            if member_links:
                name = self._clean_text("".join(member_links[0].xpath(".//text()")))
                member_url = self._clean_text(member_links[0].get("href", ""))
            else:
                name = self._clean_text("".join(tds[1].xpath(".//text()")))
                member_url = None

            # 3. Party
            party = self._clean_text("".join(tds[2].xpath(".//text()")))

            # 4. Room
            room = self._clean_text("".join(tds[3].xpath(".//text()")))

            # 5. Phone
            phone = self._clean_text("".join(tds[4].xpath(".//text()")))

            # 6. Committees (Optional)
            committees = ""
            if len(tds) > 5:
                committees = self._clean_text("".join(tds[5].xpath(".//text()")))

            if name:
                reps.append({
                    "name": name,
                    "district": district,
                    "party": party,
                    "room": room,
                    "phone": phone,
                    "committees": committees,
                    "member_url": member_url,
                })

        return reps

    def _clean_text(self, s: str) -> str:
        return re.sub(r"\s+", " ", (s or "").strip())

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = USHouseRepresentativesScraper()
    asyncio.run(scraper.run(force=True))