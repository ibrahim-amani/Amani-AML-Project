"""
src/sanction_parser/scrapers/sources/us_marshals.py

Scraper for US Marshals – 15 Most Wanted.
Source: https://www.usmarshals.gov/what-we-do/fugitive-investigations/15-most-wanted-fugitive
"""

import re
import json
import asyncio
import logging
import platform
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Iterator
from urllib.parse import urljoin

# Third-party
from lxml import html
from crawl4ai import AsyncWebCrawler, BrowserConfig, CrawlerRunConfig, CacheMode

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

class USMarshalsMostWantedScraper(BaseSanctionScraper):
    """
    Scraper for US Marshals – 15 Most Wanted.
    
    Source URL: https://www.usmarshals.gov/what-we-do/fugitive-investigations/15-most-wanted-fugitive
    Format: Web Scraping (Crawl4AI)
    Type: Wanted (High Risk)
    """
    name = "US Marshals – 15 Most Wanted"
    country = "US"
    
    BASE_URL = "https://www.usmarshals.gov/what-we-do/fugitive-investigations/15-most-wanted-fugitive"
    DATA_FILENAME = "us_marshals_most_wanted.json"
    
    DEFAULT_HEADLESS = True

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Scrape listing and detail pages via Crawl4AI.
        """
        self.logger.info(f"Starting extraction from: {self.BASE_URL}")
        
        # Windows loop policy fix
        if platform.system() == "Windows":
            asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

        local_path = self.raw_dir / self.DATA_FILENAME

        try:
            # Run Crawl4AI logic
            raw_data = await self._scrape_pipeline()
            
            if not raw_data or not raw_data.get("fugitives"):
                self.logger.warning("No fugitives scraped.")
                return None

            # Save Raw Data
            with open(local_path, "w", encoding="utf-8") as f:
                json.dump(raw_data, f, indent=2, ensure_ascii=False)
            
            return local_path

        except Exception as e:
            self.logger.error(f"Extraction failed: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform raw JSON to Golden Profile.
        """
        if not raw_path.exists():
            return

        self.logger.info(f"Transforming file: {raw_path}")
        mapper = ProfileMapper()

        try:
            with open(raw_path, "r", encoding="utf-8") as f:
                data = json.load(f)

            scraped_at = data.get("scraped_at", datetime.now(timezone.utc).isoformat())

            for entry in data.get("fugitives", []):
                try:
                    name = entry.get("name")
                    if not name: continue

                    # 1. ID Generation
                    uid = self.generate_uuid(name)

                    # 2. Extract Details (Regex)
                    detail_text = entry.get("detail_page", {}).get("detail_text", "")
                    
                    dob_str = self._extract_regex(r"Date of Birth\s+([A-Za-z]+\s+\d{1,2},?\s+\d{4})", detail_text)
                    dob_iso = self._parse_date(dob_str)
                    
                    sex = self._extract_regex(r"Sex\s+(Male|Female)", detail_text)
                    race = self._extract_regex(r"Race(?: and Ethnicity)?\s+([A-Za-z]+)", detail_text)
                    
                    aliases = []
                    aliases_str = self._extract_regex(r"Aliases\s+(.*?)(?:Reward|Wanted Since|$)", detail_text)
                    if aliases_str:
                        aliases = [self._normalize_space(p) for p in aliases_str.split(",") if p.strip()]

                    # 3. Status
                    is_active = True
                    status = entry.get("status", "wanted").lower()
                    if "apprehended" in status or "captured" in status:
                        is_active = False

                    # 4. Reason
                    reason = self._extract_regex(r"Wanted For\s+(.*?)(?:Aliases|Reward|Date of Birth|$)", detail_text)
                    if not reason:
                        reason = entry.get("summary", "Wanted by US Marshals")

                    # 5. Build Record
                    mapped_record = {
                        "profile": {
                            "id": uid,
                            "full_name": name,
                            "entity_type": "INDIVIDUAL",
                            "gender": sex,
                            "date_of_birth": dob_iso,
                            "nationality": "US", 
                            "is_active": is_active,
                            "aliases": aliases,
                            "images": [entry.get("image_url")] if entry.get("image_url") else [],
                            "addresses": []
                        },
                        "risk_events": [
                            {
                                "type": "Wanted",
                                "source_list": self.name,
                                "authority": "US Marshals Service",
                                "reason": reason,
                                "date_listed": self._extract_regex(r"Wanted Since\s+(\d{4})", detail_text), 
                                "is_current": is_active,
                                "risk_level": "High"
                            }
                        ],
                        "evidence": [
                            {
                                "url": entry.get("detail_url") or self.BASE_URL,
                                "scraped_at": scraped_at,
                                "raw_text_snippet": (
                                    f"Name: {name}. Summary: {entry.get('summary')}. "
                                    f"Race: {race}. Reward: {self._extract_regex(r'Reward\s+(\$[\d,]+)', detail_text)}. "
                                    f"Height: {self._extract_regex(r'Height\s+(\d+\'\d+\")', detail_text)}. "
                                )
                            }
                        ]
                    }

                    # 6. Normalize & Yield
                    result = mapper.map_single_profile(mapped_record)

                    yield result

                except Exception as inner_e:
                    self.logger.warning(f"Error transforming fugitive: {inner_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process JSON file: {e}")
            raise e

    # ---------------------------------------------------------
    # Scraping Logic (Async Crawl4AI)
    # ---------------------------------------------------------

    async def _scrape_pipeline(self) -> Dict[str, Any]:
        """Core scraping pipeline."""
        browser_config = BrowserConfig(headless=self.DEFAULT_HEADLESS)
        
        async with AsyncWebCrawler(config=browser_config) as crawler:
            # 1. Fetch Listing
            try:
                listing_html = await self._fetch_html(crawler, self.BASE_URL)
                fugitives = self._parse_listing_page(listing_html)
                self.logger.info(f"Found {len(fugitives)} fugitives.")
            except Exception as e:
                self.logger.error(f"Failed to fetch listing: {e}")
                return {}

            # 2. Fetch Details
            for i, f in enumerate(fugitives):
                detail_url = f.get("detail_url")
                if not detail_url: continue

                try:
                    if i > 0: await asyncio.sleep(1)
                    detail_html = await self._fetch_html(crawler, detail_url)
                    f["detail_page"] = self._parse_detail_page(detail_html, detail_url)
                except Exception as e:
                    self.logger.warning(f"Failed detail page {detail_url}: {e}")
                    f["detail_page"] = {}

        return {
            "source_url": self.BASE_URL,
            "total": len(fugitives),
            "fugitives": fugitives,
            "scraped_at": datetime.now(timezone.utc).isoformat()
        }

    async def _fetch_html(self, crawler: AsyncWebCrawler, url: str) -> str:
        run_config = CrawlerRunConfig(cache_mode=CacheMode.BYPASS)
        result = await crawler.arun(url=url, config=run_config)
        
        if not getattr(result, "success", False):
            raise RuntimeError(f"Crawl failed for {url}")
            
        html_text = getattr(result, "html", None) or getattr(result, "cleaned_html", None)
        if not html_text:
            raise RuntimeError(f"Empty HTML from {url}")
        return html_text

    def _parse_listing_page(self, html_text: str) -> List[Dict[str, Any]]:
        doc = html.fromstring(html_text)
        fugitives = []
        
        card_nodes = doc.xpath('//ul[contains(@class,"usa-card-group")]//li[contains(@class,"usa-card")]')
        
        for li in card_nodes:
            name_nodes = li.xpath('.//h2[contains(@class,"usa-card__heading")]//text()')
            name = self._normalize_space(" ".join(name_nodes)) or None

            img = li.xpath('.//div[contains(@class,"usa-card__img")]//img[1]')
            image_url = None
            if img:
                src = img[0].get("src")
                if src: image_url = urljoin(self.BASE_URL, src)

            summary_nodes = li.xpath('.//div[contains(@class,"usa-card__body")]//p[1]//text()')
            summary = self._normalize_space(" ".join(summary_nodes)) or None

            link = li.xpath('.//div[contains(@class,"usa-card__footer")]//a[1]')
            detail_url = None
            if link:
                href = link[0].get("href")
                if href: detail_url = urljoin(self.BASE_URL, href)

            status = "wanted"
            combined_text = (name or "") + (summary or "")
            if "apprehended" in combined_text.lower() or "captured" in combined_text.lower():
                status = "apprehended"

            fugitives.append({
                "name": name,
                "summary": summary,
                "image_url": image_url,
                "detail_url": detail_url,
                "status": status,
            })
        return fugitives

    def _parse_detail_page(self, html_text: str, url: str) -> Dict[str, Any]:
        doc = html.fromstring(html_text)
        main = doc.xpath("//main")
        root = main[0] if main else doc
        
        text_nodes = root.xpath(".//text()")
        text = self._normalize_space(" ".join(text_nodes))
        
        return {"url": url, "detail_text": text}

    # --- Helpers ---

    def _normalize_space(self, s: str) -> str:
        return " ".join(s.split()) if s else ""

    def _extract_regex(self, pattern: str, text: str) -> Optional[str]:
        if not text: return None
        match = re.search(pattern, text, re.IGNORECASE)
        return self._normalize_space(match.group(1)) if match else None

    def _parse_date(self, date_str: Optional[str]) -> Optional[str]:
        if not date_str: return None
        try:
            return datetime.strptime(date_str, "%B %d, %Y").strftime("%Y-%m-%d")
        except ValueError: return None

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = USMarshalsMostWantedScraper()
    asyncio.run(scraper.run(force=True))