"""
src/sanction_parser/scrapers/sources/us_occ_enforcement.py

Scraper for Office of the Comptroller of the Currency (OCC) - OTS Enforcement Orders.
Source: https://occ.gov/static/ots/enforcement/ots-enforcement-order-listing.xlsx
"""

import logging
import asyncio
import pandas as pd
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper
from sanction_parser.scrapers.utils.web_client import get_request

# Initialize logger
logger = logging.getLogger(__name__)

class OCCEnforcementScraper(BaseSanctionScraper):
    """
    Scraper for OCC - OTS Enforcement Order Listing.
    
    Source URL: https://occ.gov/static/ots/enforcement/ots-enforcement-order-listing.xlsx
    Format: Excel (Specific Sheet)
    Filters: Individuals Only.
    """
    name = "OCC - OTS Enforcement Orders"
    country = "USA"
    
    FILE_URL = "https://occ.gov/static/ots/enforcement/ots-enforcement-order-listing.xlsx"
    DATA_FILENAME = "ots-enforcement-order-listing.xlsx" # Stable filename

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Download the Excel file directly.
        """
        self.logger.info(f"Downloading file from: {self.FILE_URL}")
        
        local_path = self.raw_dir / self.DATA_FILENAME

        def _download_task():
            # Stream download for stability
            response = get_request(self.FILE_URL, stream=True, timeout=120)
            with open(local_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

        try:
            await asyncio.to_thread(_download_task)
            
            if local_path.exists() and local_path.stat().st_size > 0:
                return local_path
            else:
                self.logger.error("Download failed or file is empty.")
                return None

        except Exception as e:
            self.logger.error(f"Failed to download file: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform Excel (Sheet: Enforcements_SearchResults) to Golden Profile.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            # Fallback
            excel_files = list(raw_path.parent.glob("*.xlsx"))
            if not excel_files:
                self.logger.warning("No Excel files found.")
                return
            target_file = excel_files[0]

        self.logger.info(f"Transforming file: {target_file}")
        mapper = ProfileMapper()

        try:
            # Read specific sheet
            try:
                df = pd.read_excel(target_file, sheet_name="Enforcements_SearchResults")
            except ValueError:
                self.logger.warning("Sheet 'Enforcements_SearchResults' not found. Reading first sheet.")
                df = pd.read_excel(target_file)
            
            # Fill NaNs for string columns
            obj_cols = df.select_dtypes(include=['object']).columns
            df[obj_cols] = df[obj_cols].fillna("")

            for index, row in df.iterrows():
                try:
                    # 1. Entity Identification Logic
                    first_name = str(row.get("First Name", "")).strip()
                    last_name = str(row.get("Last Name", "")).strip()
                    institution = str(row.get("Institution Name", "")).strip()
                    
                    is_individual = False
                    full_name = ""
                    
                    if last_name or first_name:
                        is_individual = True
                        parts = [first_name, last_name]
                        full_name = " ".join([p for p in parts if p])
                    elif institution:
                        # Skip pure institutions
                        continue
                    else:
                        continue

                    if not full_name:
                        continue

                    # 2. Date Parsing
                    issue_date_val = row.get("Issue Date")
                    date_listed = None
                    if pd.notnull(issue_date_val):
                        try:
                            if isinstance(issue_date_val, (pd.Timestamp, datetime)):
                                date_listed = issue_date_val.strftime("%Y-%m-%d")
                            else:
                                date_listed = pd.to_datetime(issue_date_val).strftime("%Y-%m-%d")
                        except:
                            pass

                    # 3. Location & Details
                    city = str(row.get("City", "")).strip()
                    state = str(row.get("State", "")).strip()
                    region = str(row.get("OTS Region", "")).strip()
                    
                    address_parts = [p for p in [city, state, "USA"] if p] 
                    address_full = ", ".join(address_parts)

                    # 4. Reason Construction
                    type_desc = str(row.get("Type Description", "")).strip()
                    type_order = str(row.get("Type of Order", "")).strip()
                    reason = f"{type_desc} - {type_order}".strip(" -")
                    
                    # 5. Metadata
                    record_id = str(row.get("Record ID", "")) 
                    docket_num = str(row.get("Docket Number", "")).strip()
                    order_num = str(row.get("Order Number", "")).strip()
                    evidence_link = str(row.get("Link to Enforcement Action", "")).strip()

                    # 6. ID Generation
                    unique_key = f"OTS_{record_id}_{full_name}"
                    generated_id = self.generate_uuid(unique_key)

                    # 7. Build Record
                    raw_record = {
                        "profile": {
                            "id": generated_id,
                            "full_name": full_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": None,
                            "date_of_birth": None,
                            "nationality": "USA",
                            "is_active": True, # Enforcement actions are historic facts
                            "aliases": [],
                            "images": [],
                            "addresses": [address_full] if address_full else []
                        },
                        "risk_events": [
                            {
                                "type": "Enforcement Action",
                                "source_list": self.name,
                                "authority": "Office of Thrift Supervision (OTS) / OCC",
                                "reason": reason,
                                "date_listed": date_listed,
                                "is_current": True,
                                "risk_level": "High",
                            }
                        ],
                        "evidence": [
                            {
                                "url": self.FILE_URL,
                                "pdf_url": evidence_link if "http" in evidence_link else None,
                                "scraped_at": datetime.now().isoformat(),
                                "raw_text_snippet": f"Inst: {institution} | Region: {region} | Docket: {docket_num} | Order: {order_num}"
                            }
                        ]
                    }

                    # 8. Normalize & Yield
                    result = mapper.map_single_profile(raw_record)

                    yield result

                except Exception as inner_e:
                    self.logger.warning(f"Error processing row {index}: {inner_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process Excel file: {e}")
            raise e

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = OCCEnforcementScraper()
    asyncio.run(scraper.run(force=True))