"""
src/sanction_parser/scrapers/sources/us_senate.py

Scraper for US Senate - Senators List (PEP).
Source: https://www.senate.gov/general/contact_information/senators_cfm.xml
"""

import logging
import asyncio
import xml.etree.ElementTree as ET
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper
from sanction_parser.scrapers.utils.web_client import get_request

# Initialize logger
logger = logging.getLogger(__name__)

class USSenateScraper(BaseSanctionScraper):
    """
    Scraper for US Senate - Senators List.
    
    Source URL: https://www.senate.gov/general/contact_information/senators_cfm.xml
    Format: XML
    Type: PEP (Medium Risk)
    """
    name = "US Senate - Senators List"
    country = "USA"
    
    BASE_URL = "https://www.senate.gov/general/contact_information/senators_cfm.xml"
    HEADERS = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    }
    DATA_FILENAME = "us_senators.xml"

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Download the XML file directly.
        """
        self.logger.info(f"Downloading data from: {self.BASE_URL}")
        
        local_path = self.raw_dir / self.DATA_FILENAME

        def _download_task():
            response = get_request(self.BASE_URL, headers=self.HEADERS, timeout=60)
            with open(local_path, 'wb') as f:
                f.write(response.content)

        try:
            await asyncio.to_thread(_download_task)
            if local_path.exists() and local_path.stat().st_size > 0:
                return local_path
            return None
        except Exception as e:
            self.logger.error(f"Failed to download data: {e}")
            if local_path.exists():
                local_path.unlink()
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Parse XML to Golden Profile.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            xml_files = list(raw_path.parent.glob("*.xml"))
            if not xml_files:
                self.logger.warning("No XML files found.")
                return
            target_file = xml_files[0]

        self.logger.info(f"Processing file: {target_file}")
        mapper = ProfileMapper()

        try:
            tree = ET.parse(target_file)
            root = tree.getroot()

            for member in root.findall("member"):
                try:
                    # 1. Extract Fields
                    last_name = self._get_text(member, "last_name")
                    first_name = self._get_text(member, "first_name")
                    party = self._get_text(member, "party")
                    state = self._get_text(member, "state")
                    address = self._get_text(member, "address")
                    bioguide_id = self._get_text(member, "bioguide_id")
                    email_url = self._get_text(member, "email")
                    website = self._get_text(member, "website")
                    senate_class = self._get_text(member, "class")
                    position = self._get_text(member, "leadership_position") 

                    # 2. Normalize Data
                    full_name = f"{first_name} {last_name}".strip()
                    party_full = "Democrat" if party == "D" else "Republican" if party == "R" else "Independent" if party == "I" else party

                    # 3. Construct Role Description
                    roles = ["Senator"]
                    if position:
                        roles.append(position)
                    role_description = f"{', '.join(roles)} for {state}"

                    # 4. Generate ID
                    unique_key = bioguide_id if bioguide_id else f"{full_name}_{state}"
                    record_id = self.generate_uuid(unique_key)

                    # 5. Build Record
                    mapped_record = {
                        "profile": {
                            "id": record_id,
                            "full_name": full_name,
                            "entity_type": "INDIVIDUAL",
                            "gender": None, 
                            "date_of_birth": None,
                            "nationality": "USA",
                            "is_active": True,
                            "aliases": [],
                            "images": [],
                            "addresses": [address] if address else []
                        },
                        "risk_events": [
                            {
                                "type": "PEP", # Politically Exposed Person
                                "source_list": self.name,
                                "authority": "US Senate",
                                "reason": role_description,
                                "date_listed": datetime.now().strftime("%Y-%m-%d"), 
                                "is_current": True,
                                "risk_level": "Medium",
                            }
                        ],
                        "evidence": [
                            {
                                "url": website or self.BASE_URL,
                                "scraped_at": datetime.now().isoformat(),
                                "raw_text_snippet": f"Bioguide ID: {bioguide_id} | Class: {senate_class} | Party: {party_full}"
                            }
                        ]
                    }
                    
                    # 6. Normalize & Yield
                    result = mapper.map_single_profile(mapped_record)

                    yield result

                except Exception as inner_e:
                    self.logger.warning(f"Error parsing member: {inner_e}")
                    continue

        except Exception as e:
            self.logger.error(f"Failed to process XML file: {e}")
            raise e

    # ---------------------------------------------------------
    # Helper Methods
    # ---------------------------------------------------------

    def _get_text(self, element, tag) -> Optional[str]:
        """Helper to extract and clean text from XML node."""
        node = element.find(tag)
        if node is not None and node.text:
            cleaned = node.text.strip()
            return cleaned if cleaned else None
        return None

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = USSenateScraper()
    asyncio.run(scraper.run(force=True))