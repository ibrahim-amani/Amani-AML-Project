"""
src/sanction_parser/scrapers/sources/world_bank.py

Scraper for World Bank Listing of Ineligible Firms and Individuals.
Source: https://www.worldbank.org/en/projects-operations/procurement/debarred-firms
"""

import logging
import asyncio
import hashlib
import time
import pandas as pd
import openpyxl
import pycountry
import os
from pathlib import Path
from datetime import datetime
from typing import Iterator, Dict, Any, Optional, Generator

# Selenium
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

# Internal Package Imports
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.domain.normalizers import ProfileMapper

# Initialize logger
logger = logging.getLogger(__name__)

def country_to_iso2(country_name: str) -> Optional[str]:
    if not country_name or not country_name.strip(): return None
    name = country_name.strip()
    c = pycountry.countries.get(name=name)
    if c: return c.alpha_2
    try:
        matches = pycountry.countries.search_fuzzy(name)
        if matches: return matches[0].alpha_2
    except LookupError: pass
    return None

class WorldBankSanctionsScraper(BaseSanctionScraper):
    """
    Scraper for World Bank Ineligible Firms.
    
    Source URL: https://www.worldbank.org/en/projects-operations/procurement/debarred-firms
    Format: Excel (Dynamic Export via Selenium)
    Strategy: Content Hashing on Data (not file metadata).
    """
    name = "World Bank - Ineligible Firms"
    country = "Global" # International Organization
    
    BASE_URL = "https://www.worldbank.org/en/projects-operations/procurement/debarred-firms"
    DATA_FILENAME = "world_bank_sanctions.xlsx"

    async def extract(self) -> Optional[Path]:
        """
        Step 1: Download Excel via Selenium (handling dynamic button).
        """
        self.logger.info(f"Starting Selenium download from: {self.BASE_URL}")
        
        temp_download_dir = self.raw_dir / "temp_dl"
        temp_download_dir.mkdir(exist_ok=True)
        
        # Clear temp dir
        for f in temp_download_dir.glob("*"):
            try: f.unlink()
            except: pass

        options = webdriver.ChromeOptions()
        options.add_argument("--headless") 
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")

        prefs = {
            "download.default_directory": str(temp_download_dir.resolve()),
            "download.prompt_for_download": False,
            "download.directory_upgrade": True,
            "safebrowsing.enabled": True
        }
        options.add_experimental_option("prefs", prefs)

        def _selenium_task():
            driver = None
            try:
                driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
                driver.get(self.BASE_URL)
                
                # Click Export Button
                download_button = WebDriverWait(driver, 30).until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, "a.k-grid-excel"))
                )
                download_button.click()

                # Wait for file
                timeout = 60
                start_time = time.time()
                while time.time() - start_time < timeout:
                    files = list(temp_download_dir.glob("*.xlsx"))
                    if files and not any(f.name.endswith('.crdownload') for f in files):
                        return files[0]
                    time.sleep(1)
                raise Exception("Timeout waiting for file download.")
            finally:
                if driver: driver.quit()

        try:
            downloaded_file = await asyncio.to_thread(_selenium_task)
            
            # --- Custom Data Hashing ---
            self.logger.info("Calculating content-based hash (ignoring metadata)...")
            new_hash = await asyncio.to_thread(self._calculate_data_hash, downloaded_file)
            
            metadata = self._load_metadata()
            if metadata.get("content_hash") == new_hash:
                self.logger.info(f"Data Hash Match ({new_hash[:8]}). Content unchanged.")
                if downloaded_file.exists(): downloaded_file.unlink()
                try: temp_download_dir.rmdir() 
                except: pass
                return None
            
            # Update Metadata
            metadata.update({
                "content_hash": new_hash,
                "last_updated": datetime.now().isoformat(),
                "last_file_processed": self.DATA_FILENAME
            })
            self._save_metadata(metadata)

            # Move file
            local_path = self.raw_dir / self.DATA_FILENAME
            if local_path.exists(): local_path.unlink()
            downloaded_file.rename(local_path)
            
            try: temp_download_dir.rmdir()
            except: pass

            return local_path

        except Exception as e:
            self.logger.error(f"Selenium download failed: {e}")
            return None

    def transform(self, raw_path: Path) -> Iterator[Dict[str, Any]]:
        """
        Step 2: Transform Excel to Golden Profile.
        """
        target_file = raw_path
        if raw_path.is_dir():
            target_file = raw_path / self.DATA_FILENAME
        
        if not target_file.exists():
            return

        self.logger.info(f"Processing file: {target_file}")
        mapper = ProfileMapper()

        try:
            wb = openpyxl.load_workbook(target_file, data_only=True)
            sheet = wb.active
            
            for row_data in self._sheet_to_dicts(sheet):
                try:
                    name = str(row_data.get("firm_name", "")).strip()
                    if not name: continue

                    country = str(row_data.get("country", "")).strip()
                    address = str(row_data.get("address", "")).strip()
                    grounds = str(row_data.get("grounds", "")).strip()
                    
                    from_date_raw = row_data.get("from_date")
                    to_date_raw = row_data.get("to_date")

                    date_listed = None
                    is_active = True
                    
                    start_dt = self._parse_date(from_date_raw)
                    end_dt = self._parse_date(to_date_raw)
                    
                    if start_dt: date_listed = start_dt.strftime("%Y-%m-%d")
                    if end_dt and end_dt < datetime.now(): is_active = False

                    # ID
                    unique_key = f"{name}_{country}_{date_listed}"
                    record_id = self.generate_uuid(unique_key)
                    c_iso = country_to_iso2(country) if country else None
                    
                    # Mapping
                    mapped_record = {
                        "profile": {
                            "id": record_id, 
                            "full_name": name, 
                            "entity_type": "FIRM", # Mostly firms
                            "gender": None, 
                            "date_of_birth": None,
                            "nationality": c_iso, 
                            "is_active": is_active, 
                            "aliases": [], 
                            "images": [],
                            "addresses": [address] if address else []
                        },
                        "risk_events": [
                            {
                                "type": "Sanction", 
                                "source_list": self.name, 
                                "authority": "World Bank Group",
                                "reason": grounds, 
                                "date_listed": date_listed, 
                                "is_current": is_active, 
                                "risk_level": "High"
                            }
                        ],
                        "evidence": [
                            {
                                "url": self.BASE_URL, 
                                "scraped_at": datetime.now().isoformat(),
                                "raw_text_snippet": f"Grounds: {grounds} | Period: {start_dt} to {end_dt}"
                            }
                        ]
                    }
                    
                    result = mapper.map_single_profile(mapped_record)

                    yield result

                except Exception: continue
                    
        except Exception as e:
            self.logger.error(f"Failed to process workbook: {e}")
            raise e

    # ---------------------------------------------------------
    # Helper Methods
    # ---------------------------------------------------------

    def _calculate_data_hash(self, file_path: Path) -> str:
        """Hashes pandas dataframe content to ignore file metadata."""
        try:
            df = pd.read_excel(file_path)
            content_str = df.to_json(orient='split', date_format='iso', double_precision=10)
            return hashlib.sha256(content_str.encode('utf-8')).hexdigest()
        except Exception as e:
            self.logger.warning(f"Data hashing failed, falling back to file hash: {e}")
            return self._calculate_file_hash(file_path)

    def _slugify(self, text: str) -> str:
        if not text: return ""
        return str(text).strip().lower().replace(" ", "_").replace("/", "_")

    def _parse_date(self, d: Any) -> Optional[datetime]:
        if not d: return None
        if isinstance(d, datetime): return d
        try: return datetime.strptime(str(d).strip(), "%Y-%m-%d")
        except: return None

    def _sheet_to_dicts(self, sheet) -> Generator[Dict[str, Any], None, None]:
        """Iterates over rows, dynamically detects header."""
        headers_map: Dict[str, int] = {} 
        header_found = False
        rows = list(sheet.rows)
        
        for row_idx, row in enumerate(rows):
            cells = [c.value for c in row]
            clean_cells_str = [str(c).strip() if c is not None else "" for c in cells]
            
            if not header_found:
                if "Firm Name" in clean_cells_str:
                    header_found = True
                    for col_idx, cell_val in enumerate(clean_cells_str):
                        slug = self._slugify(cell_val)
                        if slug: headers_map[slug] = col_idx
                    
                    # Handle sub-headers if present
                    if row_idx + 1 < len(rows):
                        next_row = [str(c.value).strip() if c.value else "" for c in rows[row_idx+1]]
                        if "From Date" in next_row:
                            if "From Date" in next_row: headers_map["from_date"] = next_row.index("From Date")
                            if "To Date" in next_row: headers_map["to_date"] = next_row.index("To Date")
                    continue
                continue

            if "From Date" in clean_cells_str: continue # Skip subheader row
            if not any(clean_cells_str): continue # Skip empty

            row_dict = {}
            for key, idx in headers_map.items():
                if idx < len(cells):
                    row_dict[key] = cells[idx]
            
            # Fallback for merged date cells
            if "ineligibility_period" in headers_map and "from_date" not in row_dict:
                idx = headers_map["ineligibility_period"]
                row_dict["from_date"] = cells[idx]
                if idx + 1 < len(cells): row_dict["to_date"] = cells[idx + 1]

            if row_dict.get("firm_name"): yield row_dict

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    scraper = WorldBankSanctionsScraper()
    asyncio.run(scraper.run(force=True))