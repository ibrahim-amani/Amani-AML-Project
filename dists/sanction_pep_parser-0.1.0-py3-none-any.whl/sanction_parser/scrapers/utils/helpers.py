"""
src.sanction_parser.scrapers.utils.helpers
Helper functions for scraping and data processing.
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Set, Tuple
import re

# ---------------------------------------------------------------------
# Local helpers (kept here to make the provider self-contained)
# ---------------------------------------------------------------------

def _safe_mkdir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _now_ms() -> int:
    return int(datetime.now(tz=timezone.utc).timestamp() * 1000)


def _is_valid_iso_date(d: str) -> bool:
    """
    Accept only valid YYYY-MM-DD dates.
    Reject placeholders like 0000-00-00, 0000-01-00, or any date containing -00.
    """
    if not isinstance(d, str) or len(d) != 10:
        return False
    if d.startswith("0000-") or "-00" in d:
        return False
    try:
        datetime.strptime(d, "%Y-%m-%d")
        return True
    except ValueError:
        return False


def _clean_date_list(value) -> List[str]:
    """
    Normalize dates field into a list of valid ISO dates.
    Supports: list[str] | str | None
    """
    if isinstance(value, list):
        return [d for d in value if _is_valid_iso_date(d)]
    if isinstance(value, str):
        return [value] if _is_valid_iso_date(value) else []
    return []


# -----------------------------
# Risk & Topic Mapping
# -----------------------------
RISK_MAPPING: Dict[str, str] = {
    "Sanction": "Sanction",
    "PEP": "PEP",
    "Warrant": "Warrant",
    "Criminal": "Criminal",
    "Disqualification": "Disqualification",
    "Debarment": "Debarment",
}

TOPIC_RISK_RULES: List[Tuple[str, str]] = [
    ("sanction", "Sanction"),
    ("sanction.linked", "Sanction"),
    ("sanction.counter", "Sanction"),
    ("asset.frozen", "Sanction"),
    ("role.pep", "PEP"),
    ("role.rca", "PEP"),
    ("role.pol", "PEP"),
    ("wanted", "Warrant"),
    ("crime", "Criminal"),
    ("crime.cyber", "Criminal"),
    ("crime.fraud", "Criminal"),
    ("crime.fin", "Criminal"),
    ("crime.env", "Criminal"),
    ("crime.theft", "Criminal"),
    ("crime.war", "Criminal"),
    ("crime.boss", "Criminal"),
    ("crime.terror", "Criminal"),
    ("crime.traffick", "Criminal"),
    ("crime.traffick.drug", "Criminal"),
    ("crime.traffick.human", "Criminal"),
    ("corp.disqual", "Disqualification"),
    ("debarment", "Debarment"),
]

def _topic_reason(topic: str) -> str:
    return topic.replace(".", " ").replace("_", " ").title()



RELATIONSHIP_MAPPING = {
    "Family": {"subject": "person", "object": "relative", "role": "relationship"},
    "Associate": {"subject": "person", "object": "associate", "role": "relationship"},
    "Employment": {"subject": "employee", "object": "employer", "role": "role"},
    "Directorship": {"subject": "director", "object": "organization", "role": "role"},
    "Ownership": {"subject": "owner", "object": "asset", "role": "role"},
    "Membership": {"subject": "member", "object": "organization", "role": "role"},
    "Representation": {"subject": "agent", "object": "client", "role": "role"},
    "UnknownLink": {"subject": "subject", "object": "object", "role": "role"},
}

US_STATES = {
    "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA", "HI", "ID", "IL", "IN", "IA",
    "KS", "KY", "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ",
    "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT",
    "VA", "WA", "WV", "WI", "WY", "DC"
}

NOISE_SUFFIXES = {
    "DMD", "D.M.D", "DDS", "D.D.S", "MD", "M.D", "PHD", "PH.D",
    "DCFH", "LLC", "LTD", "INC", "CORP", "S.A.", "GMBH", "D.O."
}

POSTCODE_RE = re.compile(
    r"\b("
    r"\d{5}-\d{4}"
    r"|"
    r"\d{5,9}"
    r"|"
    r"[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}"
    r"|"
    r"[A-Z]\d[A-Z]\s*\d[A-Z]\d"
    r")\b",
    re.IGNORECASE,
)
ISO2_AT_END_RE = re.compile(r"(?:,|\s)\b([A-Z]{2})\b\s*$")
TRAIL_PUNCT_RE = re.compile(r"^[\W_]+|[\W_]+$", re.UNICODE)
PATRONYMIC_RE = re.compile(r".*(ovich|evich|yevich|ovna|evna|ich)$", re.IGNORECASE)
