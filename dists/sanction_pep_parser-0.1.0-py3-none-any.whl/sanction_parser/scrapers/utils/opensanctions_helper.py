
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import re
import shutil
import sqlite3
import tempfile
import time
from calendar import monthrange
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Set, Tuple
import requests

from tqdm import tqdm
import shutil

# Mandatory dependency
from nameparser import HumanName

# Internal Package Imports (adjust paths if your project differs)
from sanction_parser.interfaces.scraper_base import BaseSanctionScraper
from sanction_parser.core.config import settings
from sanction_parser.scrapers.utils.helpers import (
    RISK_MAPPING , TOPIC_RISK_RULES ,_topic_reason ,
    RELATIONSHIP_MAPPING ,US_STATES ,NOISE_SUFFIXES ,
    POSTCODE_RE , ISO2_AT_END_RE,TRAIL_PUNCT_RE ,PATRONYMIC_RE
)
logger = logging.getLogger(__name__)


# -----------------------------
# Risk & Topic Mapping
# -----------------------------
DATA_DIR = settings.RAW_DIR / "opensanctions"
LOCAL_METADATA_FILE = DATA_DIR /"metadata.json"
LOCAL_DATA_FILE = DATA_DIR / "entities.ftm.json"




@dataclass(frozen=True)
class EvidenceKey:
    url: str
    tag: str


# ETL buffer (SQLite) - used ONLY inside transform(), then deleted.

class OpenSanctionsETL:
    TAG_ORDER = [
        "DD", "INS", "PEP-CURRENT", "PEP-FORMER", "PEP-LINKED",
        "POI", "REL", "RRE", "SAN-CURRENT", "SAN-FORMER", "GRI",
    ]
    _POSTCODE_RE = POSTCODE_RE
    _ISO2_AT_END_RE = ISO2_AT_END_RE
    _TRAIL_PUNCT_RE = TRAIL_PUNCT_RE
    _PATRONYMIC_RE = PATRONYMIC_RE
    LOCAL_METADATA_FILE =Path("src/sanction_parser/constant/datasets_mapping.json")

    def __init__(self, db_path: str = "etl_buffer.db"):
        self.db_path = db_path
        self.conn: Optional[sqlite3.Connection] = None
        self.cursor: Optional[sqlite3.Cursor] = None

        self.seen_datasets: Set[str] = set()
        self.dataset_mapping = self._load_dataset_mapping()

        self.error_log = None
        self.warn_log = None

        self.ingest_error_count = 0
        self.ingest_warning_count = 0
        self.truncated_rel_endpoints = 0

    # ---------------------------------------------------------
    # Context manager
    # ---------------------------------------------------------
    def __enter__(self):
        self.error_log = open("ingest_errors.log", "w", encoding="utf-8")
        self.warn_log = open("ingest_warnings.log", "w", encoding="utf-8")

        self.conn = sqlite3.connect(self.db_path)
        self.conn.execute("PRAGMA synchronous = OFF")
        self.conn.execute("PRAGMA journal_mode = MEMORY")
        self.conn.execute("PRAGMA temp_store = MEMORY")
        self.conn.execute("PRAGMA cache_size = -1000000")  # ~1GB cache

        mmap_size = int(os.getenv("SQLITE_MMAP_SIZE", "0"))
        if mmap_size > 0:
            try:
                self.conn.execute(f"PRAGMA mmap_size = {mmap_size}")
            except Exception as e:
                self._warn(f"Failed to apply PRAGMA mmap_size={mmap_size}: {e}")

        self.cursor = self.conn.cursor()
        self._setup_db()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        try:
            if self.error_log:
                self.error_log.close()
            if self.warn_log:
                self.warn_log.close()
        finally:
            if self.conn:
                if exc_type:
                    self.conn.rollback()
                    logger.critical(f"Critical failure. Rolled back. Error: {exc_val}")
                else:
                    self.conn.commit()
                self.conn.close()

    # ---------------------------------------------------------
    # Logging helpers
    # ---------------------------------------------------------
    def _warn(self, msg: str):
        self.ingest_warning_count += 1
        if self.warn_log:
            self.warn_log.write(msg.strip() + "\n")

    def _error(self, msg: str):
        self.ingest_error_count += 1
        if self.error_log:
            self.error_log.write(msg.strip() + "\n")

    # ---------------------------------------------------------
    # Dataset mapping
    # ---------------------------------------------------------
    def _load_dataset_mapping(self, path: str = LOCAL_METADATA_FILE) -> Dict[str, str]:
        if not os.path.exists(path):
            return {}
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def _map_datasets_readable(self, ds: List[str]) -> List[str]:
        out: List[str] = []
        seen: Set[str] = set()
        for x in (ds or []):
            if not x:
                continue
            mapped = self.dataset_mapping.get(x, x)
            if mapped in seen:
                continue
            seen.add(mapped)
            out.append(mapped)
        return out

    # ---------------------------------------------------------
    # DB Setup
    # ---------------------------------------------------------
    def _setup_db(self):
        assert self.cursor is not None

        self.cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS entities (
                id TEXT PRIMARY KEY,
                schema TEXT,
                full_name TEXT,
                countries_json TEXT,
                gender TEXT,
                birth_dates_json TEXT,
                death_dates_json TEXT,
                is_target INTEGER,
                aliases_json TEXT,
                addresses_json TEXT,
                identifiers_json TEXT,
                notes_json TEXT,
                contacts_json TEXT,
                source_wealth TEXT,
                caption TEXT,
                datasets_json TEXT
            )
            """
        )

        self.cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS risk_events (
                target_id TEXT,
                event_id TEXT,
                schema TEXT,
                authority TEXT,
                source_ds TEXT,
                reason TEXT,
                start_date TEXT,
                end_date TEXT,
                is_active INTEGER,
                evidence_url TEXT,
                country TEXT,
                PRIMARY KEY (target_id, event_id, schema)
            )
            """
        )

        self.cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS relationships (
                rel_id TEXT,
                schema TEXT,
                source_id TEXT,
                target_id TEXT,
                role TEXT,
                start_date TEXT,
                end_date TEXT,
                PRIMARY KEY (source_id, target_id, schema, role, start_date)
            )
            """
        )

        self.cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS positions (
                id TEXT PRIMARY KEY,
                name TEXT,
                country TEXT,
                organization TEXT
            )
            """
        )

        self.cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS occupancies (
                id TEXT PRIMARY KEY,
                holder_id TEXT,
                post_id TEXT,
                start_date TEXT,
                end_date TEXT,
                status TEXT
            )
            """
        )

        self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_risk_target ON risk_events(target_id)")
        self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_rel_source ON relationships(source_id)")
        self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_rel_target ON relationships(target_id)")
        self.cursor.execute("CREATE INDEX IF NOT EXISTS idx_occ_holder ON occupancies(holder_id)")

        assert self.conn is not None
        self.conn.commit()

    # ---------------------------------------------------------
    # Normalization Helpers
    # ---------------------------------------------------------
    @staticmethod
    def _sha256_hex(val: str) -> str:
        return hashlib.sha256(val.encode("utf-8")).hexdigest()

    def parse_date_of_birth(self, date_of_birth: str) -> Dict[str, str]:
        """
        Parse ISO date 'YYYY-MM-DD' into a dict {year, month, day}.
        Returns empty strings if invalid.
        """
        result = {"year": "", "month": "", "day": ""}
        try:
            components = str(date_of_birth or "").split("-")
            for i, component in enumerate(components):
                if not component.isdigit():
                    return result

                if i == 0:  # Year
                    result["year"] = component
                elif i == 1:  # Month
                    result["month"] = component
                elif i == 2:  # Day
                    result["day"] = component
            return result
        except Exception:
            return result
        
    
    def _generate_resource_id(self, val: str) -> str:
        return self._sha256_hex(val)

    def _stable_qrcode(self, val: str, length: int = settings.QRCODE_LEN) -> str:
        return self._sha256_hex(val)[:length]

    def _short_id(self, val: str, length: int) -> str:
        return self._sha256_hex(val)[:length]

    @staticmethod
    def _first(props: Dict[str, Any], key: str) -> Optional[str]:
        arr = props.get(key, []) or []
        return str(arr[0]) if arr else None

    @staticmethod
    def _norm_ws(s: Optional[str]) -> str:
        if not s:
            return ""
        return " ".join(str(s).strip().split())

    @staticmethod
    def _norm_iso2(val: Optional[str]) -> Optional[str]:
        if not val:
            return None
        v = str(val).strip()
        if len(v) == 2 and v.isalpha():
            return v.upper()
        return v

    def _collect_countries(self, props: Dict[str, Any]) -> List[str]:
        vals: Set[str] = set()
        for k in ("nationality", "citizenship", "country"):
            for x in (props.get(k, []) or []):
                nx = self._norm_iso2(str(x))
                if nx:
                    vals.add(nx)
        return sorted(vals)

    def _clean_name_token(self, tok: str) -> str:
        tok = self._norm_ws(tok)
        return self._TRAIL_PUNCT_RE.sub("", tok)

    def _clean_name_noise(self, full_name: str) -> str:
        parts = full_name.split()
        cleaned = []
        for p in parts:
            clean_p = p.replace(".", "").upper()
            if clean_p in NOISE_SUFFIXES:
                continue
            cleaned.append(p)
        return " ".join(cleaned)

    # ---------------------------------------------------------
    # Name Parsing 
    # ---------------------------------------------------------
    def _parse_name(self, full_name: str) -> Dict[str, str]:
        if not full_name:
            return {"first": "", "middle": "", "last": ""}

        s = self._clean_name_noise(self._norm_ws(full_name))
        if not s:
            return {"first": "", "middle": "", "last": ""}

        if "," in s:   # Heuristic 1: "LAST, First Middle" like :"Smith, John A"
            left, right = [x.strip() for x in s.split(",", 1)]
            right_parts = right.split()
            first = self._clean_name_token(right_parts[0]) if right_parts else ""
            middle = self._clean_name_token(" ".join(right_parts[1:])) if len(right_parts) > 1 else ""
            last = self._clean_name_token(left)
            return {"first": first, "middle": middle, "last": last}

        parts = s.split()   # Heuristic 2: Slavic "Last First Patronymic"  like: "Ivanov Ivan Ivanovich"
        if len(parts) == 3 and self._PATRONYMIC_RE.match(parts[2]):
            last = self._clean_name_token(parts[0])
            first = self._clean_name_token(parts[1])
            middle = self._clean_name_token(parts[2])
            return {"first": first, "middle": middle, "last": last}

        try:
            hn = HumanName(s)
            first = self._clean_name_token(hn.first)
            middle = self._clean_name_token(f"{hn.middle} {hn.nickname}")
            last = self._clean_name_token(f"{hn.last} {hn.suffix}")

            if not (first or last):
                p = s.split()
                if len(p) == 1:
                    return {"first": p[0], "middle": "", "last": ""}
                return {"first": p[0], "middle": " ".join(p[1:-1]) if len(p) > 2 else "", "last": p[-1]}

            return {"first": first, "middle": middle, "last": last}
        except Exception:
            p = s.split()
            if len(p) == 1:
                return {"first": p[0], "middle": "", "last": ""}
            return {"first": p[0], "middle": " ".join(p[1:-1]) if len(p) > 2 else "", "last": p[-1]}

    # ---------------------------------------------------------
    # Date Normalization
    # ---------------------------------------------------------
    def _coerce_date(self, s: Optional[str], is_end: bool = False) -> Optional[str]:
        s = (s or "").strip()
        if not s:
            return None
        try:
            if re.fullmatch(r"\d{4}", s):
                return f"{s}-12-31" if is_end else f"{s}-01-01"
            if re.fullmatch(r"\d{4}-\d{2}", s):
                y, m = map(int, s.split("-"))
                last_day = monthrange(y, m)[1] if is_end else 1
                return f"{y:04d}-{m:02d}-{last_day:02d}"
            if re.fullmatch(r"\d{4}-\d{2}-\d{2}", s):
                return s
        except Exception:
            return None
        return None

    # ---------------------------------------------------------
    # Address Parsing (Smart Country/State Detection)
    # ---------------------------------------------------------
    def _parse_address_smart(self, addr: str, default_country: str) -> Dict[str, Any]:
        s = self._norm_ws(addr)
        if not s:
            return {
                "addressType": "Registered Address",
                "line1": None,
                "city": None,
                "postcode": None,
                "countryIsoCode": default_country,
            }

        country = default_country
        m = self._ISO2_AT_END_RE.search(s)
        if m:
            detected_code = m.group(1).upper()
            is_us_state = detected_code in US_STATES
            is_default_us = (default_country == "US")
            if is_us_state and (is_default_us or detected_code == default_country or default_country == "XX"):
                country = "US"
            else:
                country = detected_code

        matches = list(self._POSTCODE_RE.finditer(s))
        postcode = None
        if matches:
            cand = matches[-1].group(0).strip()
            if re.fullmatch(r"\d{4}", cand):
                year = int(cand)
                if 1900 <= year <= 2099:
                    cand = ""
            postcode = cand or None

        return {
            "addressType": "Registered Address",
            "line1": s,
            "postcode": postcode,
            "city": None,
            "countryIsoCode": country,
        }

    def _dedupe_addresses(self, addrs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        out = []
        seen = set()
        for a in (addrs or []):
            line = str(a.get("line1") or "").lower().strip()
            pc = str(a.get("postcode") or "").lower().strip()
            cc = str(a.get("countryIsoCode") or "").lower().strip()
            clean_key = re.sub(r"[\W_]+", "", f"{line}|{pc}|{cc}")
            if clean_key and clean_key not in seen:
                seen.add(clean_key)
                out.append(a)
        return out

    def _prune_addresses(self, addrs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        if not addrs:
            return []
        out = []
        for a in addrs:
            line_a = (a.get("line1") or "").strip().lower()
            pc_a = (a.get("postcode") or "").strip().lower()
            cc_a = (a.get("countryIsoCode") or "").strip().lower()

            is_weaker = False
            for b in addrs:
                if a is b:
                    continue
                line_b = (b.get("line1") or "").strip().lower()
                pc_b = (b.get("postcode") or "").strip().lower()
                cc_b = (b.get("countryIsoCode") or "").strip().lower()

                if pc_a == pc_b and cc_a == cc_b and line_a and line_b:
                    if line_a != line_b and line_a in line_b:
                        is_weaker = True
                        break
            if not is_weaker:
                out.append(a)
        return out

    # ---------------------------------------------------------
    # Segment derivation (used to replace hardcoded "Public Office")
    # ---------------------------------------------------------
    def _derive_segment(self, position_text: Optional[str], org_text: Optional[str]) -> str:
        """
        Classify the person's segment (Government/Executive/Judicial/Law Enforcement/etc.)
        using free-text heuristics from POI position name and/or organization.
        """
        t = f"{position_text or ''} {org_text or ''}".lower()

        # Judicial
        if any(k in t for k in ["judge", "justice", "court", "prosecutor", "attorney general", "magistrate"]):
            return "Judicial"

        # Law enforcement / security
        if any(k in t for k in ["police", "sheriff", "investigation", "detective", "security service", "intelligence"]):
            return "Law Enforcement"

        # Military
        if any(k in t for k in ["army", "navy", "air force", "military", "general", "colonel", "brigade"]):
            return "Military"

        # Finance / Central bank / regulator
        if any(k in t for k in ["ministry of finance", "central bank", "financial regulator", "securities", "treasury"]):
            return "Financial"

        # Diplomacy / foreign affairs
        if any(k in t for k in ["ambassador", "embassy", "diplomat", "foreign affairs", "consul"]):
            return "Diplomatic"

        # Generic government
        if any(k in t for k in ["ministry", "government", "parliament", "mayor", "governor", "cabinet"]):
            return "Government"

        return "Public Office"

    def _choose_primary_segment_from_poi(self, poi_rows: List[tuple]) -> Optional[str]:
        """
        Pick a 'best' segment for the individual from their POI occupancies.
        poi_rows rows are: (holder_id, position_name, country, start_date, end_date, organization)
        """
        if not poi_rows:
            return None

        segments = []
        for r in poi_rows:
            pos_name = r[1]
            org_name = r[5]
            segments.append(self._derive_segment(pos_name, org_name))

        for s in segments:
            if s and s != "Public Office":
                return s
        return segments[0] if segments else None

    # ---------------------------------------------------------
    # Tag helpers
    # ---------------------------------------------------------
    def _risk_tag(self, schema: str, is_active: int) -> str:
        if schema == "Sanction":
            return "SAN-CURRENT" if is_active else "SAN-FORMER"
        if schema == "PEP":
            return "PEP-CURRENT" if is_active else "PEP-FORMER"
        if schema == "Warrant":
            return "REL"
        if schema == "Criminal":
            return "RRE"
        if schema == "Disqualification":
            return "DD"
        if schema == "Debarment":
            return "INS"
        return "REL"

    def _derive_schema_tags(
        self,
        *,
        san_data,
        pep_entries,
        rel_entries,
        rre_entries,
        poi_entries,
        ins_entries,
        dd_entries,
        gri_entries,
        individual_links,
        business_links,
    ) -> List[str]:
        tags: Set[str] = set()

        if dd_entries:
            tags.add("DD")
        if ins_entries:
            tags.add("INS")

        pep_current = bool(pep_entries.get("current"))
        pep_former = bool(pep_entries.get("former"))
        if pep_current:
            tags.add("PEP-CURRENT")
            tags.add("PEP-LINKED")
        if pep_former:
            tags.add("PEP-FORMER")
            tags.add("PEP-LINKED")

        if poi_entries:
            tags.add("POI")
        if rel_entries or individual_links or business_links:
            tags.add("REL")
        if rre_entries:
            tags.add("RRE")

        if san_data.get("current"):
            tags.add("SAN-CURRENT")
        if san_data.get("former"):
            tags.add("SAN-FORMER")
        if gri_entries:
            tags.add("GRI")

        return [t for t in self.TAG_ORDER if t in tags]

    # ---------------------------------------------------------
    # Ingestion
    # ---------------------------------------------------------
    def load_data(self, file_path: str):
        assert self.conn is not None and self.cursor is not None

        logger.info(f"Phase 1: Ingesting JSONL: {file_path}")

        try:
            with open(file_path, "rb") as bf:
                head = bf.read(64).lstrip()
            if head.startswith(b"["):
                raise RuntimeError("INPUT appears to be a JSON array. JSONL is required.")
        except FileNotFoundError:
            raise

        buf_ent: List[Tuple] = []
        buf_risk: List[Tuple] = []
        buf_rel: List[Tuple] = []
        buf_pos: List[Tuple] = []
        buf_occ: List[Tuple] = []

        total_lines = 0
        total_entities = 0

        self.conn.execute("BEGIN")

        with open(file_path, "r", encoding="utf-8") as f:
            for line_num, line in enumerate(f, start=1):
                total_lines += 1
                line = line.strip()
                if not line:
                    continue

                try:
                    data = json.loads(line)
                except json.JSONDecodeError as e:
                    self._error(f"[JSON] line={line_num} err={e} head={line[:120]}")
                    continue

                schema = data.get("schema")
                eid = data.get("id")
                if not eid or not schema:
                    continue

                props = data.get("properties", {}) or {}
                ds = data.get("datasets", []) or []
                if ds:
                    self.seen_datasets.update([str(x) for x in ds if x])

                # ----------------------------
                # Core Entities:
                # ----------------------------
                if schema in  {"Person", "Company", "Organization", "LegalEntity"}:
                    # Full name
                    full_name = (props.get("name") or [data.get("caption", "")])[0] or ""
                    
                    # Gender
                    raw_gender = self._first(props, "gender")
                    gender = raw_gender.title() if raw_gender else None
                    
                    # Countries
                    countries = self._collect_countries(props)
                    default_country = countries[0] if countries else "XX"
                    
                    
                    #Address
                    raw_addrs = props.get("address", []) or []
                    parsed_addrs = [self._parse_address_smart(str(a), default_country) for a in raw_addrs if a]
                    parsed_addrs = self._dedupe_addresses(parsed_addrs)
                    parsed_addrs = self._prune_addresses(parsed_addrs)
                    
                    #Birth Date
                    birth_dates = [
                        str(x)
                        for x in (props.get("birthDate", []) or props.get("incorporationDate", []) or [])
                        if x
                    ]
                    death_dates = [str(x) for x in (props.get("deathDate", []) or []) if x]
                    
                    #Aliases + notes
                    aliases = json.dumps((props.get("alias", []) + props.get("weakAlias", [])), ensure_ascii=False)
                    notes = json.dumps(props.get("notes", []) or [], ensure_ascii=False)
                    
                    # Contact entries
                    contacts = []
                    for e in (props.get("email", []) or []):
                        contacts.append({"category": "Email", "value": str(e)})
                    for p in (props.get("phone", []) or []):
                        contacts.append({"category": "Phone", "value": str(p)})
                    contacts_json = json.dumps(contacts, ensure_ascii=False)

                    id_keys = [
                        "idNumber",
                        "passportNumber",
                        "taxNumber",
                        "registrationNumber",
                        "vatCode",
                        "npiCode",
                        "innCode",
                        "kppCode",
                        "ogrnCode",
                        "swiftBic",
                        "leiCode",
                        "dunsCode",
                    ]
                    ids_list = []
                    for k in id_keys:
                        for v in (props.get(k, []) or []):
                            if v:
                                ids_list.append({"category": k, "value": str(v)})

                    sw = " ".join([str(x) for x in (props.get("sourceWealth", []) or []) if x]).strip()

                    buf_ent.append(
                        (
                            str(eid),
                            str(schema),
                            str(full_name),
                            json.dumps(countries, ensure_ascii=False),
                            gender,
                            json.dumps(birth_dates, ensure_ascii=False),
                            json.dumps(death_dates, ensure_ascii=False),
                            1 if data.get("target") else 0,
                            aliases,
                            json.dumps(parsed_addrs, ensure_ascii=False),
                            json.dumps(ids_list, ensure_ascii=False),
                            notes,
                            contacts_json,
                            sw,
                            str(data.get("caption", "") or ""),
                            json.dumps([str(x) for x in ds if x], ensure_ascii=False),
                        )
                    )
                    total_entities += 1

                    # ----------------------------
                    # Derived Risk Events from topics
                    # ----------------------------
                    topics = [str(x) for x in (props.get("topics", []) or []) if x]
                    if topics:
                        topics_set = set(topics)
                        src_ds = str(ds[0]) if ds else "opensanctions"
                        derived_authority = "Derived"
                        derived_country = countries[0] if countries else None

                        for topic_code, r_schema in TOPIC_RISK_RULES:
                            if topic_code in topics_set:
                                ev_id = f"{eid}|topic|{r_schema}|{topic_code}"
                                buf_risk.append(
                                    (
                                        str(eid),                  # target_id
                                        str(ev_id),                # event_id
                                        str(r_schema),             # schema
                                        derived_authority,         # authority
                                        src_ds,                    # source_ds
                                        _topic_reason(topic_code), # reason
                                        None,                      # start_date
                                        None,                      # end_date
                                        1,                         # is_active
                                        None,                      # evidence_url
                                        derived_country,           # country
                                    )
                                )

                # ----------------------------
                # Positions / Occupancies
                # ----------------------------
                elif schema == "Position":
                    buf_pos.append(
                        (
                            str(eid),
                            str((props.get("name") or ["Unknown"])[0]),
                            self._norm_iso2(self._first(props, "country")),
                            self._first(props, "organization"),
                        )
                    )

                elif schema == "Occupancy":
                    holder, post = self._first(props, "holder"), self._first(props, "post")
                    if holder and post:
                        buf_occ.append(
                            (
                                str(eid),
                                str(holder),
                                str(post),
                                self._coerce_date(self._first(props, "startDate")),
                                self._coerce_date(self._first(props, "endDate"), True),
                                self._first(props, "status"),
                            )
                        )

                # ----------------------------
                # Risk Events (explicit risk entities)
                # ----------------------------
                elif schema in RISK_MAPPING:
                    targets = (
                        props.get("entity", [])
                        or props.get("holder", [])
                        or props.get("subject", [])
                        or props.get("object", [])
                        or []
                    )
                    targets = [str(t) for t in targets if t]

                    reason = str((props.get("reason") or [schema])[0])
                    auth = str((props.get("authority") or ["Unknown"])[0])
                    start = self._coerce_date(self._first(props, "startDate"))
                    end = self._coerce_date(self._first(props, "endDate"), True)

                    is_active = 1
                    if end and end < datetime.now().strftime("%Y-%m-%d"):
                        is_active = 0

                    url = self._first(props, "sourceUrl")
                    r_country = self._norm_iso2(self._first(props, "country"))

                    for t in targets:
                        buf_risk.append(
                            (
                                t,
                                str(eid),
                                str(schema),
                                auth,
                                (str(ds[0]) if ds else ""),
                                reason,
                                start,
                                end,
                                is_active,
                                url,
                                r_country,
                            )
                        )

                # ----------------------------
                # Relationships
                # ----------------------------
                elif schema in RELATIONSHIP_MAPPING:
                    m = RELATIONSHIP_MAPPING[schema]
                    s_list = [str(x) for x in (props.get(m["subject"], []) or []) if x]
                    t_list = [str(x) for x in (props.get(m["object"], []) or []) if x]
                    r_list = [str(x) for x in (props.get(m["role"], []) or []) if x]

                    start = self._coerce_date(self._first(props, "startDate")) or ""
                    end = self._coerce_date(self._first(props, "endDate"), True) or ""
                    roles = r_list if r_list else [schema]
                    
                    # source x target = (O(n*m))
                    if len(s_list) > settings.MAX_REL_ENDPOINTS_PER_SIDE:
                        self.truncated_rel_endpoints += (len(s_list) - settings.MAX_REL_ENDPOINTS_PER_SIDE)
                        s_list = s_list[:settings.MAX_REL_ENDPOINTS_PER_SIDE]
                    if len(t_list) > settings.MAX_REL_ENDPOINTS_PER_SIDE:
                        self.truncated_rel_endpoints += (len(t_list) - settings.MAX_REL_ENDPOINTS_PER_SIDE)
                        t_list = t_list[:settings.MAX_REL_ENDPOINTS_PER_SIDE]

                    if s_list and t_list:
                        for s in s_list:
                            for t in t_list:
                                if s == t:
                                    continue
                                for role in roles:
                                    buf_rel.append((str(eid), str(schema), s, t, role, start, end))

                if len(buf_ent) >= settings.FLUSH_SIZE:
                    self._flush(buf_ent, buf_risk, buf_rel, buf_pos, buf_occ)
                    logger.info(f"Ingest progress: entities={total_entities:,} lines={total_lines:,}")
                    buf_ent, buf_risk, buf_rel, buf_pos, buf_occ = [], [], [], [], []

        self._flush(buf_ent, buf_risk, buf_rel, buf_pos, buf_occ)
        self.conn.commit()

        logger.info(
            f"Ingestion complete: entities={total_entities:,} lines={total_lines:,} "
            f"errors={self.ingest_error_count} warnings={self.ingest_warning_count} "
            f"rel_endpoints_truncated={self.truncated_rel_endpoints}"
        )

    def _flush(self, e, r, rel, pos, occ):
        assert self.cursor is not None
        if e:
            self.cursor.executemany("INSERT OR REPLACE INTO entities VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", e)
        if r:
            self.cursor.executemany("INSERT OR REPLACE INTO risk_events VALUES (?,?,?,?,?,?,?,?,?,?,?)", r)
        if rel:
            self.cursor.executemany("INSERT OR REPLACE INTO relationships VALUES (?,?,?,?,?,?,?)", rel)
        if pos:
            self.cursor.executemany("INSERT OR REPLACE INTO positions VALUES (?,?,?,?)", pos)
        if occ:
            self.cursor.executemany("INSERT OR REPLACE INTO occupancies VALUES (?,?,?,?,?,?)", occ)

    # ---------------------------------------------------------
    # Export (JSONL, crash-safe)
    # ---------------------------------------------------------
    def export(self, output_prefix: str, is_target="1"):
        assert self.conn is not None and self.cursor is not None

        logger.info("Phase 2: Exporting Individuals Only (JSONL)...")

        out_jsonl = f"{output_prefix}.jsonl"
        count = 0

        self.cursor.execute(f"SELECT * FROM entities WHERE schema='Person' AND is_target={is_target}")

        with open(out_jsonl, "w", encoding="utf-8") as out:
            while True:
                rows = self.cursor.fetchmany(settings.BATCH_SIZE)
                if not rows:
                    break

                ids = [row[0] for row in rows]
                id_map = {row[0]: row for row in rows}
                ph = ",".join("?" for _ in ids)  # placeholders

                # Risks
                risk_map = defaultdict(list)
                c = self.conn.cursor()
                c.execute(
                    f"""
                    SELECT target_id, event_id, schema, authority, source_ds, reason,
                           start_date, end_date, is_active, evidence_url, country
                    FROM risk_events
                    WHERE target_id IN ({ph})
                    """,
                    ids,
                )
                for row in c:
                    risk_map[row[0]].append(row)

                # POI
                poi_map = defaultdict(list)
                c.execute(
                    f"""
                    SELECT o.holder_id, p.name, p.country, o.start_date, o.end_date, p.organization
                    FROM occupancies o
                    JOIN positions p ON o.post_id = p.id
                    WHERE o.holder_id IN ({ph})
                    """,
                    ids,
                )
                for row in c:
                    poi_map[row[0]].append(row) # holder_id is row[0]]

                # Relationships
                rel_map = defaultdict(list)
                # Common Table Expressions
                
                ## CTE1 --> rels(relationships)
                ### SELECT when person is source
                #### source -> target.    for that I put 1 AS direction
                
                ### SELECT when person is Target
                #### target <- source.         for that I put 2 AS direction
                ## CTE2 --> ranked 
                query = f"""
                    WITH rels AS (
                        SELECT r.source_id AS my_id, r.target_id AS other_id, r.schema, r.role, r.start_date,
                               e.full_name, e.schema AS oschema, 1 AS dir
                        FROM relationships r
                        JOIN entities e ON e.id = r.target_id
                        WHERE r.source_id IN ({ph})
                        UNION ALL
                        SELECT r.target_id AS my_id, r.source_id AS other_id, r.schema, r.role, r.start_date,
                               e.full_name, e.schema AS oschema, 2 AS dir
                        FROM relationships r
                        JOIN entities e ON e.id = r.source_id
                        WHERE r.target_id IN ({ph})
                    ),
                    ranked AS (
                        SELECT *,
                               ROW_NUMBER() OVER (
                                   PARTITION BY my_id
                                   ORDER BY CASE WHEN start_date IS NULL THEN 0 ELSE 1 END DESC,
                                            start_date DESC,
                                            other_id ASC
                               ) AS rn
                        FROM rels
                    )
                    SELECT my_id, other_id, schema, role, start_date, full_name, oschema
                    FROM ranked
                    WHERE rn <= ?
                """
                c.execute(query, ids + ids + [settings.MAX_RELS_PER_ENTITY])
                for row in c:
                    rel_map[row[0]].append(row)

                # Build Records
                for eid in ids:
                    row = id_map[eid]
                    (
                        eid,
                        schema,
                        full_name,
                        countries_json,
                        gender,
                        birth_dates_json,
                        death_dates_json,
                        _,
                        aliases_json,
                        addresses_json,
                        identifiers_json,
                        notes_json,
                        contacts_json,
                        sw,
                        caption,
                        ds_json,
                    ) = row

                    res_id = self._generate_resource_id(eid)
                    name_parts = self._parse_name(full_name or "")

                    countries = json.loads(countries_json) if countries_json else []
                    birth_dates = json.loads(birth_dates_json) if birth_dates_json else []
                    dates_of_birth: List[Dict[str, str]] = []
                    if birth_dates:
                        for date in birth_dates:
                            date_of_birth = self.parse_date_of_birth(date)
                            if date_of_birth.get("year"):
                                dates_of_birth.append(date_of_birth)
                    
                    death_dates = json.loads(death_dates_json) if death_dates_json else []
                    nat_iso = countries[0] if countries else "XX"

                    raw_aliases = json.loads(aliases_json) if aliases_json else []
                    name_aliases = [{"fullName": a} for a in raw_aliases if a]
                    aliases_struct = []
                    for a in raw_aliases:
                        ap = self._parse_name(str(a))
                        if ap["first"] or ap["last"]:
                            aliases_struct.append(
                                {
                                    "firstName": ap["first"],
                                    "middleName": ap["middle"],
                                    "lastName": ap["last"],
                                    "type": "Original Script Name",
                                }
                            )

                    addrs = json.loads(addresses_json) if addresses_json else []
                    raw_notes = json.loads(notes_json) if notes_json else []
                    formatted_notes = [{"value": n} for n in raw_notes if n]
                    contact_entries = json.loads(contacts_json) if contacts_json else []
                    identifiers = json.loads(identifiers_json) if identifiers_json else []

                    # derive a better segment from POI (if available) 
                    poi_rows_for_person = poi_map.get(eid, [])
                    primary_segment = self._choose_primary_segment_from_poi(poi_rows_for_person) or "Public Office"

                    san_data = {"current": [], "former": []}
                    pep_entries = {"current": [], "former": []}
                    rel_entries, rre_entries, ins_entries, dd_entries, gri_entries, poi_entries = [], [], [], [], [], []

                    evidences: List[Dict[str, Any]] = []
                    evidence_ids_by_key: Dict[EvidenceKey, str] = {}

                    for r in risk_map.get(eid, []):
                        (_, ev_id, r_schema, auth, src_ds, reason, start, end, active, url, r_cntry) = r
                        tag = self._risk_tag(str(r_schema), int(active))
                        ev_ids: List[str] = []

                        if url:
                            ek = EvidenceKey(url=str(url), tag=tag)
                            if ek not in evidence_ids_by_key:
                                evidence_id = self._short_id(f"{url}|{tag}", settings.EVIDENCE_ID_LEN)
                                evid = {
                                    "datasets": [tag],
                                    "evidenceId": evidence_id,
                                    "originalUrl": str(url),
                                    "isCopyrighted": False,
                                    "title": f"Report for {reason}",
                                    "summary": f"Listed by {auth}",
                                }
                                evidence_ids_by_key[ek] = evidence_id
                                evidences.append(evid)
                            ev_ids = [evidence_ids_by_key[ek]]

                        event_obj = {"type": "Listed", "dateIso": start, "evidenceIds": ev_ids}

                        if r_schema == "Sanction":
                            bucket = "current" if int(active) == 1 else "former"
                            san_data[bucket].append(
                                {
                                    "sanctionId": self._stable_qrcode(str(ev_id), 6),
                                    "measures": [reason],
                                    "regime": {"body": auth, "name": reason, "origin": src_ds, "types": ["Sanctions"]},
                                    "events": [event_obj],
                                }
                            )

                        elif r_schema == "PEP":
                            bucket = "current" if int(active) == 1 else "former"

                            # Better PEP segment logic:
                            # - role.rca -> Close Associate (not Public Office)
                            # - otherwise use POI-derived segment if possible
                            reason_s = str(reason or "")
                            if reason_s.strip().lower() in {"role rca", "role.rca"}:
                                pep_segment = "Close Associate"
                                pep_position = "RCA"
                            else:
                                pep_segment = primary_segment
                                pep_position = reason_s

                            pep_entries[bucket].append(
                                {
                                    "countryIsoCode": r_cntry or nat_iso,
                                    "segment": pep_segment,
                                    "position": pep_position,
                                    "dateFromIso": start,
                                    "dateToIso": end,
                                    "evidenceIds": ev_ids,
                                }
                            )

                        elif r_schema == "Warrant":
                            rel_entries.append(
                                {"category": "Law Enforcement", "subcategory": reason, "events": [event_obj]}
                            )

                        elif r_schema == "Criminal":
                            cat = "Crime"
                            if isinstance(reason, str):
                                if "Cyber" in reason:
                                    cat = "Cybercrime"
                                elif "Fraud" in reason or "Fin" in reason or "Financial" in reason:
                                    cat = "Financial Crime"
                                elif "Terror" in reason:
                                    cat = "Terrorism"
                                elif "War" in reason:
                                    cat = "War Crimes"
                                elif "Traffick" in reason:
                                    cat = "Trafficking"
                                elif "Env" in reason or "Environmental" in reason:
                                    cat = "Environmental Crime"
                                elif "Theft" in reason:
                                    cat = "Theft"
                            rre_entries.append({"category": cat, "subcategory": reason, "events": [event_obj]})

                        elif r_schema == "Disqualification":
                            dd_entries.append(
                                {
                                    "reason": reason,
                                    "conduct": auth,
                                    "dateFromIso": start,
                                    "dateToIso": end,
                                    "evidenceIds": ev_ids,
                                }
                            )

                        elif r_schema == "Debarment":
                            ins_entries.append(
                                {
                                    "type": "Insolvency",
                                    "petitioner": auth,
                                    "insolvencyStartDateIso": start,
                                    "evidenceIds": ev_ids,
                                }
                            )
                    def _dedupe_san(items):
                        seen = set()
                        out_items = []
                        for it in items:
                            key = (it["regime"]["origin"], it["regime"]["name"], (it["events"][0]["dateIso"] or ""))
                            if key in seen:
                                continue
                            seen.add(key)
                            out_items.append(it)
                        return out_items

                    san_data["current"] = _dedupe_san(san_data["current"])
                    san_data["former"] = _dedupe_san(san_data["former"])

                    # Links
                    ind_links, bus_links = [], []
                    seen_links = set()

                    for link in rel_map.get(eid, []):
                        oid = link[1]
                        rschema = link[2]
                        role = link[3]
                        oname = link[5]
                        oschema = link[6]

                        if oid == eid:
                            continue

                        role_s = str(role)
                        display_role = role_s
                        if "UnknownLink" in str(rschema) or "Unknown" in role_s:
                            display_role = "Associated with"

                        key = (str(oid), role_s)
                        if key in seen_links:
                            continue
                        seen_links.add(key)

                        ores = self._generate_resource_id(str(oid))
                        uri_prefix = "/individuals/" if str(oschema) == "Person" else "/business/"
                        l_obj = {
                            "qrCode": self._stable_qrcode(str(oid)),
                            "relationship": f"{full_name} is {display_role} of {oname}",
                            "resourceUri": f"{uri_prefix}{ores}",
                            "resourceId": ores,
                        }

                        if str(oschema) == "Person":
                            op = self._parse_name(str(oname))
                            l_obj.update({"firstName": op["first"], "middleName": op["middle"], "lastName": op["last"]})
                            ind_links.append(l_obj)
                        else:
                            l_obj["name"] = str(oname)
                            bus_links.append(l_obj)

                    positions = []
                    for p in poi_map.get(eid, []):
                        positions.append(
                            {
                                "position": p[1],
                                "segment": self._derive_segment(p[1], p[5]),
                                "countryIsoCode": p[2] or "XX",
                                "dateFromIso": p[3],
                                "dateToIso": p[4],
                            }
                        )
                    if positions:
                        poi_entries.append({"category": "Government", "positions": positions})

                    # GRI
                    if sw:
                        gri_entries.append(
                            {
                                "evidenceId": self._short_id(str(sw), settings.EVIDENCE_ID_LEN),
                                "title": "Source of Wealth",
                                "summary": str(sw),
                                "keywords": "Source of Wealth",
                            }
                        )

                    schema_tags = self._derive_schema_tags(
                        san_data=san_data,
                        pep_entries=pep_entries,
                        rel_entries=rel_entries,
                        rre_entries=rre_entries,
                        poi_entries=poi_entries,
                        ins_entries=ins_entries,
                        dd_entries=dd_entries,
                        gri_entries=gri_entries,
                        individual_links=ind_links,
                        business_links=bus_links,
                    )

                    for l in ind_links:
                        l["datasets"] = schema_tags
                    for l in bus_links:
                        l["datasets"] = schema_tags
                        l["individualLinks"] = ind_links

                    record_dataset_names = self._map_datasets_readable(json.loads(ds_json) if ds_json else [])

                    data_obj = {
                        "qrCode": self._stable_qrcode(str(eid)),
                        "resourceUri": f"/individuals/{res_id}",
                        "resourceId": res_id,
                        "firstName": name_parts["first"],
                        "fullName": full_name,
                        "middleName": name_parts["middle"],
                        "lastName": name_parts["last"],
                        "gender": gender or "Unknown",
                        "provider": "AmaniAI",
                        "nationality": countries,
                        "datesOfBirthParsed": dates_of_birth,
                        "provider_version": int(time.time() * 1000),
                        "isDeleted": False,
                        "nameAliases": name_aliases,
                        "isDeceased": bool(death_dates),
                        "aliases": aliases_struct,
                        "datesOfBirthIso": birth_dates,
                        "datesOfDeathIso": death_dates,
                        "nationalitiesIsoCodes": countries,
                        "addresses": addrs,   
                        "profileImages": [],
                        "notes": formatted_notes,
                        "contactEntries": contact_entries,
                        "identifiers": identifiers,
                        "evidences": evidences, 
                        "sanEntries": san_data,
                        "relEntries": rel_entries,
                        "rreEntries": rre_entries,                             
                        "poiEntries": poi_entries,
                        "insEntries": ins_entries,
                        "ddEntries": dd_entries,     
                        "pepEntries": pep_entries,      
                        "pepByAssociationEntries": [],         
                        "individualLinks": ind_links,
                        "businessLinks": bus_links,               
                        "griEntries": gri_entries,                       
                                           
                    }

                    out.write(json.dumps({"data": data_obj , "datasets": record_dataset_names}, ensure_ascii=False) + "\n")
                    count += 1
                    if count % 10000 == 0:
                        logger.info(f"Exported {count:,} individuals...")


        logger.info(f"Done. Exported={count:,} JSONL={out_jsonl} ")


# =============================================================================
# Downloader (metadata-based)
# =============================================================================

# Downloader / Updater Logic
# ---------------------------------------------------------
import os
import json
import requests
import logging
from typing import Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------
class OpenSanctionsDownloader:
    """
    Handles checking for updates via metadata and downloading the latest dataset.

    This version is fully data_dir-driven (no global LOCAL_* paths).
    """

    DATA_FILENAME = "entities.ftm.json"
    METADATA_FILENAME = "index.json"

    def __init__(self, data_dir: str, metadata_url: str):
        self.data_dir = data_dir
        self.metadata_url = metadata_url

        os.makedirs(self.data_dir, exist_ok=True)

        # ✅ Local paths are now derived ONLY from data_dir
        self.local_data_file = os.path.join(self.data_dir, self.DATA_FILENAME)
        self.local_metadata_file = os.path.join(self.data_dir, self.METADATA_FILENAME)

    def check_and_download(self) -> Optional[str]:
        """
        Checks if a new version is available.

        Returns:
            str: Path to the data file if updated or re-downloaded.
            None: If local data is up-to-date and exists.
        """
        logger.info("Checking for updates from OpenSanctions...")

        # 1) Fetch remote metadata
        try:
            response = requests.get(self.metadata_url, timeout=30)
            response.raise_for_status()
            remote_metadata = response.json()
        except Exception as e:
            logger.error(f"Failed to fetch metadata: {e}")

            # ✅ Fallback: if we already have a local file, keep using it
            if os.path.exists(self.local_data_file):
                logger.warning("Network error checking metadata. Using existing local file (Risk of stale data).")
                return self.local_data_file
            raise

        remote_last_export = remote_metadata.get("last_export")

        # Find entities.ftm.json URL in resources
        file_url = None
        for resource in remote_metadata.get("resources", []):
            if resource.get("name") == self.DATA_FILENAME:
                file_url = resource.get("url")
                break

        if not file_url:
            raise ValueError(f"Could not find '{self.DATA_FILENAME}' url in remote metadata.")

        # 2) Check local metadata
        should_update = False

        if not os.path.exists(self.local_metadata_file):
            logger.info("No local metadata found. Initial download required.")
            should_update = True
        else:
            try:
                with open(self.local_metadata_file, "r", encoding="utf-8") as f:
                    local_metadata = json.load(f)

                stored_last_export = local_metadata.get("last_export")

                if stored_last_export != remote_last_export:
                    logger.info(f"New version found. Local: {stored_last_export}, Remote: {remote_last_export}")
                    should_update = True
                else:
                    logger.info(f"Local data is up-to-date (Version: {stored_last_export}).")

                    # Edge case: metadata matches but file missing
                    if not os.path.exists(self.local_data_file):
                        logger.warning("Data file missing despite metadata match. Re-downloading.")
                        should_update = True

            except json.JSONDecodeError:
                logger.warning("Corrupt local metadata. Re-downloading.")
                should_update = True
            except Exception as e:
                logger.warning(f"Failed reading local metadata. Re-downloading. Err={e}")
                should_update = True

        # 3) Download OR Skip
        if should_update:
            self._download_file(file_url, self.local_data_file)

            # Save new metadata (same json returned from server)
            with open(self.local_metadata_file, "w", encoding="utf-8") as f:
                json.dump(remote_metadata, f, indent=2)

            logger.info(f"Update complete. Version: {remote_last_export}")
            return self.local_data_file

        # Up-to-date
        return None
    def _download_file(self, url: str, local_path: str):
        logger.info(f"Downloading data from {url}...")

        # Ensure folder exists before writing
        os.makedirs(os.path.dirname(local_path) or ".", exist_ok=True)

        # Replace existing file
        if os.path.exists(local_path):
            os.remove(local_path)

        with requests.get(url, stream=True, timeout=60) as r:
            r.raise_for_status()

            total = r.headers.get("Content-Length")
            total_size = int(total) if total and total.isdigit() else None

            # Use temp file to avoid partial/corrupt outputs on interruption
            tmp_path = local_path + ".part"

            try:
                with open(tmp_path, "wb") as f:
                    if total_size:
                        with tqdm(
                            total=total_size,
                            unit="B",
                            unit_scale=True,
                            unit_divisor=1024,
                            desc="Downloading",
                            miniters=1,
                            leave=True,
                        ) as pbar:
                            for chunk in r.iter_content(chunk_size=1024 * 1024):  # 1MB chunks
                                if not chunk:
                                    continue
                                f.write(chunk)
                                pbar.update(len(chunk))
                    else:
                        # Fallback: unknown size
                        with tqdm(
                            total=0,
                            unit="B",
                            unit_scale=True,
                            unit_divisor=1024,
                            desc="Downloading",
                            miniters=1,
                            leave=True,
                        ) as pbar:
                            for chunk in r.iter_content(chunk_size=1024 * 1024):
                                if not chunk:
                                    continue
                                f.write(chunk)
                                pbar.update(len(chunk))

                # Atomic-ish rename after successful download
                os.replace(tmp_path, local_path)

            finally:
                # Cleanup partial file if something failed
                if os.path.exists(tmp_path) and not os.path.exists(local_path):
                    try:
                        os.remove(tmp_path)
                    except Exception:
                        pass

        logger.info(f"Download finished: {local_path}")


