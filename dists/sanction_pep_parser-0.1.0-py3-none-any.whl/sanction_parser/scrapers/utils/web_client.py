"""
src/sanction_parser/scrapers/utils/web_client.py

A robust utility module for web scraping tasks including:
- HTTP Requests with retry logic and session management.
- File extension guessing based on MIME types and URL patterns.
- Hybrid link extraction using static requests and dynamic browser rendering (Playwright).
"""

import os
import time
import logging
import requests
import urllib3
from typing import List, Dict, Optional, Union
from urllib.parse import urlparse, parse_qs
from lxml import html

# Disable SSL warnings for legacy sites
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Initialize module logger
logger = logging.getLogger(__name__)

# Check Playwright availability for dynamic scraping
try:
    from playwright.sync_api import sync_playwright
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False
    logger.warning("Playwright is not installed. Dynamic scraping features will be disabled.")

# Standard User-Agent to mimic a real browser
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/120.0.0.0 Safari/537.36"
)

DEFAULT_TIMEOUT = 45
MAX_RETRIES = 3

# ---------------------------------------------------------------------------
# HTTP Session & Request Helpers
# ---------------------------------------------------------------------------

def get_session() -> requests.Session:
    """
    Creates and configures a new requests.Session instance.
    """
    session = requests.Session()
    session.headers.update({
        "User-Agent": USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Connection": "keep-alive",
        "Referer": "https://www.google.com/",
    })
    return session

def get_request(
    url: str,
    timeout: int = DEFAULT_TIMEOUT,
    raise_for_status: bool = True,
    session: Optional[requests.Session] = None,
    **kwargs,
) -> requests.Response:
    """
    Performs a robust HTTP GET request with exponential backoff retry logic.

    Args:
        url: Target URL.
        timeout: Request timeout in seconds.
        raise_for_status: If True, raises HTTPError for bad status codes.
        session: Optional existing session to use.
        **kwargs: Additional arguments passed to requests.get().

    Returns:
        requests.Response object.
    """
    if session is None:
        session = get_session()

    # Force verify=False unless specified otherwise
    kwargs.setdefault("verify", False)

    last_error: Optional[Exception] = None

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            response = session.get(url, timeout=timeout, **kwargs)
            if raise_for_status:
                response.raise_for_status()
            return response
        except Exception as e:
            last_error = e
            logger.debug(f"Attempt {attempt}/{MAX_RETRIES} failed for {url}: {e}")
            time.sleep(1.5 * attempt)  # Exponential backoff

    logger.error(f"Failed to fetch {url} after {MAX_RETRIES} attempts.")
    if last_error:
        raise last_error
    raise requests.exceptions.RequestException(f"Unknown error fetching {url}")

# ---------------------------------------------------------------------------
# File Extension Detection Logic
# ---------------------------------------------------------------------------

COMMON_FILE_EXTS: List[str] = [
    "pdf", "csv", "xls", "xlsx",
    "xml", "json", "zip", "tar", "gz",
    "doc", "docx", "txt", "ods"
]

def normalize_extensions(exts: Optional[List[str]]) -> List[str]:
    """Ensures extensions are lowercase and without dots."""
    if not exts:
        return COMMON_FILE_EXTS
    return [e.lower().lstrip(".") for e in exts]

def guess_ext_from_content_type(content_type: str, allowed_exts: List[str]) -> Optional[str]:
    """
    Maps MIME types (Content-Type header) to file extensions.
    """
    ct = (content_type or "").lower()

    mime_mapping = {
        "csv": ["text/csv", "application/csv"],
        "xls": ["application/vnd.ms-excel"],
        "xlsx": ["application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "spreadsheetml.sheet"],
        "pdf": ["application/pdf"],
        "json": ["application/json"],
        "xml": ["application/xml", "text/xml"],
        "zip": ["application/zip", "application/x-zip-compressed", "zip", "octet-stream"],
        "ods": ["application/vnd.oasis.opendocument.spreadsheet"],
    }

    for ext_key, mime_list in mime_mapping.items():
        if ext_key in allowed_exts:
            for mime in mime_list:
                if mime in ct:
                    return ext_key
    return None

def guess_file_extension(href: str, link_text: str, allowed_exts: List[str]) -> Optional[str]:
    """
    Heuristic detection of file extensions from URLs and Link Text.
    Priority:
    0. Special XML edge cases.
    1. URL Path extension.
    2. URL Query Parameters (filename=...).
    3. REST endpoints ending in extension.
    4. Text content inference.
    """
    href_lower = href.lower()
    text_lower = (link_text or "").lower()

    # 0) Special handling for XML links
    if "xml" in allowed_exts:
        if href_lower.endswith("/xml") or "xml format" in text_lower or "download in xml" in text_lower:
            return "xml"

    parsed = urlparse(href)
    path = parsed.path or ""
    query_params = parse_qs(parsed.query)

    # 1) Detect extension directly from the path
    for ext in allowed_exts:
        if path.lower().endswith(f".{ext}"):
            return ext

    # 2) Detect extension from query filename parameters
    for key in ("filename", "file", "download", "name"):
        if key in query_params:
            for fname in query_params[key]:
                _, ext = os.path.splitext(fname)
                if ext:
                    clean_ext = ext.lstrip(".").lower()
                    if clean_ext in allowed_exts:
                        return clean_ext

    # 3) Detect REST-style endpoints
    for ext in allowed_exts:
        if href_lower.endswith(f"/{ext}"):
            return ext
        if f"format={ext}" in href_lower or f"={ext}" in href_lower:
            return ext

    # 4) Text-based inference
    if "excel" in text_lower:
        if "xlsx" in allowed_exts: return "xlsx"
        if "xls" in allowed_exts: return "xls"

    if ("spreadsheet" in text_lower or "open standard" in text_lower) and "ods" in allowed_exts:
        return "ods"

    # 5) Generic fallback: extension appears in link text
    for ext in allowed_exts:
        if ext in text_lower:
            return ext

    return None

# ---------------------------------------------------------------------------
# Link Extraction Logic (Hybrid Strategy)
# ---------------------------------------------------------------------------

def _parse_links_from_html(html_text: str, page_url: str, exts: List[str]) -> List[Dict[str, str]]:
    """Parses static HTML content to find file links."""
    links: List[Dict[str, str]] = []
    if not html_text:
        return links

    try:
        doc = html.fromstring(html_text)
        doc.make_links_absolute(page_url)
        seen: set[str] = set()
        
        for el in doc.xpath("//a[@href]"):
            href = el.get("href")
            if not href or href.startswith(("mailto:", "javascript:", "#", "tel:")):
                continue
            
            text = " ".join((el.text_content() or "").split())
            ext = guess_file_extension(href, text, allowed_exts=exts)
            
            if ext:
                if href not in seen:
                    seen.add(href)
                    links.append({"url": href, "ext": ext, "text": text})
    except Exception as e:
        logger.debug(f"Error parsing HTML: {e}")

    return links

def _get_links_with_browser(page_url: str, exts: List[str], deep_scan: bool = False) -> List[Dict[str, str]]:
    """
    Uses Playwright to handle dynamic content.
    If deep_scan=True, it attempts to click buttons and sniff network traffic.
    """
    if not PLAYWRIGHT_AVAILABLE:
        return []

    mode_label = "DEEP SCAN" if deep_scan else "DYNAMIC RENDER"
    logger.info(f"[{mode_label}] Starting Playwright for: {page_url}")
    
    found_links: List[Dict[str, str]] = []
    seen_urls: set[str] = set()

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            context = browser.new_context(user_agent=USER_AGENT, ignore_https_errors=True)
            page = context.new_page()

            # Network Sniffing Handler (Used primarily in Deep Scan)
            if deep_scan:
                def handle_response(resp):
                    try:
                        url = resp.url
                        if url in seen_urls: return

                        ct = (resp.headers.get("content-type") or "").lower()
                        # Try sniffing via Content-Type or URL
                        ext = guess_ext_from_content_type(ct, exts) or guess_file_extension(url, "", exts)
                        
                        if ext:
                            seen_urls.add(url)
                            found_links.append({
                                "url": url,
                                "ext": ext,
                                "text": f"NETWORK: {resp.status} {ct}",
                            })
                            logger.info(f"Captured network file: {ext.upper()} -> {url}")
                    except Exception:
                        pass

                page.on("response", handle_response)

            # Navigate
            try:
                page.goto(page_url, timeout=60000, wait_until="domcontentloaded")
                # Scroll to trigger lazy loading
                page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
                time.sleep(3)
            except Exception as nav_err:
                logger.warning(f"Playwright navigation warning: {nav_err}")

            if not deep_scan:
                # Standard Dynamic: Just parse the rendered HTML
                content = page.content()
                found_links = _parse_links_from_html(content, page_url, exts)
            
            else:
                # Deep Scan: Try clicking "export" like buttons
                keywords = ["export", "download", "excel", "spreadsheet", "csv", "تصدير", "تحميل"]
                try:
                    candidates = page.locator("a, button")
                    for el in candidates.all():
                        try:
                            txt = el.inner_text().strip().lower()
                            if any(k in txt for k in keywords):
                                logger.info(f"Clicking candidate: '{txt[:30]}...'")
                                el.click(timeout=3000)
                                time.sleep(3) # Wait for network response
                        except Exception:
                            continue
                except Exception as e:
                    logger.debug(f"Element scanning error: {e}")
                
                time.sleep(2) # Grace period

            browser.close()
    except Exception as e:
        logger.error(f"Playwright crashed for {page_url}: {e}")

    return found_links

def extract_download_links(page_url: str, exts: Optional[List[str]] = None) -> List[Dict[str, str]]:
    """
    Main entry point. Orchestrates the extraction strategy:
    1. Static HTTP Request (Fastest).
    2. Dynamic HTML via Playwright (If static fails).
    3. Deep Network Sniffing via Playwright (If both fail).
    """
    exts_list = normalize_extensions(exts)
    links: List[Dict[str, str]] = []
    
    # Strategy 1: Static HTTP
    try:
        resp = get_request(page_url, raise_for_status=False)
        
        if resp.status_code >= 400:
            logger.warning(f"HTTP {resp.status_code} for {page_url}. Proceeding to browser fallback.")
        else:
            ct = resp.headers.get("Content-Type", "")
            
            # Check if the URL itself is a file
            if "html" not in ct.lower():
                direct_ext = guess_ext_from_content_type(ct, exts_list) or guess_file_extension(page_url, "", exts_list)
                if direct_ext:
                    return [{"url": page_url, "ext": direct_ext, "text": "Direct Link"}]
            
            # Parse HTML
            links = _parse_links_from_html(resp.text, page_url, exts_list)

    except Exception as e:
        logger.warning(f"Static request failed for {page_url}: {e}")

    # Strategy 2: Dynamic HTML (Browser)
    if not links and PLAYWRIGHT_AVAILABLE:
        logger.info(f"Switching to Dynamic Browser for: {page_url}")
        links = _get_links_with_browser(page_url, exts_list, deep_scan=False)

    # Strategy 3: Deep Network Scan (The "Nuclear Option")
    if not links and PLAYWRIGHT_AVAILABLE:
        logger.info(f"Engaging Deep Network Scan for: {page_url}")
        links = _get_links_with_browser(page_url, exts_list, deep_scan=True)

    return links